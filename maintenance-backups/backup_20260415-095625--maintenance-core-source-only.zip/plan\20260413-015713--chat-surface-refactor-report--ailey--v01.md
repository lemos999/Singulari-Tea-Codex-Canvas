---
title: Chat Surface Refactor Report
slug: chat-surface-refactor-report
created: 2026-04-13 01:57:13 +09:00
last_updated: 2026-04-13 02:01:29 +09:00
status: deployed-awaiting-user-validation
owner: Codex
requested_by: User
version: v01
related_plan: 20260413-013404--chat-surface-refactor-plan--ailey--v01.md
---

# Chat Surface Refactor Report

## Summary

The legacy chat surface was refactored into a cleaner composer-driven flow with true multi-attachment handling, cleaned session/sidebar/settings copy, and improved provider payload compatibility. The goal was to move the chat experience closer to a coherent ChatGPT-style interaction model without breaking existing session/project behavior.

## Delivered

- Restored the `이전 대화 참조` control to a chain-style icon.
- Rebuilt the chat shell and composer surface for cleaner structure and copy.
- Upgraded the composer from single-file handling to staged multi-attachment support.
- Added support for:
  - multiple files from picker
  - clipboard paste of files/images
  - drag-and-drop into the composer
  - sending image, PDF, and text/code files together
- Upgraded user-message rendering to show multi-image previews and non-image attachment chips.
- Updated payload generation to better support:
  - Gemini inline data
  - OpenAI-compatible image_url payloads
  - Anthropic image payload blocks
- Cleaned project/session/sidebar/settings strings that were visually rough or outdated.

## Design Intent

- Keep the composer as the single visible intake point.
- Make staged attachments explicit and reversible before send.
- Preserve old runtime assumptions where needed through compatibility aliases like `attachedFile`.
- Improve behavior without forcing a wider chat architecture rewrite in this same slice.

## Compatibility Notes

- Legacy single-attachment call sites remain protected through compatibility mapping.
- Text attachments are included in downstream payloads as readable text content where appropriate.
- PDFs are preserved for Gemini inline flows and downgraded safely for providers that do not support native PDF multimodal input in this path.

## Verification

- Syntax-checked modified JS files with `node --check`
- Rebuilt bundle successfully with `node Ailey/bundler.js`
- Deployed hosted bundle to `Singulari-Tea-Codex-Canvas` `main`
- Hosted deployment commit: `036f4ed9b5b9cfe701c7cbe6cb2d9415117f6a60`

## Remaining Risks

- Browser runtime validation is still needed for:
  - multiple pasted images
  - mixed file batches
  - attachment-only sends
  - session switching with staged attachments
  - provider-specific behavior in live presets
- Separate legacy `refined` / non-chat image-generation cleanup remains outside this report scope.

## Recommended User Validation

- Paste two images and one text file into the composer.
- Drag multiple files onto the composer.
- Send an attachment-only message.
- Switch sessions while attachments are staged.
- Open a project session and confirm the context toggle, settings surface, and session list still feel coherent.
