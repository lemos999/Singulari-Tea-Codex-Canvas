# Panorama Fullscreen And Gemini Local Chat Fix Report

Date: 2026-04-14

## Scope

- Fix missing fullscreen return/hover controls in `[태양계의 파노라마.html]`.
- Fix `google_paid / gemini-2.5-flash` local chat no-response behavior.

## Findings

1. Fullscreen control loss was a runtime-hosting bug.
   - The visualization wrapper is moved into a body-level `.viz-cinema-host` during cinema/fullscreen mode.
   - Existing control CSS was still scoped under `.type-visualization ...`, so once the wrapper left that subtree the control group lost its layout sizing rules.
   - Result: controls existed in DOM with `opacity: 1`, but their rects collapsed to `0x0` off-screen.

2. Gemini local chat no-response was a transport bug.
   - `google_paid` chat calls used `@google/genai` via dynamic import from `https://esm.run/@google/genai`.
   - In the exported/runtime-embedded browser environment this SDK path stalled and did not resolve reliably.
   - Direct REST calls to `generativelanguage.googleapis.com` succeeded quickly with the same key/model.

## Changes

- `Ailey/src_css/029_viz_cinema_host.css`
  - Added cinema-host-native styles for `.viz-controls-group`, `.viz-control-btn`, and button SVG sizing/fill.
  - Ensured fullscreen controls keep fixed positioning, real dimensions, and visible icon color after host relocation.

- `Ailey/src/04_features_chat/213_chat_api_service.js`
  - Replaced hanging Gemini SDK text path with direct REST `generateContent` requests.
  - Kept the streaming contract by returning a single-chunk async generator for `google_paid`.
  - Added explicit timeout handling and retry behavior for retryable Google failures (`429`, `500`, `503`).

## Validation

- Validation script:
  - `visual-tests/panorama-fullscreen-google-paid-repro/validate_panorama_fullscreen_google_paid.mjs`

- Validation output:
  - `visual-tests/panorama-fullscreen-google-paid-repro/validation.json`

- Key acceptance points:
  - Fullscreen enter:
    - control group rect present
    - expand button rect present
    - SVG rect present
    - icon color/fill visible
  - Gemini:
    - direct stream path returns text
    - direct non-stream path returns text
    - temporary chat path returns text
    - UI send path renders an AI message

## Result

- Fullscreen hover/return controls are visible again in panorama fullscreen mode.
- Local Gemini preset chat no longer hangs on the SDK path and returns responses through the runtime chat flow.
- The verified bundle was published to `lemos999/Singulari-Tea-Codex-Canvas` on `main` as commit `193c1e2`.
