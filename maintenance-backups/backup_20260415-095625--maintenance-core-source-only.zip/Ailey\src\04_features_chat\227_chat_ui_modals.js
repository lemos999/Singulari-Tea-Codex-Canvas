/* --- Ailey & Bailey Canvas --- */
// File: 227_chat_ui_modals.js
// Version: 6.0 (Clean Settings Surface)
// Description: Renders the chat header settings surface, quick prompt control, and project/session context menus.

function renderApiPresetSelector() {
    if (!apiPresetSelector) return;

    const presets = userApiSettings.apiPresets || [];
    const activeId = userApiSettings.activePresetId;
    apiPresetSelector.innerHTML = '';

    const universalOption = document.createElement('option');
    universalOption.value = 'universal';
    universalOption.textContent = '범용 모델 (기본)';
    if (activeId === null) {
        universalOption.selected = true;
    }
    apiPresetSelector.appendChild(universalOption);

    presets.forEach(preset => {
        const option = document.createElement('option');
        option.value = preset.id;
        option.textContent = preset.name;
        option.selected = activeId === preset.id;
        apiPresetSelector.appendChild(option);
    });
}

function renderQuickPromptSelect() {
    if (!quickPromptSelect) return;

    const sortedTemplates = [...promptTemplatesCache].sort((a, b) => {
        if (a.isDefault && !b.isDefault) return -1;
        if (!a.isDefault && b.isDefault) return 1;
        return (a.name || '').localeCompare(b.name || '', 'ko');
    });

    quickPromptSelect.innerHTML = '';
    let defaultTemplateId = null;

    sortedTemplates.forEach(template => {
        if (template.isDefault) {
            defaultTemplateId = template.id;
        }
        const option = document.createElement('option');
        option.value = template.id;
        option.textContent = template.name;
        quickPromptSelect.appendChild(option);
    });

    let shouldSave = false;
    if (activePromptId && sortedTemplates.some(template => template.id === activePromptId)) {
        quickPromptSelect.value = activePromptId;
    } else if (!activePromptId) {
        activePromptId = defaultTemplateId || (sortedTemplates[0]?.id || null);
        shouldSave = true;
        if (activePromptId) {
            quickPromptSelect.value = activePromptId;
        }
    } else {
        quickPromptSelect.selectedIndex = -1;
    }

    updateSettingsDisplayText();
    if (shouldSave) {
        saveUserSettingsToFirebase(true);
    }
}

function renderPromptManager() {
    if (!templateListContainer) return;

    const sortedTemplates = [...promptTemplatesCache].sort((a, b) => {
        if (a.isDefault && !b.isDefault) return -1;
        if (!a.isDefault && b.isDefault) return 1;
        return (a.name || '').localeCompare(b.name || '', 'ko');
    });

    if (sortedTemplates.length === 0) {
        templateListContainer.innerHTML = '<div class="empty-list-message">템플릿이 없습니다.<br>새 템플릿을 추가해보세요.</div>';
        return;
    }

    templateListContainer.innerHTML = sortedTemplates.map(template => `
        <div class="template-list-item ${template.id === selectedTemplateId ? 'active' : ''} ${template.isDefault ? 'is-default' : ''}" data-id="${template.id}">
            <span class="item-name">${template.name || '제목 없음'}</span>
        </div>
    `).join('');
}

function showProjectContextMenu(projectId, event) {
    createContextMenu([
        { label: '이름 바꾸기', action: () => startProjectRename(projectId) },
        { label: '프로젝트 백업', action: () => exportChatProject(projectId) },
        { separator: true },
        { label: '삭제', action: () => deleteProject(projectId) }
    ], event);
}

function showSessionContextMenu(sessionId, event) {
    const session = localChatSessionsCache.find(item => item.id === sessionId);
    if (!session) return;

    const moveTargets = localProjectsCache
        .filter(project => project?.name)
        .sort((a, b) => a.name.localeCompare(b.name, 'ko'))
        .map(project => ({
            label: project.name,
            disabled: session.projectId === project.id,
            action: () => moveSessionToProject(sessionId, project.id)
        }));

    createContextMenu([
        { label: '이름 바꾸기', action: () => startSessionRename(sessionId) },
        {
            label: '프로젝트로 이동',
            submenu: [
                { label: '[일반 대화로 이동]', disabled: !session.projectId, action: () => moveSessionToProject(sessionId, null) },
                ...(moveTargets.length ? [{ separator: true }, ...moveTargets] : [])
            ]
        },
        { label: session.isPinned ? '고정 해제' : '고정하기', action: () => toggleChatPin(sessionId) },
        { separator: true },
        { label: '삭제', action: () => handleDeleteSession(sessionId) }
    ], event);
}

function updateChatHeaderModelSelector() {
    if (!aiModelSelector) return;

    const previousModel = aiModelSelector.value;
    const defaultModels = [
        { value: 'gemini-2.5-flash-preview-09-2025', text: '⚡ Gemini 2.5 Flash' }
    ];
    aiModelSelector.innerHTML = '';

    const activePreset = userApiSettings.apiPresets.find(preset => preset.id === userApiSettings.activePresetId);

    if (groundingQuickToggleBtn) {
        if (activePreset?.provider === 'google_paid') {
            groundingQuickToggleBtn.style.display = 'flex';
            groundingQuickToggleBtn.classList.toggle('active', !!activePreset.useGrounding);
        } else {
            groundingQuickToggleBtn.style.display = 'none';
        }
    }

    if (activePreset) {
        const modelsToShow = [...(activePreset.availableModels || [])];
        if (modelsToShow.length === 0 && activePreset.selectedModel) {
            modelsToShow.push(activePreset.selectedModel);
        }

        modelsToShow.forEach(modelId => {
            const option = document.createElement('option');
            option.value = modelId;
            option.textContent = `[개인] ${modelId}`.substring(0, 30);
            aiModelSelector.appendChild(option);
        });

        aiModelSelector.value = activePreset.selectedModel;
    } else {
        defaultModels.forEach(model => {
            const option = document.createElement('option');
            option.value = model.value;
            option.textContent = model.text;
            aiModelSelector.appendChild(option);
        });

        const savedDefaultModel = localStorage.getItem('selectedAiModel') || defaultModel;
        aiModelSelector.value = savedDefaultModel;
    }

    updateSettingsDisplayText();

    const newModel = aiModelSelector.value;
    if (previousModel && previousModel !== newModel) {
        trace('UI.StateSync', 'ModelChangeReflected', { from: previousModel, to: newModel });
    }
}

function updateSettingsDisplayText() {
    if (!settingsDisplayText || !aiModelSelector || !quickPromptSelect) return;

    const selectedModelOption = aiModelSelector.options[aiModelSelector.selectedIndex];
    const modelText = selectedModelOption ? selectedModelOption.textContent.replace('[개인] ', '') : '모델 선택';
    const selectedPromptOption = quickPromptSelect.options[quickPromptSelect.selectedIndex];
    const promptText = selectedPromptOption ? selectedPromptOption.textContent : '템플릿 선택';

    settingsDisplayText.textContent = `${modelText} | ${promptText}`;
}

function setupUnifiedSettingsControl() {
    if (!settingsButton || !settingsPopover) return;

    settingsButton.addEventListener('click', event => {
        event.stopPropagation();
        if (document.body?.classList.contains('mobile-shell-mode') && chatPanel) {
            chatPanel.classList.remove('mobile-sidebar-open');
        }
        renderApiPresetSelector();
        updateChatHeaderModelSelector();
        renderQuickPromptSelect();
        settingsPopover.classList.toggle('show');
    });

    apiPresetSelector?.addEventListener('change', () => {
        const selectedValue = apiPresetSelector.value;
        userApiSettings.activePresetId = selectedValue === 'universal' ? null : selectedValue;
        saveUserSettingsToFirebase(true);
        updateChatHeaderModelSelector();
        updateSettingsDisplayText();
        settingsPopover.classList.remove('show');
    });

    aiModelSelector?.addEventListener('change', () => {
        const newModel = aiModelSelector.value;
        const activePreset = userApiSettings.apiPresets.find(preset => preset.id === userApiSettings.activePresetId);
        if (activePreset) {
            activePreset.selectedModel = newModel;
        } else {
            localStorage.setItem('selectedAiModel', newModel);
        }

        saveUserSettingsToFirebase(true);
        updateSettingsDisplayText();
        settingsPopover.classList.remove('show');
    });

    quickPromptSelect?.addEventListener('change', () => {
        activePromptId = quickPromptSelect.value;
        updateSettingsDisplayText();
        settingsPopover.classList.remove('show');
        saveUserSettingsToFirebase();
    });
}

function getActivePresetSummaryText() {
    const activePreset = userApiSettings.apiPresets.find((preset) => preset.id === userApiSettings.activePresetId);
    return activePreset ? activePreset.name : '범용 모델 (기본)';
}

function renderPromptManager() {
    if (!templateListContainer) return;

    const sortedTemplates = [...promptTemplatesCache].sort((a, b) => {
        if (a.isDefault && !b.isDefault) return -1;
        if (!a.isDefault && b.isDefault) return 1;
        return (a.name || '').localeCompare(b.name || '', 'ko');
    });

    if (sortedTemplates.length === 0) {
        templateListContainer.innerHTML = '<div class="empty-list-message">템플릿이 없습니다.<br>새 템플릿을 추가해보세요.</div>';
        return;
    }

    templateListContainer.innerHTML = sortedTemplates.map((template) => `
        <div class="template-list-item ${template.id === selectedTemplateId ? 'active' : ''} ${template.isDefault ? 'is-default' : ''}" data-id="${template.id}">
            <div class="template-item-main">
                <span class="item-name">${template.name || '제목 없음'}</span>
                <span class="template-item-badge">${template.isDefault ? '기본' : '사용자'}</span>
            </div>
            <span class="template-item-preview">${(template.promptText || '설정된 안내 문구가 없습니다.').replace(/\s+/g, ' ').trim().slice(0, 72)}</span>
        </div>
    `).join('');
}

function updateSettingsDisplayText() {
    if (!settingsDisplayText || !aiModelSelector || !quickPromptSelect) return;

    const presetText = getActivePresetSummaryText();
    const selectedModelOption = aiModelSelector.options[aiModelSelector.selectedIndex];
    const modelText = selectedModelOption ? selectedModelOption.textContent.replace('[개인] ', '') : '모델 선택';
    const selectedPromptOption = quickPromptSelect.options[quickPromptSelect.selectedIndex];
    const promptText = selectedPromptOption ? selectedPromptOption.textContent : '템플릿 선택';

    const primaryLine = document.createElement('span');
    primaryLine.className = 'settings-line settings-primary';
    primaryLine.textContent = presetText;

    const secondaryLine = document.createElement('span');
    secondaryLine.className = 'settings-line settings-secondary';
    secondaryLine.textContent = `${modelText} | ${promptText}`;

    settingsDisplayText.replaceChildren(primaryLine, secondaryLine);
}
