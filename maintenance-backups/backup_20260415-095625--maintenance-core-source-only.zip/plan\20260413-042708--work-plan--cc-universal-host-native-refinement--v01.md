# Work Plan

Plan Type: Work Plan
Workstream: Universal `.cc/.ccc` host-native recursive refinement
Version: v01
Status: Completed
Created: 2026-04-13 04:27:08 +09:00
Last Updated: 2026-04-13 04:34:35 +09:00
Related Plan:
- `plan/20260413-040309--work-plan--cc-universal-module-validation--v01.md`
Supersedes: None

Approval Record

- Prior understanding report was delivered in chat immediately before this plan.
- The user explicitly approved the new direction with: `응 /sub 빡쌔게 재귀개선해`.
- This approval applies to a new refinement loop focused on eliminating structure priming and preserving host-native output structure.

Current Completion State

- The current English universal module exists at `cc_universal_module_mm.md`.
- The current module size is 4588 characters, which is inside the target budget.
- The prior validation loop already proved that the current module is structurally strong as a canvas shell, but it still leaks foreign document structure such as keywords, summaries, prerequisites, and major-topic chaptering.
- The user has now identified that this leakage is itself a correctness failure because it causes host prompts to follow the module's structure instead of preserving their own.
- The English module has been rewritten around a host-defined-units rule.
- Two read-only high-reasoning workers completed initial fail audits and final pass revalidation.
- The final accepted English module measures 4150 characters.

Completed So Far

- A first universal `.cc/.ccc` module was extracted from the Ailey-specific prompt and converted into a compact English insertion payload.
- A full `/sub` validation loop was already completed and documented under the previous plan.
- The previous loop improved MM packaging, removed wrapper scaffolding, and restored important shell rules.
- The previous loop did not yet fully solve the deeper universality issue: foreign output structure was still being proposed by the module.
- The user supplied a concrete counterexample host at `Singulari-Tea Codex_v5_260312.txt`, making the failure mode explicit.
- Launched a new `/sub` refinement run dedicated to host-native preservation.
- Captured initial fail verdicts from both workers that isolated the remaining foreign structure instructions.
- Rewrote the English module so that `host-defined units` became the only content-shape rule.
- Removed the explicit overview/deep-dive taxonomy and the keyword, prerequisites, chapter, recap, and final-section leakage phrases.
- Re-measured the final accepted module at 4150 characters.
- Captured final pass verdicts from both workers and preserved static evidence on disk.

Remaining Work

1. None for the approved English refinement scope.
2. Optional future follow-up: sync `cc_universal_module_mm_ko.md` to the accepted English version if translation parity is desired.

Current Blockers

- No active blocker remains for the approved scope.

Next Step

- Deliver the accepted result and evidence summary to the user.

Objective

The objective of this run is to turn the universal `.cc/.ccc` module from a strong teaching-shell transmuter into a true host-native canvas layer. The module should preserve the host prompt's content structure, pacing, interface logic, and native response grammar rather than silently introducing summary boxes, keyword chips, chapter sections, prerequisites, or other foreign scaffolding. The module should own only the trigger logic, canvas rendering shell, hydration mechanics, and placeholder authoring rules. It must not replace the host's compositional logic with a default document template.

Scope

This workstream includes prompt analysis, prompt rewriting, strict read-only subagent review, size verification, evidence preservation, and edits to `cc_universal_module_mm.md`. It may also lead to a later update of `cc_universal_module_mm_ko.md`, but translation parity is not required for this run. This workstream does not require changes to the Ailey source prompt or deployment assets. It does not require bundle edits, GitHub updates, or browser automation unless a later ambiguity makes that necessary.

Primary Deliverables

- A revised `cc_universal_module_mm.md` that no longer injects foreign content structure into arbitrary hosts.
- Updated `/sub` evidence under `subagent-runs/20260413-042708-cc-host-native-refinement/`.
- An updated active plan file with score tracking.
- A concise evidence-based final report explaining what was removed, what was preserved, and what residual limitations remain.

User Constraints

- Use `/sub`.
- Push the reasoning hard and iterate recursively if needed.
- Treat preservation of host-native structure as the governing acceptance criterion.
- Do not let generic educational structure survive merely because it looked good in a prior test.
- Keep the universal English module under 5000 characters if possible.

Hidden Rules And Consistency Requirements

The hidden rule is that a universal module fails if it tells the host what shape to think in. A canvas module may define assets, containers, placeholders, and hydration behavior, but it must not define a summary just because summaries are useful, define keyword chips just because classification is often useful, or define major/sub-topic sectioning just because a lesson shell wants them. If the host is story-first, the canvas output must remain story-first. If the host is menu-first, the canvas output must preserve that navigation logic. If the host is dashboard-first, the module may render that dashboard more richly but cannot replace it with article structure. Another hidden rule is that shell fidelity still matters: removing foreign structure must not accidentally erase the `.cc` or `.ccc` runtime contract. The challenge is subtraction without losing the fixed renderer handshake.

Technical Approach

The parent will run a strict read-only two-worker review. Worker 1 will act as a host-native simulation analyst and examine whether the module still biases arbitrary hosts toward article structure. Worker 2 will act as a structure-priming and MM auditor and isolate every phrase that encodes foreign compositional defaults. After the reviews return, the parent will rewrite the module in the primary workspace so that the only prescriptive elements that remain are trigger conditions, shell assets, container requirements, hydration mechanics, and placeholder authoring guarantees. The parent will then measure the revised module, compare it against the budget, and send the refined version back through a final read-only delta review.

Why Delegation Is Justified

The user explicitly requested `/sub` and asked for aggressive recursive improvement. The failure mode here is subtle because the module can appear structurally polished while still corrupting host behavior. Parallel read-only audits are therefore justified: one to test host preservation from a generative perspective and another to audit the module as a transfer contract. Since the writable surface is a single prompt file, the safest pattern remains read-only worker analysis plus parent-owned rewriting.

Validation Strategy

Validation will focus on what the module stops doing as much as on what it still does. The revised module should stop implying keyword sections, summary sections, prerequisites, chapter stacks, and document-style structural defaults unless those are already implied by the host itself. It should preserve `.cc` standard shell requirements, `.ccc` freestyle shell requirements, placeholder specificity, hydration behavior, and host-language continuity. It should still fit under 5000 characters. A pass requires both the absence of foreign structure leakage and the continued presence of the renderer handshake.

Final Outcome Against Validation Strategy

- Prior foreign-structure leak phrases were removed.
- Renderer handshake markers remain present.
- Host-native preservation passed final worker review.
- Size target remains satisfied at 4150 characters.

Definition Of Done

This run is complete when the universal module has been rewritten so that it no longer prescribes foreign output structure, has been reviewed by `/sub` workers for host-native preservation, still preserves the `.cc/.ccc` shell contract, remains inside the size target or comes with a clear documented reason if the final version barely exceeds it, and the evidence files and active plan reflect the result accurately.

Risks

The main risk is over-correcting by stripping away too much structure and accidentally weakening the fixed shell contract. A second risk is leaving subtle structure priming behind through phrases like "major topic", "summary", "keyword extraction", or "broad exploration surface". A third risk is shrinking the module by removing wording that actually protected shell fidelity. A fourth risk is that a host-native module may need more abstraction and therefore become harder to validate at a glance.

Open Questions

- Should the final module mention any example section types at all, or should it talk only about preserving the host's native section grammar?
- Should placeholders be attached to host-defined structural units rather than "major sections"?
- Should the module refer to "host-defined blocks" or "host-native units" as its generic structural abstraction?

Acceptance Criteria

- The revised module no longer instructs the model to emit keyword, summary, prerequisites, or chapter structures unless those are already implied by the host.
- The revised module still preserves `.cc` and `.ccc` trigger and shell fidelity.
- The revised module still enforces high-quality image and visualization placeholder authoring.
- The revised module still preserves host identity, language, safety scope, and dialogue intent.
- The revised module remains at or below 5000 characters if achievable without breaking the shell contract.
- `/sub` reviewers judge the revised module as host-native enough to accept.

Fallback And Repair Logic

If the first rewrite still leaks structure, the next pass will remove any remaining host-shape examples and replace them with one abstract rule keyed to host-native units. If the first rewrite becomes too vague and weakens the shell contract, the next pass will restore literal shell obligations while keeping structure-prescription abstract. If worker verdicts conflict, the parent will prefer the smaller rule set that preserves the renderer handshake without injecting foreign document shape.

Operational Notes

- All workers remain read-only.
- The parent remains the only writer in the primary workspace.
- Evidence for this run will live under `subagent-runs/20260413-042708-cc-host-native-refinement/`.

Scoreboard

Current Score: 50
Score Source: provisional
Last Updated: 2026-04-13 04:34:35 +09:00
Score Rationale: The corrected host-native acceptance bar is now met, the module passed final worker revalidation, and the approved scope is complete. The provisional score remains capped at 50 until the user gives an explicit score.
What Improved:
- The universality criterion is now sharper and more correct.
- A concrete hostile-host test case exists.
- The next rewrite target is precise.
- The final module no longer injects foreign article structure.
- The final module remains under budget while preserving shell fidelity.
What Remains Unsatisfactory:
- No blocking issue remains within the approved English-module scope.
- The Korean translation file is not yet synchronized to the final accepted English text.
Actions To Raise Or Maintain The Score:
- Run the strict read-only worker audit.
- Remove structure priming while preserving shell fidelity.
- Revalidate and deliver a cleaner accepted module.
- Sync the Korean translation later if needed.

Score History

- 2026-04-13 04:27:08 +09:00 | score 50 | source provisional | New approved refinement run started after the user identified host-structure corruption in the previously accepted module. Provisional score remains capped at 50 by local workflow policy.
- 2026-04-13 04:34:35 +09:00 | score 50 | source provisional | Scope completed. The module now passes the corrected host-native acceptance bar and remains under budget, but provisional scoring stays capped at 50 until the user provides an explicit score.
