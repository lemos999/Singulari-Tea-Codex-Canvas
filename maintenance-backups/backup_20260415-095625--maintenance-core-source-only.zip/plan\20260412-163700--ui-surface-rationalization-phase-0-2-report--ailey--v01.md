# Ailey UI Surface Rationalization Phase 0-2 Report

- Artifact Type: progress-report
- Created: 2026-04-12 16:37:00 +09:00
- Scope: Phase 0 through Phase 2 of `20260412-161230--ui-surface-rationalization-plan--ailey--v01.md`
- Status: completed-locally

## Summary

Phase 0 through Phase 2 were completed locally.

- A rollback backup was created before edits.
- The debugger UI surface was removed.
- The immersion subsystem was removed from the visible product path.
- Internal logging compatibility was preserved through a headless `trace(...)` implementation.
- Obsolete `immersionMode` settings are now deleted during persistence and silently migrated away on load.

## Implemented Changes

### 1. Debugger UI removal with logging preservation

Updated:

- `Ailey/src/02_utils/015_utils_debugger.js`
- `Ailey/src/00_shell/000_shell_template.js`
- `Ailey/src/00_shell/004_shell_part5_panel_vision_debugger.js`
- `Ailey/src/03_core/120_core_main_initializer.js`
- `Ailey/src/01_state/001_state_globalVars.js`
- `Ailey/src_css/001_base.css`

What changed:

- removed the debugger header button
- removed the live debugger panel markup
- removed debugger panel styling
- removed debugger-specific panel initialization and focus wiring
- preserved the `trace(...)` API by moving it to a headless ring-buffer logger with optional console echo
- kept `setupDebugger()` as a compatibility-safe bootstrap instead of a UI initializer

### 2. Immersion subsystem removal and settings migration

Updated:

- `Ailey/src/00_shell/000_shell_template.js`
- `Ailey/src/00_shell/002_shell_part3_modals_advanced.js`
- `Ailey/src/06_features_immersion/250_immersion_controller.js`
- `Ailey/src/03_core/120_core_main_initializer.js`
- `Ailey/src/03_core/111_core_api_settings_data.js`
- `Ailey/src/01_state/001_state_globalVars.js`
- `Ailey/src_css/005_widget_immersion_mode.css`
- `Ailey/src_css/013_immersion_modes.css`

What changed:

- removed the immersion header entry
- removed the immersion modal payload from shell assembly
- neutralized the immersion controller into a no-op compatibility stub
- removed immersion initialization from core startup
- stopped loading `immersionMode` into runtime settings
- migrated existing saved `immersionMode` away by deleting it on save and cleaning it up on load
- neutralized immersion CSS bundles so dead selectors stop shipping behavior

## Verification

Executed successfully:

- `node --check` on all touched JavaScript files
- `node Ailey/bundler.js`

Artifacts:

- local backup: `backup_20260412-162337--ui-surface-rationalization-preflight.zip`
- rebuilt bundle:
  - `Ailey/bundle/main.js`
  - `Ailey/bundle/main.css`

## Deferred to Later Phases

Not yet implemented:

- Phase 3: remove the current back-scene rollback behavior
- Phase 4: shrink the visualization control rail into `expand`, `regenerate`, and `more`
- Phase 6: hosted deployment, final report, and user validation

## Notes

- No hosted bundle deployment was performed in this phase slice.
- The compatibility stubs are intentional. They reduce rollback risk while the remaining cleanup phases are still pending.
