/* --- Ailey & Bailey Canvas --- */
// File: 001_shell_part2_modals_common.js
// Version: 2.3 (Chunk Size Popover Fix)
// Description: Added the missing popover HTML element to fix the non-functional chunk size button in the data extraction modal. The `chunk-size-popover` div is now included to enable the UI for setting chunk sizes during data processing jobs.

const SHELL_PART_2 = `
    <div id="selection-popover" role="toolbar" aria-label="선택 텍스트 빠른 작업">
        <button id="popover-ask-ai" class="selection-popover-btn" title="AI에게 질문">
            <svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor" aria-hidden="true"><path d="M12,2A2,2 0 0,1 14,4A2,2 0 0,1 12,6A2,2 0 0,1 10,4A2,2 0 0,1 12,2M15.9,8.4C15.9,7.3 15,6.5 13.9,6.5C12.8,6.5 11.9,7.3 11.9,8.4C11.9,9.5 12.8,10.3 13.9,10.3C15,10.3 15.9,9.5 15.9,8.4M8.1,8.4C8.1,7.3 9,6.5 10.1,6.5C11.2,6.5 12.1,7.3 12.1,8.4C12.1,9.5 11.2,10.3 10.1,10.3C9,10.3 8.1,9.5 8.1,8.4M12,20C13.8,20 15.5,19.2 16.8,18H7.2C8.5,19.2 10.2,20 12,20M20,12V7C20,5.9 19.1,5 18,5H6C4.9,5 4,5.9 4,7V12C4,13.1 4.9,14 6,14H7.2C8.1,15.2 9.5,16 11,16V18H9V20H15V18H13V16C14.5,16 15.9,15.2 16.8,14H18C19.1,14 20,13.1 20,12Z" /></svg>
            <span>질문</span>
        </button>
        <button id="popover-add-note" class="selection-popover-btn" title="메모에 추가">
            <svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor" aria-hidden="true"><path d="M19,13H13V19H11V13H5V11H11V5H13V11H19M17,3H7A2,2 0 0,0 5,5V19A2,2 0 0,0 7,21H17A2,2 0 0,0 19,19V5A2,2 0 0,0 17,3Z" /></svg>
            <span>메모</span>
        </button>
    </div>
    <div id="copy-modal-overlay" class="custom-modal-overlay">
        <div id="copy-modal-container" class="custom-modal">
            <p>아래 내용이 자동으로 선택되었습니다. <strong>Ctrl+C</strong> 또는 <strong>Cmd+C</strong>를 눌러 복사하세요.</p>
            <textarea id="copy-modal-textarea" readonly></textarea>
        </div>
    </div>
    <div id="quiz-modal-overlay" class="custom-modal-overlay">
        <div class="quiz-modal custom-modal">
            <h2>📝 핵심 개념 퀴즈</h2>
            <div id="quiz-container"></div>
            <button id="quiz-submit-btn">제출하기</button>
            <div id="quiz-results"></div>
        </div>
    </div>
    <div id="prompt-modal-overlay" class="custom-modal-overlay">
        <div class="custom-modal generic-feedback-modal" data-variant="info">
            <div class="generic-feedback-head">
                <span id="modal-badge" class="generic-feedback-badge">Notice</span>
                <h3 id="modal-title">안내</h3>
            </div>
            <h3>⚙️ Ailey & Bailey 역할 설정</h3>
            <p style="font-size:0.9em;">Ailey & Bailey에게 원하는 역할을 부여해주세요. (예: 5살 아이에게 설명하듯 알려줘)</p>
            <textarea id="custom-prompt-input" placeholder="여기에 원하는 역할을 입력하세요..."></textarea>
            <div class="custom-modal-actions">
                <button id="prompt-cancel-btn" class="modal-btn">취소</button>
                <button id="prompt-save-btn" class="modal-btn">저장</button>
            </div>
        </div>
    </div>
    <div id="prompt-manager-modal-overlay" class="custom-modal-overlay">
        <div class="custom-modal prompt-manager-modal">
             <button class="close-btn" id="prompt-manager-close-btn"><svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z" /></svg></button>
            <div class="prompt-manager-container">
                <div class="template-list-panel">
                    <div class="template-panel-header">
                        <span class="template-panel-kicker">Prompt Workspace</span>
                        <h3>템플릿 목록</h3>
                        <p class="template-panel-helper">기본 템플릿은 보호되고, 사용자 템플릿만 직접 편집하거나 삭제할 수 있습니다.</p>
                    </div>
                    <div id="template-list-container"></div>
                    <button id="add-new-template-btn" class="notes-btn template-create-btn" style="width: 100%;">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z" /></svg>
                        <span>새 템플릿 추가</span>
                    </button>
                </div>
                <div class="template-editor-panel">
                    <div class="template-editor-header">
                        <div>
                            <span class="template-panel-kicker">Template Editor</span>
                            <h3 id="template-editor-title">템플릿 편집</h3>
                            <p id="template-editor-status" class="template-editor-status">좌측에서 템플릿을 선택하면 역할과 지시사항을 바로 수정할 수 있습니다.</p>
                        </div>
                    </div>
                    <div class="editor-form-group">
                        <label for="template-name-input">템플릿 이름</label>
                        <input type="text" id="template-name-input" placeholder="예: 데이터 분석 전문가">
                    </div>
                    <div class="editor-form-group">
                        <label for="template-prompt-textarea">프롬프트 내용</label>
                        <textarea id="template-prompt-textarea" rows="10" placeholder="AI에게 전달할 역할, 지시사항 등을 입력하세요..."></textarea>
                    </div>
                    <div class="editor-actions">
                        <button id="delete-template-btn" class="modal-btn cancel">삭제</button>
                        <button id="save-template-btn" class="modal-btn confirm">저장</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="custom-modal" class="custom-modal-overlay">
        <div class="custom-modal generic-feedback-modal" data-variant="info">
            <div class="generic-feedback-head">
                <span id="modal-badge" class="generic-feedback-badge">Notice</span>
                <h3 id="modal-title">Notice</h3>
            </div>
            <p id="modal-message">정말로 이 항목을 삭제하시겠습니까?</p>
            <div class="custom-modal-actions">
                <button id="modal-cancel-btn" class="modal-btn">취소</button>
                <button id="modal-confirm-btn" class="modal-btn">삭제</button>
            </div>
        </div>
    </div>
    <div id="choice-modal" class="custom-modal-overlay">
        <div class="custom-modal">
            <h3 id="choice-modal-title" style="margin-top:0; margin-bottom: 10px;"></h3>
            <p id="choice-modal-message" style="margin-top:0;"></p>
            <div id="choice-modal-actions" class="custom-modal-actions">
                <!-- Buttons added via JS -->
            </div>
        </div>
    </div>
    <div id="move-to-folder-modal-overlay" class="custom-modal-overlay">
        <div class="custom-modal move-to-folder-modal">
            <h3 id="move-to-folder-modal-title"></h3>
            <input type="search" id="move-to-folder-search-input" placeholder="폴더 검색...">
            <div id="move-to-folder-list-container">
                <!-- Folder list will be populated by JS -->
            </div>
            <div class="custom-modal-actions">
                <button id="move-to-folder-cancel-btn" class="modal-btn cancel">취소</button>
            </div>
        </div>
    </div>
    <div id="manual-refinement-modal-overlay" class="custom-modal-overlay">
        <div class="custom-modal manual-refinement-modal">
            <h3>정제 기록 수동 설정</h3>
            <p>실수로 기록을 초기화했거나 특정 지점부터 다시 시작하고 싶을 때, 기준이 될 메모를 선택하세요. 선택한 메모 **이전까지** 처리된 것으로 기록이 설정됩니다.</p>
            <div id="manual-refinement-note-list">
                <!-- Note list will be populated by JS -->
            </div>
            <div class="custom-modal-actions">
                <button id="manual-refinement-cancel-btn" class="modal-btn cancel">취소</button>
                <button id="manual-refinement-save-btn" class="modal-btn confirm" disabled>저장</button>
            </div>
        </div>
    </div>
    <div id="chunk-size-modal-overlay" class="custom-modal-overlay">
        <div class="custom-modal chunk-size-modal" style="max-width: 400px;">
            <h3 id="chunk-size-modal-title"></h3>
            <div class="api-form-section">
                 <label for="chunk-size-input">서사 기록 묶음 크기 (턴 수)</label>
                 <input type="number" id="chunk-size-input" min="1" max="100" step="1" placeholder="10">
                 <small>데이터 추출 시, 몇 개의 턴(서사)을 하나의 메모로 묶을지 설정합니다. 비워두면 기본값(10)이 사용됩니다.</small>
            </div>
            <div class="custom-modal-actions">
                <button id="chunk-size-cancel-btn" class="modal-btn cancel">취소</button>
                <button id="chunk-size-save-btn" class="modal-btn confirm">저장</button>
            </div>
        </div>
    </div>
    <div id="chunk-size-popover" class="custom-popover"></div>
    <div id="doc-translator-modal-overlay" class="custom-modal-overlay">
        <div class="custom-modal doc-translator-modal">
            <h3><svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M12.87,15.43L11.5,14.06L10.13,15.43L9.03,14.33L10.4,12.96L9.03,11.59L10.13,10.5L11.5,11.87L12.87,10.5L13.97,11.59L12.6,12.96L13.97,14.33L12.87,15.43M19.35,10.04C18.67,6.59 15.64,4 12,4C9.11,4 6.6,5.64 5.35,8.04C2.34,8.36 0,10.91 0,14A6,6 0 0,0 6,20H19A5,5 0 0,0 23.64,15.35C23.9,13.8 23.23,12.16 22.1,11.1C21.2,10.24 20.13,10 19.35,10.04Z" /></svg> 새 문서 번역</h3>
            <div class="doc-translator-layout">
                <div class="doc-translator-left">
                    <div class="api-form-section">
                        <label for="doc-translator-title-input">문서 제목 (폴더 이름)</label>
                        <input type="text" id="doc-translator-title-input" placeholder="예: 기술 문서 번역">
                    </div>
                    <div class="api-form-section content-section">
                        <label for="doc-translator-content-textarea">번역할 내용</label>
                        <textarea id="doc-translator-content-textarea" placeholder="여기에 번역할 텍스트를 붙여넣으세요..."></textarea>
                    </div>
                </div>
                <div class="doc-translator-right">
                    <div class="accordion-container">
                        <div class="accordion-header expanded">번역 언어 설정</div>
                        <div class="accordion-content expanded">
                            <div class="settings-card">
                                <div class="language-option-item">
                                    <label class="language-option-label-part" for="lang-select-radio">
                                        <input type="radio" id="lang-select-radio" name="language-option" value="select" checked>
                                        <span class="custom-radio"></span>
                                        <span class="option-label">주요 언어 선택</span>
                                    </label>
                                    <div class="language-option-control-part">
                                        <select id="doc-translator-lang-select">
                                            <option value="Korean">한국어</option>
                                            <option value="English">English (영어)</option>
                                            <option value="Japanese">日本語 (일본어)</option>
                                            <option value="Chinese">中文 (중국어)</option>
                                            <option value="Spanish">Español (스페인어)</option>
                                            <option value="French">Français (프랑스어)</option>
                                            <option value="German">Deutsch (독일어)</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="language-option-item">
                                     <label class="language-option-label-part" for="lang-direct-radio">
                                        <input type="radio" id="lang-direct-radio" name="language-option" value="direct">
                                        <span class="custom-radio"></span>
                                        <span class="option-label">직접 입력</span>
                                    </label>
                                    <div class="language-option-control-part">
                                        <input type="text" id="doc-translator-lang-direct-input" placeholder="번역할 언어 입력 (예: Italian)" disabled>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-container">
                        <div class="accordion-header expanded">번역 옵션</div>
                        <div class="accordion-content expanded">
                            <div class="api-form-section">
                                <label for="doc-translator-prompt-select">번역 프롬프트 템플릿</label>
                                <select id="doc-translator-prompt-select"></select>
                                <small>'Document Translator'는 구조, 'Master Translator'는 뉘앙스, 'Learning Subtitle Translator'는 학습용 주석에 중점을 둡니다.</small>
                            </div>
                            <div class="api-form-section">
                                <div class="chunk-size-container">
                                    <div class="chunk-size-input-group">
                                        <label>청크 당 목표 글자 수</label>
                                        <div class="chunk-size-selector">
                                            <button id="chunk-size-decrease-btn" class="chunk-btn" aria-label="감소">-</button>
                                            <div id="chunk-size-value-display" class="chunk-value">1K</div>
                                            <button id="chunk-size-increase-btn" class="chunk-btn" aria-label="증가">+</button>
                                        </div>
                                        <input type="hidden" id="doc-translator-chunk-size-input" value="1000">
                                        <small>한 턴에 많이 처리할수록 오작동 및 API 비용이 크게 증가할 수 있습니다. (특히 자막)</small>
                                    </div>
                                    <div class="turn-count-display">
                                        <span class="turn-count-label">예상 청크(메모) 수:</span>
                                        <strong id="doc-translator-turn-count">0</strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-modal-actions">
                <button id="doc-translator-cancel-btn" class="modal-btn cancel">취소</button>
                <button id="doc-translator-save-btn" class="modal-btn confirm">저장 및 번역 준비</button>
            </div>
        </div>
    </div>
    <div id="translation-language-modal-overlay" class="custom-modal-overlay">
        <div class="custom-modal" style="max-width: 450px; text-align: left;">
            <h3><svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M12.87,15.43L11.5,14.06L10.13,15.43L9.03,14.33L10.4,12.96L9.03,11.59L10.13,10.5L11.5,11.87L12.87,10.5L13.97,11.59L12.6,12.96L13.97,14.33L12.87,15.43M19.35,10.04C18.67,6.59 15.64,4 12,4C9.11,4 6.6,5.64 5.35,8.04C2.34,8.36 0,10.91 0,14A6,6 0 0,0 6,20H19A5,5 0 0,0 23.64,15.35C23.9,13.8 23.23,12.16 22.1,11.1C21.2,10.24 20.13,10 19.35,10.04Z" /></svg> '<span id="translation-language-modal-title-text"></span>' 번역 언어 설정</h3>
            <div class="api-form-section">
                <label>번역 결과물을 받을 언어를 선택해주세요.</label>
                <div class="settings-card">
                    <div class="language-option-item">
                        <label class="language-option-label-part" for="trans-lang-select-radio">
                            <input type="radio" id="trans-lang-select-radio" name="trans-language-option" value="select" checked>
                            <span class="custom-radio"></span>
                            <span class="option-label">주요 언어 선택</span>
                        </label>
                        <div class="language-option-control-part">
                            <select id="translation-language-select">
                                <option value="Korean">한국어</option>
                                <option value="English">English (영어)</option>
                                <option value="Japanese">日本語 (일본어)</option>
                                <option value="Chinese">中文 (중국어)</option>
                                <option value="Spanish">Español (스페인어)</option>
                                <option value="French">Français (프랑스어)</option>
                                <option value="German">Deutsch (독일어)</option>
                            </select>
                        </div>
                    </div>
                    <div class="language-option-item">
                        <label class="language-option-label-part" for="trans-lang-direct-radio">
                            <input type="radio" id="trans-lang-direct-radio" name="trans-language-option" value="direct">
                            <span class="custom-radio"></span>
                            <span class="option-label">직접 입력</span>
                        </label>
                        <div class="language-option-control-part">
                            <input type="text" id="translation-language-direct-input" placeholder="번역할 언어 입력 (예: Italian)" disabled>
                        </div>
                    </div>
                </div>
            </div>
            <div class="api-form-section">
                <label for="translation-prompt-select">번역 프롬프트 템플릿</label>
                <select id="translation-prompt-select"></select>
                <small>'Document Translator'는 구조, 'Master Translator'는 뉘앙스, 'Learning Subtitle Translator'는 학습용 주석에 중점을 둡니다.</small>
            </div>
            <div class="api-form-section">
                <label for="translation-delay-input">청크 간 번역 지연 (초)</label>
                <input type="number" id="translation-delay-input" min="1" value="10" step="1" placeholder="10">
                <small>각 문서 조각(청크) 번역 사이에 지연 시간을 설정합니다. API 과부하를 방지하는 데 도움이 됩니다. (기본값: 10초)</small>
            </div>
            <div class="custom-modal-actions">
                <button id="translation-language-cancel-btn" class="modal-btn cancel">취소</button>
                <button id="translation-language-confirm-btn" class="modal-btn confirm">번역 시작</button>
            </div>
        </div>
    </div>
`;
