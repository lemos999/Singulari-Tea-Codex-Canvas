/* --- Ailey & Bailey Canvas --- */
// File: 020_utils_intelligent_splitter.js
// Version: 2.1 (Korean Punctuation Fix)
// Description: Implements the 'Natural Boundary-First Splitting' algorithm.
// This new logic searches backwards from a target chunk size to find the most natural split point,
// prioritizing paragraph breaks, then line breaks, then sentence/punctuation, and finally whitespace.
// This version specifically improves detection of Korean sentence endings by not requiring a space after punctuation.

/**
 * Splits text into chunks using the 'Natural Boundary-First Splitting' algorithm.
 * Searches backwards from a target chunk size to find the most natural split point.
 *
 * @param {string} text The full text to be split.
 * @param {number} chunkSize The target maximum size for each chunk.
 * @returns {string[]} An array of text chunks.
 */
function hybridHierarchicalSplit(text, chunkSize) {
    if (!text) return [];
    if (text.length <= chunkSize) return [text];

    const chunks = [];
    let offset = 0;

    while (offset < text.length) {
        const remainingText = text.substring(offset);
        if (remainingText.length <= chunkSize) {
            chunks.push(remainingText);
            break;
        }

        let splitPoint = -1;
        const searchEnd = Math.min(chunkSize, remainingText.length - 1);
        const minSplitPoint = chunkSize * 0.5; // Avoid creating tiny chunks if possible

        const findBestSplit = (minPoint) => {
            // Priority 1: Paragraph break (\n\n)
            let boundary = remainingText.lastIndexOf('\n\n', searchEnd);
            if (boundary > minPoint) return boundary + 2;

            // Priority 2: Line break (\n)
            boundary = remainingText.lastIndexOf('\n', searchEnd);
            if (boundary > minPoint) return boundary + 1;

            // Priority 3 & 4: Punctuation (Korean-aware)
            let sentenceEnderPoint = -1;
            let otherPuncPoint = -1;
            for (let i = searchEnd; i > minPoint; i--) {
                const char = remainingText[i];
                if ('.!?。…'.includes(char)) {
                    sentenceEnderPoint = i + 1;
                    break; // Found best punc, stop.
                }
                if (',;:)"[]'.includes(char) && otherPuncPoint === -1) {
                    otherPuncPoint = i + 1; // Save but keep looking for a better one.
                }
            }
            if (sentenceEnderPoint !== -1) return sentenceEnderPoint;
            if (otherPuncPoint !== -1) return otherPuncPoint;

            // Priority 5: Whitespace
            boundary = remainingText.lastIndexOf(' ', searchEnd);
            if (boundary > minPoint) return boundary + 1;
            
            return -1;
        };

        // First pass: try to find an ideal split point that is not too small
        splitPoint = findBestSplit(minSplitPoint);
        
        // Fallback pass: if no ideal point, find any valid point > 0 to avoid cutting mid-word
        if (splitPoint === -1) {
            splitPoint = findBestSplit(0);
        }

        // Last resort: hard cut if no boundary was found at all
        if (splitPoint <= 0) {
            splitPoint = chunkSize;
        }
        
        chunks.push(remainingText.substring(0, splitPoint));
        offset += splitPoint;
    }

    return chunks.filter(c => c.trim().length > 0);
}
