# Scene Image Studio Low-Height Overflow Fix Report

- Artifact Type: implementation-report
- Created: 2026-04-12 22:09:20 +09:00
- Scope: prevent the left-side cards in the scene image studio from collapsing and overlapping when the window height is reduced
- Status: implemented-and-deployed-awaiting-manual-validation
- Related Plan: `20260412-181504--visualization-options-upgrade-plan--ailey--v01.md`

## What Happened

- the earlier label-spacing fix improved the normal-height case
- but when the window height became small, the left-side cards still shrank vertically
- once that happened, content from the reference-image helper area could overflow into the `장면 설명 메모` card

## Root Cause

- the left column is a vertical flex layout
- its child sections were still allowed to shrink under height pressure
- that meant the column tried to compress cards before handing the overflow to the column scroll container

## What Changed

- `Ailey/src_css/027_image_gen_studio.css`
  - left-column sections now do not shrink under low-height pressure
  - side cards now clip internal overflow instead of painting over neighboring cards
  - the prompt card is explicitly a column layout with a minimum safe height
  - the textarea keeps its own vertical scroll
  - an extra low-height media rule ensures the modal and left column favor scrolling over card collapse

## Verification

- `node Ailey/bundler.js`

## Deployment

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `7d75fc0`
- commit message: `Keep scene image studio cards from shrinking`

## Remaining Risk

- very unusual browser zoom levels or OS text scaling still need manual confirmation
