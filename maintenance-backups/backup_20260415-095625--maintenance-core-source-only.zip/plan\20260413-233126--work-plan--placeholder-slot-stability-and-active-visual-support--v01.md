Plan Type: Work Plan
Workstream: Placeholder Slot Stability And Active Visual Support
Version: v01
Status: Completed
Created: 2026-04-13 23:31:26 +09:00
Last Updated: 2026-04-13 23:47:30 +09:00
Supersedes or Related Plan: Related to 20260413-221358--live-export-fullscreen-parity-report--v01.md
Current Completion State: The slot-versus-block placeholder contract is implemented in the runtime, validated against the active specimen, bundled, and published to the canonical bundle repository.
Completed So Far: The runtime now preserves authored media frames for slot-mode image placeholders, preserves slot-mode visualization frames when explicitly mounted that way, and keeps standalone visualization blocks on the normal block path. The `.cc` contract now explicitly encourages active placeholder use and defines slot-versus-block behavior, fit intent, and stability expectations. `1.html` was updated as a concrete specimen to mark card-top image placeholders as slot media and the lower visualization area as a block support surface. The bundle was rebuilt and published to GitHub.
Remaining Work: No required implementation work remains in this plan version. Optional follow-up work could broaden fixture coverage or bring the same explicit slot attributes into more authored examples.
Current Blockers: None.
Next Step: Report the shipped change set and the verification evidence to the user.

## Objective

The objective is to make `.cc` artifacts use image placeholders and visualization placeholders more actively while keeping the rendered page stable after generation. The specific failure the user called out is that a placeholder can start as a neat framed media area inside a card, but once the image is generated the runtime replaces the placeholder with a generic standalone generated-image block and the resulting media visually spills over the authored composition or covers nearby content. The system should instead preserve the author’s intended frame and keep the media constrained inside that frame unless the placeholder was explicitly authored as a standalone support block.

This work must change both the contract and the runtime. The contract side matters because the prompt needs to actively create more placeholder opportunities and do so deliberately. The runtime side matters because even a good prompt contract will still fail visually if the replacement logic ignores authored frame intent. The target result is a system where the prompt is encouraged to add meaningful media support more often, but the runtime is predictable enough that those placeholders remain safe to use in cards, split panels, galleries, and support rails.

## User-Visible Outcome

After this work, a `.cc` page should be able to place an image placeholder in a card-top media slot, a side-panel illustration area, a hero band, or a standalone block. When generation runs, the resulting image should stay inside that authored frame by default when the placeholder was clearly acting as a slot. The text and feature summaries below or beside the slot should remain readable and should not be pushed under the image or visually covered by a newly injected generic block wrapper.

Visualization placeholders should also behave more deliberately. Standalone explanatory visualizations should still render as their own sections. Compact or card-embedded visualization surfaces should only replace into the same outer frame when they are intentionally authored as slots. This avoids the current unstable behavior where replacement can discard the frame and substitute a very different layout surface than the author intended.

## Confirmed Facts

The current runtime already auto-generates image and visualization placeholders when those placeholder elements exist and the generation settings allow it. The current weakness is therefore not a lack of generation triggers. The weakness is the display contract after hydration and after replacement.

The current image placeholder hydration rewrites the class list into a generic generated-image container and the current image insertion function appends a generic wrapper designed for standalone block images. The current visualization flow similarly prefers replacing the placeholder node with a newly rendered visualization block. These behaviors are acceptable for full-width support blocks but not for embedded media slots.

The user also wants the prompt contract to become more active about using placeholders. That means the work should not merely make slot rendering safe. It should also make the contract explicitly bias toward using one or more meaningful visual support units when the subject benefits from them.

## Safe Assumptions

The safest assumption is that the user does not want the runtime to guess wildly. The system should infer slot mode from strong authored hints but should also support explicit author control through data attributes. This means the runtime should preserve existing authored classes and add a resolved display mode attribute rather than hard-overwriting the placeholder node.

The safest assumption for image fitting is that scenic photographic surfaces and card-top illustration slots usually want `cover`, while diagrammatic, map-like, specimen, or schematic support surfaces often want `contain`. The runtime should allow the authored payload to override this explicitly and should avoid making every generated image use the same object-fit mode.

The safest assumption for visualization placeholders is that most visualization blocks remain standalone support sections. Slot-style visualization replacement should require either explicit authored intent or a very clear compact media-frame use case, because interactive or scripted visuals are more layout-sensitive than static images.

## Hidden Rules And Consistency Requirements

The runtime must not destroy authored layout classes just because a placeholder hydrates. The authored frame is part of the `.cc` artifact meaning, especially now that `.cc` is allowed to be more composition-sensitive and more freeform inside the mounted payload. Destroying that frame is a semantic and visual regression.

The runtime must preserve the reading spine. Generated content is an enrichment surface. The surrounding explanatory text must remain readable and spatially stable even if the media generation is delayed, fails, or resolves after the rest of the page has already landed.

The runtime must remain compatible with live export and the persistent shell. This work cannot regress the previously fixed export parity or fullscreen stabilization. Any new CSS or DOM contract must therefore scope media-slot behavior to the payload rather than taking over body-level layout or shell-owned chrome.

The contract update must encourage placeholder use without forcing every page into noisy ornamentation. The prompt should be more active, but only for support units that clarify the answer. Decorative media that does not teach or orient should remain discouraged.

## Technical Approach

### 1. Introduce a stable placeholder display contract

The runtime and the prompt contract should share a simple mental model:

- `data-placeholder-display="block"` means the placeholder is a standalone support block and may expand into a conventional support section.
- `data-placeholder-display="slot"` means the placeholder is an authored media frame inside a larger composition and generated media must stay inside that frame.

The runtime should also write a resolved mode back onto the element, such as `data-placeholder-display-resolved="slot"` or `block`, so downstream code and CSS can behave consistently after hydration.

### 2. Preserve authored classes during hydration

Hydration should stop replacing the class list with one generic placeholder class. Instead it should add the type-specific state classes while preserving the existing authored frame classes. This is especially important for Tailwind-authored payloads, because width, height, rounding, overflow, and positioning are often carried by the original class list.

### 3. Make image insertion slot-aware

The image insertion function should detect whether the target is a slot or a block. For slot mode it should:

- keep the outer target element
- preserve authored sizing and rounded corners
- mount the image to fill the slot frame
- respect `data-image-fit` or `data-media-fit`
- keep overlay controls inside the frame without covering the whole reading surface

For block mode it can keep the existing standalone behavior, but with minimal cleanup if needed.

### 4. Make visualization replacement slot-aware

Visualization generation should use the same display contract. If the placeholder is a slot, the runtime should mount the visualization inside the existing target element rather than replacing the target with a new generic block container. If the placeholder is a standalone support block, replacement can continue to use the standard block path.

### 5. Add CSS for slot-mode media and slot-mode visualizations

The image placeholder stylesheet needs a separate visual treatment for slot-mode generated images so that:

- the slot has no extra section padding or block-level min-height unless authored
- the wrapper fills the frame
- the generated image fills the frame using `cover` or `contain`
- overlay controls remain compact and anchored inside the frame

The visualization stylesheet needs similar slot-mode handling so that compact or card-embedded visualizations respect the authored height and width rather than expanding into a generic standalone visualization block.

### 6. Strengthen the `.cc` contract

The markdown contract should explicitly say:

- placeholders should be used actively when the topic would benefit from them
- a page may use both an image placeholder and a visualization placeholder if they do distinct explanatory work
- placeholders embedded in cards, split panels, galleries, heroes, or rails must preserve the authored frame
- block placeholders are for full support sections, slot placeholders are for embedded media frames
- image fit should be deliberately chosen
- visualization placeholders should not be buried in tiny utility bars unless intentionally compact and structurally safe

### 7. Validate with a concrete specimen

`1.html` is the practical regression specimen because it clearly demonstrates the failure mode: before generation the card layout looks correct; after generation the new media can overwhelm the card surface. Validation should exercise image generation insertion behavior and visualization mounting behavior at the DOM level and in a browser capture. The point is not to test remote model quality. The point is to confirm that the generated media stays inside the intended frame and that the explanatory text remains readable.

## Scope

In scope:

- runtime insertion and mounting logic for image and visualization placeholders
- placeholder hydration behavior
- slot-specific CSS
- prompt contract update in `cc_universal_module_mm.md`
- one or more targeted HTML fixture adjustments if necessary to express the new attributes clearly
- bundle rebuild
- browser validation against the current local runtime
- publish of runtime bundle files to GitHub if validation passes

Out of scope:

- redesigning the persistent application shell
- changing the underlying remote generation model
- solving the semantic quality of arbitrary AI-generated images
- adding new shell-level buttons or duplicated runtime chrome

## Risks

The biggest risk is overfitting slot behavior and accidentally breaking normal standalone image blocks. The implementation must preserve the block path and make slot handling additive instead of invasive.

Another risk is visualization replacement complexity. Interactive visualizations often assume block-level containers, so slot-mode mounting must not silently create zero-height or clipped interactive regions. The slot contract should therefore remain explicit and conservative for visualization surfaces.

There is also a CSS risk. Tailwind-authored payloads and handcrafted payloads can coexist. The new CSS must be specific enough to support slot-mode placeholders without globally overriding unrelated media blocks.

## Verification Plan

Verification should prove observable behavior, not just code intent.

1. Confirm that placeholder hydration preserves authored classes and resolves slot or block mode correctly.
2. Confirm that injecting a generated image into a slot placeholder keeps the image inside the authored frame and does not push or cover adjacent text content.
3. Confirm that injecting a generated image into a normal standalone block still renders as a normal support block.
4. Confirm that visualization replacement in slot mode preserves the outer frame.
5. Confirm that `1.html` still looks structurally correct before generation and remains structurally correct after generation.
6. Confirm that the bundle rebuild succeeds and that the publish repo picks up only the expected bundle outputs.

If any validation shows layout regression, the fix loop should remain bounded to the slot contract and should not sprawl into unrelated shell or prompt behavior.

## Definition Of Done

This work is done when:

- placeholder usage policy is more active in the `.cc` contract
- the runtime has a clear slot-versus-block display contract
- generated images no longer cover card content in the tested specimen
- visualization placeholders can preserve their authored frame when explicitly used as slots
- `1.html` demonstrates stable before-and-after behavior
- the bundle is rebuilt successfully
- the updated runtime bundle is pushed to GitHub

## Scoreboard

Current Score: 50
Score Source: provisional
Last Updated: 2026-04-13 23:47:30 +09:00
Score Rationale: The workstream achieved its requested technical outcome and shipped the runtime bundle, but the local scoring policy caps provisional scores at 50 until the user supplies an explicit rating.
What Improved: Slot-safe image insertion is now real, visualization slot mounting is validated, the `.cc` contract is clearer about active placeholder use, and the canonical bundle is published at the new commit.
What Remains Unsatisfactory: No blocking technical gap remains in this scoped workstream. The only missing input is an explicit user satisfaction score if the user wants the scoreboard to move above the provisional cap.
What Should Happen Next To Raise Or Maintain The Score: Let the user try the published bundle. If they want more refinement, extend the same slot contract to additional fixtures or examples; otherwise keep the current state as the stable baseline.

### Score History

- 2026-04-13 23:31:26 +09:00 | Score 50 | provisional | Initial approved planning state for this workstream. Understanding and execution path are clear, but implementation and verification are still pending.
- 2026-04-13 23:47:30 +09:00 | Score 50 | provisional | Implementation, validation, bundle rebuild, and GitHub publish completed. Provisional score stays capped pending explicit user rating.
