/* --- Ailey & Bailey Canvas --- */
// File: 341_notes_job_state.js
// Version: 1.0 (File Splitting)
// Description: Manages the global state variables for background data processing jobs.

let activeRefinementJob = null; // For multi-step data refinement.
let activeReportJob = null; // For multi-step AI comprehensive report generation.
