/* --- Ailey & Bailey Canvas --- */
// File: 111_core_api_settings_data.js
// Version: 1.8 (Local API Storage Split)
// Description: Stores local runtime API presets in localStorage while keeping shared settings in Firestore or the local shim.

const LOCAL_API_PRESETS_STORAGE_KEY = 'ailey_local_api_presets';
const LOCAL_ACTIVE_PRESET_STORAGE_KEY = 'ailey_local_active_preset_id';

function isLocalRuntimeMode() {
    return (window.__AILEY_RUNTIME_MODE__ === 'local') || (typeof __firebase_config === 'undefined');
}

function getDefaultUniversalModelSettings() {
    return {
        maxOutputTokens: 65536,
        temperature: 1,
        topP: 0.95,
        useGrounding: false,
        chatHistoryLimit: 20,
        autoCompactEnabled: true
    };
}

function getDefaultVisionSettings() {
    return {
        autoGenerateMode: 'quick',
        imageApi: 'universal',
        activePreset: null,
        presets: {
            "1": { main: null, face: null, clothing: null },
            "2": { main: null, face: null, clothing: null },
            "3": { main: null, face: null, clothing: null },
            "4": { main: null, face: null, clothing: null },
            "5": { main: null, face: null, clothing: null }
        },
        disableTextOutput: false,
        rememberOptions: false,
        rememberedOptions: {}
    };
}

function getDefaultVisualizationSettings() {
    return {
        autoGenerateOnLoad: true,
        educationalMode: false,
        worldsimMode: false,
        preferHighContrast: true,
        preferExportSafe: true,
        rememberLastVisualizationForm: true,
        defaultUseAiRecommendedProfile: false,
        defaultGoal: 'explain',
        defaultFamily: 'comparison',
        defaultRendererStrategy: 'ai-recommended',
        defaultTheme: '[표준 기본]',
        defaultInteractionLevel: 'balanced',
        defaultComplexityBias: 'balanced',
        defaultFallbackPolicy: 'prefer-stable',
        defaultAudienceMode: 'general',
        defaultDensityMode: 'balanced',
        defaultMotionMode: 'guided',
        defaultAddonPolicy: 'auto',
        defaultPresetKey: 'teach-clearly',
        lastUsedForm: {
            goal: 'explain',
            family: 'comparison',
            rendererStrategy: 'ai-recommended',
            theme: '[표준 기본]',
            interactionLevel: 'balanced',
            complexityBias: 'balanced',
            fallbackPolicy: 'prefer-stable',
            audienceMode: 'general',
            densityMode: 'balanced',
            motionMode: 'guided',
            addonPolicy: 'auto',
            useAiRecommendedProfile: false,
            presetKey: 'teach-clearly',
            libraries: []
        },
        batchGenerationSize: 1
    };
}

function normalizeVisualizationSettings(settings = {}) {
    const mergedSettings = {
        ...getDefaultVisualizationSettings(),
        ...(settings || {})
    };

    return {
        autoGenerateOnLoad: !!mergedSettings.autoGenerateOnLoad,
        educationalMode: !!mergedSettings.educationalMode,
        worldsimMode: !!mergedSettings.worldsimMode,
        preferHighContrast: mergedSettings.preferHighContrast !== false,
        preferExportSafe: mergedSettings.preferExportSafe !== false,
        rememberLastVisualizationForm: mergedSettings.rememberLastVisualizationForm !== false,
        // AI recommendation is no longer a global default-on preference.
        // It can only reappear through remembered last-used form state.
        defaultUseAiRecommendedProfile: false,
        defaultGoal: typeof mergedSettings.defaultGoal === 'string' && mergedSettings.defaultGoal ? mergedSettings.defaultGoal : 'explain',
        defaultFamily: typeof mergedSettings.defaultFamily === 'string' && mergedSettings.defaultFamily ? mergedSettings.defaultFamily : 'comparison',
        defaultRendererStrategy: typeof mergedSettings.defaultRendererStrategy === 'string' && mergedSettings.defaultRendererStrategy ? mergedSettings.defaultRendererStrategy : 'ai-recommended',
        defaultTheme: typeof mergedSettings.defaultTheme === 'string' && mergedSettings.defaultTheme ? mergedSettings.defaultTheme : '[표준 기본]',
        defaultInteractionLevel: typeof mergedSettings.defaultInteractionLevel === 'string' && mergedSettings.defaultInteractionLevel ? mergedSettings.defaultInteractionLevel : 'balanced',
        defaultComplexityBias: typeof mergedSettings.defaultComplexityBias === 'string' && mergedSettings.defaultComplexityBias ? mergedSettings.defaultComplexityBias : 'balanced',
        defaultFallbackPolicy: typeof mergedSettings.defaultFallbackPolicy === 'string' && mergedSettings.defaultFallbackPolicy ? mergedSettings.defaultFallbackPolicy : 'prefer-stable',
        defaultAudienceMode: typeof mergedSettings.defaultAudienceMode === 'string' && mergedSettings.defaultAudienceMode ? mergedSettings.defaultAudienceMode : 'general',
        defaultDensityMode: typeof mergedSettings.defaultDensityMode === 'string' && mergedSettings.defaultDensityMode ? mergedSettings.defaultDensityMode : 'balanced',
        defaultMotionMode: typeof mergedSettings.defaultMotionMode === 'string' && mergedSettings.defaultMotionMode ? mergedSettings.defaultMotionMode : 'guided',
        defaultAddonPolicy: typeof mergedSettings.defaultAddonPolicy === 'string' && mergedSettings.defaultAddonPolicy ? mergedSettings.defaultAddonPolicy : 'auto',
        defaultPresetKey: typeof mergedSettings.defaultPresetKey === 'string' && mergedSettings.defaultPresetKey ? mergedSettings.defaultPresetKey : 'teach-clearly',
        lastUsedForm: {
            goal: typeof mergedSettings.lastUsedForm?.goal === 'string' && mergedSettings.lastUsedForm.goal ? mergedSettings.lastUsedForm.goal : 'explain',
            family: typeof mergedSettings.lastUsedForm?.family === 'string' && mergedSettings.lastUsedForm.family ? mergedSettings.lastUsedForm.family : 'comparison',
            rendererStrategy: typeof mergedSettings.lastUsedForm?.rendererStrategy === 'string' && mergedSettings.lastUsedForm.rendererStrategy ? mergedSettings.lastUsedForm.rendererStrategy : 'ai-recommended',
            theme: typeof mergedSettings.lastUsedForm?.theme === 'string' && mergedSettings.lastUsedForm.theme ? mergedSettings.lastUsedForm.theme : '[표준 기본]',
            interactionLevel: typeof mergedSettings.lastUsedForm?.interactionLevel === 'string' && mergedSettings.lastUsedForm.interactionLevel ? mergedSettings.lastUsedForm.interactionLevel : 'balanced',
            complexityBias: typeof mergedSettings.lastUsedForm?.complexityBias === 'string' && mergedSettings.lastUsedForm.complexityBias ? mergedSettings.lastUsedForm.complexityBias : 'balanced',
            fallbackPolicy: typeof mergedSettings.lastUsedForm?.fallbackPolicy === 'string' && mergedSettings.lastUsedForm.fallbackPolicy ? mergedSettings.lastUsedForm.fallbackPolicy : 'prefer-stable',
            audienceMode: typeof mergedSettings.lastUsedForm?.audienceMode === 'string' && mergedSettings.lastUsedForm.audienceMode ? mergedSettings.lastUsedForm.audienceMode : 'general',
            densityMode: typeof mergedSettings.lastUsedForm?.densityMode === 'string' && mergedSettings.lastUsedForm.densityMode ? mergedSettings.lastUsedForm.densityMode : 'balanced',
            motionMode: typeof mergedSettings.lastUsedForm?.motionMode === 'string' && mergedSettings.lastUsedForm.motionMode ? mergedSettings.lastUsedForm.motionMode : 'guided',
            addonPolicy: typeof mergedSettings.lastUsedForm?.addonPolicy === 'string' && mergedSettings.lastUsedForm.addonPolicy ? mergedSettings.lastUsedForm.addonPolicy : 'auto',
            // AI recommendation should never silently restore as a remembered default.
            useAiRecommendedProfile: false,
            presetKey: typeof mergedSettings.lastUsedForm?.presetKey === 'string' && mergedSettings.lastUsedForm.presetKey ? mergedSettings.lastUsedForm.presetKey : 'teach-clearly',
            libraries: Array.isArray(mergedSettings.lastUsedForm?.libraries) ? mergedSettings.lastUsedForm.libraries.filter((item) => typeof item === 'string' && item) : []
        },
        // Visualization generation is intentionally enforced as single-item only.
        batchGenerationSize: 1
    };
}

function normalizePresetUsage(preset) {
    if (!preset.tokenUsage) {
        preset.tokenUsage = {
            prompt: 0,
            completion: 0,
            todayRequests: 0,
            totalRequests: 0,
            lastRequestDate: null,
            dailyModelUsage: {},
            todayPromptTokens: 0,
            todayCompletionTokens: 0
        };
    }

    if (preset.tokenUsage.todayRequests === undefined) preset.tokenUsage.todayRequests = 0;
    if (preset.tokenUsage.totalRequests === undefined) preset.tokenUsage.totalRequests = 0;
    if (preset.tokenUsage.lastRequestDate === undefined) preset.tokenUsage.lastRequestDate = null;
    if (preset.tokenUsage.dailyModelUsage === undefined) preset.tokenUsage.dailyModelUsage = {};
    if (preset.tokenUsage.todayPromptTokens === undefined) preset.tokenUsage.todayPromptTokens = 0;
    if (preset.tokenUsage.todayCompletionTokens === undefined) preset.tokenUsage.todayCompletionTokens = 0;
    if (!preset.maxOutputTokens) preset.maxOutputTokens = 65536;
    if (preset.temperature === undefined) preset.temperature = 1;
    if (preset.topP === undefined) preset.topP = 0.95;
    if (preset.useGrounding === undefined) preset.useGrounding = false;
    if (preset.chatHistoryLimit === undefined) preset.chatHistoryLimit = 20;
    if (preset.autoCompactEnabled === undefined) preset.autoCompactEnabled = true;
    if (preset.thinkingBudget === undefined) preset.thinkingBudget = null;
}

function readLocalApiSettingsFromStorage() {
    try {
        const rawPresets = localStorage.getItem(LOCAL_API_PRESETS_STORAGE_KEY);
        const rawActiveId = localStorage.getItem(LOCAL_ACTIVE_PRESET_STORAGE_KEY);
        return {
            hasStoredValue: rawPresets !== null || rawActiveId !== null,
            apiPresets: rawPresets ? JSON.parse(rawPresets) : [],
            activePresetId: rawActiveId || null
        };
    } catch (error) {
        console.warn("Failed to read local API settings storage.", error);
        return {
            hasStoredValue: false,
            apiPresets: [],
            activePresetId: null
        };
    }
}

function hydrateLocalApiSettingsFromStorage() {
    if (!isLocalRuntimeMode()) return;

    const stored = readLocalApiSettingsFromStorage();
    userApiSettings.apiPresets = Array.isArray(stored.apiPresets) ? stored.apiPresets : [];
    userApiSettings.activePresetId = stored.activePresetId || null;
    userApiSettings.apiPresets.forEach(normalizePresetUsage);
}

function persistLocalApiSettingsToStorage() {
    if (!isLocalRuntimeMode()) return;

    try {
        localStorage.setItem(LOCAL_API_PRESETS_STORAGE_KEY, JSON.stringify(userApiSettings.apiPresets || []));
        if (userApiSettings.activePresetId) {
            localStorage.setItem(LOCAL_ACTIVE_PRESET_STORAGE_KEY, userApiSettings.activePresetId);
        } else {
            localStorage.removeItem(LOCAL_ACTIVE_PRESET_STORAGE_KEY);
        }
    } catch (error) {
        console.warn("Failed to persist local API settings storage.", error);
    }
}

function applyLoadedUserSettings(settings) {
    const defaultVisionSettings = getDefaultVisionSettings();
    const isLocalMode = isLocalRuntimeMode();

    userApiSettings.apiPresets = settings.apiPresets || [];
    userApiSettings.activePresetId = settings.activePresetId || null;
    userApiSettings.universalModelSettings = settings.universalModelSettings || getDefaultUniversalModelSettings();

    if (typeof userApiSettings.universalModelSettings.useGrounding !== 'boolean') {
        userApiSettings.universalModelSettings.useGrounding = false;
    }
    if (userApiSettings.universalModelSettings.chatHistoryLimit === undefined) {
        userApiSettings.universalModelSettings.chatHistoryLimit = 20;
    }
    if (userApiSettings.universalModelSettings.autoCompactEnabled === undefined) {
        userApiSettings.universalModelSettings.autoCompactEnabled = true;
    }

    if (settings.apiSettings && settings.apiSettings.apiKey && userApiSettings.apiPresets.length === 0) {
        const migratedPreset = {
            id: `preset-${Date.now()}`,
            name: `[Legacy] ${settings.apiSettings.provider || 'API Key'}`,
            key: settings.apiSettings.apiKey,
            provider: settings.apiSettings.provider,
            availableModels: settings.apiSettings.availableModels || [],
            selectedModel: settings.apiSettings.selectedModel,
            tokenUsage: {
                prompt: settings.apiSettings.tokenUsage?.prompt || 0,
                completion: settings.apiSettings.tokenUsage?.completion || 0,
                todayRequests: 0,
                totalRequests: 0,
                lastRequestDate: null,
                dailyModelUsage: {},
                todayPromptTokens: 0,
                todayCompletionTokens: 0
            },
            maxOutputTokens: settings.apiSettings.maxOutputTokens || 65536,
            temperature: 1,
            topP: 0.95,
            chatHistoryLimit: 20,
            autoCompactEnabled: true,
            thinkingBudget: null
        };
        userApiSettings.apiPresets.push(migratedPreset);
        userApiSettings.activePresetId = migratedPreset.id;
        trace("System", "Migration.apiKeyToPreset", { newId: migratedPreset.id });
    }

    if (isLocalMode) {
        const storedLocalSettings = readLocalApiSettingsFromStorage();
        if (storedLocalSettings.hasStoredValue) {
            hydrateLocalApiSettingsFromStorage();
        } else if (userApiSettings.apiPresets.length > 0 || userApiSettings.activePresetId) {
            persistLocalApiSettingsToStorage();
        }
    }

    userApiSettings.apiPresets.forEach(normalizePresetUsage);
    userApiSettings.panelStates = settings.panelStates || {};

    if (settings.visionWeaverSettings) {
        const savedPresets = settings.visionWeaverSettings.presets || {};
        const mergedPresets = { ...defaultVisionSettings.presets };
        Object.keys(mergedPresets).forEach(key => {
            if (savedPresets[key]) {
                mergedPresets[key] = { ...mergedPresets[key], ...savedPresets[key] };
            }
        });

        userApiSettings.visionWeaverSettings = {
            ...defaultVisionSettings,
            ...settings.visionWeaverSettings,
            autoGenerateMode: settings.visionWeaverSettings.autoGenerateMode === 'off' ? 'off' : 'quick',
            presets: mergedPresets,
            disableTextOutput: settings.visionWeaverSettings.disableTextOutput || false,
            rememberOptions: settings.visionWeaverSettings.rememberOptions || false,
            rememberedOptions: settings.visionWeaverSettings.rememberedOptions || {}
        };
        delete userApiSettings.visionWeaverSettings.refineApi;
    } else {
        userApiSettings.visionWeaverSettings = defaultVisionSettings;
    }

    userApiSettings.visualizationSettings = normalizeVisualizationSettings(settings.visualizationSettings);

    if (settings.activePromptId) {
        activePromptId = settings.activePromptId;
    }

    const theme = settings.theme || 'dark';
    document.body.classList.toggle('dark-mode', theme === 'dark');
    if (window.toastEditorInstance) {
        window.toastEditorInstance.setTheme(theme === 'dark' ? 'dark' : 'default');
    }
}

async function loadUserSettingsFromFirebase() {
    if (!userSettingsRef) return;

    try {
        const doc = await userSettingsRef.get();
        if (doc.exists) {
            const loadedSettings = doc.data() || {};
            applyLoadedUserSettings(loadedSettings);
            trace("System", "loadUserSettings.success", {
                activePresetId: userApiSettings.activePresetId?.substring(0, 5),
                theme: document.body.classList.contains('dark-mode') ? 'dark' : 'light',
                promptId: activePromptId?.substring(0, 5) || 'default'
            });
            if (Object.prototype.hasOwnProperty.call(loadedSettings, 'immersionMode')) {
                trace("Migration", "ImmersionModeSettingRemoved");
                await saveUserSettingsToFirebase(true);
            }
        } else {
            trace("System", "loadUserSettings.default");
            applyLoadedUserSettings({});
            userApiSettings.visionWeaverSettings = getDefaultVisionSettings();
            userApiSettings.visualizationSettings = normalizeVisualizationSettings();
            userApiSettings.apiPresets = [];
            userApiSettings.activePresetId = null;
            userApiSettings.universalModelSettings = getDefaultUniversalModelSettings();

            if (isLocalRuntimeMode()) {
                hydrateLocalApiSettingsFromStorage();
            }

            await saveUserSettingsToFirebase(true);
        }
    } catch (error) {
        console.error("Error loading user settings from Firebase:", error);
        trace("System", "loadUserSettings.error", { error: error.message }, {}, "ERROR");
    }

    updateChatHeaderModelSelector();
}

async function saveUserSettingsToFirebase(isSilent = false) {
    if (!userSettingsRef) return;

    const currentTheme = document.body.classList.contains('dark-mode') ? 'dark' : 'light';
    const isLocalMode = isLocalRuntimeMode();

    userApiSettings.visualizationSettings = normalizeVisualizationSettings(userApiSettings.visualizationSettings);

    if (isLocalMode) {
        persistLocalApiSettingsToStorage();
    }

    const settingsToSave = {
        apiPresets: isLocalMode ? firebase.firestore.FieldValue.delete() : userApiSettings.apiPresets,
        activePresetId: isLocalMode ? firebase.firestore.FieldValue.delete() : userApiSettings.activePresetId,
        panelStates: userApiSettings.panelStates,
        visionWeaverSettings: userApiSettings.visionWeaverSettings,
        visualizationSettings: userApiSettings.visualizationSettings,
        theme: currentTheme,
        activePromptId: activePromptId,
        immersionMode: firebase.firestore.FieldValue.delete(),
        universalModelSettings: userApiSettings.universalModelSettings || getDefaultUniversalModelSettings(),
        apiSettings: firebase.firestore.FieldValue.delete()
    };

    try {
        await userSettingsRef.set(settingsToSave, { merge: true });
        if (!isSilent) {
            const activePreset = userApiSettings.apiPresets.find(p => p.id === userApiSettings.activePresetId);
            trace("Firestore", "saveUserSettings.success", {
                activeModel: activePreset?.selectedModel || 'default',
                theme: settingsToSave.theme,
                runtime: isLocalMode ? 'local' : 'canvas'
            });
        }
    } catch (error) {
        console.error("Error saving user settings to Firebase:", error);
        if (!isSilent) {
            trace("Firestore", "saveUserSettings.error", { error: error.message }, {}, "ERROR");
        }
    }
}
