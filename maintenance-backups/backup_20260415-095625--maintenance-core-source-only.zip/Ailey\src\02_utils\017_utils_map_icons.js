/* --- Ailey & Bailey Canvas --- */
// File: 017_utils_map_icons.js
// Version: 1.1 (Color Update)
// Description: Defines a custom, dependency-free SVG map marker icon for Leaflet.js. Color changed to red.

const defaultIcon = L.divIcon({
    // [HCA] The icon's HTML is an inline SVG, removing any external image file dependencies.
    html: `
        <svg width="30" height="42" viewBox="0 0 30 42" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(2px 2px 3px rgba(0,0,0,0.3));">
            <path d="M15 0C8.373 0 3 5.373 3 12C3 21.05 15 42 15 42S27 21.05 27 12C27 5.373 21.627 0 15 0Z" fill="#DC3545"/>
            <circle cx="15" cy="12" r="5" fill="white"/>
        </svg>
    `,
    className: 'custom-leaflet-marker-icon', // Assign a class for potential future styling.
    iconSize: [30, 42],      // Size of the icon
    iconAnchor: [15, 42],     // Point of the icon which will correspond to marker's location
    popupAnchor: [0, -45]     // Point from which the popup should open relative to the iconAnchor
});