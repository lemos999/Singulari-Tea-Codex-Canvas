/* --- Ailey & Bailey Canvas --- */
// File: 232_chat_prompt_manager.js
// Version: 1.0 (Refactored from 230_chat_app.js)
// Description: Handles all logic for the prompt template manager UI.

async function handleSaveTemplate() {
    if (!templateNameInput || !templatePromptTextarea) return;
    const name = templateNameInput.value.trim();
    const promptText = templatePromptTextarea.value.trim();
    if (!name) {
        alert("템플릿 이름을 입력해주세요.");
        templateNameInput.focus();
        return;
    }
    const data = { name, promptText };
    if (selectedTemplateId) {
        const existingTemplate = promptTemplatesCache.find(t => t.id === selectedTemplateId);
        if (existingTemplate.isDefault) {
            alert("기본 템플릿은 수정할 수 없습니다.");
            return;
        }
        await updatePromptTemplate(selectedTemplateId, data);
    } else {
        const newTemplateId = await addPromptTemplate({ ...data, isDefault: false });
        if (newTemplateId) selectTemplate(newTemplateId);
    }
}

function handleDeleteTemplate() {
    if (!selectedTemplateId) return;
    const template = promptTemplatesCache.find(t => t.id === selectedTemplateId);
    if (!template || template.isDefault) {
        alert("기본 템플릿은 삭제할 수 없습니다.");
        return;
    }
    showModal(`템플릿 "${template.name}"을(를) 정말 삭제하시겠습니까?`, async () => {
        await deletePromptTemplate(selectedTemplateId);
        selectTemplate(null);
    });
}

function selectTemplate(templateId) {
    selectedTemplateId = templateId;
    if (templateId) {
        const template = promptTemplatesCache.find(t => t.id === templateId);
        if (template) {
            templateNameInput.value = template.name || '';
            const isDefault = template.isDefault || false;
            
            if (isDefault) {
                templatePromptTextarea.value = "[기본 템플릿의 내용은 보호되어 있습니다.]";
            } else {
                templatePromptTextarea.value = template.promptText || '';
            }

            deleteTemplateBtn.disabled = isDefault;
            saveTemplateBtn.disabled = isDefault;
            templateNameInput.disabled = isDefault;
            templatePromptTextarea.disabled = isDefault;
        } else {
            selectedTemplateId = null;
        }
    } else {
        templateNameInput.value = '';
        templatePromptTextarea.value = '';
        deleteTemplateBtn.disabled = true;
        saveTemplateBtn.disabled = false;
        templateNameInput.disabled = false;
        templatePromptTextarea.disabled = false;
    }
    renderPromptManager();
}

function handleAddNewTemplateClick() {
    selectTemplate(null);
    if(templateNameInput) templateNameInput.focus();
}

function selectTemplate(templateId) {
    selectedTemplateId = templateId;
    const editorTitle = document.getElementById('template-editor-title');
    const editorStatus = document.getElementById('template-editor-status');

    if (templateId) {
        const template = promptTemplatesCache.find((t) => t.id === templateId);
        if (template) {
            templateNameInput.value = template.name || '';
            const isDefault = template.isDefault || false;

            if (isDefault) {
                templatePromptTextarea.value = '[기본 템플릿의 내용은 보호되어 있습니다.]';
            } else {
                templatePromptTextarea.value = template.promptText || '';
            }

            deleteTemplateBtn.disabled = isDefault;
            saveTemplateBtn.disabled = isDefault;
            templateNameInput.disabled = isDefault;
            templatePromptTextarea.disabled = isDefault;

            if (editorTitle) {
                editorTitle.textContent = isDefault ? '기본 템플릿 보기' : '템플릿 편집';
            }
            if (editorStatus) {
                editorStatus.textContent = isDefault
                    ? '기본 템플릿은 읽기 전용입니다. 이름과 안내 문구는 보호되고 선택만 가능합니다.'
                    : '사용자 템플릿은 이름과 프롬프트를 바로 수정하고 저장할 수 있습니다.';
            }
        } else {
            selectedTemplateId = null;
        }
    } else {
        templateNameInput.value = '';
        templatePromptTextarea.value = '';
        deleteTemplateBtn.disabled = true;
        saveTemplateBtn.disabled = false;
        templateNameInput.disabled = false;
        templatePromptTextarea.disabled = false;

        if (editorTitle) {
            editorTitle.textContent = '새 템플릿 만들기';
        }
        if (editorStatus) {
            editorStatus.textContent = '새 역할, 톤, 작업 규칙을 저장해 빠르게 불러올 수 있습니다.';
        }
    }

    renderPromptManager();
}
