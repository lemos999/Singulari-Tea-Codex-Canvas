const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Dependency Auto-Manager Protocol
function ensureDependencies(dependencies) {
    console.log('Checking for required dependencies...');
    const missingDependencies = dependencies.filter(dep => {
        try {
            require.resolve(dep);
            return false;
        } catch (e) {
            return true;
        }
    });

    if (missingDependencies.length > 0) {
        console.log(`Missing dependencies found: ${missingDependencies.join(', ')}.`);
        console.log('Attempting to install all required dependencies to ensure consistency...');
        try {
            // Ensure package.json exists to avoid npm errors in certain environments.
            const packageJsonPath = path.join(__dirname, 'package.json');
            if (!fs.existsSync(packageJsonPath)) {
                console.log('package.json not found. Creating a minimal one to proceed...');
                // Using a hardcoded, valid package name avoids errors from directory names with special characters.
                const minimalPackageJson = {
                    name: "codex-build-env",
                    version: "1.0.0",
                    description: "A temporary environment for bundling Codex assets.",
                    private: true
                };
                fs.writeFileSync(packageJsonPath, JSON.stringify(minimalPackageJson, null, 2));
                console.log('package.json created successfully.');
            }
            
            // [FIX] Install ALL dependencies if any are missing to prevent npm from pruning existing ones.
            const command = `npm install ${dependencies.join(' ')} --save-dev`;
            console.log(`> ${command}`);
            execSync(command, { stdio: 'inherit' });
            console.log('Dependencies installed successfully.');
            console.log('Re-requiring dependencies...');
        } catch (error) {
            console.error('Failed to install dependencies automatically.');
            console.error('Please run the following command manually in your terminal:');
            console.error(`npm install ${dependencies.join(' ')} --save-dev`);
            process.exit(1);
        }
    } else {
        console.log('All dependencies are already installed.');
    }
}

// Ensure all required build tools are installed before requiring them
ensureDependencies(['terser', 'postcss', 'cssnano', 'esbuild']);

const Terser = require('terser');
const postcss = require('postcss');
const cssnano = require('cssnano');
const esbuild = require('esbuild');

const vendorDir = path.join(__dirname, 'vendor');
const distDirForKatex = path.join(__dirname, 'dist');
const srcBaseDirs = [path.join(__dirname, 'src/00_shell'), path.join(__dirname, 'src')];
const srcCssDir = path.join(__dirname, 'src_css');
const bundleDir = path.join(__dirname, 'bundle');

const bundleJsPath = path.join(bundleDir, 'main.js');
const bundleCssPath = path.join(bundleDir, 'main.css');

const VENDOR_LOAD_ORDER = [
    'firebase-app-compat.js',
    'firebase-auth-compat.js',
    'firebase-firestore-compat.js',
    'toastui-editor-all.min.js',
    'prism.min.js',
    'toastui-editor-plugin-code-syntax-highlight-all.min.js',
    'katex.min.js',
    'marked.min.js',
    'leaflet.js' // [ADDED] Include Leaflet.js library
];

function getAllAppFiles(dirPath, arrayOfFiles) {
    const files = fs.readdirSync(dirPath);
    arrayOfFiles = arrayOfFiles || [];
    files.forEach(file => {
        const fullPath = path.join(dirPath, file);
        if (fs.statSync(fullPath).isDirectory()) {
            if (path.basename(fullPath) !== '00_shell') {
                arrayOfFiles = getAllAppFiles(fullPath, arrayOfFiles);
            }
        } else {
            if (path.extname(fullPath) === '.js') {
                arrayOfFiles.push(fullPath);
            }
        }
    });
    return arrayOfFiles;
}

function isShellSourceFile(filePath) {
    const relativePath = path.relative(__dirname, filePath).replace(/\\/g, '/');
    return relativePath.startsWith('src/00_shell/');
}

function isLikelyESModule(filePath, content) {
    if (isShellSourceFile(filePath)) {
        return false;
    }

    const esmSyntaxPattern = /^\s*(import\s+(?:[\w*{}\s,$]+\s+from\s+)?['"][^'"]+['"]\s*;?|export\s+(?:default|const|function|class|\{))/m;
    return esmSyntaxPattern.test(content);
}

async function bundleJsFiles() {
    console.log(`Starting bundling for .JS files...`);
    let bundledContent = `/* Auto-generated bundle from ${new Date().toISOString()} */\n\n`;
    console.log('Files will be bundled in this order:');

    console.log('--- EMBEDDED STYLES ---');
    const katexStylePath = path.join(distDirForKatex, 'katex-styles.js');
    if (fs.existsSync(katexStylePath)) {
        console.log(` - dist/katex-styles.js`);
        bundledContent += fs.readFileSync(katexStylePath, 'utf8') + '\n\n';
    } else {
        console.error('[ERROR] katex-styles.js not found! Please run setup_katex_js_style.js first.');
        process.exit(1);
    }

    console.log('--- VENDOR LIBRARIES ---');
    VENDOR_LOAD_ORDER.forEach(fileName => {
        const filePath = path.join(vendorDir, fileName);
        if (fs.existsSync(filePath)) {
            console.log(` - vendor/${fileName}`);
            const fileContent = fs.readFileSync(filePath, 'utf8');
            bundledContent += `/* --- Vendor: ${fileName} --- */\n`;
            bundledContent += fileContent + '\n\n';
        } else {
            console.warn(` - [WARNING] Vendor file not found: ${fileName}`);
        }
    });

    console.log('--- APPLICATION SOURCE ---');
    let appFiles = [];
    srcBaseDirs.forEach(dir => {
        if (fs.existsSync(dir)) appFiles.push(...getAllAppFiles(dir));
    });
    const uniqueAppFiles = [...new Set(appFiles)];
    uniqueAppFiles.sort((a, b) => path.basename(a).localeCompare(path.basename(b), undefined, { numeric: true }));

    // --- ES Module Bundling Logic ---
    const esmFiles = [];
    const regularFiles = [];

    uniqueAppFiles.forEach(file => {
        const content = fs.readFileSync(file, 'utf8');
        if (isLikelyESModule(file, content)) {
            esmFiles.push(file);
        } else {
            regularFiles.push(file);
        }
    });

    // Bundle regular files first
    regularFiles.forEach(file => {
        const relativePath = path.relative(__dirname, file);
        console.log(` - ${relativePath} (Regular)`);
        const fileContent = fs.readFileSync(file, 'utf8');
        bundledContent += `/* --- Source: ${relativePath} --- */\n`;
        bundledContent += fileContent + '\n\n';
    });

    // Bundle ES modules using esbuild
    if (esmFiles.length > 0) {
        console.log('\n--- PRE-BUNDLING ES MODULES ---');
        esmFiles.forEach(file => console.log(` - ${path.relative(__dirname, file)} (ESM)`));
        
        // [FIX] Create an in-memory entry point that imports all other ESM files.
        // This provides a single, unambiguous entry for esbuild to bundle into one output.
        const stdinContent = esmFiles.map(file => `import '${file.replace(/\\/g, '/')}';`).join('\n');

        try {
            const esmBundleResult = esbuild.buildSync({
                stdin: {
                    contents: stdinContent,
                    resolveDir: __dirname,
                    loader: 'js',
                },
                bundle: true,
                write: false,
                format: 'iife',
            });
            const esmBundledCode = esmBundleResult.outputFiles[0].text;
            bundledContent += `/* --- Bundled ES Modules --- */\n`;
            bundledContent += esmBundledCode + '\n\n';
            console.log('✅ ES Modules bundled successfully.');
        } catch (e) {
            console.error('❌ ESBuild bundling failed:', e);
            process.exit(1);
        }
    }
    // --- End ES Module Logic ---


    console.log('\n--- MINIFYING & OBFUSCATING JS ---');
    console.log('Applying Terser to reduce file size and protect the code...');
    const terserOptions = {
        compress: {
            drop_console: true,
        },
        mangle: {
            reserved: [
                'renderAppShell',
                'firebase',
                'toastui',
                'marked',
                'Prism',
                'katex',
                'katex_css_data',
                'L' // [ADDED] Reserve Leaflet.js global object
            ]
        }
    };
    
    const result = await Terser.minify(bundledContent, terserOptions);

    if (result.error) {
        console.error('Terser minification failed:', result.error);
        return;
    }

    if (!fs.existsSync(bundleDir)) fs.mkdirSync(bundleDir, { recursive: true });
    fs.writeFileSync(bundleJsPath, result.code);
    console.log(`\n✅ Successfully created and obfuscated JS bundle at: ${bundleJsPath}\n`);
}

async function bundleCssFiles() {
    console.log(`Starting bundling for .CSS files...`);
    // This logic automatically picks up any .css files in the src_css directory
    const cssFiles = fs.readdirSync(srcCssDir)
        .filter(f => f.endsWith('.css'))
        .map(f => path.join(srcCssDir, f));
        
    cssFiles.sort((a, b) => path.basename(a).localeCompare(path.basename(b), undefined, { numeric: true }));
    
    let bundledContent = `/* Auto-generated bundle from ${new Date().toISOString()} */\n\n`;
    console.log('Files will be bundled in this order:');
    cssFiles.forEach(file => {
        const relativePath = path.relative(__dirname, file);
        if (fs.existsSync(file)) {
             console.log(` - ${relativePath}`);
             bundledContent += `/* --- Source: ${relativePath} --- */\n`;
             bundledContent += fs.readFileSync(file, 'utf8') + '\n\n';
        } else {
             console.warn(` - [WARNING] CSS file not found: ${relativePath}`);
        }
    });

    console.log('\n--- MINIFYING CSS ---');
    console.log('Applying postcss and cssnano to reduce file size...');
    const result = await postcss([cssnano]).process(bundledContent, { from: undefined });

    if (!fs.existsSync(bundleDir)) fs.mkdirSync(bundleDir, { recursive: true });
    fs.writeFileSync(bundleCssPath, result.css);
    console.log(`\n✅ Successfully created and minified CSS bundle at: ${bundleCssPath}\n`);
}

async function main() {
    console.log('--- Running Bundler Script (v9 - Accordion Map) ---');
    await bundleJsFiles();
    await bundleCssFiles();
    console.log('--- Bundler Script Finished ---');
}

main();
