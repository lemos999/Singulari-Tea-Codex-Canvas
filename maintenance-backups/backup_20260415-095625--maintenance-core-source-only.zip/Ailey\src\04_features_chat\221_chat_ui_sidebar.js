/* --- Ailey & Bailey Canvas --- */
// File: 221_chat_ui_sidebar.js
// Version: 5.0 (Clean Sidebar Surface)
// Description: Renders the chat sidebar with projects, grouped sessions, and clear Korean labels.

function renderSidebarContent() {
    if (!sessionListContainer) return;

    const searchTerm = (searchSessionsInput?.value || '').toLowerCase();
    sessionListContainer.innerHTML = '';
    const fragment = document.createDocumentFragment();

    if (currentSessionId === 'temporary-chat') {
        fragment.appendChild(createSessionItem({ id: 'temporary-chat', title: '임시 대화' }));
    }

    const projectsToDisplay = localProjectsCache
        .filter(project => {
            if (!searchTerm) return true;
            return (project.name || '').toLowerCase().includes(searchTerm)
                || localChatSessionsCache.some(session => session.projectId === project.id && (session.title || '').toLowerCase().includes(searchTerm));
        })
        .sort((a, b) => (b.updatedAt?.toMillis?.() || 0) - (a.updatedAt?.toMillis?.() || 0));

    if (projectsToDisplay.length > 0) {
        const header = document.createElement('div');
        header.className = 'session-group-header';
        header.textContent = '프로젝트';
        fragment.appendChild(header);

        projectsToDisplay.forEach(project => {
            fragment.appendChild(createProjectContainer(project, searchTerm));
        });
    }

    const unassignedSessions = localChatSessionsCache
        .filter(session => !session.projectId)
        .filter(session => !searchTerm || (session.title || '새 대화').toLowerCase().includes(searchTerm));

    if (unassignedSessions.length > 0) {
        const header = document.createElement('div');
        header.className = 'session-group-header';
        header.textContent = '일반 대화';
        fragment.appendChild(header);

        const groupedSessions = unassignedSessions.reduce((accumulator, session) => {
            const groupInfo = getRelativeDateGroup(session.updatedAt || session.createdAt, session.isPinned);
            if (!accumulator[groupInfo.label]) {
                accumulator[groupInfo.label] = { key: groupInfo.key, items: [] };
            }
            accumulator[groupInfo.label].items.push(session);
            return accumulator;
        }, {});

        Object.keys(groupedSessions)
            .sort((a, b) => groupedSessions[a].key - groupedSessions[b].key)
            .forEach(label => {
                const dateHeader = document.createElement('div');
                dateHeader.className = 'date-group-header';
                dateHeader.textContent = label;
                fragment.appendChild(dateHeader);

                groupedSessions[label].items
                    .sort((a, b) => (b.updatedAt?.toMillis?.() || 0) - (a.updatedAt?.toMillis?.() || 0))
                    .forEach(session => fragment.appendChild(createSessionItem(session)));
            });
    }

    sessionListContainer.appendChild(fragment);
}

function createProjectContainer(project, searchTerm) {
    const projectContainer = document.createElement('div');
    projectContainer.className = 'project-container';
    projectContainer.dataset.projectId = project.id;

    const projectHeader = document.createElement('div');
    projectHeader.className = 'project-header';

    const createdAt = project.createdAt?.toDate?.()?.toLocaleString('ko-KR', { dateStyle: 'short', timeStyle: 'short' }) || '정보 없음';
    const updatedAt = project.updatedAt?.toDate?.()?.toLocaleString('ko-KR', { dateStyle: 'short', timeStyle: 'short' }) || createdAt;
    projectHeader.title = `생성: ${createdAt}\n마지막 수정: ${updatedAt}`;
    projectHeader.innerHTML = `
        <svg class="project-toggle-icon ${project.isExpanded ? 'expanded' : ''}" viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z" /></svg>
        <span class="project-icon">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M4,6H2V20A2,2 0 0,0 4,22H18V20H4V6M20,2H8A2,2 0 0,0 6,4V16A2,2 0 0,0 8,18H20A2,2 0 0,0 22,16V4A2,2 0 0,0 20,2Z" /></svg>
        </span>
        <span class="project-title">${project.name}</span>
        <button class="project-actions-btn" title="프로젝트 메뉴">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z" /></svg>
        </button>
    `;

    const sessionsContainer = document.createElement('div');
    sessionsContainer.className = `sessions-in-project ${project.isExpanded ? 'expanded' : ''}`;

    localChatSessionsCache
        .filter(session => session.projectId === project.id)
        .filter(session => !searchTerm || (session.title || '새 대화').toLowerCase().includes(searchTerm))
        .sort((a, b) => (b.updatedAt?.toMillis?.() || 0) - (a.updatedAt?.toMillis?.() || 0))
        .forEach(session => sessionsContainer.appendChild(createSessionItem(session)));

    projectContainer.appendChild(projectHeader);
    projectContainer.appendChild(sessionsContainer);
    return projectContainer;
}

function createSessionItem(session) {
    const item = document.createElement('div');
    item.className = 'session-item';
    item.dataset.sessionId = session.id;

    if (session.id === 'temporary-chat') {
        item.classList.add('temporary');
    } else {
        item.draggable = true;
    }

    if (session.id === currentSessionId) {
        item.classList.add('active');
    }

    if (session.createdAt) {
        const createdAt = session.createdAt?.toDate?.()?.toLocaleString('ko-KR', { dateStyle: 'short', timeStyle: 'short' }) || '정보 없음';
        const updatedAt = session.updatedAt?.toDate?.()?.toLocaleString('ko-KR', { dateStyle: 'short', timeStyle: 'short' }) || createdAt;
        item.title = `생성: ${createdAt}\n마지막 수정: ${updatedAt}`;
    }

    const titleSpan = document.createElement('div');
    titleSpan.className = 'session-item-title';
    titleSpan.textContent = session.title || '새 대화';
    item.appendChild(titleSpan);

    if (pendingResponses.has(session.id) || (activeStreams[session.id] && !activeStreams[session.id].isComplete)) {
        const indicator = document.createElement('span');
        indicator.className = 'status-indicator';
        item.appendChild(indicator);
    } else if (completedButUnseenResponses.has(session.id)) {
        const indicator = document.createElement('span');
        indicator.className = 'status-indicator-complete';
        item.appendChild(indicator);
    }

    return item;
}
