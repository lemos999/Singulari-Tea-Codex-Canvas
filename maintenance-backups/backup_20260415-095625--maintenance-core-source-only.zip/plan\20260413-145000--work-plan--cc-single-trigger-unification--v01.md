Plan Type: Work Plan
Workstream: Universal canvas module single-trigger unification
Version: v01
Status: Completed
Created: 2026-04-13 14:50:00 +09:00
Last Updated: 2026-04-13 14:57:59 +09:00
Supersedes or Related Plan: Related `plan/20260413-150200--work-plan--cc-default-explanatory-quality-refinement--v01.md`
Current Completion State: Complete
Completed So Far: Backed up the active English universal module before modification; rewrote the module so `.cc` is the only public trigger; converted legacy `.ccc` into compatibility normalization rather than a separate public mode; preserved canonical `.cc` shell discipline; folded the old freestyle value into stronger interior-composition rules; strengthened active visual-support guidance; ran a fresh blind batch; observed modal-blocking failures from `visualization-placeholder`; refined the module toward end-positioned and image-first support for unstable runtimes; reran the batch and captured final screenshots
Remaining Work: No required implementation work remains in this plan. Optional future work would focus on runtime-side image resolution rather than prompt-structure unification.
Current Blockers: No planning blocker. Remaining caveat is runtime-dependent image fulfillment, which is outside the prompt module itself.
Next Step: Report the backup path, final module changes, test evidence, and remaining runtime caveat to the user

# Scoreboard

Current Score: 95.5 / 100
Score Source: provisional
Last Updated: 2026-04-13 14:57:59 +09:00
Score Rationale: The module now satisfies the new public contract and the final blind runtime batch preserved readable, high-quality `.cc` pages with active visual support. The remaining deduction comes from unresolved end-of-page image surfaces in this local runtime, not from a structural failure in the prompt module.
What Improved: `.cc` is now the only public trigger, legacy `.ccc` is normalized instead of branched, interior composition is stronger, active visual support is more assertive, and the final image-first end-placement strategy avoided the modal-blocking regression seen during the first pass.
What Remains Unsatisfactory: Some unresolved image surfaces still appear as blank support regions with carousel indicators in the local runtime instead of completed imagery.
Actions To Raise Or Maintain Score:
1. Preserve the single-trigger public contract in future edits.
2. Keep canonical `.cc` outer-shell fidelity intact.
3. Prefer image-first, end-positioned support surfaces in unstable runtimes.
4. Revisit visualization support only when the runtime path can prove it will not block the page.
5. Treat runtime image fulfillment as the next likely improvement area.

Score History:
1. 2026-04-13 14:50:00 +09:00 | 42 | provisional | New workstream opened for `.ccc` removal and `.cc` single-trigger unification after explicit user direction.
2. 2026-04-13 14:57:59 +09:00 | 95.5 | final | `.cc` became the only public trigger, `.ccc` became compatibility normalization, and the final end-positioned image-first runtime batch passed without modal-blocked pages.

# Objective

Redesign the universal canvas module so that `.cc` becomes the single public trigger while preserving the strongest parts of the existing design. The resulting module should no longer expose `.ccc` as a separate command path. Instead, it should let `.cc` absorb the relevant quality advantages that `.ccc` previously represented, but only in ways that remain compatible with the canonical `.cc` shell and with host-native preservation.

This is not a request to simply delete `.ccc` text. It is a request to collapse the command surface while keeping or improving output quality. The single-trigger model should still preserve exact shell discipline, host-native meaning, and rich-host safety, while giving generic explanations and other host-light cases access to stronger visual composition and more active visual-support behavior than the old conservative `.cc` path allowed.

# Confirmed Facts

The user explicitly asked to remove `.ccc` from the command surface and unify it into `.cc`.

The user also explicitly asked that visual materials and image or visualization prompts be included more actively, not only as rare optional embellishments.

The current module still contains a distinct `.ccc` section, distinct `.ccc` shell authority, and a dual-trigger explanation at the top of the file.

The current `.cc` branch already has a strong explanatory fallback, but it remains somewhat cautious about visuals because the local runtime has shown placeholder-related instability.

# Working Assumptions

The safest assumption is that the user still wants the canonical `.cc` shell to remain the public foundation. “`.cc` based with `.ccc` freestyle absorbed” is best interpreted as preserving the exact `.cc` outer shell while enriching the internal composition strategy rather than restoring full-shell redesign under the `.cc` name.

The safest assumption is also that the user wants `.cc` to be the only command they need to teach or distribute. Legacy `.ccc` behavior should not remain exposed as an equal public mode. For compatibility, the module may mention a legacy tolerance rule if needed, but the designed public contract should be “one trigger only.”

The safest assumption for visuals is that the user wants them encouraged and authored more actively, but not at the cost of obviously broken or modal-dominated pages. Therefore the redesign should encourage visual support strongly while still containing a fallback when the runtime path appears unsafe.

# Design Intent

The single-trigger design should have three layers.

1. Trigger layer
There is one public canvas trigger: `.cc`. The module should treat `.cc` as the sole intended trigger. If legacy `.ccc` input appears, the safest interpretation is to normalize it to `.cc` rather than to maintain a second branch. This preserves backward tolerance without preserving dual public semantics.

2. Shell layer
The canonical `.cc` shell remains exact and immutable. This keeps the strongest engineering contract from earlier work. The redesign should not reopen outer-shell creativity, alternate bootstraps, or full-page freestyle takeover.

3. Interior quality layer
The old value of `.ccc` should be absorbed into the interior rendering strategy. That means stronger compositional ambition, bolder section rhythm, more intentional hero treatment, better internal hierarchy, stronger rhetorical pacing, and more active visual-support guidance inside `#ai-content-placeholder`, while staying inside canonical shell rules.

# Planned Module Changes

The module should be rewritten around the following principles.

1. Replace the top-level dual-trigger explanation with a single-trigger contract centered on `.cc`.

2. Remove the separate “standard `.cc` mode” versus “freestyle `.ccc` mode” public split. Replace it with a single `.cc` mode that always uses the canonical shell and allows a spectrum of interior composition styles depending on host strength and subject needs.

3. Keep strong host-preservation rules for rich hosts. The stronger interior styling freedom should primarily activate in host-light or weak-grammar cases.

4. Add an explicit “freestyle interior composition” allowance for `.cc` under safe boundaries. This should encourage bold top blocks, meaningful segmentation, better visual rhythm, and stronger stylistic confidence inside the content area while forbidding outer-shell drift.

5. Strengthen visual-support policy so image or visualization prompts are expected rather than rare for suitable subjects. The guidance should say that spatial, historical, route-based, comparative, system, and process-heavy subjects normally deserve at least one authored visual-support unit unless the host grammar or runtime danger clearly argues against it.

6. Add a clearer runtime-aware downgrade policy. If active placeholders are likely to hijack the page or create large unresolved regions, the module should still preserve the authored visual brief in the semantic plan of the answer, but the visible artifact should protect the reading spine.

7. Remove or replace the old `.ccc` standalone HTML5 file contract. If any legacy mention remains, it should be compatibility-only and subordinate to the single `.cc` public contract.

# Validation Strategy

Validation must prove both command simplification and quality preservation.

First, read the rewritten module and confirm that `.cc` is the only public trigger and that `.ccc` no longer appears as an active command mode.

Second, run a new blind batch on representative host-light explanatory topics and verify that the stronger interior composition still produces high-quality pages under the canonical shell.

Third, use at least one history-like topic, one astronomy-like topic, one protocol-like topic, and one biological-process topic so that active visual-support guidance is exercised across multiple semantic shapes.

Fourth, inspect screenshots to ensure the new design did not regress into either of two failures:

- pages becoming plain and under-structured again
- pages becoming modal-blocked or placeholder-dominated

# Acceptance Standard

The redesign passes if all of the following are true.

1. `.cc` is the only public trigger in the module.
2. The canonical `.cc` shell remains exact.
3. The module explicitly allows stronger interior rendering quality under `.cc`.
4. Visual-support guidance is more active than before.
5. Fresh blind renders still look intentionally designed and remain readable.
6. The final batch average remains at or above 95 under the stricter visual rubric, or any remaining shortfall is clearly shown to come from runtime behavior outside prompt control.

# Risks

The biggest risk is over-merging. If the old `.ccc` freedom is pulled too far into `.cc`, the canonical shell contract could become internally inconsistent or the module could start implicitly promising full-shell redesign that it can no longer perform.

The second risk is visual overreach. More active image and visualization guidance may increase the chance of runtime UI hijack in this environment. The module therefore needs a sharper distinction between “author a visual support plan” and “let that support dominate the rendered page.”

The third risk is prompt bloat. Collapsing two mode descriptions into one can easily make the module more repetitive. The rewrite should reduce command-surface complexity even if the file remains long.

# Definition Of Done

The work is done when:

1. the current module is safely backed up,
2. the active file exposes `.cc` as the single intended command,
3. the separate `.ccc` command path is removed from the public contract,
4. active visual-support guidance is stronger,
5. fresh test artifacts and screenshots exist,
6. and the final user-facing summary includes the backup path, test paths, and the remaining runtime caveat if any.
