/* --- Ailey & Bailey Canvas --- */
// File: 012_utils_ui_components.js
// Version: 1.4 (Connection Toast Simplification)
// Description: Keeps direct-action toasts intact while moving runtime connection feedback to a dedicated bottom-floating toast.

function openPromptModal() { 
    if (customPromptInput) customPromptInput.value = customPrompt; 
    if (promptModalOverlay) promptModalOverlay.style.display = 'flex'; 
}

function closePromptModal() { 
    if (promptModalOverlay) promptModalOverlay.style.display = 'none'; 
}

function saveCustomPrompt() { 
    if (customPromptInput) { 
        customPrompt = customPromptInput.value; 
        localStorage.setItem('customTutorPrompt', customPrompt); 
        closePromptModal(); 
    } 
}

function describeModalPresentation(message) {
    const normalizedMessage = String(message || '').trim();
    const [firstPart, ...restParts] = normalizedMessage.split(':');
    const hasColonBody = restParts.length > 0 && firstPart.length <= 18;
    const inferredBody = hasColonBody ? restParts.join(':').trim() : normalizedMessage;
    const inferredTitle = hasColonBody ? firstPart.trim() : '';

    const isDanger = /삭제하시겠|정말.*삭제|초기화하시겠/.test(normalizedMessage);
    const isError = !isDanger && /(실패|오류|error|찾을 수 없습니다|못했습니다|중단되었습니다)/i.test(normalizedMessage);
    const isQuestion = isDanger || /하시겠습니까|\?$/.test(normalizedMessage);

    if (isDanger) {
        return {
            variant: 'danger',
            badge: 'Action',
            title: inferredTitle || '삭제 확인',
            body: inferredBody,
            confirmLabel: '삭제',
            showCancel: true,
            confirmClassName: 'modal-btn cancel'
        };
    }

    if (isError) {
        return {
            variant: 'error',
            badge: 'Runtime',
            title: inferredTitle || '오류',
            body: inferredBody,
            confirmLabel: '확인',
            showCancel: false,
            confirmClassName: 'modal-btn confirm'
        };
    }

    return {
        variant: isQuestion ? 'question' : 'info',
        badge: isQuestion ? 'Confirm' : 'Notice',
        title: inferredTitle || (isQuestion ? '확인' : '안내'),
        body: inferredBody,
        confirmLabel: '확인',
        showCancel: isQuestion,
        confirmClassName: 'modal-btn confirm'
    };
}

function showModal(message, onConfirm, onCancel = () => {}) { 
    if (!customModal || !modalMessage || !modalConfirmBtn || !modalCancelBtn) return; 

    const presentation = describeModalPresentation(message);
    customModal.dataset.variant = presentation.variant;
    if (modalTitle) modalTitle.textContent = presentation.title;
    if (modalBadge) modalBadge.textContent = presentation.badge;
    modalMessage.textContent = presentation.body;
    modalConfirmBtn.textContent = presentation.confirmLabel;
    modalConfirmBtn.className = presentation.confirmClassName;
    modalCancelBtn.style.display = presentation.showCancel ? 'inline-flex' : 'none';

    highestZIndex++;
    customModal.style.zIndex = highestZIndex;
    trace("UI", "showModal.zIndex", { zIndex: highestZIndex });

    customModal.style.display = 'flex'; 
    modalConfirmBtn.onclick = () => { 
        onConfirm(); 
        customModal.style.display = 'none'; 
    }; 
    modalCancelBtn.onclick = () => { 
        onCancel();
        customModal.style.display = 'none'; 
    }; 
}

function describeModalPresentationV2(message) {
    const normalizedMessage = String(message || '').trim();
    const colonIndex = normalizedMessage.indexOf(':');
    const canSplitOnColon = colonIndex > 0 && colonIndex < 24;
    const inferredTitle = canSplitOnColon ? normalizedMessage.slice(0, colonIndex).trim() : '';
    const inferredBody = canSplitOnColon ? normalizedMessage.slice(colonIndex + 1).trim() : normalizedMessage;

    const isDanger = /(삭제하시겠습니까|정말로|영구|초기화|되돌릴 수 없습니다|remove|delete)/i.test(normalizedMessage);
    const isError = !isDanger && /(실패|오류|error|찾지 못했|불가능|중단|유효한|응답에서|runtime)/i.test(normalizedMessage);
    const isQuestion = isDanger || /(하시겠습니까|\?)$/.test(normalizedMessage);

    if (isDanger) {
        return {
            variant: 'danger',
            badge: 'Action',
            title: inferredTitle || '삭제 확인',
            body: inferredBody || normalizedMessage,
            confirmLabel: '삭제',
            cancelLabel: '취소',
            showCancel: true,
            confirmClassName: 'modal-btn cancel'
        };
    }

    if (isError) {
        return {
            variant: 'error',
            badge: 'Runtime',
            title: inferredTitle || '오류',
            body: inferredBody || normalizedMessage,
            confirmLabel: '확인',
            cancelLabel: '닫기',
            showCancel: false,
            confirmClassName: 'modal-btn confirm'
        };
    }

    return {
        variant: isQuestion ? 'question' : 'info',
        badge: isQuestion ? 'Confirm' : 'Notice',
        title: inferredTitle || (isQuestion ? '확인' : '안내'),
        body: inferredBody || normalizedMessage,
        confirmLabel: '확인',
        cancelLabel: '취소',
        showCancel: isQuestion,
        confirmClassName: 'modal-btn confirm'
    };
}

showModal = function(message, onConfirm, onCancel = () => {}) {
    if (!customModal || !modalMessage || !modalConfirmBtn || !modalCancelBtn) return;

    const presentation = describeModalPresentationV2(message);
    const modalCard = customModal.querySelector('.generic-feedback-modal') || customModal.querySelector('.custom-modal');

    customModal.dataset.variant = presentation.variant;
    if (modalCard) {
        modalCard.dataset.variant = presentation.variant;
    }
    if (modalTitle) modalTitle.textContent = presentation.title;
    if (modalBadge) modalBadge.textContent = presentation.badge;

    modalMessage.textContent = presentation.body;
    modalConfirmBtn.textContent = presentation.confirmLabel;
    modalConfirmBtn.className = presentation.confirmClassName;
    modalCancelBtn.textContent = presentation.cancelLabel;
    modalCancelBtn.style.display = presentation.showCancel ? 'inline-flex' : 'none';

    highestZIndex++;
    customModal.style.zIndex = highestZIndex;
    trace("UI", "showModal.zIndex", { zIndex: highestZIndex, variant: presentation.variant });

    customModal.style.display = 'flex';
    modalConfirmBtn.onclick = () => {
        onConfirm();
        customModal.style.display = 'none';
    };
    modalCancelBtn.onclick = () => {
        onCancel();
        customModal.style.display = 'none';
    };
};

function showChoiceModal(title, message, buttons) {
    const choiceModal = document.getElementById('choice-modal');
    const modalTitle = document.getElementById('choice-modal-title');
    const modalMessage = document.getElementById('choice-modal-message');
    const modalActions = document.getElementById('choice-modal-actions');

    if (!choiceModal || !modalTitle || !modalMessage || !modalActions) return;

    highestZIndex++;
    choiceModal.style.zIndex = highestZIndex;

    modalTitle.textContent = title;
    modalMessage.textContent = message;
    modalActions.innerHTML = ''; // Clear old buttons
    modalActions.className = 'custom-modal-actions choice-modal-buttons';

    buttons.forEach(buttonInfo => {
        const button = document.createElement('button');
        button.id = buttonInfo.id;
        button.className = 'modal-btn';
        if (buttonInfo.class) {
            button.classList.add(buttonInfo.class);
        }

        let buttonHTML = buttonInfo.text; // Main text / Icon
        if (buttonInfo.description) {
            buttonHTML += `<span class="modal-btn-description">${buttonInfo.description}</span>`;
        }
        button.innerHTML = buttonHTML;

        button.onclick = () => {
            if (buttonInfo.action) {
                buttonInfo.action();
            }
            choiceModal.style.display = 'none';
        };
        modalActions.appendChild(button);
    });

    choiceModal.style.display = 'flex';
}

function updateStatus(msg, success) { 
    if (!autoSaveStatus) return; 
    autoSaveStatus.textContent = msg; 
    autoSaveStatus.style.color = success ? 'lightgreen' : 'lightcoral'; 
    setTimeout(() => { autoSaveStatus.textContent = ''; }, 3000); 
}

function shouldSuppressAmbientToast(message = '', content = '', sessionId = '') {
    const normalizedSessionId = String(sessionId || '');
    const normalizedMessage = String(message || '');
    const normalizedContent = String(content || '');
    const combined = `${normalizedMessage}\n${normalizedContent}`;

    const suppressedSessionPrefixes = [
        'image-gen-busy-',
        'temp-response-',
        'auto-generate-complete-'
    ];

    if (suppressedSessionPrefixes.some(prefix => normalizedSessionId.startsWith(prefix))) {
        return true;
    }

    const suppressedMessagePatterns = [
        /새로운 답변이 도착했습니다/u,
        /질문이 전송되었습니다/u,
        /임시 답변 도착/u,
        /이미지 생성 중입니다/u,
        /자동 생성 완료/u
    ];

    return suppressedMessagePatterns.some(pattern => pattern.test(combined));
}

function showToastNotification(message, content, sessionId) {
    if (shouldSuppressAmbientToast(message, content, sessionId)) return;

    const existingToast = document.querySelector(`.toast-notification[data-session-id="${sessionId}"]`);
    if (existingToast) return;
    const toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.dataset.sessionId = sessionId;
    toast.innerHTML = `
        <div class="toast-icon">💬</div>
        <div class="toast-content">
            <p>${message}</p>
            <small>${content}</small>
        </div>
    `;
    toast.addEventListener('click', () => {
        removeToast(toast);
    });
    document.body.appendChild(toast);
    setTimeout(() => {
        removeToast(toast);
    }, 5000);
}

function showConnectionToast(message, content = '') {
    const toastId = 'app-connection-toast';
    const existingToast = document.getElementById(toastId);
    if (existingToast) {
        existingToast.remove();
    }

    const toast = document.createElement('div');
    toast.id = toastId;
    toast.className = 'connection-toast-notification';

    let contentHTML = `<p>${message}</p>`;
    if (content) {
        contentHTML += `<small>${content}</small>`;
    }

    toast.innerHTML = `
        <div class="toast-icon connection-toast-dot" aria-hidden="true"></div>
        <div class="toast-content">${contentHTML}</div>
    `;

    document.body.appendChild(toast);

    setTimeout(() => {
        hideConnectionToast(toastId);
    }, 1600);
}

function hideConnectionToast(toastId = 'app-connection-toast') {
    const toast = document.getElementById(toastId);
    if (!toast) return;

    toast.classList.add('exiting');
    toast.addEventListener('animationend', () => {
        toast.remove();
    }, { once: true });
}

function removeToast(toastElement) {
    if (toastElement) {
        toastElement.classList.add('exiting');
        toastElement.addEventListener('animationend', () => {
            toastElement.remove();
        });
    }
}

function showProgressToast(message, toastId, options = {}) {
    const { icon = 'spinner', content = null } = options;

    let toast = document.getElementById(toastId);
    if (!toast) {
        toast = document.createElement('div');
        toast.id = toastId;
        toast.className = 'progress-toast-notification';
        document.body.appendChild(toast);
    }

    let iconHTML = '';
    if (icon === 'spinner') {
        iconHTML = '<div class="spinner"></div>';
    } else if (icon === 'success') {
        iconHTML = '<svg class="toast-success-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z" /></svg>';
    }

    const iconContainerHTML = iconHTML ? `<div class="toast-icon">${iconHTML}</div>` : '';
    
    let contentHTML = `<p>${message}</p>`;
    if (content) {
        contentHTML += `<small>${content}</small>`;
    }

    toast.innerHTML = `
        ${iconContainerHTML}
        <div class="toast-content">${contentHTML}</div>
    `;
    toast.classList.remove('exiting');
    toast.style.display = 'flex';
}

function updateProgressToast(message, toastId) {
    showProgressToast(message, toastId);
}

function hideProgressToast(toastId) {
    const toast = document.getElementById(toastId);
    if (toast) {
        toast.classList.add('exiting');
        toast.addEventListener('animationend', () => {
            if (toast) toast.remove();
        });
    }
}

function createCustomSelect(selectElement) {
    if (!selectElement) return;

    if (selectElement.nextElementSibling && selectElement.nextElementSibling.classList.contains('custom-select-container')) {
        return; 
    }

    const container = document.createElement('div');
    container.className = 'custom-select-container';

    const trigger = document.createElement('div');
    trigger.className = 'custom-select-trigger';

    const optionsContainer = document.createElement('div');
    optionsContainer.className = 'custom-select-options';

    const updateTriggerText = () => {
        trigger.textContent = selectElement.options[selectElement.selectedIndex].textContent;
    };

    Array.from(selectElement.options).forEach((option, index) => {
        const customOption = document.createElement('div');
        customOption.className = 'custom-select-option';
        customOption.textContent = option.textContent;
        customOption.dataset.value = option.value;

        if (option.selected) {
            customOption.classList.add('selected');
        }

        customOption.addEventListener('click', () => {
            selectElement.selectedIndex = index;
            selectElement.dispatchEvent(new Event('change'));
            updateTriggerText();
            container.classList.remove('open');
            optionsContainer.querySelectorAll('.custom-select-option').forEach(opt => opt.classList.remove('selected'));
            customOption.classList.add('selected');
        });

        optionsContainer.appendChild(customOption);
    });

    trigger.addEventListener('click', (e) => {
        e.stopPropagation();
        container.classList.toggle('open');
    });

    container.appendChild(trigger);
    container.appendChild(optionsContainer);
    selectElement.style.display = 'none';
    selectElement.after(container);
    updateTriggerText();

    document.addEventListener('click', (e) => {
        if (!container.contains(e.target)) {
            container.classList.remove('open');
        }
    });
}
