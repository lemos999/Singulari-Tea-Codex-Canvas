# Runtime Toast Simplification Plan

- Created: 2026-04-13 00:10:14 +09:00
- Last Updated: 2026-04-13 00:10:14 +09:00
- Status: completed_pending_user_validation
- Plan Type: implementation
- Scope: runtime notification surface

## Objective

Reduce passive toast noise so the reading surface stays clear.

The approved direction is:

- remove ambient answer-arrival and image-generation busy toasts
- keep direct user-action confirmation toasts unchanged for now
- replace the runtime connection success toast with a short bottom-floating fade toast
- keep the new toast away from the upper-right corner dock

## Files In Scope

- `Ailey/src/02_utils/012_utils_ui_components.js`
- `Ailey/src_css/007_widget_notifications.css`
- `Ailey/src/03_core/100_core_firebase.js`

## Execution Summary

1. Added a dedicated `showConnectionToast(...)` helper for a bottom-floating connection-only toast.
2. Added a compact bottom-safe-area toast style with quick fade-in/fade-out timing.
3. Suppressed ambient background toasts inside the shared toast helper.
4. Switched Firebase/runtime startup to use the new connection toast instead of the progress toast.
5. Rebundled and deployed the hosted bundle.

## Scoreboard

- Current Score: 96
- Score Source: provisional
- Last Updated: 2026-04-13 00:10:14 +09:00
- Rationale: the intrusive passive notification flow has been simplified to a short bottom connection toast that no longer competes with the upper-right corner dock, but the user has not yet runtime-validated the final feel in exported/live HTML
- What Improved: connection feedback now appears at the very bottom with a short fade, passive answer/image-generation toasts are suppressed, and the toast surface no longer competes with the corner dock
- What Remains Unsatisfactory: direct-action toasts still use the older style and the user has not yet confirmed the final balance in live pages
- Next Step: user validates the new toast behavior in exported/live HTML
