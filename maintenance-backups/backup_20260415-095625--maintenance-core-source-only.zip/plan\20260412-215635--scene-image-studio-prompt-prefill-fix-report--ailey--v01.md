# Scene Image Studio Prompt Prefill Fix Report

- Artifact Type: implementation-report
- Created: 2026-04-12 21:56:35 +09:00
- Scope: make the scene image studio memo open with the selected image block's own prompt instead of defaulting to full-page context
- Status: implemented-and-deployed-awaiting-manual-validation
- Related Plan: `20260412-181504--visualization-options-upgrade-plan--ailey--v01.md`

## What Changed

- `Ailey/src/03_core/125_core_initializer_vision_ui.js`
  - added prompt-first memo resolution helpers
  - image studio now prefers `data-studio-prompt`, then `data-prompt`, then fallback text
  - image generation from the studio now writes the normalized memo back onto the target/generated image block
  - appended full-screen context is stripped back out when deriving the stored memo
- `Ailey/src/03_core/123_core_initializer_vision_logic.js`
  - image overlay `옵션` now opens the studio with the image block's stored prompt first
  - only falls back to `extractContextFromDOM(...)` for legacy blocks with no stored prompt
- `Ailey/src/02_utils/013_utils_block_renderer.js`
  - rehydrated placeholder `옵션` now prefers stored prompt metadata before nearby sibling scraping

## Why It Was Needed

- existing generated images were reopening the scene image studio with the whole page context inside `장면 설명 메모`
- that made the memo harder to edit and did not match the user's mental model of "edit this image"
- the selected image block already had prompt metadata in many cases, but the modal prefill path was not consistently honoring it

## Verification

- `node --check Ailey/src/03_core/125_core_initializer_vision_ui.js`
- `node --check Ailey/src/03_core/123_core_initializer_vision_logic.js`
- `node --check Ailey/src/02_utils/013_utils_block_renderer.js`
- `node Ailey/bundler.js`

## Deployment

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `0e4031f`
- commit message: `Use image placeholder prompt for scene studio prefill`

## Remaining Risk

- very old image blocks that never stored any prompt metadata still fall back to broader context
- manual browser validation is still required on live/exported HTML
