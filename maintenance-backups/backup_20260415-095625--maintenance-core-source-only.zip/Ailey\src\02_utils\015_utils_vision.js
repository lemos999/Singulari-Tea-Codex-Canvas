/* --- Ailey & Bailey Canvas --- */
// File: 015_utils_vision.js
// Version: 3.0 (API Preset Integration)
// Description: Modified generateImage to use the active API preset for authentication and model selection.

/**
 * Calls the Gemini image generation API with a given prompt and an optional array of reference images.
 * @param {string} prompt - The text prompt to send to the image generation model.
 * @param {string[]} [referenceImages=[]] - An optional array of Base64 data URLs for reference images.
 * @returns {Promise<string>} A promise that resolves with the base64 data URL of the generated image.
 * @throws {Error} Throws an error if the API call fails or the response is invalid.
 */
async function generateImage(prompt, referenceImages = []) {
    const visionSettings = userApiSettings.visionWeaverSettings || {};
    const usePersonalApi = visionSettings.imageApi === 'personal';
    
    let apiKey = "";
    
    if (usePersonalApi) {
        const activePreset = userApiSettings.apiPresets.find(p => p.id === userApiSettings.activePresetId);
        if (activePreset) {
            apiKey = activePreset.key;
        } else {
            throw new Error("개인 API를 사용하도록 설정되었지만, 활성화된 API 프리셋이 없습니다.");
        }
    }
    
    trace("API.Vision", "generateImage.preflight", { usePersonal: usePersonalApi, referenceCount: referenceImages.length });

    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image-preview:generateContent?key=${apiKey}`;

    const generationConfig = {
        responseModalities: ['IMAGE']
    };

    const parts = [{ text: prompt }];
    if (referenceImages && referenceImages.length > 0) {
        referenceImages.forEach(imgDataUrl => {
            if (imgDataUrl) {
                try {
                    const mimeType = imgDataUrl.substring(imgDataUrl.indexOf(":") + 1, imgDataUrl.indexOf(";"));
                    const base64Data = imgDataUrl.substring(imgDataUrl.indexOf(",") + 1);
                    parts.push({
                        inlineData: {
                            mimeType: mimeType,
                            data: base64Data
                        }
                    });
                } catch (e) {
                    console.error("Failed to parse a reference image data URL:", e);
                    trace("API.Vision", "generateImage.parseArrayError", { error: e.message }, {}, "WARN");
                }
            }
        });
        trace("API.Vision", "generateImage.multimodalPayload", { promptLength: prompt.length, imageCount: parts.length - 1 });
    }


    const payload = {
        contents: [{
            parts: parts 
        }],
        generationConfig: generationConfig,
    };

    try {
        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            const errorBody = await response.json();
            throw new Error(`HTTP Error! Status: ${response.status}, Message: ${errorBody.error.message}`);
        }

        const result = await response.json();
        const base64Data = result?.candidates?.[0]?.content?.parts?.find(p => p.inlineData)?.inlineData?.data;

        if (base64Data) {
            return `data:image/png;base64,${base64Data}`;
        } else {
            console.error("Invalid response structure from Image API:", result);
            throw new Error("Could not find image data in the API response.");
        }
    } catch (error) {
        console.error("Image API call failed:", error);
        throw error;
    }
}
