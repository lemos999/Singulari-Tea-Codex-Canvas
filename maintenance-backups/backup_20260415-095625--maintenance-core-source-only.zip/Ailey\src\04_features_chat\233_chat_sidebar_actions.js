/* --- Ailey & Bailey Canvas --- */
// File: 233_chat_sidebar_actions.js
// Version: 2.0 (Clean Sidebar Labels)
// Description: Manages rename actions for projects and sessions with clean labels.

function getNewProjectDefaultName() {
    const baseName = '새 프로젝트';
    const existingNames = new Set(localProjectsCache.map(project => project.name));
    if (!existingNames.has(baseName)) return baseName;

    let index = 2;
    while (existingNames.has(`${baseName} ${index}`)) {
        index += 1;
    }
    return `${baseName} ${index}`;
}

function toggleProjectExpansion(projectId) {
    const project = localProjectsCache.find(item => item.id === projectId);
    if (!project) return;
    project.isExpanded = !project.isExpanded;
    renderSidebarContent();
}

function startProjectRename(projectId) {
    const projectContainer = document.querySelector(`.project-container[data-project-id="${projectId}"]`);
    if (!projectContainer) return;
    const titleSpan = projectContainer.querySelector('.project-title');
    if (!titleSpan) return;

    const originalTitle = titleSpan.textContent;
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'project-title-input';
    input.value = originalTitle;
    titleSpan.replaceWith(input);
    input.focus();
    input.select();

    const finishEditing = () => {
        const newName = input.value.trim();
        if (newName && newName !== originalTitle) {
            renameProject(projectId, newName);
        } else {
            renderSidebarContent();
        }
    };

    input.addEventListener('blur', finishEditing);
    input.addEventListener('keydown', event => {
        if (event.key === 'Enter') input.blur();
        if (event.key === 'Escape') {
            input.value = originalTitle;
            input.blur();
        }
    });
}

function startSessionRename(sessionId) {
    const sessionItem = document.querySelector(`.session-item[data-session-id="${sessionId}"]`);
    if (!sessionItem) return;
    const titleSpan = sessionItem.querySelector('.session-item-title');
    if (!titleSpan) return;

    const originalTitle = titleSpan.textContent;
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'project-title-input';
    input.value = originalTitle;
    titleSpan.replaceWith(input);
    input.focus();
    input.select();

    const finishEditing = () => {
        const newTitle = input.value.trim();
        if (newTitle && newTitle !== originalTitle) {
            renameSession(sessionId, newTitle);
        } else {
            renderSidebarContent();
        }
    };

    input.addEventListener('blur', finishEditing);
    input.addEventListener('keydown', event => {
        if (event.key === 'Enter') input.blur();
        if (event.key === 'Escape') {
            input.value = originalTitle;
            input.blur();
        }
    });
}
