Plan Type: Work Plan
Workstream: Ailey's Note Renewal And Archive Reliability
Version: v01
Status: Completed
Created: 2026-04-13 23:58:52 +09:00
Last Updated: 2026-04-14 00:45:41 +09:00
Supersedes or Related Plan: Related to the existing runtime stabilization and placeholder stability plans; no earlier note-renewal plan is active for this exact scope.
Current Completion State: Planning approved, root backup completed, architecture scan completed, renewal implemented, runtime bundle rebuilt, local browser validation completed, and GitHub publish completed.
Completed So Far: A root-level local backup zip was created, the note panel shell was renewed into an archive-workspace layout, note list and project cards were refreshed, archive summary and maintenance actions were promoted, archive write helpers were serialized and deduped, backup status helpers were added, note-side extraction entry points were removed from the renewed list surface, recall and editor flows were preserved, the runtime bundle was rebuilt, a local Playwright validation run passed, and the updated runtime bundle was published to GitHub.
Remaining Work: No required implementation work remains inside this approved scope. The only optional follow-up is deeper cleanup of a still-hidden legacy recall export control in the static shell markup if the user wants the internal leftover removed as well.
Current Blockers: No blocker remains for the approved renewal scope. The remaining risk is only a low-priority cleanup item around a hidden legacy recall-export element that is no longer user-visible.
Next Step: Let the user exercise the renewed notes workspace in real use and collect feedback for a second-pass polish only if needed.

# Objective

Renew Ailey's Note so it no longer feels like an old utility panel, while keeping the system dependable for long-running real use. The new note experience should feel simpler, clearer, and more intentional. Archive behavior must become easier to trust. Existing note data must remain usable. Existing core behaviors that people actually depend on must keep working. The note-side extraction feature is allowed to disappear. The archive story must get stronger, not weaker. The user explicitly wants archive reliability and continued support for the current useful flows, and does not require the note extraction feature to survive the renewal.

The smallest safe interpretation of the request is this: keep notes, projects, editor access, recall access, learning-note access, archive writes, JSON backup, JSON restore, local auto-backup mirror behavior, and system reset behavior working; remove or demote the aging note-side extraction and note-side HTML export surfaces; renew the panel shell and list interactions so the notes app feels current instead of legacy; do this without introducing a data migration that could strand existing archives.

# Assumptions

The safest working assumptions for implementation are listed here so the work can continue without blocking on broad clarification:

1. The user wants the renewal to apply to the in-app Ailey's Note panel, not to a separate standalone notes application.
2. The user's statement that extraction is unnecessary applies to the note panel's extraction and recall-export surfaces, not to every export-related feature elsewhere in the entire app shell.
3. Existing stored notes and note projects must remain valid without a destructive migration.
4. Archive reliability is more important than preserving every old convenience button.
5. JSON backup and restore are part of the archive trust story and should remain available, even if their placement or wording changes.
6. The local automatic backup mirror should remain available because it directly supports recovery and archive safety in local runtime mode.
7. The renewal should preserve the current note editor and recall semantics unless a narrower replacement is clearly safer.

# What Must Continue To Work

The renewal should preserve these concrete behaviors:

- Opening the note panel and switching between list, editor, and recall views.
- Creating notes and note projects.
- Renaming notes and note projects.
- Moving notes between projects.
- Opening regular notes in the editor.
- Opening recallable narrative or learning notes in the recall viewer.
- Archiving learning content into a stable note target.
- Archiving narrative turns into stable note targets without duplicate turn corruption.
- Archiving generated visualization data into a note in a way that still round-trips through recall.
- Backing up all notes and related note project data through JSON backup.
- Restoring from JSON backup or local mirror backup.
- Preserving the ability to reset the system when the user explicitly chooses that path.

The renewal may remove or materially reduce these note-side surfaces:

- Project extraction buttons and extraction-related note job entry points.
- Recall-view HTML export button.
- Note context-menu HTML export actions when they are only serving the old extraction/export story and not the archive reliability story.

# Why The Current State Feels Old

The current Ailey's Note surface mixes too many concerns into one panel. It acts as a note list, editor launcher, recall viewer, archive browsing surface, extraction launcher, refinement launcher, backup entry point, restore entry point, reset entry point, and translation entry point. That makes the panel feel crowded and inconsistent. The current list UI is serviceable, but it does not present a strong information hierarchy. Project-level actions are crowded into a header area that tries to do too many jobs. The recall view also carries compatibility, editor mode, and HTML export controls inside the same bar. The backup and restore surfaces exist, but they are buried inside a generic dropdown with unrelated actions. Archive behavior is also currently implemented as a mix of direct note-content mutation and cached/server reads with only partial race protection.

The right renewal target is not a decorative reskin. The right target is a clearer product shape:

- Notes should feel like a primary archive workspace.
- Archive and recovery should be explicit and trustworthy.
- Writing and reading should feel separate from maintenance actions.
- Recovery and destructive actions should be available but not noisy.
- Legacy extraction and note-side export affordances should no longer dominate the information architecture.

# Current Architecture Summary

The current architecture already contains separable modules, which is useful because the renewal can stay compatible instead of rewriting everything at once.

The note shell and view switching live in the note app controller and shell panel files. The editor flow is already isolated enough to preserve. The recall viewer is already its own rendering path and can be preserved while its header controls are simplified. Backup and restore already have dedicated modules, including a local automatic backup mirror. System reset is already isolated. The archive pipeline writes to notes through helper functions in the note data layer and the main core archiver. That means the system is not architecturally trapped, but the UI surface and write-path discipline are not yet cleanly aligned.

The highest-value renewal strategy is therefore:

- preserve the data model
- preserve the modular runtime wiring
- simplify the note UI surface
- harden archive writes
- bring backup and restore into a clearer reliability-first story
- remove the aging extraction-driven surface instead of trying to modernize it

# Design Intent

The design should favor the smallest complete renewal with the largest effect on trust and usability. That means the work should not attempt a full application-wide redesign or a note storage migration. The right shape is a compatibility-preserving panel renewal.

The renewed Ailey's Note should feel like an archive workstation rather than a bag of buttons. The main list should be easier to scan. Projects should clearly show their name, note count, and the small set of actions that matter now. Recall should remain powerful, but its header should not promote export behavior that the user no longer needs. Backup and restore should become more explicit as preservation actions instead of hiding behind generic overflow semantics. Dangerous actions should remain available but visually secondary.

This plan deliberately keeps the data schema narrow. Archive reliability should be improved by tightening read and write flow discipline rather than introducing a new archive store. That keeps rollback safe and minimizes migration risk.

# Phased Work Sequence

## Phase 1: Freeze Compatibility Boundaries Before UI Change

Document and preserve the behaviors that must not regress: note open paths, project grouping, editor launch, recall launch, learning-note parsing, visualization archive comments, JSON backup payload shape, JSON restore acceptance, local mirror snapshot behavior, and reset behavior. The goal of this phase is not to add code. The goal is to avoid accidental feature loss during renewal by defining the compatibility boundary first.

The renewal should keep the current note and project documents valid. The backup payload format should continue to accept the currently supported versions that the importer already recognizes. If the backup payload is extended at all, it should remain backward-compatible. The archive writer should still target the same notes collection and note project collection.

## Phase 2: Renew The Note Panel Shell And Information Hierarchy

Rework the Ailey's Note panel shell so the list experience feels modern and archive-first. This includes the panel header, top controls, list spacing, project grouping, empty-state treatment, search treatment, and the way project actions are laid out. The new shell should make it obvious that the panel is for archived knowledge and recoverable working notes.

The list should bias toward clarity over button density. The left side should remain creation-focused. The center should remain search-focused. The right side should become maintenance-focused. The interface should feel deliberate even before any note is opened.

The project rows should emphasize project identity, note volume, and the small number of actions that still matter. The renewal should avoid carrying forward the old "extract" mindset in the visible surface. Selection mode may remain if it still supports useful batch behavior, but its backup meaning should be explicit and archive-oriented.

## Phase 3: Simplify The Action Surface And Remove Unneeded Extraction Paths

Remove the note-side extraction entry points that no longer serve the renewed product direction. This includes the project extraction action and the recall-view HTML export control. Remove or reduce legacy note-side HTML export actions where they only serve old extraction or externalization flows that the user no longer wants.

When removing these surfaces, do not silently break unrelated code paths. The removal should happen at the UI and event-routing level first, and then any dead helper surfaces should be pruned only where safe. If other workflows still depend on the underlying modules elsewhere in the app, they should not be broken just because the note panel stops surfacing them.

Backup and restore must not be confused with extraction. Backup and restore should remain. Extraction should go.

## Phase 4: Strengthen Archive Reliability In The Existing Data Model

This is the most important behavioral phase. The archive pipeline currently relies on read-modify-write behavior against note content, including special comments for visualization data and content appends for narrative snapshots. Some race awareness already exists through bypass-cache reads, but the overall discipline is still fragile enough that the archive story does not feel unquestionably safe.

The renewal should harden archive writes in the smallest safe way. That means:

- prefer authoritative reads when appending archive content
- reduce accidental duplication opportunities
- keep update order explicit
- avoid hidden dependence on stale local cache when correctness matters
- keep narrative turn append semantics stable
- keep learning-note overwrite semantics stable
- keep visualization comment archival compatible with the recall parser

The goal is not to invent a new archive database. The goal is to make the current model more predictable under repeated writes, quick successive writes, and local-runtime behavior.

## Phase 5: Promote Backup And Restore As First-Class Archive Safety Features

The current backup exporter and importer are structurally useful and should be preserved. The renewal should bring them into a clearer reliability-first story. Archive trust comes from users knowing that their notes can be exported, restored, and recovered from the local mirror when needed. The UI should therefore make backup and restore easier to understand and harder to confuse with unrelated workflow actions.

The restored system should continue to support:

- full backup export
- project-specific note backup where appropriate
- selected-note backup if selection mode remains
- restore from a file
- restore from local mirror snapshot
- overwrite or merge restore flows

The renewal should improve wording, placement, and confirmation quality where needed, but should not break the importer contract.

## Phase 6: Keep Editor And Recall Powerful While Making Them Feel Cleaner

The note editor should stay dependable. Auto-save status, title behavior, and editor launch should remain intact. The editor does not need a radical rewrite if its function remains solid.

The recall viewer should stay available for recallable narrative and learning notes, but it should feel less like a side utility and more like a proper read mode. That means simplifying the header controls, keeping useful mode toggles if they still serve real reading workflows, and removing export behavior that no longer belongs there.

The recall content and parsing behavior should remain compatible with existing archived notes, including learning note parsing, curriculum comment parsing, and visualization comment parsing.

## Phase 7: Verify, Review, Rebuild, And Publish

After the renewal and archive hardening are implemented, validate the observable behavior end to end. This must include:

- note list load and search
- note creation and project creation
- note rename and project rename
- note editor open and save
- recall open for narrative notes
- recall open for learning notes
- automatic archiving for narrative and learning flows
- visualization archive append compatibility
- backup export and restore entry points
- local backup mirror behavior in local runtime
- absence of the removed extraction/export note-side surfaces

Then rebuild the runtime bundle and publish the changes to GitHub only after the results are good enough to be defended as a reliability improvement.

# Key Decisions

## Keep The Existing Data Shape

The renewal should not require a note data migration. Existing note documents, project documents, and archived content formats should remain usable. This keeps rollback safe and protects existing user data.

## Remove Extraction From Notes, Not Recovery

The note-side extraction feature can go because the user explicitly does not need it. Backup and restore must stay because they are part of archive trust.

## Preserve Recall Compatibility

The recall viewer must continue to understand existing archived note formats, including special archived comments for visualization and curriculum data. This is critical because archive reliability includes being able to read older archives.

## Favor UI Simplification Over Feature Addition

The renewal should mostly remove confusion and strengthen trust. It should not add a large new concept surface unless necessary for archive clarity.

## Harden Writes Before Inventing New Storage

Archive reliability should be improved in the current model first. A larger archive-store redesign would increase risk, migration complexity, and rollback cost.

# Risks And Failure Modes

The largest risk is accidental regression in archive and restore behavior while the UI is being simplified. Another risk is leaving dead wiring in place after removing extraction controls, which could create broken buttons or console noise. A third risk is over-coupling the renewed UI to current caches in a way that makes archive trust worse rather than better.

Specific failure cases to defend against:

- a note panel refresh that accidentally hides backup or restore
- removal of export surfaces that also breaks a different workflow unexpectedly
- a cleaner list UI that no longer exposes important project actions
- archive writes that still read stale content and overwrite newer content
- recall view simplification that breaks learning note rendering or visualization replay
- restore flow wording that makes overwrite versus merge too easy to misunderstand

# Validation Strategy

Validation should be observable and practical. This work should not be accepted on visual confidence alone.

The implementation should be validated through targeted runtime checks:

1. Open the note panel and confirm the renewed shell renders correctly in both current theme contexts.
2. Create a note and a note project and confirm they appear correctly in the list.
3. Rename both and confirm UI and stored state remain aligned.
4. Open a normal note in the editor and confirm save and return-to-list behavior.
5. Open a recallable note and confirm recall view still renders.
6. Confirm that removed extraction surfaces are actually gone from the note panel and recall header.
7. Trigger archive behavior for a narrative and a learning path and confirm the correct note updates occur.
8. Trigger visualization archive append and confirm the recall parser still sees the archived visualization data.
9. Export a backup and confirm payload generation still works.
10. Exercise restore entry points and confirm local mirror detection still works.
11. Confirm local auto-backup mirror initialization still runs in local runtime.
12. Rebuild the bundle and load a real runtime page to ensure the note panel still behaves after bundling.

# Definition Of Done

This work is done when all of the following are true:

- A root-level local backup of the pre-renewal state exists.
- The Ailey's Note panel feels materially renewed rather than cosmetically tweaked.
- Archive and recovery actions are clearer than before.
- The note-side extraction feature is removed from the renewed notes experience.
- Existing important note flows still work.
- Archive writes are at least as compatible as before and more trustworthy under real use.
- Backup export and restore still work.
- The bundle rebuild succeeds.
- The GitHub publish includes only the intended runtime changes.
- The final verification evidence is strong enough to explain exactly what improved and what still carries residual risk.

# Open Questions And Safe Defaults

There are a few decisions that could expand scope if treated too broadly. The safe defaults are listed here to keep implementation bounded.

Question: Should the renewal also redesign translation project creation inside notes?
Safe default: no broad redesign. Keep translation support if it still works, but do not let it drive the visual hierarchy.

Question: Should every note-side export path be removed across the whole app?
Safe default: no. Remove the note-side extraction and recall HTML export surfaces that the user no longer needs, but do not disturb unrelated global export features unless they are directly coupled and harmful.

Question: Should selection mode remain?
Safe default: keep it if it continues to support useful batch backup behavior cleanly; simplify it if it creates too much UI clutter.

Question: Should system reset stay in the notes dropdown?
Safe default: keep it available but visually secondary and clearly dangerous, because it is still an operational recovery tool.

# Rollback And Safety

Rollback safety comes from four decisions already in scope:

- keep the current data model
- create and preserve the root backup archive before implementation
- keep backup and restore modules alive during renewal
- avoid destructive migration

If the renewal goes wrong, the intended rollback path is to revert the runtime source changes and rebuild the bundle. Since the current note data format remains unchanged, rollback should not require a data transformation reversal.

# Scoreboard

Current Score: 50
Score Source: provisional
Last Updated: 2026-04-14 01:13:07 +09:00
Score Rationale: The approved renewal now includes the follow-up cleanup-only slice, free-layout HTML archive capture works for exported `.cc` pages, the notes shell clipping issue is corrected, and the hidden recall export residue has been removed. The remaining risk is limited to ordinary runtime observation rather than a known workflow defect.
What Improved: The notes workspace now reads as an archive-first panel, archive health is visible, backup and restore are clearer, selection mode is explicitly batch-backup oriented, extraction clutter is removed from the renewed list surface, free-layout live-export HTML now archives real body content instead of only loader text, note panel corners are clipped cleanly, and the legacy recall HTML export control is no longer mounted.
What Remains Unsatisfactory: No blocking defect remains in the validated scope. Residual risk is limited to future runtime regressions that would need normal observation after publish.
What Should Happen Next To Raise Or Maintain The Score: Publish the refreshed bundle, let the user exercise the cave-page archive flow in normal use, and only reopen the work if they want a broader notes UX redesign beyond the current renewal.

## Score History

- 2026-04-13 23:58:52 +09:00 | Score: 44 | Source: provisional | Reason: Planning is approved, backup exists, and architecture scan is complete, but implementation and proof are still pending.
- 2026-04-14 00:45:41 +09:00 | Score: 50 | Source: provisional | Reason: Renewal, archive hardening, browser validation, bundle rebuild, and GitHub publish are complete for the approved scope.
- 2026-04-14 01:13:07 +09:00 | Score: 50 | Source: provisional | Reason: Follow-up cleanup-only work completed, free-layout archive capture for live exports is validated, notes shell clipping is corrected, and the hidden recall export residue is removed.
