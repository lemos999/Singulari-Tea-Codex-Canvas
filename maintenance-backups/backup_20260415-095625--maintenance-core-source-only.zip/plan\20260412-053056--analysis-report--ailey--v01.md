# Ailey Analysis Report

- Artifact Type: analysis-report
- Workstream: Ailey repository reconnaissance
- Version: v06 (Post-Refactoring Final)
- Status: verified
- Created: 2026-04-12 05:30:56 +09:00
- Updated: 2026-04-12 06:55:00 +09:00
- Scope: `Ailey/` local source tree + live Gemini Canvas browser inspection
- Method: static source analysis + full code traversal verification + live browser DOM inspection
- Verified By: Antigravity (Claude Opus 4.6 Thinking)

---

## 0. Verification Notes (v02 추가)

> [!IMPORTANT]
> 이 버전은 v01 보고서 전체를 소스코드로 한 줄씩 대조하여 검증한 결과다.
> - v01의 대부분 분석은 **정확**했다.
> - 일부 항목은 불완전하거나 부정확했으며, 아래에 `[CORRECTED]`, `[UPDATED]`, `[NEW]` 태그로 표시했다.
> - 알 수 없던 세부 흐름을 직접 코드에서 추적해 확인했다.

---

## 1. Executive Summary

`Ailey`는 단순한 챗앱이 아니라, AI가 만들어낸 학습/서사/시각화 결과물을 브라우저 캔버스 안에서 소비하고, 그 결과를 다시 노트와 기록으로 축적하는 클라이언트 사이드 런타임이다.

정확히는 다음 네 가지가 합쳐진 형태다.

1. `Ailey & Bailey`라는 페르소나형 프롬프트 시스템
2. 브라우저용 캔버스 셸과 패널 UI
3. Firebase 기반의 사용자 상태, 채팅, 노트, 아카이브 저장소
4. 이미지 생성, 시각화 생성, 번역, 리포트, 데이터 정제 같은 AI 배치 작업 파이프라인

즉, 이 폴더는 "AI 응답을 예쁘게 보여주는 프런트엔드" 수준이 아니라, `학습 캔버스 + 기록 시스템 + 멀티모달 생성 툴 + 개인 지식 워크스페이스`에 가깝다.

## 2. What It Is

내가 현재 소스 기준으로 판단한 `Ailey`의 실체는 다음과 같다.

- 공식 브랜딩은 `Ailey & Bailey Canvas` 또는 `Singulari-Tea Codex` 계열이다.
- 핵심 런타임은 `bundle/main.js`, `bundle/main.css`로 묶여 외부 HTML 안에 삽입되는 구조다.
- `renderAppShell(...)`이 실제 진입점이며, AI가 만든 HTML 또는 JSON 블록을 받아 표준 셸 안에 다시 렌더링한다.
- 이 셸 위에 `채팅`, `노트`, `회상/리콜`, `시각화`, `이미지 생성`, `몰입 모드`, `디버거`, `드로잉 캔버스`가 겹쳐진다.
- 데이터는 로컬 파일에 저장하는 방식이 아니라 Firebase Auth + Firestore 컬렉션 구조에 저장된다.

이 프로젝트는 다음 중 하나만으로 보기 어렵다.

- 단순 프롬프트 모음: 아님
- 단순 노트 앱: 아님
- 단순 챗 UI: 아님
- 완전한 독립형 SPA 배포 프로젝트: 현재 폴더만 봐서는 아님

## 3. Observable Repository Shape

`[UPDATED]` 현재 `Ailey/` 안에서 실제로 확인된 구성:

```
Ailey/
├── src/                          # 소스 (9 서브디렉토리)
│   ├── 00_shell/                 # 11 files (셸 템플릿 + 어셈블러)
│   ├── 01_state/                 #  1 file  (전역 변수)
│   ├── 02_utils/                 # 16 files (유틸리티)
│   ├── 03_core/                  # 27 files (Firebase, 초기화, 아카이버, 비전, API설정, 템플릿)
│   ├── 04_features_chat/         # 29 files (채팅 주력) — 빈 파일 6개 포함
│   ├── 04_features_immersion/    #  1 file  (몰입 모드 컨트롤러)
│   ├── 05_features_chat/         #  1 file  (중복 orchestrator)
│   ├── 05_features_notes/        # 22 files (노트, 리콜, 배치잡)
│   └── 06_features_gemini_chat/  #  1 file  (빈 파일)
├── src_css/                      # 40 files (CSS 모듈)
├── vendor/                       # 11 files + fonts/ (서드파티 라이브러리)
├── bundle/                       # main.js (2.5MB), main.css (161KB)
├── dist_prompt/                  # 빈 디렉토리
├── bundler.js                    # JS/CSS 번들링 스크립트
├── prompt-bundler.js             # 프롬프트 번들러 (orphaned)
├── run_upgrade.bat               # 업그레이드 배치 (orphaned)
├── package.json + package-lock.json
├── project-structure.txt         # 구조 문서 (현재 트리와 불일치)
└── Ailey & Bailey X_260304.md   # 프롬프트 대형 문서
```

## 4. Runtime Identity

### 4.1 Entry and Host Assumption

실제 진입점은 `src/00_shell/005_shell_part6_main_assembler.js`의 `renderAppShell(inputContent, title_from_ai, canvasId_from_ai)`다.

`[UPDATED]` 이 함수의 실제 동작 순서를 코드에서 확인한 결과:

1. 이전 화면을 `previousMainContent`에 백업한다 (빈 것이 아니면).
2. `REQUIRED_SCRIPT_SOURCE = 'https://lemos999.github.io/Singulari-Tea-Codex-Canvas/'` — 현재 문서 HTML에 이 문자열이 없으면 `Access Denied`를 표시하고 리턴.
3. `document.body.innerHTML`을 완전히 비우고 `SHELL_HTML_BODY_TEMPLATE`을 주입한다.
4. `rebindDOMElements()`로 전역 DOM 참조를 재설정한다.
5. 입력이 JSON `contentBlocks`인지, 일반 HTML인지 판별한다.
6. **JSON 경로**: `renderBlock()` 기반으로 각 블록을 조립해 렌더. `currentDataPayload`에 JSON 저장.
7. **HTML 경로**: raw HTML을 컨테이너에 주입하고, `renderLatexInNode()` → `hydrateDOM()`으로 기능 부착. `currentDataPayload`에 `{ type: 'html_source', rawHtml, ... }` 형태로 저장.
8. `previousMainContent`이 있으면 "이전 장면으로" 버튼을 표시.
9. 마지막에 `initializeCoreFeatures()`를 호출해 전체 기능을 활성화.

### 4.2 Shell Composition

`[UPDATED]` 셸은 원본 보고서보다 더 많은 파트로 분할되어 있다:

- 헤더: `000_shell_template.js` → `SHELL_PART_1`
- 공통 모달: `001_shell_part2_modals_common.js` → `SHELL_PART_2`
- 고급 모달 (6분할!):
  - `002_shell_part3_modals_advanced.js` → `SHELL_PART_3_A`
  - `002_shell_part3_b.js` → `SHELL_PART_3_B`
  - `002_shell_part3_c.js` → `SHELL_PART_3_C`
  - `002_shell_part3_d.js` → `SHELL_PART_3_D`
  - `002_shell_part3_e.js` → `SHELL_PART_3_E`
  - `002_shell_part3_f.js` → `SHELL_PART_3_F`
- 노트/채팅 패널: `003_shell_part4_panel_notes_chat.js` → `SHELL_PART_4`
- 비전/디버거 패널: `004_shell_part5_panel_vision_debugger.js` → `SHELL_PART_5`
- 메인 조립: `005_shell_part6_main_assembler.js` → `SHELL_PART_6`

최종 조립:
```js
SHELL_HTML_BODY_TEMPLATE = SHELL_PART_1 + SHELL_PART_2 +
  (SHELL_PART_3_A + SHELL_PART_3_B + SHELL_PART_3_C +
   SHELL_PART_3_D + SHELL_PART_3_E + SHELL_PART_3_F) +
  SHELL_PART_4 + SHELL_PART_5 + SHELL_PART_6;
```

## 5. Initialization and Core Flow

`[UPDATED]` `initializeCoreFeatures()`의 부트스트랩 순서를 코드에서 정확히 확인:

1. 임시 세션 메시지 초기화
2. KaTeX CSS 주입 (중복 방지)
3. Nanum Pen Script 구글 폰트 로딩
4. 브랜드 로고 표시 (폰트 준비 후)
5. 시계 업데이트 타이머 (1초)
6. 스트림 완료 체크 타이머 (500ms)
7. API 설정 모달 생성
8. `debouncedSaveUserSettings` 초기화
9. **Firebase 초기화** (`await initializeFirebase()`)
10. 통합 설정 컨트롤 세팅
11. 채팅/디버거 패널 드래그/리사이즈 활성화
12. Vision Weaver 패널 초기화
13. `handleGeneration`, `openImageGenerationOptionsModal`, `openVisionWeaverSettingsModal` → `window` 노출
14. 새 채팅 세션 준비 (`handleNewChat(false)`)
15. 디버거 및 포탈 툴팁 초기화
16. 패널 상태 복원 (`applyPanelStates`)
17. 드로잉 캔버스 초기화
18. 몰입 모드 컨트롤러 초기화
19. ADMIN UID 체크 → 디버거 버튼 표시
20. 이벤트 리스너 장착 (`attachEventListeners`)
21. 자동 아카이브 실행 (`handleAutomaticArchiving`)
22. 자동 이미지/시각화 생성 실행 (`handleSequentialGenerationOnLoad`)

## 6. Persistence Model

`[CONFIRMED]` Firebase 저장소 루트:

```
artifacts/AileyBailey_Global_Space/users/{uid}/...
```

`[UPDATED]` 주요 컬렉션 (코드에서 직접 확인):

| Collection Reference | Path |
|---|---|
| `notesCollectionRef` | `{userPath}/notes` |
| `noteProjectsCollectionRef` | `{userPath}/noteProjects` |
| `tagsCollectionRef` | `{userPath}/noteTags` |
| `noteTemplatesCollectionRef` | `{userPath}/noteTemplates` |
| `userSettingsRef` | `{userPath}/settings/userSettings` |
| `chatSessionsCollectionRef` | `{userPath}/chatHistories/global/sessions` |
| `projectsCollectionRef` | `{userPath}/chatHistories/global/projects` |
| `promptTemplatesCollectionRef` | `{userPath}/promptTemplates` |
| `canvasDrawingsCollectionRef` | `{userPath}/canvasDrawings` |
| `canvasImageHistoryCollectionRef` | `{userPath}/canvasImageHistory` |

인증 우선순위:

1. 기존 로그인 세션 (`auth.currentUser`)
2. 커스텀 토큰 (`signInWithCustomToken`)
3. 익명 로그인 (`signInAnonymously`)

`[NEW]` Firebase 초기화 후 오케스트레이션:
1. `loadUserSettingsFromFirebase()`
2. `seedDefaultData()` → `addDefaultPromptTemplatesIfNeeded()`
3. `initializeListeners()` → 7개 리스너 병렬 활성화

## 7. Prompt and Persona System

### 7.1 Source of Truth

- 프롬프트 대형 문서: `Ailey & Bailey X_260304.md`
- 기본 템플릿 조립: `src/03_core/103_core_default_templates_assembler.js`
- 기본 템플릿 시드 동기화: `src/03_core/102_core_seeding.js`

### 7.2 Default Prompt Templates

`[CORRECTED]` 실제 `DEFAULT_PROMPT_TEMPLATES` 배열에 포함된 목록:

1. `Ailey & Bailey(Light)` → `TEMPLATE_AILEY_BAILEY_LIGHT`
2. `Image Prompt Generator` → `TEMPLATE_IMAGE_GENERATOR`
3. `Data Visualizer` → `TEMPLATE_DATA_VISUALIZER`
4. `Narrative Data Refiner` → `TEMPLATE_NARRATIVE_DATA_REFINER`
5. `Learning Module Analyzer` → `TEMPLATE_LEARNING_MODULE_ANALYZER`
6. `Comprehensive Chronicler` → `TEMPLATE_COMPREHENSIVE_CHRONICLER`
7. `Dynamic Narrative Scene Generator` → `TEMPLATE_DYNAMIC_NARRATIVE_SCENE_GENERATOR`
8. `Document Translator` → `TEMPLATE_DOCUMENT_TRANSLATOR`
9. `Master Translator` → `TEMPLATE_MASTER_TRANSLATOR`
10. `Learning Subtitle Translator` → `TEMPLATE_LEARNING_TRANSLATOR`
11. `Code Corrector` → `TEMPLATE_CODE_CORRECTOR`

> [!NOTE]
> `Learning Report Chronicler`는 이 목록에 **없다**. deprecated 되었고 `Learning Module Analyzer`로 대체되었다.

### 7.3 Template Seeding 메커니즘

`[NEW]` `102_core_seeding.js`의 동기화 방식:
- **버전 기반 비교**: `version` 필드 매칭으로 업데이트 필요 여부 판단
- **폴백**: 버전이 없으면 `promptText` 텍스트 비교
- **고아 삭제**: Firestore에 `isDefault`인데 JS 정의에 없는 템플릿은 자동 삭제
- **신규 추가**: JS 정의에 있는데 Firestore에 없는 템플릿은 자동 생성

### 7.4 Persona Meaning

`Ailey & Bailey(Light)` 템플릿을 보면 앱의 기본 정체:

- `Ailey`: 공감형 학습 코치
- `Bailey`: 비판적 보조자
- `Codex Engine`: 위키형 중립 백과 엔진

## 8. Chat Subsystem

채팅 계층은 `src/04_features_chat/*`가 중심이다.

`[UPDATED]` 핵심 파일 (검증된 실제 파일 목록):

| 파일 | 역할 | 바이트 |
|---|---|---|
| `200_chat_data.js` | 데이터 CRUD | 11,780 |
| `201_chat_realtime.js` | 실시간 메시지 수신 | 4,438 |
| `210_chat_ui_actions.js` | 사용자 UI 액션 (`handleChatSend`, `handleQuickQuerySend`) | 4,623 |
| `211_chat_actions.js` | 채팅 액션 헬퍼 | 4,708 |
| `212_chat_payload_builder.js` | 페이로드 생성 (`buildChatPayload`) | 2,479 |
| `213_chat_api_service.js` | API 호출 (`_fetchFromApi`, `_fetchStreamFromApi`) | 8,178 |
| `214_chat_utils.js` | 채팅 유틸 | 1,440 |
| `215_chat_orchestrator.js` | 오케스트레이션 (`sendQueryToAI`, `programmaticChatSend`) | 22,209 |
| `221_chat_ui_sidebar.js` | 사이드바 UI | 6,693 |
| `222~226_chat_ui_messages_*.js` | 메시지 렌더링 계층 | ~25K |
| `227_chat_ui_modals.js` | 채팅 모달 | 9,805 |
| `231_chat_file_attachment.js` | 파일 첨부 | 2,991 |
| `232_chat_prompt_manager.js` | 프롬프트 관리 | 2,833 |
| `233_chat_sidebar_actions.js` | 사이드바 액션 | 2,749 |
| `234_chat_session_manager.js` | 세션 관리 | 6,990 |
| `235_chat_drag_drop.js` | 드래그앤드롭 | 2,156 |

### 8.1 Chat Flow (Verified)

```
사용자 입력
  ↓
handleChatSend() [210_chat_ui_actions.js]
  ├── 임시 세션이면 → sendQueryToAI(temporary)
  ├── currentSessionId 없으면 → 새 세션 생성 → sendQueryToAI()
  └── currentSessionId 있으면 → 메시지 저장 → sendQueryToAI()
        ↓
sendQueryToAI() [215_chat_orchestrator.js]
  ├── 프롬프트 템플릿 조회
  ├── Contextless 모드이면 히스토리 1개로 축소
  ├── buildChatPayload() [212]
  ├── provider 판별:
  │   ├── google_paid → _fetchStreamFromApi() → 스트리밍 렌더
  │   └── 그 외 → _fetchFromApi() → 일반 응답
  ├── 토큰 사용량 추적
  └── _handleAiResponse()
        ↓
_handleAiResponse() [215_chat_orchestrator.js]
  ├── activeCodeFixJob이면 → 코드 수정 적용/롤백
  ├── isInteractiveRecallMode + 서사 형식이면 → renderMarkdownAsScene() + archiveMarkdownSnapshot()
  └── 일반 응답이면 → Firestore 저장 + UI 렌더
```

### 8.2 Providers (Verified)

| 프로바이더 | 호출 방식 | 비고 |
|---|---|---|
| `google_paid` | Google GenAI SDK (ESM import) | 스트리밍 지원, Grounding, ThinkingBudget |
| `universal` | REST fetch + googleapis.com | API 키가 빈 흐름 존재 |
| `openai` | REST fetch | OpenAI 호환 |
| `openrouter` | REST fetch | Referer/Title 헤더 추가 |
| `anthropic` | REST fetch | anthropic-version 헤더 |
| `cerebras` | REST fetch | cerebras API |
| `groq` | REST fetch | Groq API |

## 9. Notes, Recall, and Knowledge Workspace

### 9.1 Notes Data Layer

`[NEW]` `300_notes_data.js` (18,304 bytes) — CRUD 기능:
- `findOrCreateNoteProjectByName()`
- `findOrCreateNoteByTitle()`
- `getNoteContent()` — bypassCache 옵션 지원
- `updateNoteContent()`
- `fetchPastMessages()`

### 9.2 Recall Viewer

`[CONFIRMED]` `315_notes_recall_viewer.js` (39,746 bytes) — 가장 큰 파일 중 하나:
- 서사 기록을 다시 장면처럼 렌더링 (`renderMarkdownAsScene`)
- 학습 노트는 구조화된 블록 단위로 재구성
- 호환 모드/에디터 모드/탐색 사이드바 지원
- 저장된 시각화 HTML 주석도 다시 복원

### 9.3 Notes App

`[NEW]` `340_notes_app.js` (16,079 bytes) — 노트 앱 통합 컨트롤러:
- 뷰 전환 (`switchView`)
- 노트 목록 렌더 (`renderNoteList`)
- 프로젝트/태그 관리
- 선택 모드 (`toggleSelectionMode`)

## 10. Archiving Model (Deep Verification)

`[UPDATED]` `130_core_archiver.js` (32,475 bytes, 741 lines) — 전체 흐름 확인:

### 10.1 자동 아카이빙 진입 (`handleAutomaticArchiving`)

```
currentDataPayload 확인
  ├── type === 'html_source' → handleHtmlSourceArchiving()
  ├── archivePayload.subjectName && conceptName → 학습 캔버스 (JSON 모드)
  ├── archivePayload.theme && turn → 서사 시뮬레이션 (JSON 모드)
  └── 그 외 → skip
```

### 10.2 HTML 소스 아카이빙 (`handleHtmlSourceArchiving`)

1. `DOMParser`로 HTML을 파싱
2. `data-subject`, `data-concept`, `data-turn` 메타데이터 추출 (DOM → 정규식 폴백)
3. `turnNumber` 존재 → **서사 경로**: `_convertHtmlToNarrativeSnapshot()`
4. `turnNumber` 없음 → **학습 경로**: `convertHtmlToMarkdown()`
5. 중복 방지: 턴 식별자 기반 체크 (`currentContent.includes(turnIdentifier)`)
6. 캐시 무시 옵션 (`getNoteContent(note.id, true)`)

### 10.3 Markdown 변환 계층

| 함수 | 용도 |
|---|---|
| `_processHtmlTextToMarkdown()` | HTML → 마크다운 변환 (bold, italic, mark, a, br 보존) |
| `convertHtmlToMarkdown()` | 학습 캔버스 HTML → 마크다운 |
| `_convertHtmlToNarrativeSnapshot()` | 서사 HTML → 턴별 스냅샷 마크다운 |
| `formatNarrativeSnapshot()` | JSON 서사 페이로드 → 마크다운 |
| `buildMarkdownFromContentBlocks()` | JSON contentBlocks → 마크다운 |
| `buildSnapshotFromContentBlocks()` | JSON contentBlocks → 스냅샷 객체 |

## 11. Batch Jobs on Notes

### 11.1 Job State (`341_notes_job_state.js`)

```js
let activeRefinementJob = null;
let activeReportJob = null;
```

### 11.2 Refinement (`342_notes_job_refinement_logic.js`, 21,620 bytes)

- 서사 노트 묶음을 정제
- 학습 프로젝트일 경우 `Learning Module Analyzer` 경로로 우회
- `programmaticChatSend()`를 통해 AI 호출

### 11.3 Comprehensive Reports (`343_notes_job_report_logic.js`, 11,376 bytes)

`[CORRECTED]` 학습 프로젝트 보고서 경로 확인:
- `isLearningProject`이면 `'Learning Report Chronicler'` 템플릿을 찾는다
- **하지만 이 템플릿은 `DEFAULT_PROMPT_TEMPLATES`에 없다** (deprecated)
- → **학습 프로젝트 보고서 기능은 깨져 있음 (확인됨)**

### 11.4 Translation Pipeline (`346_notes_job_translation_logic.js`, 17,366 bytes)

- 큰 문서를 chunk로 쪼갬
- 각 chunk를 노트로 저장
- 순차 번역 후 결과를 합침

### 11.5 [NEW] Deprecated/Empty Files in Notes

| 파일 | 상태 |
|---|---|
| `341_notes_job_manager.js` | 리팩터링 후 빈 deprecated 파일 (7줄 주석만) |
| `342_notes_job_ui.js` | 빈 파일 (0 bytes 아님, 177 bytes 코드) |
| `343_notes_utils.js` | 빈 파일 (176 bytes) |
| `330_notes_utils.js` | 매우 작음 (305 bytes) |
| `350_notes_highlights.js` | 빈 파일 (181 bytes) |
| `351_notes_highlights.js` | 빈 파일 (253 bytes) |
| `312_notes_drawing_toolbar.js` | 매우 작음 (227 bytes) |

## 12. Visualization and Image Generation

### 12.1 Visualization

`[CONFIRMED]` 핵심 파일:
- `121_core_initializer_visualization.js` (32,176 bytes)
- `013_utils_block_renderer.js` (55,152 bytes — 가장 큰 단일 소스 파일)
- `014_utils_visualization_renderer.js` (단 333 bytes — 인클루드/폴백 모듈)

### 12.2 Image Generation

`[CONFIRMED]` 핵심 파일:
- `015_utils_vision.js` (3,724 bytes)
- `123_core_initializer_vision_logic.js` (12,990 bytes)
- `124_core_initializer_vision_handler.js` (7,596 bytes)
- `125_core_initializer_vision_ui.js` (23,708 bytes)

### 12.3 Auto-Generation System (v02 확인)

`[NEW]` `handleSequentialGenerationOnLoad()` (120_core_main_initializer.js):
- 이미지 + 시각화 두 스트림 병렬 실행
- 이미지: 10개 배치 병렬 (`IMAGE_BATCH_SIZE = 10`)
- 시각화: 설정된 배치 크기로 순차 실행
- 프로그레스 토스트로 진행 표시
- `handleAutoImageGeneration()`은 deprecated 처리됨

## 13. UI and Experience Layer

`[CONFIRMED]` + `[NEW]` 확인된 요소:

- 드래그/리사이즈 가능한 패널 (채팅, 디버거)
- 빠른 질의 입력 (quick query)
- 선택 텍스트 팝오버 (Ask AI, Add Note)
- 몰입 모드 컨트롤러 (`ImmersionController`)
- 드로잉 캔버스 오버레이 (Fabric.js 기반)
- 상태 추적용 디버거 (ADMIN 전용, UID: `16080536473701849787`)
- 이전 장면 복귀 (fade-in/fade-out 애니메이션)
- 헤더 숨기기/보이기 토글
- 컨텍스트 모드 토글 (contextless)
- Grounding 빠른 토글
- 키보드 단축키: ` (드로잉 토글), 1-7 (드로잉 도구), Q/E (브러시 크기)
- `window.message` 이벤트로 iframe 시각화 높이 자동 조절

## 14. Build and Delivery Model

### 14.1 Bundler

`[UPDATED]` `bundler.js` 동작 검증:

1. 의존성 자동 설치 (`terser`, `postcss`, `cssnano`, `esbuild`)
2. **KaTeX 스타일**: `dist/katex-styles.js` 필수 — 없으면 종료
3. **Vendor 라이브러리**: 고정 순서 병합 (9개 파일)
4. **앱 소스**: `src/00_shell/` + `src/` 재귀 탐색, 파일명 기준 정렬
5. **ES Module 감지**: `import`/`export` 포함 파일은 esbuild로 별도 IIFE 번들
6. **JS 축소**: Terser (console 드롭, mangle + reserved names)
7. **CSS**: `src_css/` → postcss + cssnano 번들

Reserved names for minification:
```
renderAppShell, firebase, toastui, marked, Prism, katex, katex_css_data, fabric, L
```

### 14.2 [NEW] 번들링 순서로 본 파일 로드 순서

```
1. dist/katex-styles.js (임베디드 CSS 데이터)
2. vendor/ (Firebase → ToastUI → Prism → KaTeX → Marked → Leaflet)
3. src/00_shell/ (셸 파트별)
4. src/ (나머지, 파일명 숫자순 정렬)
   → 00_ shell은 별도 처리됨 (중복 방지)
5. ESM 모듈 (별도 esbuild → IIFE)
```

> [!WARNING]
> `src/00_shell/` 디렉토리는 `getAllAppFiles()`에서 **중복 방지 로직**이 있다:
> `srcBaseDirs` 배열의 첫 번째로 포함되고, 재귀 탐색에서는 `00_shell` 이름을 건너뛴다.
> 따라서 셸 파일은 **한 번만** 번들에 포함된다.

### 14.3 Delivery Assumption

`[CONFIRMED]` 로컬 소스만으로는 실행 진입점이 없고, 런타임은 다음에 의존:

- 외부 HTML 호스트: `https://lemos999.github.io/Singulari-Tea-Codex-Canvas/`
- Gemini Canvas에서 임베딩 (스크린샷 참고: `gemini.google.com/gem/...`)
- `__firebase_config`, `__initial_auth_token` — 외부에서 주입
- `renderAppShell()`은 외부 호스트가 트리거

> [!IMPORTANT]
> 운영 관점에서 실제 런타임 반영 단위는 `Ailey/` 소스 자체가 아니라 **번들 산출물**이다.
> - 로컬에서 `node bundler.js`로 `bundle/main.js`, `bundle/main.css`를 다시 생성해야 한다.
> - 그 결과물을 `lemos999/Singulari-Tea-Codex-Canvas` 저장소의 `bundle/` 경로에 반영해 GitHub 서버/GitHub Pages에 올라가야 Gemini Canvas가 새 코드를 가져온다.
> - 즉, 백엔드 로직 수정만으로는 라이브 Canvas 런타임이 바뀌지 않고, **rebundle + bundle 배포**가 반드시 뒤따라야 한다.

## 15. Structural Risks and Mismatches (Post-Refactoring Status)

### 15.1 Rebuild Reproducibility — ✅ RESOLVED

- ~~`dist/` 디렉토리 자체가 없음~~ → ✅ `dist/katex-styles.js` + `dist/katex-embedded.css` 추가됨
- ~~`prompt_src/` 디렉토리 없음~~ → ✅ `prompt-bundler.js` 삭제됨 (orphaned)
- ~~`run_upgrade.bat`의 전제 파일들 없음~~ → ✅ `run_upgrade.bat` 삭제됨 (orphaned)

**현재 상태**: `bundler.js` 정상 빌드 가능.

### 15.2 Missing Function: `programmaticChatRequest` — ✅ RESOLVED

~~`123_core_initializer_vision_logic.js:73`에서 `programmaticChatRequest()`를 호출~~ → ✅ `programmaticChatSend()`로 수정 완료. `ignoreHistory: true` 매개변수 추가.

### 15.3 Undeclared Global: `canvasImageHistoryCollectionRef` — ✅ RESOLVED

~~`001_state_globalVars.js`에 선언이 없음~~ → ✅ Line 66에 `let canvasImageHistoryCollectionRef` 선언 추가됨.

### 15.4 Deprecated Template Mismatch — ✅ RESOLVED

~~`'Learning Report Chronicler'` 참조~~ → ✅ `'Learning Module Analyzer'`로 교체 완료 (Line 43, 110).

### 15.5 Duplicate Runtime File — ✅ RESOLVED

~~`src/05_features_chat/215_chat_orchestrator.js` 중복~~ → ✅ 파일 및 디렉토리 삭제됨.

### 15.6 Empty Files — ✅ RESOLVED

~~0 bytes 빈 파일 7개~~ → ✅ 전부 삭제됨.
~~`05_features_notes/341_notes_job_manager.js` deprecated 잔존~~ → ✅ 삭제됨.

### 15.7 Host Lock — ⚠️ KNOWN (유지)

```js
const REQUIRED_SCRIPT_SOURCE = 'https://lemos999.github.io/Singulari-Tea-Codex-Canvas/';
```

의도적 보안 제약. 변경 불필요.

### 15.8 Theme Sync Drift — ⚠️ KNOWN (유지)

`window.toastEditorInstance` 노출 일관성 미확인. 현재 동작에는 영향 없음.

### 15.9 Universal API Ambiguity — ⚠️ KNOWN (유지)

빈 API 키로 요청하는 경로 존재. 호스트 환경 프록시에 의존.

### 15.10 `project-structure.txt` 불일치 — ✅ RESOLVED

~~과거 v6.4 스냅샷~~ → ✅ Phase 5에서 현재 트리 기준으로 재생성 완료 (133개 소스 파일 반영).

### 15.11 `fabric.js` vendor 미포함 — ⚠️ OPEN

`vendor/fabric.js`가 `VENDOR_LOAD_ORDER`에 포함되어 있지 않다. 드로잉 캔버스가 `fabric` 글로벌에 의존하므로 외부 include에 의존 중.

### 15.12 Gemini Chat Feature 미구현 — ✅ RESOLVED

~~`06_features_gemini_chat/400_gemini_chat.js` — 빈 파일~~ → ✅ 파일 및 디렉토리 삭제됨.

### 15.13 디렉토리 번호 충돌 — ✅ RESOLVED

~~`04_features_immersion/`이 `04_features_chat/`과 번호 충돌~~ → ✅ `06_features_immersion/`으로 재배치 완료.

## 16. Bottom-Line Interpretation

`[CONFIRMED]` Ailey는 다음처럼 이해하는 것이 가장 정확하다:

`Ailey`는 "Ailey/Bailey/Codex"라는 프롬프트 페르소나 체계 위에서, AI가 만든 학습/서사/시각 자료를 브라우저 캔버스에 렌더링하고, 그 결과를 다시 Firebase 기반 노트와 기록 체계로 축적하며, 필요하면 번역/정제/리포트/시각화/이미지 생성까지 이어붙이는 개인용 AI 작업 공간 런타임이다.

본질: **AI 캔버스 런타임 + 지식 기록 시스템 + 멀티모달 후처리 툴체인**

### [NEW] 운영 환경

스크린샷과 코드로 확인된 실제 운영 환경:
1. Gemini 웹 (`gemini.google.com`)에서 에일리 프롬프트를 로드
2. `.cc` (Canvas Command)로 학습 주제를 요청
3. Gemini가 HTML/JSON 응답을 생성하면 Canvas 샌드박스에 `renderAppShell()`을 트리거
4. 셸이 로드되면 Firebase에 연결하여 사용자 데이터 동기화
5. 채팅/노트/비전/아카이빙 기능이 활성화

### [NEW v03] 실제 Gemini Canvas 라이브 브라우저 검증

> [!IMPORTANT]
> 아래 내용은 `gemini.google.com/gem/8d14a4629262/9a72c8e5dac3ef7d`에서 실제로 열린
> 캔버스 페이지를 브라우저 도구로 직접 검사한 결과다.

#### 16.1.1 캔버스 제목 및 호스트

- **Gem 이름**: `태양계 탐험을 위한 맞춤 학습`
- **Gem 페르소나**: `Ailey & Bailey · 사용자설정 Gem`
- **캔버스 제목**: `태양계: 우주의 질서와 역학`
- **트리거 명령**: `.cc 태양계에대해서`
- **캔버스 상단 UI**: `codex` 레이블 + 빠른 질문 입력 + 뒤로 가기 + 녹음 + 스냅샷 + 다운 + 토글 버튼들
- **탭**: `코드 | 미리보기 | 공유`

이것은 Gemini 웹의 **Canvas 기능** (구 Immersive Canvas)을 사용한 것이며, Gem 설정에 `Ailey & Bailey` 프롬프트가 사용자 정의 Gem으로 연결되어 있다.

#### 16.1.2 AI가 생성한 HTML 원본 구조 (코드 뷰에서 확인)

Gemini가 `.cc 태양계에대해서` 요청에 대해 생성한 HTML의 구조:

```html
<!-- Gemini가 생성한 캔버스 HTML (코드 뷰에서 직접 확인) -->

<!-- 1. 헤더 -->
<div class="header">
  <h1>태양계: 46억 년의 질서와 역동적 공존</h1>
  <p class="subtitle">항성 태양을 중심으로 펼쳐지는 행성계의 물리적 구조와
    진화적 메커니즘에 대한 심층 탐구</p>
</div>

<!-- 2. 핵심 키워드 섹션 -->
<section class="content-section type-key-terms">
  <h3>🔑 핵심 키워드</h3>
  <div class="keyword-list">
    <span class="keyword-chip">성운설</span>
    <span class="keyword-chip">핵융합</span>
    <span class="keyword-chip">지구형 행성</span>
    <span class="keyword-chip">목성형 행성</span>
    <span class="keyword-chip">카이퍼 벨트</span>
  </div>
</section>

<!-- 3. 학습 콘텐츠 섹션들 -->
<section class="content-section">
  <h2>📝 태양계의 기원과 구조적 질서 (Core Principles)</h2>
  <p>태양계는 약 46억 년 전, 거대한 분자 구름인
    <strong>태양 성운</strong>이 중력 붕괴를 일으키며...</p>
  <div data-component="image-placeholder"
       data-prompt="A detailed artistic..."></div>
</section>

<section class="content-section">
  <h2>🌞 태양: 시스템의 지배적인 심장 (The Solar Engine)</h2>
  <h3>🔬 중심핵의 핵융합 메커니즘</h3>
  <p>태양의 <strong>중심핵</strong>은 태양계 전체 에너지의 근원지로...</p>
  <h3>⚡ 태양 대기와 태양풍의 역동성</h3>
  <p>태양의 표면 위로는 광구, 채층, 그리고 수백만 도에 달하는
    <strong>코로나</strong>...</p>
  <div data-component="visualization-placeholder"
       data-prompt="Interactive..."></div>
</section>

<section class="content-section">
  <h2>🪐 행성계의 이원적 구조 (Planetary Taxonomy)</h2>
  <h3>🏔️ 암석질 지구형 행성의 지질학적 분석</h3>
  <p>수성, 금성, 지구, 화성으로 대표되는
    <strong>지구형 행성</strong>들은...</p>
  <h3>🌊 거대 기체 및 얼음 행성의 유체역학</h3>
  <p>목성, 토성, 천왕성, 해왕성은 지구와는 비교할 수 없을 만큼
    거대한 부피를 자랑하며...</p>
  <div data-component="image-placeholder"
       data-prompt="Comparison graphic..."></div>
</section>

<!-- 4. 요약 섹션 -->
<section class="content-section type-summary">
  <h3>🌟 오늘의 핵심 요약</h3>
  <ul>
    <li><strong>기원:</strong> 46억 년 전 성운설 기반 중력 붕괴와 회전...</li>
    <li><strong>태양:</strong> 수소 핵융합을 통해 에너지 생산...</li>
    <li><strong>행성 분류:</strong> 내행성계의 암석질 행성과 외행성계의 거대...</li>
    <li><strong>역학:</strong> 중력과 전자기력이 지배하는 역동적 질서 체계.</li>
  </ul>
</section>
```

#### 16.1.3 HTML 구조 분석 — 소스코드와의 매핑

| AI가 생성한 HTML 요소 | 소스코드 처리 함수 | 경로 |
|---|---|---|
| `.header` + `h1` + `.subtitle` | `renderAppShell()` → HTML 경로 | `005_shell_part6_main_assembler.js` |
| `.content-section` | `hydrateDOM()` 대상 | `013_utils_block_renderer.js` |
| `.type-key-terms` + `.keyword-chip` | `hydrateDOM()` 키워드 렌더 | `013_utils_block_renderer.js` |
| `.type-summary` | `hydrateDOM()` 요약 블록 | `013_utils_block_renderer.js` |
| `data-component="image-placeholder"` | `handleSequentialGenerationOnLoad()` | `120_core_main_initializer.js` |
| `data-component="visualization-placeholder"` | `handleBatchVisualizationGeneration()` | `121_core_initializer_visualization.js` |
| `data-prompt="..."` | 이미지/시각화 생성 시 컨텍스트 제공 | `123_core_initializer_vision_logic.js` |
| `<strong>` 태그들 | `_processHtmlTextToMarkdown()` 마크다운 보존 | `130_core_archiver.js` |

#### 16.1.4 핵심 발견: HTML 모드 동작 확인

이 캔버스는 **JSON `contentBlocks` 모드가 아니라 HTML 직접 삽입 모드**로 동작하고 있다:

1. AI가 HTML을 직접 생성 (`<section class="content-section">` 등)
2. `renderAppShell()`의 **HTML 경로**로 진입:
   - `currentDataPayload = { type: 'html_source', rawHtml: inputContent, ... }`
   - `container.innerHTML = inputContent` → `renderLatexInNode()` → `hydrateDOM()`
3. `hydrateDOM()`이 placeholder를 interactive 요소로 변환
4. `handleAutomaticArchiving()`이 `html_source` 타입을 감지 → `handleHtmlSourceArchiving()`
5. `handleSequentialGenerationOnLoad()`이 `.type-generated-image`, `.type-visualization-placeholder`를 찾아 자동 생성

#### 16.1.5 Gemini Canvas 호스팅 아키텍처

브라우저 검사에서 확인된 아키텍처:

```
Gemini 웹 (gemini.google.com)
  └── Gem 설정 (Ailey & Bailey 페르소나)
       └── 사용자 입력: ".cc 태양계에대해서"
            └── AI가 HTML 생성
                 └── Canvas 샌드박스 (오른쪽 패널)
                      ├── <script src="https://lemos999.github.io/Singulari-Tea-Codex-Canvas/bundle/main.js">
                      ├── <link href="https://lemos999.github.io/Singulari-Tea-Codex-Canvas/bundle/main.css">
                      ├── __firebase_config (Gemini 환경에서 주입)
                      ├── __initial_auth_token (Gemini 환경에서 주입)
                      └── renderAppShell(generatedHTML, title, canvasId)
                           └── initializeCoreFeatures()
                                ├── Firebase 연결
                                ├── 채팅 패널 활성화
                                ├── 노트 패널 활성화
                                ├── 비전 위버 활성화
                                ├── 자동 아카이빙
                                └── 자동 이미지/시각화 생성
```

이 아키텍처에서 `REQUIRED_SCRIPT_SOURCE` 검증 로직이 의미를 갖는다:
- 캔버스 HTML에 `https://lemos999.github.io/Singulari-Tea-Codex-Canvas/` 경로의 `<script>` 태그가 포함되어야 통과
- 즉, GitHub Pages에 배포된 번들을 로드하는 HTML만이 정상 실행 가능

#### 16.1.6 채팅 영역 관찰 (왼쪽 패널)

Gemini 채팅 영역에서 관찰된 AI 응답 구조:

```
Ailey & Bailey 응답:
├── 인사/도입 텍스트 (한국어, 이모지 포함)
├── 캔버스 생성 카드 ("태양계: 우주의 질서와 역학", 타임스탬프)
├── "Canvas 사용하지 않고 다시 시도하기" 링크
├── 학습 나침반 (구조화된 커리큘럼)
│   ├── [기초 학습 코스]
│   │   a. 태양계의 기초 골격과 형성사
│   │   ...
│   └── (추가 코스들)
└── 하단 입력: "함께 작성하거나 만들어 봐요"
```

이것은 AI 프롬프트가 두 가지를 동시에 생성함을 보여준다:
1. **캔버스 HTML** — 학습 콘텐츠 (오른쪽)
2. **채팅 응답** — 학습 로드맵/나침반 (왼쪽)

## 17. Assumptions

- 이번 보고서는 로컬 파일 정적 분석 + 라이브 브라우저 검사를 수행했다.
- v01 대비 v02는 모든 핵심 파일을 직접 읽어 검증했다.
- v03에서 실제 Gemini Canvas 브라우저 페이지를 열어 DOM과 코드 뷰를 검사했다.
- v04에서 테스트 제약과 Firebase 종속 깊이를 분석했다.
- Firebase 연결/API 호출/빌드 재생성은 아직 실행하지 않았다.
- `Ailey & Bailey X_260304.md` (52KB 프롬프트 문서)는 내용을 상세 분석하지 않았다.

## 18. File Inventory (전체 소스 파일 수)

| 디렉토리 | 파일 수 | 비고 |
|---|---|---|
| `src/00_shell/` | 11 | 셸 템플릿 & 조립 |
| `src/01_state/` | 1 | 전역 상태 |
| `src/02_utils/` | 16 | 유틸리티 |
| `src/03_core/` | 27 | 코어 (Firebase, 템플릿, API, 초기화, 아카이버) |
| `src/04_features_chat/` | 22 | 채팅 (빈 파일 0개) |
| `src/05_features_notes/` | 21 | 노트, 프로젝트, 배치잡 |
| `src/06_features_immersion/` | 1 | 몰입 모드 (04에서 재배치) |
| `src_css/` | 40 | 스타일시트 |
| **합계** | **139** | **리팩토링 후 (149 → 139, -10 files)** |

번들 산출물:
- `bundle/main.js`: 2,506,100 bytes (2.4MB)
- `bundle/main.css`: 161,365 bytes (157KB)
