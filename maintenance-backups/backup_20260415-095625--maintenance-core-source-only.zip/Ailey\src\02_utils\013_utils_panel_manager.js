/* --- Ailey & Bailey Canvas --- */
// File: 013_utils_panel_manager.js
// Version: 1.1 (Refactored + Mobile Shell Mode)
// Description: Centralized manager for panel behaviors like dragging, resizing, focus, and state persistence.
// Merged content from the deprecated 122_core_initializer_panel_utils.js.

const MOBILE_SHELL_BREAKPOINT = 900;
const PANEL_VIEWPORT_MARGIN = 12;
const PANEL_HEADER_PEEK_AMOUNT = 10;

function isMobileShellViewport() {
    return window.innerWidth <= MOBILE_SHELL_BREAKPOINT;
}

function parsePanelPixel(value, fallback = 0) {
    const parsed = Number.parseFloat(value);
    return Number.isFinite(parsed) ? parsed : fallback;
}

function measurePanelBounds(panelElement, state = null) {
    const computedStyle = window.getComputedStyle(panelElement);
    return {
        width: parsePanelPixel(state?.width, parsePanelPixel(panelElement.style.width, parsePanelPixel(computedStyle.width, panelElement.offsetWidth || 640))),
        height: parsePanelPixel(state?.height, parsePanelPixel(panelElement.style.height, parsePanelPixel(computedStyle.height, panelElement.offsetHeight || 520))),
        left: parsePanelPixel(state?.left, parsePanelPixel(panelElement.style.left, parsePanelPixel(computedStyle.left, PANEL_VIEWPORT_MARGIN))),
        top: parsePanelPixel(state?.top, parsePanelPixel(panelElement.style.top, parsePanelPixel(computedStyle.top, PANEL_VIEWPORT_MARGIN))),
    };
}

function clampPanelToViewport(panelElement, state = null) {
    if (!panelElement || panelElement.classList.contains('maximized') || isMobileShellViewport()) return;

    const header = panelElement.querySelector('.panel-header');
    const bounds = measurePanelBounds(panelElement, state);
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    const headerHeight = Math.max(header?.offsetHeight || 42, 42);
    const minTop = -(headerHeight - PANEL_HEADER_PEEK_AMOUNT);
    const maxWidth = Math.max(320, viewportWidth - (PANEL_VIEWPORT_MARGIN * 2));
    const maxHeight = Math.max(260, viewportHeight - (PANEL_VIEWPORT_MARGIN * 2));
    const width = Math.min(bounds.width, maxWidth);
    const height = Math.min(bounds.height, maxHeight);
    const maxLeft = Math.max(PANEL_VIEWPORT_MARGIN, viewportWidth - width - PANEL_VIEWPORT_MARGIN);
    const maxTop = Math.max(PANEL_VIEWPORT_MARGIN, viewportHeight - height - PANEL_VIEWPORT_MARGIN);
    const left = Math.min(Math.max(bounds.left, PANEL_VIEWPORT_MARGIN), maxLeft);
    const top = Math.min(Math.max(bounds.top, minTop), maxTop);

    panelElement.style.width = `${Math.round(width)}px`;
    panelElement.style.height = `${Math.round(height)}px`;
    panelElement.style.left = `${Math.round(left)}px`;
    panelElement.style.top = `${Math.round(top)}px`;
}

function schedulePanelClampPass() {
    if (isMobileShellViewport()) return;
    window.requestAnimationFrame(() => {
        window.requestAnimationFrame(() => {
            document.querySelectorAll('.draggable-panel').forEach((panel) => {
                if (!panel || panel.classList.contains('maximized')) return;
                clampPanelToViewport(panel);
            });
        });
    });
}

function syncMobileShellViewportMetrics() {
    const root = document.documentElement;
    if (!root) return;

    const vv = window.visualViewport;
    const viewportWidth = Math.max(320, Math.round(vv?.width || window.innerWidth || MOBILE_SHELL_BREAKPOINT));
    const viewportHeight = Math.max(360, Math.round(vv?.height || window.innerHeight || 640));
    const viewportTop = Math.max(0, Math.round(vv?.offsetTop || 0));
    const viewportLeft = Math.max(0, Math.round(vv?.offsetLeft || 0));

    root.style.setProperty('--ailey-mobile-vw', `${viewportWidth}px`);
    root.style.setProperty('--ailey-mobile-vh', `${viewportHeight}px`);
    root.style.setProperty('--ailey-mobile-vtop', `${viewportTop}px`);
    root.style.setProperty('--ailey-mobile-vleft', `${viewportLeft}px`);
}

function closeOtherMobilePanels(activePanel) {
    document.querySelectorAll('.draggable-panel').forEach((panel) => {
        if (!panel || panel === activePanel) return;
        panel.style.display = 'none';
        panel.classList.remove('minimized', 'maximized', 'mobile-sidebar-open');
    });
}

function getVisibleMobilePanels() {
    return Array.from(document.querySelectorAll('.draggable-panel')).filter((panel) => {
        if (!panel) return false;
        const styles = window.getComputedStyle(panel);
        return styles.display !== 'none' && styles.visibility !== 'hidden';
    });
}

function choosePrimaryMobilePanel(visiblePanels) {
    if (!Array.isArray(visiblePanels) || visiblePanels.length === 0) return null;
    return (
        visiblePanels.find((panel) => panel.classList.contains('panel-focused'))
        || visiblePanels
            .slice()
            .sort((left, right) => Number(right.style.zIndex || 0) - Number(left.style.zIndex || 0))[0]
        || visiblePanels.find((panel) => panel.id === 'chat-panel')
        || visiblePanels[0]
    );
}

function applyMobileShellViewportMode() {
    const pageBody = document.body;
    if (!pageBody) return false;

    const wasMobile = pageBody.classList.contains('mobile-shell-mode');
    const isMobile = isMobileShellViewport();
    pageBody.classList.toggle('mobile-shell-mode', isMobile);
    syncMobileShellViewportMetrics();

    const recallView = document.getElementById('note-recall-view');
    const chat = document.getElementById('chat-panel');

    if (isMobile && !wasMobile) {
        document.querySelectorAll('.draggable-panel').forEach((panel) => {
            panel.classList.remove('minimized', 'maximized');
        });

        const primaryPanel = choosePrimaryMobilePanel(getVisibleMobilePanels());
        if (primaryPanel) {
            closeOtherMobilePanels(primaryPanel);
            primaryPanel.style.display = 'flex';
            focusPanel(primaryPanel);
        }

        if (chat) {
            chat.classList.remove('mobile-sidebar-open');
        }
        if (recallView && !recallView.classList.contains('recall-sidebar-collapsed')) {
            recallView.classList.add('recall-sidebar-collapsed');
            recallView.dataset.mobileRecallAutoCollapsed = 'true';
        }
    } else if (!isMobile && wasMobile) {
        if (chat) {
            chat.classList.remove('mobile-sidebar-open');
        }
        if (recallView?.dataset.mobileRecallAutoCollapsed === 'true') {
            recallView.classList.remove('recall-sidebar-collapsed');
            delete recallView.dataset.mobileRecallAutoCollapsed;
        }
    }

    return isMobile;
}

window.isMobileShellViewport = isMobileShellViewport;
window.syncMobileShellViewportMetrics = syncMobileShellViewportMetrics;
window.applyMobileShellViewportMode = applyMobileShellViewportMode;

if (typeof document !== 'undefined') {
    document.addEventListener('DOMContentLoaded', () => {
        applyMobileShellViewportMode();
    });
}

if (typeof window !== 'undefined') {
    window.addEventListener('load', () => {
        applyMobileShellViewportMode();
    });
}

function makePanelDraggable(panelElement) {
    if (!panelElement) return;
    const header = panelElement.querySelector('.panel-header');
    if (!header) return;
    let isDragging = false, offset = { x: 0, y: 0 };

    const onMouseMove = (e) => {
        if (isDragging) {
            let newX = e.clientX + offset.x;
            let newY = e.clientY + offset.y;
            const panelRect = panelElement.getBoundingClientRect();
            const viewportWidth = window.innerWidth;
            const viewportHeight = window.innerHeight;

            const headerHeight = header ? header.offsetHeight : 42; // Fallback height
            const HEADER_PEEK_AMOUNT = 10;
            const minY = -(headerHeight - HEADER_PEEK_AMOUNT);

            if (newX < 0) newX = 0;
            if (newX + panelRect.width > viewportWidth) newX = viewportWidth - panelRect.width;
            if (newY < minY) newY = minY; // Apply peeking logic
            if (newY + panelRect.height > viewportHeight) newY = viewportHeight - panelRect.height;
            
            panelElement.style.left = `${newX}px`;
            panelElement.style.top = `${newY}px`;
        }
    };

    const onMouseUp = () => {
        isDragging = false;
        panelElement.classList.remove('is-dragging');
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
        savePanelState(panelElement);
    };

    header.addEventListener('mousedown', e => {
        if (e.target.closest('button, input, select, .resizer')) return;
        if (isMobileShellViewport()) return;
        if (panelElement.classList.contains('maximized')) return;
        isDragging = true;
        panelElement.classList.add('is-dragging');
        offset = { x: panelElement.offsetLeft - e.clientX, y: panelElement.offsetTop - e.clientY };
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    });
}

function makePanelResizable(panelElement) {
    const MIN_WIDTH = 300;
    const MIN_HEIGHT = 200;

    panelElement.querySelectorAll('.resizer').forEach(handle => {
        handle.addEventListener('mousedown', initResize);
        
        handle.addEventListener('dblclick', (e) => {
            e.preventDefault();
            e.stopPropagation();
            if (isMobileShellViewport()) return;

            panelElement.classList.remove('maximized', 'minimized');
            const maximizeBtn = panelElement.querySelector('.panel-maximize-btn');
            if (maximizeBtn) maximizeBtn.classList.remove('is-maximized');

            const defaultWidth = Math.min(700, window.innerWidth * 0.6);
            const defaultHeight = Math.min(600, window.innerHeight * 0.7);
            const centeredLeft = (window.innerWidth - defaultWidth) / 2;
            const centeredTop = (window.innerHeight - defaultHeight) / 2;

            panelElement.style.width = `${defaultWidth}px`;
            panelElement.style.height = `${defaultHeight}px`;
            panelElement.style.left = `${centeredLeft}px`;
            panelElement.style.top = `${centeredTop}px`;
            
            savePanelState(panelElement);
            trace("UI.Panel", "ResetToDefault", { panelId: panelElement.id });
        });
    });

    function initResize(e) {
        e.preventDefault();
        if (isMobileShellViewport()) return;
        const handle = e.target;
        
        let original_width = panelElement.offsetWidth;
        let original_height = panelElement.offsetHeight;
        let original_mouse_x = e.clientX;
        let original_mouse_y = e.clientY;
        let original_x = panelElement.offsetLeft;
        let original_y = panelElement.offsetTop;
        
        const resize = (e) => {
            if (handle.classList.contains('right') || handle.classList.contains('top-right') || handle.classList.contains('bottom-right')) {
                const width = original_width + (e.clientX - original_mouse_x);
                if (width > MIN_WIDTH) panelElement.style.width = width + 'px';
            }
            if (handle.classList.contains('bottom') || handle.classList.contains('bottom-left') || handle.classList.contains('bottom-right')) {
                const height = original_height + (e.clientY - original_mouse_y);
                if (height > MIN_HEIGHT) panelElement.style.height = height + 'px';
            }
            if (handle.classList.contains('left') || handle.classList.contains('top-left') || handle.classList.contains('bottom-left')) {
                const width = original_width - (e.clientX - original_mouse_x);
                if (width > MIN_WIDTH) {
                    panelElement.style.width = width + 'px';
                    panelElement.style.left = original_x + (e.clientX - original_mouse_x) + 'px';
                }
            }
            if (handle.classList.contains('top') || handle.classList.contains('top-left') || handle.classList.contains('top-right')) {
                const height = original_height - (e.clientY - original_mouse_y);
                if (height > MIN_HEIGHT) {
                    panelElement.style.height = height + 'px';
                    panelElement.style.top = original_y + (e.clientY - original_mouse_y) + 'px';
                }
            }
        };
        
        const stopResize = () => {
            window.removeEventListener('mousemove', resize);
            window.removeEventListener('mouseup', stopResize);
            savePanelState(panelElement);
        };
        
        window.addEventListener('mousemove', resize);
        window.addEventListener('mouseup', stopResize);
    }
}

function initializeDraggableAndResizablePanel(panelElement) {
    if (!panelElement || panelElement.querySelector('.resize-handles')) return; // Already initialized

    const resizers = document.createElement('div');
    resizers.className = 'resize-handles';
    resizers.innerHTML = `
        <div class="resizer top"></div>
        <div class="resizer right"></div>
        <div class="resizer bottom"></div>
        <div class="resizer left"></div>
        <div class="resizer top-left"></div>
        <div class="resizer top-right"></div>
        <div class="resizer bottom-left"></div>
        <div class="resizer bottom-right"></div>
    `;
    panelElement.appendChild(resizers);

    makePanelDraggable(panelElement);
    makePanelResizable(panelElement);
}

function savePanelState(panelElement) {
    if (!panelElement || panelElement.classList.contains('maximized') || isMobileShellViewport()) return;
    const panelId = panelElement.id;
    if (!userApiSettings.panelStates) {
        userApiSettings.panelStates = {};
    }
    userApiSettings.panelStates[panelId] = {
        top: panelElement.style.top,
        left: panelElement.style.left,
        width: panelElement.style.width,
        height: panelElement.style.height,
    };
    if (debouncedSaveUserSettings) {
        debouncedSaveUserSettings();
    }
}

function focusPanel(panelElement) {
    if (!panelElement) return;
    document.querySelectorAll('.draggable-panel').forEach(p => {
        p.classList.remove('panel-focused');
    });
    panelElement.classList.add('panel-focused');
    highestZIndex++;
    panelElement.style.zIndex = highestZIndex;
    trace("UI", "PanelFocused", { panelId: panelElement.id, zIndex: highestZIndex });
}

function togglePanel(panelElement, forceShow = null) { 
    if (!panelElement) return; 
    const isMobile = applyMobileShellViewportMode();
    const show = forceShow !== null ? forceShow : panelElement.style.display !== 'flex'; 
    if (show && isMobile) {
        closeOtherMobilePanels(panelElement);
        panelElement.classList.remove('minimized', 'maximized');
    }
    panelElement.style.display = show ? 'flex' : 'none'; 
    if (show) {
        if (isMobile && panelElement.id === 'chat-panel') {
            panelElement.classList.remove('mobile-sidebar-open');
        }
        if (!isMobile) {
            clampPanelToViewport(panelElement);
        }
        focusPanel(panelElement);
    } else if (panelElement.id === 'chat-panel') {
        panelElement.classList.remove('mobile-sidebar-open');
    }
}

function applyDesktopMinimizedPanelState(panel) {
    if (!panel || panel.classList.contains('minimized')) return;

    const header = panel.querySelector('.panel-header');
    const headerHeight = Math.max(header?.offsetHeight || 42, 42);
    const currentWidth = panel.offsetWidth || measurePanelBounds(panel).width || 420;
    const compactWidth = Math.min(Math.max(currentWidth, 360), 540);

    panel.dataset.restoreWidth = panel.style.width || `${currentWidth}px`;
    panel.dataset.restoreHeight = panel.style.height || `${panel.offsetHeight || 520}px`;
    panel.dataset.restoreMinWidth = panel.style.minWidth || '';
    panel.dataset.restoreMinHeight = panel.style.minHeight || '';
    panel.dataset.restoreMaxHeight = panel.style.maxHeight || '';

    panel.style.width = `${Math.round(compactWidth)}px`;
    panel.style.height = `${Math.round(headerHeight + 6)}px`;
    panel.style.minWidth = `${Math.round(Math.max(320, compactWidth))}px`;
    panel.style.minHeight = `${Math.round(headerHeight + 6)}px`;
    panel.style.maxHeight = `${Math.round(headerHeight + 6)}px`;
    panel.classList.add('minimized');
    clampPanelToViewport(panel);
}

function restoreDesktopMinimizedPanelState(panel) {
    if (!panel || !panel.classList.contains('minimized')) return;

    panel.classList.remove('minimized');
    if (panel.dataset.restoreWidth) panel.style.width = panel.dataset.restoreWidth;
    if (panel.dataset.restoreHeight) panel.style.height = panel.dataset.restoreHeight;
    if (panel.dataset.restoreMinWidth !== undefined) panel.style.minWidth = panel.dataset.restoreMinWidth;
    if (panel.dataset.restoreMinHeight !== undefined) panel.style.minHeight = panel.dataset.restoreMinHeight;
    if (panel.dataset.restoreMaxHeight !== undefined) panel.style.maxHeight = panel.dataset.restoreMaxHeight;
    delete panel.dataset.restoreWidth;
    delete panel.dataset.restoreHeight;
    delete panel.dataset.restoreMinWidth;
    delete panel.dataset.restoreMinHeight;
    delete panel.dataset.restoreMaxHeight;
    clampPanelToViewport(panel);
}

function handlePanelMinimize(panel) {
    if (!panel) return;
    if (isMobileShellViewport()) {
        togglePanel(panel, false);
        return;
    }
    if (panel.classList.contains('maximized')) {
        panel.classList.remove('maximized');
        const maximizeBtn = panel.querySelector('.panel-maximize-btn');
        if (maximizeBtn) maximizeBtn.classList.remove('is-maximized');
    }
    if (panel.classList.contains('minimized')) {
        restoreDesktopMinimizedPanelState(panel);
        return;
    }
    applyDesktopMinimizedPanelState(panel);
}

function handlePanelMaximize(panel) {
    if (!panel) return;
    if (isMobileShellViewport()) {
        focusPanel(panel);
        return;
    }
    if (panel.classList.contains('minimized')) {
        restoreDesktopMinimizedPanelState(panel);
    }
    panel.classList.toggle('maximized');
    const maximizeBtn = panel.querySelector('.panel-maximize-btn');
    if (maximizeBtn) maximizeBtn.classList.toggle('is-maximized');
}

function applyPanelStates() {
    if (userApiSettings.panelStates) {
        for (const panelId in userApiSettings.panelStates) {
            const panel = document.getElementById(panelId);
            const state = userApiSettings.panelStates[panelId];
            if (panel && state) {
                if (state.top) panel.style.top = state.top;
                if (state.left) panel.style.left = state.left;
                if (state.width) panel.style.width = state.width;
                if (state.height) panel.style.height = state.height;
                clampPanelToViewport(panel, state);
            }
        }
    }

    schedulePanelClampPass();
}
