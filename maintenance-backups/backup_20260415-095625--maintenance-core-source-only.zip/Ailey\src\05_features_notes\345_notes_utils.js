/* --- Ailey & Bailey Canvas --- */
// File: 345_notes_utils.js
// Version: 1.0 (File Splitting & Renaming)
// Description: Contains utility and helper functions for the notes feature,
// such as content extraction and raw data handling.

/**
 * Extracts a lightweight version of a turn/snapshot chunk for specific refinement modes.
 * @param {string} turnChunk - The markdown content of a single turn or snapshot.
 * @returns {string} The processed lightweight markdown string.
 */
function extractLightweightContent(turnChunk) {
    if (!turnChunk || !turnChunk.trim()) return '';

    const headerMatch = turnChunk.match(/## \[(?:턴\s?\d+|📸 스냅샷:.*?)\]/);
    const protagonistNameMatch = turnChunk.match(/\*\*이름:\*\* (.*?)\n/);
    const protagonistAgeMatch = turnChunk.match(/\*\*나이:\*\* (.*?)\n/);
    const locationMatch = turnChunk.match(/\*\*장소:\*\* (.*?)\n/);
    const timeMatch = turnChunk.match(/\*\*현재 시간:\*\* (.*?)\n/);
    const userChoiceMatch = turnChunk.match(/### 사용자 선택\n([\s\S]*?)(?=\n###|$)/);
    const narrativeMatch = turnChunk.match(/### 생성된 서사\n([\s\S]*?)(?=\n\n---|\n###|$)/);
    
    let result = '';
    if (headerMatch) result += headerMatch[0] + '\n\n';
    
    if (protagonistNameMatch) result += `**이름:** ${protagonistNameMatch[1].trim()}\n`;
    if (protagonistAgeMatch) result += `**나이:** ${protagonistAgeMatch[1].trim()}\n`;
    if (locationMatch) result += `**장소:** ${locationMatch[1].trim()}\n`;
    if (timeMatch) result += `**시간:** ${timeMatch[1].trim()}\n`;

    if (userChoiceMatch) result += `### 사용자 선택\n${userChoiceMatch[1].trim()}\n\n`;
    if (narrativeMatch) result += `### 생성된 서사\n${narrativeMatch[1].trim()}\n\n`;
    
    return result.trim();
}

async function handleRawDataDownload(projectId, noteIds = null) {
    const toastId = `raw-download-${Date.now()}`;
    trace("Refinement", "download.raw.start", { projectId, hasIds: !!noteIds });
    showProgressToast('RAW 데이터 수집 중...', toastId);

    try {
        const project = localNoteProjectsCache.find(p => p.id === projectId);
        if (!project) throw new Error("폴더를 찾을 수 없습니다.");

        let notesToProcess = localNotesCache
            .filter(n => noteIds ? noteIds.includes(n.id) : n.projectId === projectId)
            .sort((a, b) => (a.createdAt?.toMillis() || 0) - (b.createdAt?.toMillis() || 0));

        if (notesToProcess.length === 0) {
            hideProgressToast(toastId);
            showModal('다운로드할 데이터가 없습니다.', () => {});
            return;
        }

        updateProgressToast(`노트 ${notesToProcess.length}개 내용 불러오는 중...`, toastId);

        const contentPromises = notesToProcess.map(note => getNoteContent(note.id));
        const allContents = await Promise.all(contentPromises);
        const combinedContent = allContents.join('\n\n---\n\n');

        const blob = new Blob([combinedContent], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        const filename = `${project.name.replace(/[/\\?%*:|"<>]/g, '-')}_${noteIds ? 'selective' : 'full'}_raw.txt`;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        trace("Refinement", "download.raw.success", { byteLength: blob.size });

    } catch (error) {
        console.error("Raw data download failed:", error);
        trace("Refinement", "download.raw.error", { error: error.message }, {}, "ERROR");
        showModal(`RAW 데이터 다운로드 실패: ${error.message}`, () => {});
    } finally {
        hideProgressToast(toastId);
        if (noteIds) {
            toggleSelectionMode(projectId);
        }
    }
}
