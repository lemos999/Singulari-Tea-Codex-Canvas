# Ailey Visualization Contrast Hardening Plan

- Artifact Type: hardening-plan
- Created: 2026-04-12 17:53:07 +09:00
- Status: deployed-awaiting-user-validation
- Scope: enforce robust text and overlay readability for generated visualizations across dark mode, light mode, live export, and local mode
- Goal: ensure generated visualization fragments remain legible regardless of host theme or surface brightness, without relying on manual per-fragment fixes
- Relationship to Prior Work: this plan extends `20260412-145425--visualization-generation-stability-plan--ailey--v01.md` and follows the accepted UI cleanup work in `20260412-161230--ui-surface-rationalization-plan--ailey--v01.md`

## Scoreboard

- Current Score: 85
- Score Source: provisional
- Last Updated: 2026-04-12 18:02:04 +09:00
- Rationale: the hardening pass was implemented, rebundled, and deployed to the hosted bundle repo, but browser validation is still pending.
- What Improved: the system now enforces contrast safety at generation time, preflight repair time, and runtime mutation time.
- What Remains Unsatisfactory: no manual browser validation has confirmed the dark-mode readability fix yet.
- Next Score Target: user validation of exported/live HTML in both dark and light host themes.

### Score History

- 2026-04-12 17:53:07 +09:00 | 50 | provisional | The dark-mode readability defect was root-caused, the user approved a system-level fix, and implementation started under a new hardening plan.
- 2026-04-12 18:02:04 +09:00 | 85 | provisional | Prompt, preflight, and renderer-level contrast hardening shipped and the hosted bundle was updated for manual validation.

## Working Understanding

The defect is not limited to one exported HTML file.

The renderer already stabilizes DOM scoping and layout, but generated fragments can still rely on inherited host text color for text-bearing cards, annotations, legends, and callouts.

That assumption is unsafe when:

- a fragment creates a light surface such as a pale card, badge, label, or panel
- the fragment does not explicitly assign a matching foreground color
- and the host shell is running in dark mode

In that case, inherited light text can land on a light background and become unreadable even though the visualization otherwise renders successfully.

The fix therefore needs multiple layers:

- generation contract strengthening
- renderer preflight repair
- runtime contrast normalization
- hosted bundle deployment

## Approved Direction

### 1. Strengthen the generation contract

- Update `TEMPLATE_DATA_VISUALIZER` so generated fragments must explicitly define readable foreground colors for any custom surface that sets a background.
- Require that cards, callouts, badges, annotations, legends, floating labels, and text overlays specify both background and foreground together.
- Require that bright surfaces never rely on inherited host text color.

Primary file:

- `Ailey/src/03_core/102_template_data_visualizer.js`

### 2. Add renderer-level auto-contrast hardening

- Introduce a post-injection normalization pass in the visualization renderer.
- Detect effective brightness and contrast for root and descendant text-bearing elements.
- Apply safe block-local overrides only when contrast falls below threshold.
- Keep overrides scoped to the current visualization only.

Primary file:

- `Ailey/src/02_utils/013_utils_block_renderer.js`

### 3. Add preflight repair for common missing-color patterns

- Repair scoped CSS rules that define a background for a text-bearing surface but omit foreground color.
- Repair inline styles with background declarations and no explicit readable text color.
- Avoid destructive rewriting when contrast is already acceptable.

Primary file:

- `Ailey/src/02_utils/013_utils_block_renderer.js`

### 4. Validate, rebundle, and redeploy

- Run syntax checks on touched JS files.
- Run `node Ailey/bundler.js`.
- Sync `Ailey/bundle/main.js` and `Ailey/bundle/main.css` to `Singulari-Tea-Codex-Canvas-pr/bundle/`.
- Commit and push bundle-only deployment to hosted `main`.

Primary paths:

- `Ailey/bundle/main.js`
- `Ailey/bundle/main.css`
- `Singulari-Tea-Codex-Canvas-pr/bundle/main.js`
- `Singulari-Tea-Codex-Canvas-pr/bundle/main.css`

## Risks and Guardrails

### Risk 1. Overriding intended artistic color choices

Guardrail:

- only auto-correct when measured contrast is below threshold
- do not blindly repaint every text node
- scope fixes to the current visualization root

### Risk 2. Breaking SVG or canvas-heavy fragments

Guardrail:

- prioritize HTML overlay/card/callout surfaces first
- only apply SVG text fallback when computed contrast is clearly poor
- avoid interfering with canvas-rendered pixels

### Risk 3. Theme leakage across visualizations

Guardrail:

- keep all normalization styles and runtime overrides block-local
- reuse the existing scoped-style ownership model

## Phase Plan

### Phase 0. Root-cause capture and plan record

- Record the issue, target files, and repair direction.
- Mark this plan as the active artifact for the contrast hardening pass.

### Phase 1. Prompt contract upgrade

- Upgrade the `Data Visualizer` prompt version and add explicit foreground/background pairing rules.

### Phase 2. Renderer contrast hardening

- Implement luminance and contrast helpers.
- Add block-local normalization for HTML text surfaces and safe root defaults.

### Phase 3. Preflight repair extensions

- Add conservative repairs for light-surface fragments that omit text color.

### Phase 4. Verify, bundle, deploy, and document

- Run syntax checks.
- Rebundle.
- Push hosted bundle update.
- Update this plan and write a concise implementation report.

## Immediate Progress Note

- Phase 0 completed: root cause identified from manual test of `기단의 성질과 변화 (1).html`.
- Root cause summary: generated visualization cards with light backgrounds can inherit host dark-mode foreground color assumptions incorrectly because the fragment does not always declare local foreground colors.
- Implementation outcome:
  - `Ailey/src/03_core/102_template_data_visualizer.js` upgraded to `26.0` with explicit foreground/background pairing rules.
  - `Ailey/src/02_utils/013_utils_block_renderer.js` now performs conservative CSS and inline-style contrast repair during preflight.
  - The renderer now applies block-local contrast normalization after DOM injection and watches later DOM mutations with `MutationObserver`.
  - Hosted bundle deployment completed on `Singulari-Tea-Codex-Canvas` `main` at commit `d6a93270e0cde16a2430dcfc9fe160b90050cb4d`.
- Next validation step: user retests exported/live HTML in dark mode and light mode to confirm that light cards, labels, legends, and annotation surfaces remain readable.
