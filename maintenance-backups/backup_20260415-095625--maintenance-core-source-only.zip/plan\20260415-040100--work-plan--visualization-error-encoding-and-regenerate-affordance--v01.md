# Work Plan: Visualization Error Encoding And Regenerate Affordance

- Timestamp: 2026-04-15 04:01 KST
- Owner: Codex
- User approval: granted
- Type: bug fix
- Status: completed
- Scope: fix corrupted visualization error text and restore clear regenerate affordances for visualization failure states

## Understanding

Visualization failure cards sometimes render corrupted Korean text, and when a visualization fails the user can lose the regenerate affordance that should provide a direct recovery path. The fix must identify the source of the corrupted strings, remove or bypass the broken path, and ensure failure states still expose usable regenerate actions without regressing normal visualization controls.

## Goals

1. Find the runtime path that produces corrupted visualization error text.
2. Fix the source of the broken strings rather than masking only the screenshot case.
3. Ensure visualization failure states expose a clear regenerate action again.
4. Keep AI code fix and other visualization actions coherent with the current UI.
5. Validate the fix without widening scope into unrelated visualization behavior.

## Current Findings

- `Ailey/src/03_core/121_core_initializer_visualization.js` contains multiple visualization generation and regeneration paths, and some duplicated branches contain visibly corrupted Korean strings.
- `renderVisualizationFailureState(...)` exists as the shared failure-card renderer, but it currently renders only the error card and note, not recovery actions.
- Visualization controls such as `regenerate` are built in `Ailey/src/02_utils/013_utils_block_renderer.js`, but those controls belong to successfully mounted visualization execution wrappers, not plain failure cards.

## Steps

1. Inspect the visualization error rendering and regeneration code paths. Completed.
2. Remove or normalize corrupted string paths so failure messages render cleanly. Completed.
3. Add a stable regenerate affordance to visualization failure cards. Completed.
4. Verify runtime behavior and record evidence. Completed.

## Root Cause

- `Ailey/src/03_core/121_core_initializer_visualization.js` contained duplicated late-bound visualization generation and regeneration functions. The later active assignment path still carried corrupted Korean literals, so failure cards and modal text could surface mojibake even though an earlier clean renderer existed in the same file.
- `renderVisualizationFailureState(...)` built only a static error card and note, so plain visualization failure states had no direct regenerate affordance. Regenerate remained available only on successfully mounted visualization wrappers that owned `.viz-controls-group`.
- The error-state context menu also lacked a regenerate action, leaving failure recovery dependent on unrelated hover controls.

## Rollback Boundary

- `Ailey/src/03_core/121_core_initializer_visualization.js`
- `Ailey/src/02_utils/013_utils_block_renderer.js`
- `Ailey/src_css/004_widget_visualization_options.css`
- `plan/20260415-040100--work-plan--visualization-error-encoding-and-regenerate-affordance--v01.md`

## Scoreboard

- Current score: 50
- Score source: provisional
- Last updated: 2026-04-15 04:01 KST
- Score rationale: a new approved fix pass has opened but no code has landed yet
- What improved: the failure has been narrowed to the visualization error renderer and related regeneration paths
- What remains unsatisfactory: user acceptance is still pending and this pass has not been browser-smoked in a live canvas session
- Next score action: keep the fix bounded, report the exact root cause, and wait for user validation

### Score History

- 2026-04-15 04:01 KST | 50 | provisional | new approved visualization error fix pass opened
- 2026-04-15 04:18 KST | 50 | provisional | bounded fix landed; awaiting user validation

## Verification

- `Ailey/src/03_core/121_core_initializer_visualization.js` now exposes clean error literals for the active later generate/regenerate paths.
- `renderVisualizationFailureState(...)` now appends `.viz-error-actions` with `다시 생성` and `AI 코드 수정` when recovery context exists.
- `Ailey/src/02_utils/013_utils_block_renderer.js` error-state context menu now includes `다시 생성`.
- Rebuilt bundles succeeded with `node bundler.js`.
- Built `Ailey/bundle/main.js` contains `viz-error-actions`, `다시 생성`, and `AI 코드 수정` around the visualization failure renderer snippet.
