# Work Plan: Isolated Panel Clamp Retry

## Plan Meta

- Plan type: bugfix
- Version: v01
- Status: completed
- Requested by user: yes
- User approval received: yes
- Current phase: verify/review complete
- Scope: desktop panel restore and first-show clamp only

## Understanding

Desktop `chat-panel` and `notes-app-panel` can sometimes restore outside the visible canvas on first load when stale saved coordinates were captured on a different viewport. The user wants a narrow retry of the earlier `panel clamp` idea, with rollback readiness if anything regresses. Export behavior and bundler behavior must remain untouched in this pass.

## Constraints

- Touch only the panel restore / first-show placement path.
- Do not change mobile shell behavior.
- Do not revisit the live-export-only change in this pass.
- Publish only if shell bootstrap and clamp validation both pass cleanly.

## Design Intent

Apply the smallest complete desktop-only correction:

1. clamp saved panel width/height/position to the current viewport when saved state is restored
2. clamp again when a desktop panel is shown
3. run one delayed safety pass after panel states are applied, so late layout/measurement changes cannot leave panels off-canvas

This keeps the change in the panel manager only and avoids mixing unrelated behavior changes.

## Writable Scope

- `Ailey/src/02_utils/013_utils_panel_manager.js`
- `Ailey/bundle/main.js`
- `Ailey/bundle/main.css` only if bundle output changes indirectly
- `visual-tests/validate_isolated_panel_clamp_retry.mjs`
- this plan file
- final report for this task

## Implementation Steps

1. Inspect current panel restore and first-show logic in the panel manager.
2. Add a desktop-only clamp helper that respects header peek behavior.
3. Apply the clamp during saved-state restore and on desktop show.
4. Add one delayed safety clamp pass after restore.
5. Rebuild the bundle.
6. Validate with:
   - a synthetic off-canvas panel-state harness
   - a real shell bootstrap harness
7. Publish only if both validations pass with zero page or console errors.

## Progress

- [x] Inspect current panel restore flow and isolate the safe retry scope.
- [x] Implement desktop-only clamp helpers in the panel manager.
- [x] Rebuild bundle.
- [x] Validate synthetic off-canvas restore behavior.
- [x] Validate shell bootstrap remains healthy.
- [x] Prepare publish and maintenance notes.

## Validation Targets

- `chat-panel` restores inside the current desktop viewport.
- `notes-app-panel` restores inside the current desktop viewport.
- partially hidden top placement still preserves a reachable header peek for dragged/restored desktop panels.
- no page errors
- no console errors
- shell bootstrap still mounts `chat-panel` and `notes-app-panel`

## Assumptions

- The reported off-canvas issue is caused by stale saved desktop coordinates, not by mobile sheet layout.
- Desktop viewport clamp is the right retry boundary for this pass.
- A safe delayed clamp pass is acceptable as long as it stays desktop-only.

## Scoreboard

- Current score: 50
- Score source: provisional
- Last updated: 2026-04-14 19:50 KST
- Score rationale: the scope is isolated correctly and validation passed, but the user has not yet rated this retry.
- What improved: desktop restore now clamps without reopening the earlier export/bundler failure path.
- What remains unsatisfactory: user confirmation on the real problematic pages is still pending.
- Next step to raise or maintain score: publish the isolated pass, then let the user verify the original failing first-load case.

### Score History

- 2026-04-14 19:43 KST | 50 | provisional | approved isolated retry scope opened
- 2026-04-14 19:50 KST | 50 | provisional | implementation and validation passed; awaiting user confirmation
