# Work Plan: CC Universal Module MM Rewrite

- Timestamp: 2026-04-15 03:41 KST
- Owner: Codex
- User approval: granted
- Type: prompt-contract rewrite
- Status: completed
- Execution mode: mixed `/sub`
- Scope: rewrite `cc_universal_module_mm.md` into a universal MM-style module under 8000 characters without losing the core runtime contract

## Understanding

The current `cc_universal_module_mm.md` is high quality but too large for the target budget. The rewrite must stay universal, zero-shot, and free of priming or few-shot scaffolding. It must use the MM technique from `promptmaker.md`, meaning the final module should flatten visible structural scaffolding into dense narrative prose while still binding the required behavior with high fidelity. The result must remain suitable as a production contract for the `.cc` canvas layer rather than a decorative summary.

## Fixed Constraints

1. Keep the module universal. It must not assume a specific subject, persona, language style, or fixed page recipe.
2. Keep `.cc` as the only public trigger and treat the token as out-of-band control.
3. Keep the frozen host-native answer as the only semantic source of truth.
4. Keep the runtime-shell safety rules, bootstrap compatibility rules, and host/payload ownership boundaries.
5. Keep zero-shot operation. Do not add priming examples, few-shot scaffolds, or demonstration blocks.
6. Apply MM style: flatten visible structure into compact narrative prose and bind critical format/behavior in descriptive imperative language.
7. Final file must stay under 8000 characters.

## Non-Negotiable Contract Surfaces

- Trigger semantics and dormant behavior outside `.cc`
- Host-answer freeze and no second-author behavior
- Host-owned unit order, omission state, and visible grammar preservation
- Truthful metadata derivation
- Host-light fallback only when the host grammar is otherwise too thin
- Canonical bootstrap shell compatibility and stable runtime handoff
- Runtime shell non-interference
- Free-vs-standard mounted layout logic with truthful `data-cc-layout="free"` when applicable
- Placeholder and authored-visual policy with runtime-risk awareness
- Final self-check that preserves the safety envelope

## Delegation Plan

The `/sub` run is justified because the work benefits from two parallel read-heavy tasks before the parent lands a single final rewrite.

- Worker A: produce the tightest MM-style compressed draft that still feels production-safe.
- Worker B: review the original contract and identify any mandatory rules that the compressed draft must not drop.
- Parent: merge both into one final rewrite, enforce the character budget, and perform the final fidelity pass.

## Steps

1. Capture the approved plan and fixed constraints on disk. Completed.
2. Launch two read-only `/sub` workers for draft compression and dropped-rule review. Completed.
3. Merge the accepted results into a single MM-style rewrite and replace `cc_universal_module_mm.md`. Completed.
4. Verify character count, universality, zero-shot/no-priming posture, and contract fidelity. Completed.
5. Deliver the rewritten file with concise assumptions and verification notes. Completed.

## Verification Targets

- Final `cc_universal_module_mm.md` length is below 8000 characters.
- The rewritten module still clearly preserves the trigger, freeze, shell, layout, placeholder, and self-check contracts.
- The final voice reflects MM-style dense narrative binding rather than long visible scaffold lists.
- No topic-specific, persona-specific, or few-shot priming content is introduced.

## Rollback Boundary

- `cc_universal_module_mm.md`
- `plan/20260415-034130--work-plan--cc-universal-module-mm-rewrite--v01.md`

## Scoreboard

- Current score: 50
- Score source: provisional
- Last updated: 2026-04-15 03:41 KST
- Score rationale: the rewrite is landed and verified, but the user has not yet scored this pass, so the provisional score stays capped
- What improved: the module is now MM-compressed, universal, zero-shot, no-priming, and under the character budget
- What remains unsatisfactory: user acceptance is still pending and no downstream runtime evaluation has happened yet
- Next score action: keep fidelity high in the handoff and wait for user review

### Score History

- 2026-04-15 03:41 KST | 50 | provisional | new approved rewrite pass opened; no implementation landed yet
- 2026-04-15 03:58 KST | 50 | provisional | rewrite landed and verified under the budget; awaiting user judgment

## Worker Evidence

- Worker A: `019d8d4d-5267-7511-a34b-1695d140dc01` | draft compression and character-budget proposal
- Worker B: `019d8d4d-7f8d-7650-bde6-4d7f25664f46` | non-negotiable contract review and MM wording guidance

## Verification

- Rewritten file: `cc_universal_module_mm.md`
- Character count: `7094`
- Universal scope retained: yes
- Zero-shot and no-priming posture retained: yes
- `.cc` trigger exclusivity retained: yes
- Frozen host-answer contract retained: yes
- Canonical shell and runtime boundary contract retained: yes
- `free` / `standard` layout logic retained: yes
- Placeholder safety and `slot` / `block` / `cover` / `contain` guidance retained: yes
