# Work Plan

Plan Type: Work Plan
Workstream: Universal `.cc` exact-shell-lock refinement and hard revalidation
Version: v01
Status: Completed
Created: 2026-04-13 04:44:49 +09:00
Last Updated: 2026-04-13 04:51:19 +09:00
Related Plan:
- `plan/20260413-042708--work-plan--cc-universal-host-native-refinement--v01.md`
Supersedes: None

Approval Record

- The user reviewed a broken `.cc` sample and approved another recursive refinement pass with: `응 제대로하고 빡쌔게 테스트해 제대로나올때까지`.
- This approval applies to a new direction: exact `.cc` outer-shell lock, hard separation from `.ccc`, and repeated validation until the result stops drifting.

Current Completion State

- The current universal module exists at `cc_universal_module_mm.md`.
- The current module already preserves host-native inner structure more successfully than earlier versions.
- The user supplied a broken `.cc` sample in chat showing a different failure mode: the output preserved some host-native content shape but drifted away from the exact standard `.cc` shell.
- The current module size is 4150 characters, well inside the 5000-character target.
- The English module has been rewritten to hard-lock the `.cc` outer shell almost literally.
- Two read-only high-reasoning workers completed initial fail audits and final pass revalidation.
- The final accepted English module measures 4952 characters and stays inside the target budget.

Completed So Far

- Built an English universal `.cc/.ccc` module.
- Removed earlier article-template and keyword-summary-structure leakage.
- Revalidated the host-native preservation bar against a hostile host.
- Confirmed that the latest remaining defect is exact `.cc` shell looseness rather than host-structure corruption.
- Launched a new `/sub` refinement run dedicated to exact `.cc` shell lock.
- Captured initial fail verdicts from both workers isolating the missing literal shell bindings.
- Rewrote the English module to reproduce the canonical `.cc` shell almost literally and to restrict host-native freedom to the injection target.
- Re-measured the accepted module at 4952 characters.
- Captured final pass verdicts from both workers and preserved static evidence on disk.

Remaining Work

1. None for the approved English refinement scope.
2. Optional future follow-up: sync `cc_universal_module_mm_ko.md` to the accepted English version if translation parity is desired.

Current Blockers

- No active blocker remains for the approved scope.

Next Step

- Deliver the accepted result and evidence summary to the user.

Objective

The objective is to make `.cc` behave as a locked standard renderer instead of a soft suggestion. The module should preserve host-native content structure only inside the injected content surface, while the outer HTML document, asset order, loader, hidden main container, bootstrap script, and `renderAppShell` call pattern remain exact and non-negotiable. `.ccc` remains the only path that may freely redesign the page shell.

Scope

This workstream covers prompt refinement, worker review, evidence preservation, and edits to `cc_universal_module_mm.md`. It does not require editing the Ailey source prompt, bundle files, or deployment assets. It does not require browser automation unless ambiguity remains after prompt-level validation.

Primary Deliverables

- A revised `cc_universal_module_mm.md` with exact `.cc` outer-shell lock.
- New evidence under `subagent-runs/20260413-044449-cc-exact-shell-lock/`.
- An updated active plan with score tracking.
- A concise final report stating whether `.cc` is now strict enough and what residual limitations remain.

User Constraints

- Keep iterating hard until the result stops coming out incorrectly.
- Treat exact `.cc` shell fidelity as mandatory.
- Preserve host-native content structure only where it belongs.
- Keep the English module under 5000 characters if achievable.

Hidden Rules And Consistency Requirements

The hidden rule is that universality has two layers, not one. Inner content structure should follow the host prompt, but the `.cc` outer renderer shell should not follow the host. The broken sample showed that if the shell rule is too abstract, the model invents custom CSS, custom loader text, alternate `renderAppShell` signatures, and other freestyle behavior that belongs only to `.ccc`. Another hidden rule is that "host-native" does not mean "whole-document freedom" in `.cc`; it means "host-native within the injection target". A further hidden rule is that the bootstrap contract must be machine-simple and literal enough that the model cannot drift into a near miss.

Technical Approach

The parent will run two read-only workers. Worker 1 will act as a strict `.cc` shell-fidelity auditor and compare the current module against the original standard-shell contract and the user's broken sample pattern. Worker 2 will act as a hostile-output and failure-mode analyst, identifying the minimum wording needed to prevent `.cc` from becoming quasi-freestyle. The parent will then rewrite the module to distinguish exact `.cc` shell obligations from flexible inner content rules, re-measure size, and send the revision through a final delta audit.

Why Delegation Is Justified

The user explicitly asked for an aggressive iterative fix and prior rounds already used `/sub`. The failure mode is subtle because the current module can seem better on universality while simultaneously getting worse on exact shell fidelity. Parallel read-only review is therefore justified so one worker can guard the original shell contract while the other guards the corrected host-native logic.

Validation Strategy

Validation will focus on literal shell preservation for `.cc`. The accepted module must require the exact outer HTML5 shell shape: the canonical asset links in the right order, the `initial-loader`, the hidden `#ai-content-placeholder`, and the `DOMContentLoaded` script that calls `renderAppShell(c.outerHTML, document.title, document.querySelector('meta[name=\"canvas-id\"]').content)`. `.cc` should not allow extra shell CSS, alternate script signatures, or fallback shell redesign. At the same time, the inner content under `#ai-content-placeholder` must remain host-native. The final module should still expose `image-placeholder` and `visualization-placeholder` rules and remain under 5000 characters if possible.

Final Outcome Against Validation Strategy

- The canonical `.cc` shell is now bound almost literally.
- Outer-shell drift is explicitly blocked.
- Host-native inner-content freedom remains present and scoped to `#ai-content-placeholder`.
- Placeholder rules and `.ccc` freestyle behavior remain present.
- Size target is still satisfied at 4952 characters.

Definition Of Done

This run is complete when the module locks `.cc` to the exact standard shell, preserves host-native structure only inside the injection target, keeps `.ccc` as the freestyle path, passes read-only worker revalidation, passes parent static checks, and remains within or very near the size target with any residual tradeoffs clearly documented.

Risks

The main risk is over-tightening the `.cc` shell and accidentally reintroducing host-structure forcing inside the content surface. A second risk is keeping the module under budget while adding literal shell constraints. A third risk is leaving one ambiguous sentence that still permits custom loaders, custom styles, or alternate bootstrap code in `.cc`.

Open Questions

- Should `.cc` prohibit any inline `<style>` block outside the injected content surface, or is the exact shell lock sufficient without naming that prohibition explicitly?
- Should the `.cc` bootstrap script be described literally or almost literally to reduce drift?
- Should the module say that only `.ccc` may redesign body-level presentation?

Acceptance Criteria

- The revised module makes `.cc` outer shell exact and immutable.
- The revised module keeps host-native flexibility only inside `#ai-content-placeholder`.
- The revised module continues to preserve `image-placeholder` and `visualization-placeholder` authoring quality.
- `.ccc` remains the only freestyle shell path.
- The revised module stays under 5000 characters if achievable.
- `/sub` reviewers judge the shell-lock issue resolved.

Fallback And Repair Logic

If the first rewrite still allows shell drift, the next pass will replace abstract `.cc` shell wording with a more literal binding. If the first rewrite becomes too long, the next pass will compress explanatory prose while keeping the exact shell literal. If workers disagree, the parent will choose the smaller rule set that most directly prevents the broken sample pattern.

Operational Notes

- All workers remain read-only.
- The parent remains the only writer in the primary workspace.
- Evidence for this run will live under `subagent-runs/20260413-044449-cc-exact-shell-lock/`.

Scoreboard

Current Score: 50
Score Source: provisional
Last Updated: 2026-04-13 04:51:19 +09:00
Score Rationale: The corrected exact-shell-lock bar is now met, the module passed final worker revalidation, and the approved scope is complete. The provisional score remains capped at 50 until the user gives an explicit score.
What Improved:
- The remaining defect is sharply identified.
- The module is already under budget.
- The next refinement can be highly targeted.
- The accepted module now hard-locks the `.cc` shell.
- The accepted module still preserves host-native content only where intended.
What Remains Unsatisfactory:
- No blocking issue remains within the approved English-module scope.
- The Korean translation file is not yet synchronized to the final accepted English text.
Actions To Raise Or Maintain The Score:
- Run the read-only shell-fidelity audit.
- Lock the `.cc` outer shell literally.
- Revalidate and deliver the corrected module.
- Sync the Korean translation later if needed.

Score History

- 2026-04-13 04:44:49 +09:00 | score 50 | source provisional | New approved refinement run started after the user surfaced a broken `.cc` sample that showed exact shell drift despite improved host-native preservation.
- 2026-04-13 04:51:19 +09:00 | score 50 | source provisional | Scope completed. The module now passes the corrected exact-shell-lock bar and remains under budget, but provisional scoring stays capped at 50 until the user provides an explicit score.
