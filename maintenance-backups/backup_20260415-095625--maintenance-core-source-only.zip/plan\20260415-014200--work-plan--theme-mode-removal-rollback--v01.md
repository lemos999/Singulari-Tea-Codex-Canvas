# Work Plan - Theme Mode Removal Rollback - v01

- Status: completed
- Type: rollback
- Created: 2026-04-15 01:42 KST
- Scope: restore the pre-theme-removal shell/theme behavior without disturbing unrelated later work

## Understanding

The recent `theme mode removal` pass removed the visible theme toggle and parts of the theme restore flow. A prior rollback attempt used a partially contaminated backup, which left the workspace in an inconsistent state with missing theme controls and mojibake in restored files. The goal is to restore the theme-capable state from a known-good pre-removal snapshot, rebuild the local bundle, verify the recovered UI strings and theme controls, and then publish the corrected bundle to GitHub.

## Constraints

- Restore only the files directly affected by the theme-removal pass when possible.
- Do not revert unrelated later product changes such as live HTML export behavior.
- Keep rollback safety high: use a known-good backup and verify before publishing.

## Plan

1. Identify a clean pre-theme-removal snapshot and confirm it contains the theme toggle and saved-theme logic.
2. Restore only the affected source files from that snapshot using UTF-8-safe writes.
3. Rebuild the local bundle from restored sources.
4. Verify recovered behavior in source and bundle: theme toggle exists, saved-theme logic exists, and broken Korean strings are gone from restored files.
5. Sync the rebuilt bundle to the publish repo and push a rollback commit.

## Progress

- Completed:
  - confirmed the latest `pre-theme-mode-removal` backup was already contaminated
  - identified `backup_20260415-002809--pre-openai-oauth-pass.zip` as a clean pre-removal source for key files
- In Progress:
  - none
- Pending:
  - none
- Completed:
  - restored `000_shell_template.js`, `001_state_globalVars.js`, `005_shell_part6_main_assembler.js`, and `120_core_main_initializer.js` from the clean pre-removal snapshot
  - confirmed theme-toggle and saved-theme logic are back in source
  - discovered broader source encoding contamination still affects fresh rebundles
  - restored local and publish bundles from the last known-good pre-removal publish commit `1c8fe9c`
  - pushed rollback publish commit `cdb548b`

## Risks

- Older clean backups may predate unrelated changes in the same files, so full-file restore must be limited to files whose later edits are understood and acceptable.
- Prior mojibake indicates encoding safety matters during restore.

## Rollback Strategy

- If the rebuilt bundle fails verification, stop before publish and keep the current publish repo untouched.
- If publish verification fails after sync, revert the publish repo to the last known-good commit before this rollback attempt.

## Scoreboard

- Current score: 50
- Score source: provisional
- Last updated: 2026-04-15 02:03 KST
- Score rationale: requested rollback is complete and published, but a wider encoding issue remains unresolved for future rebuilds
- What improved:
  - restored the visible theme system
  - reverted the published bundle to a known-good state
  - avoided re-publishing a newly built bundle with mojibake contamination
- What remains unsatisfactory:
  - fresh rebundles from current source still need separate encoding diagnosis
- Next to raise or maintain score:
  - keep theme-removal changes blocked
  - diagnose and fix the broader encoding contamination before any future publish from a local rebuild

### Score History

- 2026-04-15 01:42 KST - provisional 40 - rollback requested; diagnosis complete, restoration pending
- 2026-04-15 02:03 KST - provisional 50 - rollback completed and published from known-good pre-removal bundle; encoding issue still open for future rebuilds
