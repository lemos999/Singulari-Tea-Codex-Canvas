Report Type: implementation-report
Workstream: Startup Header Ready Optimization Retry
Version: v01
Status: Completed
Created: 2026-04-15 02:01 KST
Related Plan: plan/20260415-014500--work-plan--startup-header-ready-optimization-retry--v01.md

# Summary

This pass retried the startup optimization using a narrower boundary than the previously rolled-back attempt. The earlier failed pass mixed startup behavior changes with a broad rewrite of a file that contains Korean UI strings. That widened the risk surface and led to visible text corruption. This retry changed only the header dock unlock timing and avoided editing any Korean string-bearing lines.

# What Changed

The only source behavior change was in `Ailey/src/03_core/100_core_firebase.js`.

- Added a tiny ASCII-only helper that removes `controls-disabled` from `.fixed-tool-container`.
- Called that helper immediately after `await loadUserSettingsFromFirebase();`.
- Left `seedDefaultData()` and `initializeListeners()` in place and still awaited them.
- Left the later connection-toast block intact so the rest of startup flow remained unchanged.

This means the app still completes startup exactly as before, but the top-right dock no longer keeps showing `로딩 중...` while later non-critical initialization continues.

# Why This Was Safe

The retry intentionally did not:

- rewrite the whole startup file
- move seeding to the background
- change listener contracts
- modify Korean literals
- edit any other startup module

That kept rollback limited to one source file and one bundle artifact.

# Validation

Validation harness:

- `visual-tests/validate_startup_header_ready_retry.mjs`

Validation output directory:

- `visual-tests/startup-header-ready-retry-2026-04-14T17-31-57-916Z/`

Observed results:

- `unlockAfterSettings=true`
- `unlockBeforeSeedEnd=true`
- `unlockBeforeListenersEnd=true`
- `toolContainerUnlocked=true`
- `loaderVisibleAfterUnlock=false`
- `presetLabelReadable=true`
- `toastMessageHasHangul=true`
- `toastContentHasHangul=true`
- `pageErrorCount=0`
- `consoleErrorCount=0`

Extra byte-safety check:

- The `showConnectionToast(...)` argument block inside `Ailey/src/03_core/100_core_firebase.js` was compared against the known-good backup zip.
- Result: exact byte match.

# Publication

Publish repo:

- `Singulari-Tea-Codex-Canvas-pr`

Published commit:

- `83debc4` — `Optimize startup header readiness safely`

Published artifact:

- `bundle/main.js`

# Rollback Note

If the user still sees a startup issue in the real runtime, rollback is small and obvious:

- restore `Ailey/src/03_core/100_core_firebase.js`
- restore `Ailey/bundle/main.js`
- republish the prior bundle

No additional architectural rollback is needed because listener and seeding behavior were not changed in this pass.
