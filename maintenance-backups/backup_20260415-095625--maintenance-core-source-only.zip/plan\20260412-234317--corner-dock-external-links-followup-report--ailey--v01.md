# Corner Dock External Links Follow-up Report

- Created: 2026-04-12 23:43:17 +09:00
- Status: completed_pending_user_validation
- Scope: upper-right corner dock external shortcuts
- Related Plan: `plan/20260412-232926--corner-dock-header-followup-plan--ailey--v01.md`

## Summary

Added two external shortcut icons to the left of the snapshot button in the upper-right corner dock.

The two links are:

- GitHub: `https://github.com/lemos999`
- Support: `https://ctee.kr/place/fewweekslater`

## Code Changes

- Updated `Ailey/src/00_shell/000_shell_template.js`
  - added `#github-profile-link`
  - added `#support-link`
  - placed both before `#global-snapshot-btn`
  - updated the support shortcut icon to a coffee cup glyph

- Updated `Ailey/src_css/010_widget_header_addons.css`
  - ensured anchor-style dock buttons inherit the icon button appearance
  - added `text-decoration: none`
  - added visible keyboard focus treatment

## Verification

- `node --check Ailey/src/00_shell/000_shell_template.js`
- `node Ailey/bundler.js`

All checks passed.

## Hosted Bundle Deployment

- Target repo: `Singulari-Tea-Codex-Canvas`
- Delivery path: `bundle/main.js`, `bundle/main.css`
- Commit: `5a4ae0f`
- Commit message: `Use coffee icon for support link`
