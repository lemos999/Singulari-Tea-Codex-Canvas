# Work Plan: Compact Indicator And Hover Toolbar Overlay

- Timestamp: 2026-04-14 22:34 KST
- Scope: compact visibility plus message hover/tap toolbar overlay only

## Goals

- Show when chat auto-compact actually ran.
- Make message action hover UI float above the message instead of pushing layout down.
- Preserve mobile behavior so touch actions still work and do not resize the message card.

## Steps

1. Inspect compaction call path and confirm where to attach a user-facing signal.
2. Attach compact metadata to the resulting AI message and emit a small toast on compaction.
3. Convert message toolbar from in-flow insertion to absolute overlay positioning.
4. Validate desktop hover and mobile tap behavior in a browser harness.
5. Publish only refreshed bundles after passing validation.

## Rollback Boundary

- `Ailey/src/04_features_chat/215_chat_orchestrator.js`
- `Ailey/src/04_features_chat/216_chat_context_compaction.js`
- `Ailey/src/04_features_chat/224_chat_ui_messages_element_factory.js`
- `Ailey/src/04_features_chat/225_chat_ui_messages_toolbar.js`
- `Ailey/src_css/009_message_toolbar.css`
- `Ailey/src_css/022_chat_messages.css`
- `visual-tests/validate_compaction_indicator_and_toolbar_overlay.mjs`
