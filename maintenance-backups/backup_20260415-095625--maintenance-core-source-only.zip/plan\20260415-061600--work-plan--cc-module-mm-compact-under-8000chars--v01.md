# Work Plan: CC Module MM Compact Under 8000 Chars

- Timestamp: 2026-04-15 06:16 KST
- Owner: Codex
- User approval: granted
- Type: work-plan
- Status: completed
- Scope: create a new Markdown file that rewrites `cc_universal_module_mm.md` in a tighter MM-style form under 8000 characters while preserving the critical `.cc` runtime and composition contract

## Understanding

The user wants a new compressed `.md` artifact rather than another in-place rewrite of the current file. The real goal is to preserve the current `.cc` contract but express it more compactly, in MM style, under 8000 characters. The new text must keep the critical runtime, host-preservation, placeholder, aesthetic, theme-compatibility, and self-check rules while avoiding bulk and repetition.

## Goals

1. Create a new Markdown file instead of replacing the current `cc_universal_module_mm.md`.
2. Keep the new file under 8000 characters.
3. Preserve the critical `.cc` contract:
   - `.cc` as the only trigger
   - frozen host answer as the semantic source of truth
   - host-unit preservation
   - truthful metadata
   - host-light fallback with subject-native composition
   - official runtime bootstrap and mandatory `bundle/main.js`
   - shell-safe head freedom
   - required runtime theme compatibility
   - mandatory `image-placeholder` and `visualization-placeholder`
   - risk-aware visual support
   - final self-check
4. Keep the prose in a compressed MM-style contract voice rather than turning it into bullets or examples.

## Planned Changes

1. Extract the minimum non-negotiable rules from the current module.
2. Rewrite those rules into a tighter MM-style continuous contract.
3. Save the result as a new Markdown file.
4. Measure character count and trim until it is below 8000 without dropping key contracts.
5. Re-read the compact file for omissions and drift.

## Risks And Constraints

- Over-compression could silently drop important runtime or safety rules.
- The current file includes many overlapping visual-support rules, so the compact version must merge without weakening meaning.
- The safest approach is to preserve the high-level contract and compress repetition rather than inventing a new policy.

## Validation

- Confirmed the new file `cc_universal_module_mm_compact_v01.md` is under 8000 characters.
- Confirmed the new file still explicitly covers the critical `.cc` trigger and host-freeze rules.
- Confirmed the new file still explicitly covers official runtime bootstrap and mandatory `bundle/main.js`.
- Confirmed the new file still explicitly covers theme fit, aesthetic fit, and mandatory dual placeholders.
- Confirmed the new file still includes a final self-check.

## Definition Of Done

A new `.md` file exists with a compact MM-style rewrite of the `.cc` module, under 8000 characters, preserving the critical runtime and composition contract.

## Rollback Boundary

- new compact `.md` file only
- `plan/20260415-061600--work-plan--cc-module-mm-compact-under-8000chars--v01.md`

## Scoreboard

- Current score: 50
- Score source: provisional
- Last updated: 2026-04-15 06:23 KST
- Score rationale: the compact MM-style file was created and validated under the character limit, but no explicit user score has been given yet so the provisional score remains capped
- What improved: a new under-8000 compact `.cc` module file now exists and preserves the major runtime, placeholder, aesthetic, and self-check contracts
- What remains unsatisfactory: validation was bounded to textual coverage and character count, not downstream prompt-behavior testing
- Next score action: wait for the user's readout on whether the compact tone and rule density feel right

### Score History

- 2026-04-15 06:16 KST | 50 | provisional | approved compact MM rewrite pass opened
- 2026-04-15 06:23 KST | 50 | provisional | compact MM rewrite landed under 8000 characters with core `.cc` contracts preserved
