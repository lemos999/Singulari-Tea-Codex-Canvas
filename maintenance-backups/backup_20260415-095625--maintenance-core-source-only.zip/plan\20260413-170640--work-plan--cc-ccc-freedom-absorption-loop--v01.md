Plan Type: Work Plan
Workstream: Absorb legacy `.ccc` freedom into unified `.cc`
Version: v01
Status: Completed
Created: 2026-04-13 17:06:40 +09:00
Last Updated: 2026-04-13 18:17:00 +09:00
Supersedes or Related Plan: Related `plan/20260413-161443--work-plan--cc-blind-freedom-stress-test--v01.md`; Related `plan/20260413-161443--cc-blind-freedom-stress-test-report--v01.md`
Current Completion State: The recursive improvement run is complete. The prompt has been hardened around free-layout subject-native composition and zero-key authored visuals, the runtime mount path has been corrected so canonical `.cc` payloads no longer remain hidden behind the preserved outer `<main>`, the clean round-2 batch has been regenerated, localbundle render evidence now exists for all four representative topics, and the final harsh `/sub` audit marked the batch as a pass.
Completed So Far: Re-read the active `cc_universal_module_mm.md`, re-read the most recent blind-stress-test report and parent verdict, isolated the failure pattern, completed the advisory rewrite loop, and preserved the approved workstream under this active plan. The prompt hardening pass shifted `.cc` toward stronger free-layout behavior and toward authored payload-native visuals when placeholder-backed support would risk shell interruption. A runtime fix landed in `Ailey/src/00_shell/005_shell_part6_main_assembler.js` so canonical `.cc` input is normalized to payload content before mount and keeps truthful layout metadata on the real runtime placeholder. The bundle was rebuilt with `node Ailey/bundler.js`. Clean round-2 canonical artifacts were then landed for the Portuguese sea route to India, ice smelt winter survival and symbolism, TLS 1.3 handshake, and supervised-vs-unsupervised learning. A clean localbundle harness was regenerated, screenshots were captured for all four artifacts, representative DOM checks confirmed `#immersive-header`, `#chat-panel`, `#notes-app-panel`, `#ai-content-placeholder`, and `#learning-content` coexist in the mounted runtime, and the final harsh audit returned `91 / 100` with a `Pass` verdict.
Remaining Work: No required implementation work remains under this plan. Optional future work would only pursue even more aggressive style diversity beyond the current passing threshold.
Current Blockers: No active blocker remains.
Next Step: Stop the mandatory loop and report the passing result to the user with evidence paths.

# Scoreboard

Current Score: 50 / 100
Score Source: provisional
Last Updated: 2026-04-13 18:17:00 +09:00
Score Rationale: The user has not provided an explicit satisfaction score yet, so the score must remain provisional and capped. However, the evidence state is now much stronger: the prompt no longer contains `.ccc` as a live literal public-mode concept, the runtime mount path renders canonical `.cc` payloads correctly, the clean round-2 batch renders without placeholder-modal failure, representative DOM checks confirm the persistent shell surfaces still exist, and the final harsh `/sub` audit scored the batch at `91 / 100` with a pass verdict.
What Improved:
1. The prompt now absorbs the older freestyle value into `.cc` without preserving `.ccc` as a live literal mode in the active prompt file.
2. The runtime mount path now correctly normalizes the canonical hidden outer `<main>` instead of leaving mounted payloads visually suppressed.
3. The round-2 batch now uses self-rendering zero-key visuals across route, specimen, protocol, and comparison topics rather than relying on risky placeholder-backed support.
4. The rendered screenshots show real subject-native variety instead of collapsing back into the old `title -> chips -> sections -> summary` house article.
5. Representative DOM checks confirm the runtime-owned shell surfaces remain present while the main canvas layout becomes far more expressive.
What Remains Unsatisfactory:
1. Some artifacts still favor a stable `hero -> board -> board -> board` rhythm rather than the widest possible page-shape variance.
2. The Portugal artifact still trends slightly closer to an analysis grid in the lower half than to a maximally varied atlas all the way down.
3. The current pass threshold is satisfied, but an optional future loop could still push stylistic entropy further if the user wants more experimentation.
Actions To Raise Or Maintain The Score:
1. Report the passing result and evidence bundle to the user.
2. Keep the optional next loop focused only on widening stylistic range if the user explicitly wants that.
3. Do not reopen mandatory repair work unless a new user-reported regression appears.

Score History:
1. 2026-04-13 17:06:40 +09:00 | score 50 | source provisional | New approved recursive `/sub` loop opened to absorb legacy `.ccc` freedom into the unified `.cc` contract.
2. 2026-04-13 17:24:13 +09:00 | score 50 | source provisional | Round-2 artifacts for TLS 1.3 handshake and supervised-vs-unsupervised learning were authored under the canonical shell with free-layout signaling, inline SVG visual support, and no placeholders.
3. 2026-04-13 17:37:37 +09:00 | score 50 | source provisional | Added the Portuguese route-atlas artifact and the ice-smelt specimen-feature artifact under the canonical shell with zero-key authored visuals and no placeholder dependence.
4. 2026-04-13 18:17:00 +09:00 | score 50 | source provisional | Runtime normalization fix verified, clean round-2 artifacts rendered successfully in the localbundle harness, representative shell-surface DOM checks passed, and the final harsh `/sub` audit scored the batch at 91/100 with a pass verdict.

# Objective

Revise `cc_universal_module_mm.md` so that unified `.cc` can behave with the compositional freedom formerly associated with `.ccc`, while still respecting the canonical bootstrap shell and the persistent runtime-owned header, chat, and notes surfaces.

The revised prompt should:

1. make subject-native freedom the default expectation for rich named-topic explanations instead of treating the article fallback as the safest default,
2. explicitly absorb legacy `.ccc` qualities such as immersive hero treatment, bespoke thematic rhythm, payload-local style systems, scoped local script, section-nav or control-deck style interior composition, and more decisive art direction,
3. reduce convergence on `title -> key terms -> section stack -> summary`,
4. choose safer visual-support strategies more often when runtime visualization stability is uncertain,
5. still preserve the canonical external shell and not drift into standalone page replacement.

# Confirmed Facts

The active prompt already removed `.ccc` as a public trigger.

The active prompt already allows `data-shell-layout="free"` or `data-cc-layout="free"` inside the mounted payload.

The most recent blind audit failed with a batch score of `69 / 100`.

The strongest win was the TLS 1.3 artifact; the biggest collapse was the supervised-vs-unsupervised comparison artifact.

The user explicitly wants the old `.ccc` freedom preserved in spirit, not just a more flexible article template.

# Working Assumptions

The smallest safe assumption is that the user is not asking to restore a second public trigger or a second body-level runtime. The user is asking for a single `.cc` trigger that can generate payloads with the boldness, specificity, and page-shaping confidence that old `.ccc` pages had.

The safest interpretation of “tailwind and etc” is not “import Tailwind CDN into the canonical shell,” because the shell contract still forbids that. The correct target is payload-level compositional freedom that feels as bold as old utility-first standalone pages while remaining scoped and shell-compatible.

The safest assumption is that scoped local `<style>` and payload-local `<script>` blocks should now be explicitly allowed when they are self-contained, truthfully tied to the host answer, and do not override runtime-owned shell chrome or require external credentials.

The next rewrite should aggressively demote keyword chips, recap blocks, and the default article scaffold from “recommended default” to “one available option among many.”

# Proposed Iteration Loop

## Loop 1

1. Advisory analysis with `/sub`
2. Parent lands rewrite in `cc_universal_module_mm.md`
3. Blind generation batch
4. Harsh audit

## Loop 2 if needed

1. Use the new failures only
2. Apply a targeted rewrite
3. Re-run the same blind matrix or a narrowed matrix
4. Re-audit

The run should stop early only if:

1. the new batch clearly passes the harsh threshold, or
2. remaining failures are runtime-only and no longer prompt-structural, or
3. another iteration would require a broader architectural change outside the prompt itself.

# `/sub` Team Design

This run will use a mixed staged team:

## Stage A: advisory workers

One worker focused on freedom absorption, anti-collapse rules, and subject-native composition families.

One worker focused on runtime-safe visual policy, scoped scripting, and shell-safe ways to recover old `.ccc` dynamism.

## Stage B: blind generation workers

At least two workers generating a harsh multi-subject batch after the rewrite.

## Stage C: harsh auditor

One late read-only auditor scoring the batch and deciding whether another iteration is required.

# Validation Strategy

Validation will again combine:

1. source-level contract inspection,
2. blind generation across materially different subject shapes,
3. screenshot review through the local runtime-compatible path,
4. harsh audit against an explicit rubric,
5. another rewrite only if the next failure surface is targeted enough to repair surgically.

# Definition Of Done

This run is complete when:

1. the prompt has been revised to absorb legacy `.ccc` freedom more explicitly,
2. a new blind `/sub` batch has been generated and audited,
3. the batch either passes or yields a clearly narrower and better-understood failure surface,
4. and the final report states whether the prompt is now good enough or still needs another round.

# Evidence Paths

Primary run directory:

`subagent-runs/20260413-170640-cc-ccc-freedom-absorption-loop/`

Primary plan path:

`plan/20260413-170640--work-plan--cc-ccc-freedom-absorption-loop--v01.md`
