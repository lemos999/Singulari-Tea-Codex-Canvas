# Ailey Visualization Options Upgrade Plan

- Artifact Type: product-and-implementation-plan
- Created: 2026-04-12 18:15:04 +09:00
- Status: implementation-complete-awaiting-manual-validation
- Scope: redesign and expand the visualization options modal, its backing settings model, the related post-generation action menu, the naming system across adjacent studio surfaces, and the companion image-generation studio
- Goal: turn the old "options-adjust-then-regenerate" flow into a clearer, more powerful, more intuitive, and more reliable generation control surface across both visualization and image-generation studio workflows
- Relationship to Prior Work:
  - extends `20260412-145425--visualization-generation-stability-plan--ailey--v01.md`
  - builds on `20260412-161230--ui-surface-rationalization-plan--ailey--v01.md`
  - assumes the current single-item generation enforcement remains in place

## Scoreboard

- Current Score: 77
- Score Source: provisional
- Last Updated: 2026-04-12 22:15:44 +09:00
- Rationale: the approved second-pass scope remains implemented and deployed, and the latest follow-up reduced the studio "chrome thickness" in both the visualization options studio and the scene image studio. The top header, subtitle, AI recommendation strip, and quick-note band now consume less vertical space by default and compress further under low-height windows, leaving more room for actual controls and content. Manual browser validation is still pending.
- What Improved: option labels remain more intuitive, AI recommendation semantics remain clearer and safer, the library stage now explains that selection is a preference rather than a guaranteed runtime contract, the prompt contract now prefers latest-track CDN URLs for new generations, the renderer can rescue pinned legacy URLs and certain scene-breaking hex literal mistakes, the hosted bundle now carries those protections, the image-generation studio memo surface is more usable for longer scene briefs, scene-image memo prefill is now anchored to the selected image block's own prompt history, the left-side helper note no longer visually collides with the memo label, low-height window shrink now preserves left-card integrity by scrolling the column instead of crushing cards together, and both studio headers now leave noticeably more vertical room for real working content.
- What Remains Unsatisfactory: the broader library surface still depends on real browser testing to confirm which preferences feel best in practice, latest-track CDN loading intentionally trades some maintenance burden for more upstream drift risk, some legacy image blocks may still fall back to broader context if they never stored a prompt, and final product quality still depends mostly on manual UX validation rather than missing code paths.
- Next Score Target: confirm the rebuilt studio surfaces and naming system in exported/live HTML usage and then close this plan at user-validated completion.

### Score History

- 2026-04-12 18:15:04 +09:00 | 50 | provisional | The user approved a full modernization of the visualization options surface and implementation began under this plan.
- 2026-04-12 19:21:09 +09:00 | 50 | provisional | The shipped option-upgrade surface was extended again with criteria-based AI recommendation mode, explicit lock-state UX, and a redeployed hosted bundle, but manual validation is still pending.
- 2026-04-12 19:39:00 +09:00 | 50 | provisional | The final live modal path was patched so AI recommendation now activates correctly in the shipped runtime and the hosted bundle was redeployed for retest.
- 2026-04-12 19:55:51 +09:00 | 50 | provisional | The visualization options modal was restyled into a studio-style split layout and redeployed for manual validation.
- 2026-04-12 20:02:29 +09:00 | 50 | provisional | A studio-layout follow-up fixed left-panel clipping by preventing sidebar stage cards from shrinking and by resetting panel scroll positions whenever the modal opens.
- 2026-04-12 20:15:14 +09:00 | 50 | provisional | A responsive-surface follow-up made the visualization studio viewport-safe during window shrink and hardened AI-edit submenu hover so users no longer need to move the pointer unnaturally fast.
- 2026-04-12 20:20:59 +09:00 | 50 | provisional | A stacked-layout follow-up unified modal scrolling below the preview section and retuned the cancel/regenerate action buttons to match the active light or dark theme more coherently.
- 2026-04-12 20:29:00 +09:00 | 50 | provisional | The user approved a broader second-pass scope: make classification labels more intuitive across the relevant studio surfaces, tighten AI recommendation defaults, expand libraries and addon policy controls, finish the preview-order/overflow cleanup, and remodel the image-generation studio as part of the same delivery pass.
- 2026-04-12 21:09:48 +09:00 | 68 | provisional | The broader second-pass scope shipped: intuitive naming was expanded across both studio surfaces, AI recommendation was hardened to stay off unless restored from remembered form state, the visualization prompt now treats unsupported preferred libraries as safe substitution hints, the image-generation studio was remodeled with clearer terminology, and the hosted bundle was redeployed for manual validation.
- 2026-04-12 21:29:34 +09:00 | 72 | provisional | A maintenance-and-resilience follow-up moved visualization dependencies toward latest-track CDN loading, widened the image studio scene-description memo area, added a renderer-level repair for Three.js bare hex literal mistakes that had been leaving scene blocks as empty dark canvases with UI overlays only, and redeployed the hosted bundle for manual validation.
- 2026-04-12 21:39:02 +09:00 | 73 | provisional | The visualization studio state model was tightened again so AI recommendation is opt-in only: reopening the studio no longer reactivates the AI recommendation toggle from remembered last-form state or from existing block metadata, and the hosted bundle was redeployed for retest.
- 2026-04-12 21:56:35 +09:00 | 74 | provisional | The scene-image studio now prefills its memo from the selected image block's stored prompt instead of defaulting to full-page context, newly generated images persist that prompt back onto the block for future edits, and the hosted bundle was redeployed for retest.
- 2026-04-12 22:03:28 +09:00 | 75 | provisional | A left-column layout follow-up separated the scene-image studio helper note and memo-card header with explicit internal spacing and divider treatment, fixing the visible text overlap regression in the remodeled studio and redeploying the hosted bundle for retest.
- 2026-04-12 22:09:20 +09:00 | 76 | provisional | A low-height resilience follow-up stopped the scene-image studio left-side cards from shrinking under short window heights, so the column scrolls instead of letting reference-note content spill into the memo card, and the hosted bundle was redeployed for retest.
- 2026-04-12 22:15:44 +09:00 | 77 | provisional | A chrome-thinning follow-up compressed the top header and guidance bands in both the visualization options studio and the scene image studio, including extra low-height compression rules, and redeployed the hosted bundle for retest.

## Why This Plan Exists

The current visualization option system still reflects an earlier generation of the product.

It is functional, but it is no longer coherent enough for the current runtime, prompt quality, and user expectations.

The user wants this old system upgraded rather than merely patched.

That means:

- better information architecture
- clearer generation intent controls
- expanded category coverage
- stronger option-to-prompt mapping
- more useful post-generation actions
- safer persistence and clearer defaults

## Current-State Analysis

### 1. The modal is feature-rich but mentally flat

Relevant files:

- `Ailey/src/00_shell/002_shell_part3_b.js`
- `Ailey/src/00_shell/002_shell_part3_c.js`
- `Ailey/src_css/004_widget_visualization_options.css`
- `Ailey/src/03_core/121_core_initializer_visualization.js`

Observed problems:

- the modal mixes library selection, generation intent, global toggles, themes, and free-form prompting at the same visual level
- users must understand implementation details such as libraries too early
- there is no strong top-down path like:
  - what outcome do I want
  - how interactive should it be
  - what kind of renderer is appropriate
  - what stylistic tone should it use
- the current three-step framing is visually present, but the interaction model still behaves like a large checkbox wall

Consequence:

- discoverability is weak
- option combinations are hard to reason about
- the surface feels old and improvised instead of intentional

### 2. The current taxonomy is library-first instead of task-first

Observed problems:

- categories such as `general`, `custom`, `svg`, `3d`, `maps`, `diagrams`, and `specialized` are implementation-oriented
- these are useful for power users, but they are not the best primary decision axis for most generation requests
- some categories overlap semantically
- some useful output types do not have a clear home

Consequence:

- users choose libraries before clarifying the actual communication goal
- prompt construction has to infer too much from thin option structure

### 3. Settings exist, but the backing model is too thin for future growth

Relevant file:

- `Ailey/src/03_core/111_core_api_settings_data.js`

Observed current fields:

- `autoGenerateOnLoad`
- `educationalMode`
- `worldsimMode`
- `batchGenerationSize`

Problems:

- these settings are too coarse for an upgraded option system
- there is no durable concept of:
  - preferred interaction level
  - preferred complexity
  - preferred fallback strategy
  - preferred accessibility/contrast bias
  - preferred library family
  - preferred explanation density
  - preferred export friendliness

Consequence:

- most advanced choices are session-local and fragile
- meaningful defaults cannot evolve cleanly

### 4. The post-generation action menu is still too narrow and too implementation-shaped

Relevant file:

- `Ailey/src/02_utils/013_utils_block_renderer.js`

Current structure:

- `AI edit`
  - `옵션 조정 후 재생성`
  - `코드 문제 자동 수정`
- `채팅으로 설명`
- `소스 복사`

Problems:

- `AI edit` mixes strategic regeneration and low-level repair
- action naming is still too tool-centric
- the menu helps only after generation, but it does not expose the most common edit intents directly
- there is no concept of "change just one aspect"

Consequence:

- users must mentally map their intent into a technical submenu
- repeated refinement remains clumsy

### 5. There is no explicit compatibility model between options and renderer risk

Observed problems:

- some libraries are inherently more stable than others in this product context
- some output types are poor fits for exported/live HTML
- some themes and modes are more likely to cause layout or contrast issues

Consequence:

- the UI lets users ask for combinations that are technically possible but operationally risky
- the product is missing a first-class "safe fallback" strategy

## Product Direction

The upgraded system should move from:

- library-first
- flat checkbox selection
- weak persistence
- vague edit actions

to:

- goal-first
- progressive disclosure
- capability-aware recommendations
- stronger reusable presets
- intent-based refinement actions

## Proposed Future Information Architecture

### A. Primary decision layer: generation goal

This becomes the first thing the user chooses.

Suggested top-level goals:

- `Explain`
  - for educational, comparative, and concept-teaching visualizations
- `Explore`
  - for interactive data browsing and parameter play
- `Simulate`
  - for dynamic systems, worlds, and process behavior
- `Map`
  - for spatial, geographic, and topology-related output
- `Relate`
  - for network, flow, dependency, timeline, and graph structures
- `Present`
  - for dashboards, status panels, summary cards, and polished report visuals
- `Story`
  - for narrative, scene-like, or guided visual explanation blocks

### B. Secondary layer: visualization family

This refines the selected goal.

Suggested families:

- Standard Charts
- Comparison and Ranking
- Process and Flow
- Network and Relationship
- Spatial and Geographic
- Scientific and Analytical
- Simulation and World Systems
- Diagram and Concept Structure
- Timeline and Sequence
- Dashboard and Monitoring
- Scene and Generative Canvas

### C. Tertiary layer: renderer strategy

This is where libraries become visible.

Suggested modes:

- `AI Recommended`
- `Stable 2D`
- `Interactive Chart`
- `SVG-first`
- `Canvas-first`
- `3D Scene`
- `Map Engine`
- `Graph Engine`
- `Advanced Custom`

Library buttons still exist, but they become a lower-level override rather than the main starting point.

## Proposed Category Expansion

The old category list can be expanded and re-grouped as follows:

### Existing categories to retain in transformed form

- General Charts
- Custom and Graphics
- SVG Drawing
- 3D Visualization
- Maps and Geography
- Diagrams and Relationships
- Specialized Science

### New categories to add

- Timeline and Sequence
- Dashboard and Monitoring
- Comparison and Decision
- Process and Workflow
- System State and Architecture
- Education and Teaching
- Simulation and Sandbox
- Narrative Scene Visuals
- Accessibility-First Visuals

## Proposed Modal Structure

### Step 1. Goal

User answers:

- what should this visualization do
- who is it for
- how interactive should it be

Controls:

- goal cards
- audience chips
- interaction level chips

### Step 2. Form

User chooses:

- family
- renderer strategy
- optional explicit library override

Controls:

- family tiles
- stability badge
- export badge
- interaction badge
- fallback hint

### Step 3. Style

User chooses:

- visual tone
- density
- explanation style
- contrast safety bias

Controls:

- theme packs
- density scale
- annotation richness
- accessibility toggle

### Step 4. Prompt

User provides:

- free-form instructions
- optional page-context inclusion
- optional preset prompt injection

### Step 5. Review

System shows:

- selected goal
- selected family
- chosen renderer mode
- risk/stability summary
- fallback behavior if generation fails

## Proposed New Features

### 1. Preset packs

Add reusable presets such as:

- Teach clearly
- High-confidence stable
- Interactive sandbox
- Story-like explainer
- Scientific rigor
- Executive dashboard
- Map-first briefing
- Diagram-first architecture

### 2. Compatibility badges

Each family or renderer option should show:

- stability
- export compatibility
- runtime cost
- interaction strength
- DOM complexity

### 3. Fallback strategy control

Allow the user to express:

- prefer stability over ambition
- prefer ambition over simplicity
- if unstable, fall back to 2D
- if risky, use AI recommended stable mode

### 4. Accessibility-first mode

Add explicit toggles for:

- high contrast preference
- larger labels
- annotation clarity
- avoid low-contrast aesthetics

This should map into both the prompt and renderer behavior.

### 5. Result memory

Allow saving:

- favorite preset combinations
- last used goal/family combination
- preferred default mode

### 6. Better refinement actions after generation

Replace the current narrow `AI edit` submenu with intent-based actions such as:

- Make simpler
- Make more interactive
- Make more accurate
- Make more teachable
- Change style
- Change renderer
- Fix runtime issues
- Explain structure
- Duplicate with variations

These can still call the same underlying generation and repair logic, but the user-facing taxonomy should be much clearer.

## Proposed Data Model Expansion

Relevant file:

- `Ailey/src/03_core/111_core_api_settings_data.js`

Add a richer normalized visualization settings shape, for example:

- `defaultGoal`
- `defaultFamily`
- `defaultRendererStrategy`
- `defaultInteractionLevel`
- `defaultComplexityBias`
- `defaultFallbackPolicy`
- `preferHighContrast`
- `preferExportSafe`
- `favoriteVisualizationPresets`
- `rememberLastVisualizationForm`

Guardrail:

- keep migrations backward-compatible
- preserve current booleans while introducing structured defaults gradually

## Proposed Prompt and Generation Mapping Upgrade

Relevant files:

- `Ailey/src/03_core/121_core_initializer_visualization.js`
- `Ailey/src/03_core/102_template_data_visualizer.js`

Upgrade direction:

- convert UI selections into a structured generation brief
- stop flattening too many distinct intents into one free-form description blob
- preserve a clear mapping between:
  - goal
  - family
  - renderer strategy
  - theme/style
  - safety/fallback policy

This will make generation more predictable and easier to debug.

## Proposed UI/UX Rules

- primary UI should be Korean-first
- technical library details should appear only when useful
- the default path should be fast and safe
- advanced controls should be available but not required
- every risky mode should communicate that risk clearly
- every mode should declare its fallback behavior

## Concrete Phase Plan

### Phase 0. Audit and backup

- capture the current modal, settings model, and overflow menu behavior
- create a pre-upgrade backup

### Phase 1. Information architecture redesign

- redesign the modal flow around goal -> form -> style -> prompt -> review
- define the new category tree and naming system

### Phase 2. Data model upgrade

- expand normalized visualization settings
- add migration logic
- preserve old settings safely

### Phase 3. Modal shell rebuild

- rewrite `002_shell_part3_b.js` and `002_shell_part3_c.js`
- fix remaining legacy/mojibake labels while rebuilding
- improve layout, hierarchy, and discoverability

### Phase 4. Interaction logic upgrade

- refactor `openVisualizationOptionsModal(...)`
- separate goal/family/renderer/theme state cleanly
- add compatibility badges and fallback summaries

### Phase 5. Post-generation action menu redesign

- replace the current `AI edit` submenu with clearer intent-based categories
- unify regeneration, repair, explain, and source operations under a cleaner menu model

### Phase 6. Prompt contract and mapping upgrade

- create a structured generation brief builder
- map the upgraded modal model into the visualizer prompt

### Phase 7. Verification and deployment

- syntax checks
- bundling
- hosted bundle deployment
- manual exported/live HTML validation

## Immediate Recommendation

Do not try to "add a few more buttons" to the current surface.

The right move is:

- redesign the option model
- rebuild the modal shell
- then reintroduce expansion features on top of the cleaner structure

That gives the user both more power and less confusion.

## Suggested Execution Start

If approved for implementation, the best first execution slice is:

1. Phase 0 backup and artifact update
2. Phase 1 information architecture and copy rewrite
3. Phase 2 settings model expansion
4. Phase 3 modal shell rebuild

This is the smallest slice that creates visible product improvement without yet touching every downstream generation behavior.

## Execution Outcome

The approved scope was carried through to deployment before manual browser validation.

Completed work:

- Phase 0 backup completed
- Phase 1 information architecture redesign completed
- Phase 2 visualization settings model expansion completed
- Phase 3 modal shell rebuild completed
- Phase 4 interaction logic upgrade completed
- Phase 5 post-generation action menu redesign completed
- Phase 6 structured generation brief mapping completed
- Phase 7 verification, rebundle, and hosted bundle deployment completed

Primary implementation files:

- `Ailey/src/00_shell/002_shell_part3_b.js`
- `Ailey/src/00_shell/002_shell_part3_c.js`
- `Ailey/src_css/004_widget_visualization_options.css`
- `Ailey/src/03_core/111_core_api_settings_data.js`
- `Ailey/src/03_core/121_core_initializer_visualization.js`
- `Ailey/src/02_utils/013_utils_block_renderer.js`

Deployment:

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `d62cd3d`
- commit message: `Upgrade visualization options and refinement workflow`

Backup artifact:

- `backup_20260412-181802--visualization-options-upgrade-preflight.zip`

Validation status:

- syntax checks passed
- `node Ailey/bundler.js` passed
- hosted bundle deployed
- manual browser validation still pending

## Post-Deployment Follow-Up

After deployment, a live exported HTML regression was reported on `2026-04-12` in
`C:\Users\Lemos\Downloads\기단의 성질과 변화 (1).html`.

Observed issue:

- scene-type visualizations showed expected side padding before entering fullscreen
- after entering cinema mode once and exiting, the scene could reflow too wide and visually lose its left/right padding in the exported document

Root cause:

- live export scene layout used `100vw`-anchored width logic on `.visualization-execution-wrapper`
- that made the scene wrapper depend on viewport width instead of the padded article/container width
- cinema enter/exit also restored `document.body.style.overflow` loosely, which made the resize/scrollbar transition less deterministic

Fix applied:

- live export scene wrappers now size relative to the content container, with controlled bleed that preserves article padding instead of re-centering on viewport width
- cinema mode now stores the prior `body.style.overflow` value and restores that exact value on exit or `Escape`

Follow-up deployment:

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `4184a49`
- commit message: `Fix fullscreen exit padding regression for scene visualizations`

Follow-up validation status:

- rebundle passed
- hosted bundle redeployed
- manual browser validation pending from user

## Option Surface Expansion Follow-Up

After the first upgrade pass, the option surface was expanded again to make the modal materially more expressive instead of only cosmetic.

New option axes added:

- additional visualization families:
  - hierarchy
  - causal
  - distribution
  - forecast
  - accessibility
- additional renderer strategies:
  - DOM infographic
  - hybrid mixed render
  - table / matrix
- additional control dimensions:
  - audience mode
  - density mode
  - motion profile
  - static-safe fallback mode
  - detailed complexity tier
- additional presets:
  - executive brief
  - accessibility first
  - map explainer
  - process monitor
  - network analyzer
- expanded theme packs:
  - executive brief
  - whiteboard sketch
  - accessibility first
  - operations monitor

Implementation notes:

- the modal shell was rebuilt again so the new axes are visible and selectable
- settings persistence was extended so the new axes can be remembered between runs
- generation brief construction was expanded so the model now receives audience, density, and motion guidance directly
- the `Data Visualizer` system prompt was upgraded to interpret the richer brief more explicitly

Follow-up deployment:

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `98a6508`
- commit message: `Expand visualization option surface`

Follow-up validation status:

- syntax checks passed
- rebundle passed
- hosted bundle redeployed
- manual browser validation pending from user

## Cross-Studio Naming And Policy Hardening Follow-Up

The user approved a broader polish pass after the functional upgrades landed:

- make classification names easier to understand not only inside the visualization options studio but across adjacent studio surfaces
- keep `AI recommendation for full configuration` off by default unless it is explicitly restored from remembered last-used form state
- broaden the library/addon surface while making it clearer that library choice is a preference rather than a guarantee
- bring the image-generation studio up to the same quality level and naming clarity as the newer visualization studio

Observed product gap:

- the visualization studio was already more capable, but some wording still felt expert-oriented rather than instantly readable
- the image-generation studio still used older copy such as short tab names and utility phrasing that did not match the newer studio language
- the runtime prompt contract still assumed that a preferred library should be directly available, even though the UI now exposes a broader library wish surface than the strict safe runtime allowlist
- the old persisted `defaultUseAiRecommendedProfile` field could still exist in saved settings even though product intent had already shifted away from global default-on AI recommendation

Fix applied:

- visualization studio copy stayed Korean-first and more direct:
  - clearer AI recommendation explanation
  - clearer “library choice is preference” guidance
  - stronger summary-last studio flow
- image-generation studio naming was updated to read more naturally:
  - `화풍` -> `그림 스타일`
  - `구도` -> `화면 구도`
  - `빛` -> `조명`
  - `재질` -> `재료감`
  - `색감` -> `색 분위기`
  - side labels and helper copy were rewritten to sound less tool-centric
- context-menu action labels were also clarified:
  - `AI 편집` -> `AI로 다듬기`
  - `옵션 조정 후 재생성` -> `스튜디오에서 다시 구성`
  - `코드 문제 자동 수정` -> `코드 오류 고치기`
  - `채팅으로 설명` -> `작동 원리 설명`
  - `소스 복사` -> `원본 코드 복사`
- visualization settings normalization now hard-forces `defaultUseAiRecommendedProfile: false`
  - AI recommendation can still reappear through remembered last-used form state
  - it no longer persists as a global default-on setting
- the `Data Visualizer` prompt contract was upgraded so unsupported preferred libraries are treated as family preferences
  - when a chosen library is outside the strict safe allowlist
  - the generator now substitutes the nearest safe runtime library instead of failing or blindly violating the safe registry
- horizontal overflow protection was tightened again inside the visualization studio by forcing `overflow-x: hidden` on the major studio surfaces and by making the workspace grid width/min-width behavior more defensive

Primary implementation files:

- `Ailey/src/00_shell/002_shell_part3_b.js`
- `Ailey/src/00_shell/002_shell_part3_d.js`
- `Ailey/src/02_utils/013_utils_block_renderer.js`
- `Ailey/src/03_core/102_template_data_visualizer.js`
- `Ailey/src/03_core/111_core_api_settings_data.js`
- `Ailey/src_css/004_widget_visualization_options.css`

Follow-up deployment:

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `9fef433`
- commit message: `Refine studio language and AI recommendation defaults`

Follow-up validation status:

- syntax checks passed
- `node Ailey/bundler.js` passed
- hosted bundle redeployed
- manual browser validation pending from user

## Studio Panel Clipping Follow-Up

After the studio-layout redesign was deployed, the user reported that the left sidebar could reopen with the first stage partially hidden, making controls such as `generation goal` look clipped or missing.

Observed root cause:

- the left studio sidebar is a column flex container with internal scrolling
- its stage cards were still allowed to shrink on the flex axis
- the primary stage card also uses `overflow: hidden`
- when the sidebar reopened under constrained height or retained a prior scroll position, the first card could collapse enough to hide its button grid
- the modal also reused its prior internal scroll state, so reopen behavior could start mid-panel instead of from the top

Fix applied:

- the studio sidebar now forces its stage cards to `flex-shrink: 0`
- the final active modal-open path now resets:
  - left sidebar scroll position
  - right workspace scroll position
  - freeform textarea scroll position
- that reset also runs again on the next animation frame after the modal becomes visible, so the visible state is normalized even after repeated open/close cycles

Primary implementation files:

- `Ailey/src_css/004_widget_visualization_options.css`
- `Ailey/src/03_core/121_core_initializer_visualization.js`

Follow-up deployment:

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `58a5385`
- commit message: `Fix visualization studio panel clipping on reopen`

Follow-up validation status:

- syntax check passed
- rebundle passed
- hosted bundle redeployed
- manual browser validation pending from user

## Stacked Scroll And Action Styling Follow-Up

After the responsive-surface follow-up, the user reported two remaining UX issues:

- in the stacked studio layout, the modal felt like it stopped at `current configuration preview` and would not naturally continue down into the later sections
- the `cancel` and `regenerate` buttons still looked visually detached from the rest of the studio surface, especially in dark mode

Observed root cause:

- below the width breakpoint, the studio still kept nested scroll behavior across internal containers
- users experienced that as a broken modal because the screen looked like a single continuous surface but the actual scroll ownership remained fragmented
- the action buttons were still inheriting overly generic modal button styling rather than a studio-specific light/dark treatment

Fix applied:

- in stacked mode, the studio layout now becomes the primary scroll surface
- the sidebar and right-panel internal containers stop owning separate vertical scroll in that mode
- this makes the experience behave more like one continuous studio canvas when the layout collapses
- the action bar buttons now use studio-specific styling:
  - themed neutral secondary treatment for `cancel`
  - themed primary accent treatment for `regenerate`
  - matched hover, border, and shadow behavior for both light and dark mode

Primary implementation files:

- `Ailey/src_css/004_widget_visualization_options.css`

Follow-up deployment:

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `877777f`
- commit message: `Fix stacked studio scroll and modal action styling`

Follow-up validation status:

- rebundle passed
- hosted bundle redeployed
- manual browser validation pending from user

## Responsive Surface and Submenu Hover Follow-Up

After the studio redesign and clipping fix, the user reported two additional UX regressions:

- when the browser window shrank, the visualization options studio could become partially inaccessible until the window was enlarged again
- in the `AI edit` menu, the submenu path to `adjust options then regenerate` was fragile because a small hover gap caused the submenu to disappear unless the pointer moved very quickly

Observed root cause:

- the visualization options overlay still centered a large modal inside a fixed viewport without enough viewport-safe padding and overflow behavior for aggressive resize cases
- the studio modal also stayed in side-by-side mode too long during width reduction, making the surface less resilient before the existing mobile breakpoint
- the context submenu used a visible horizontal gap and immediate close-on-leave behavior, so normal pointer travel could momentarily exit the hover zone and collapse the submenu

Fix applied:

- made the visualization options overlay viewport-safe with:
  - overlay padding
  - overlay scrolling
  - top-aligned modal placement with centered margin
  - tighter viewport-based modal width and height clamps
- moved the studio layout collapse breakpoint earlier so the modal switches to stacked mode sooner during shrink
- removed the effective submenu gap by overlapping submenu placement slightly with the parent item
- added delayed submenu close logic and submenu self-hover handling so normal pointer travel no longer requires a rushed diagonal move

Primary implementation files:

- `Ailey/src_css/004_widget_visualization_options.css`
- `Ailey/src_css/008_context_menu.css`
- `Ailey/src/02_utils/012_utils_context_menu.js`

Follow-up deployment:

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `41a2670`
- commit message: `Harden visualization studio resize and submenu hover`

Follow-up validation status:

- syntax check passed
- rebundle passed
- hosted bundle redeployed
- manual browser validation pending from user

## AI Recommendation Activation Fix

After the earlier AI recommendation follow-up shipped, the user manually tested
`C:\Users\Lemos\Desktop\새 폴더 (2)\기단의 성질 (Properties of Air Masses).html`
and reported that clicking `AI recommendation for full configuration` appeared to do nothing.

Root cause:

- `Ailey/src/03_core/121_core_initializer_visualization.js` still contained several duplicate modal function definitions
- the AI recommendation helpers already existed, but the final active `openVisualizationOptionsModal(...)` path was still an older branch
- that stale live path did not actually wire the AI recommendation button, the textarea refresh path, or the lock-state behavior

Behavioral clarification:

- the current `AI recommendation` mode does **not** make a fresh model/API call
- it is a fast local recommendation pass
- it reads the placeholder prompt and the current free-form request text
- it scores that text against a product-defined criteria table
- it then chooses a coherent option set across goal, family, renderer, density, motion, fallback, and related toggles

Why this design is intentional:

- it keeps the modal responsive with no extra request latency
- it avoids an extra API cost for every recommendation click
- it keeps recommendation behavior deterministic enough to inspect and debug

Fix applied:

- the final live modal-open path now:
  - toggles AI recommendation on and off correctly
  - recomputes recommendations from current request text
  - refreshes recommendation state when textarea content changes
  - refreshes recommendation state after placeholder prompt injection
  - locks manual controls while AI recommendation is active
  - falls back to manual control when the user clicks a custom option
  - persists the AI-recommended configuration on confirm while the toggle remains on

Primary implementation file:

- `Ailey/src/03_core/121_core_initializer_visualization.js`

Follow-up deployment:

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `aa6c519`
- commit message: `Fix visualization AI recommendation modal activation`

Follow-up validation status:

- syntax check passed
- rebundle passed
- hosted bundle redeployed
- manual browser validation pending from user

## Studio Layout Follow-Up

The user asked for the visualization options modal to feel closer to the existing image-generation studio because the older modal still read more like a long settings form than a deliberate studio workspace.

Design direction:

- preserve the upgraded option surface and AI recommendation behavior
- restyle the modal as a split-pane studio
- move toward:
  - left-side control stack
  - right-side workspace and summary
  - stronger visual hierarchy
  - more intentional “configure then inspect” flow

Implementation notes:

- `Ailey/src/00_shell/002_shell_part3_b.js` was rebuilt into a studio-style modal shell
- the modal now uses:
  - a stronger studio header
  - a left sidebar for goals, structure, and audience controls
  - a right workspace for summary, behavioral tuning, library choice, and free-form request editing
- `Ailey/src_css/004_widget_visualization_options.css` received a studio-layout override so the modal now behaves more like the image-generation studio without changing its underlying IDs or behavior contracts
- existing option IDs and runtime hooks were preserved so the logic layer did not need a new state model just to support the new presentation

Follow-up deployment:

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `e6a6017`
- commit message: `Restyle visualization options as studio layout`

Follow-up validation status:

- syntax checks passed
- rebundle passed
- hosted bundle redeployed
- manual browser validation pending from user

## AI Recommendation Summary Visibility Follow-Up

After the activation fix, the user reported that the summary panel still did not clearly tell them that the current option state came from AI recommendation mode.

Observed UX gap:

- the AI recommendation toggle could be active
- the lock note could be visible
- but the summary itself still looked like an ordinary manual configuration snapshot
- this made it unclear whether the currently displayed values were manually chosen or AI-selected

Fix applied:

- the final active summary path now explicitly shows:
  - configuration source: `AI recommendation configuration` or `manual custom configuration`
  - AI recommendation badge in the safety/action line
  - AI recommendation reasons when available
- the summary therefore now reflects recommendation state instead of only reflecting raw selected values

Follow-up deployment:

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `a1a2cc1`
- commit message: `Show AI recommendation source in visualization summary`

Follow-up validation status:

- syntax check passed
- rebundle passed
- hosted bundle redeployed
- manual browser validation pending from user

## AI Recommendation Follow-Up

After the option-surface expansion, the recommendation path itself was upgraded so `AI recommendation` is no longer just another shallow toggle.

Observed follow-up problem:

- users need a mode that can choose the whole configuration from the placeholder prompt and current request text
- when that mode is active, manual option buttons become effectively irrelevant, but the UI previously did not explain why custom buttons should stop responding
- without an explicit explanation, disabled interaction can look broken instead of intentional

Product intent for the follow-up:

- `AI recommendation` should be criteria-based, not random and not a cosmetic preset
- it should inspect the current visualization request context and choose a full configuration
- while it is active, manual selection controls should be locked so the chosen configuration remains internally coherent
- the UI should explain that the lock is intentional and that turning AI recommendation off restores manual control

Implementation notes:

- the modal now includes a top-level `AI recommendation for full configuration` toggle
- recommendation scoring uses placeholder prompt text and current request text to infer:
  - generation goal
  - visualization family
  - renderer strategy
  - interaction level
  - audience mode
  - complexity bias
  - fallback policy
  - density mode
  - motion mode
  - preset
  - theme
  - library overrides when the request strongly implies a stable engine
- the summary panel now exposes the recommendation rationale so users can see why the system chose the active configuration
- when AI recommendation is active, manual category, renderer, library, and behavior buttons are disabled
- a short lock-state note now explains:
  - AI recommendation is currently on
  - the option buttons are intentionally locked
  - users should turn AI recommendation off if they want to customize manually

Primary implementation files:

- `Ailey/src/00_shell/002_shell_part3_b.js`
- `Ailey/src_css/004_widget_visualization_options.css`
- `Ailey/src/03_core/111_core_api_settings_data.js`
- `Ailey/src/03_core/121_core_initializer_visualization.js`

Follow-up deployment:

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `58526ea`
- commit message: `Refine visualization AI recommendation mode`

Follow-up validation status:

- syntax checks passed
- rebundle passed
- hosted bundle redeployed
- manual browser validation pending from user

## Latest CDN Track And Thermal Scene Repair Follow-Up

The user requested a maintenance-oriented change in dependency handling and also reported a scene block that showed only UI overlays without the actual 3D content.

Two concrete follow-up needs emerged:

- generated fragments were still carrying many hard-pinned CDN version URLs
- at least one exported thermal air-mass scene failed before rendering because the generated JavaScript used a CSS-style bare hex literal inside a Three.js material object

Observed maintenance issue:

- `Ailey/src/03_core/102_template_data_visualizer.js` still advertised many version-pinned CDN URLs
- that made new generations age faster than necessary
- existing exported/live HTML could also keep older pinned URLs in embedded visualization fragments

Observed runtime issue:

- `기단의 성질 (Properties of Air Masses) (2).html` contains a thermal scene block whose script includes:
  - `const groundMat = new THREE.MeshPhongMaterial({ color: #1a1a1a, side: THREE.DoubleSide });`
- this is invalid JavaScript
- the scene therefore fails at parse time
- result:
  - static HTML overlays still appear
  - the actual Three.js drawing surface never initializes
- conclusion: this specific failure is a generated code problem first, not a DOM collision problem

Implementation notes:

- `Ailey/src/03_core/102_template_data_visualizer.js` now prefers latest-track or versionless CDN URLs for the supported library allowlist
- `Ailey/src/02_utils/013_utils_block_renderer.js` now normalizes known visualization dependency URLs to maintained latest-track equivalents at runtime before loading
- the same renderer now also normalizes stylesheet links found inside generated fragments
- a new preflight repair pass converts bare JavaScript hex mistakes such as `color: #1a1a1a` into valid numeric literals such as `color: 0x1a1a1a`
- `Ailey/src_css/027_image_gen_studio.css` widened the image-generation studio left column and the scene-description memo surface so longer scene briefs fit more comfortably

Primary implementation files:

- `Ailey/src/02_utils/013_utils_block_renderer.js`
- `Ailey/src/03_core/102_template_data_visualizer.js`
- `Ailey/src_css/027_image_gen_studio.css`

Follow-up deployment:

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `35a22da`
- commit message: `Harden visualization runtime and studio dependency loading`

Follow-up validation status:

- syntax checks passed
- rebundle passed
- hosted bundle redeployed
- manual browser validation pending from user

## AI Recommendation Opt-In State Fix

After the language and recommendation redesign, the user reported that turning `AI recommendation for full configuration` off still did not feel trustworthy because the toggle kept coming back on when the visualization studio reopened.

Observed problem:

- the visualization settings model already said AI recommendation should not be a global default-on behavior
- however, reopening the studio could still revive the AI recommendation toggle through:
  - remembered last-form state
  - existing block generation metadata when modifying a previously generated visualization
- this made the toggle feel sticky even when the user had explicitly turned it off

Root cause:

- `getVisualizationFormDefaults()` still pulled `lastUsedForm.useAiRecommendedProfile`
- `persistVisualizationFormPreferences()` could still write the AI recommendation state back into `lastUsedForm`
- `buildVisualizationPrefillFromBlockData()` preserved block-level `generationOptions.useAiRecommendedProfile`
- the final active `openVisualizationOptionsModal()` then respected those incoming values and reactivated the toggle on modal open

Implementation notes:

- `Ailey/src/03_core/111_core_api_settings_data.js` now normalizes `lastUsedForm.useAiRecommendedProfile` to `false`
- `Ailey/src/03_core/121_core_initializer_visualization.js` now treats AI recommendation as an explicit per-open action:
  - form defaults no longer revive it from remembered state
  - persisted last-used form no longer stores it as a remembered preference
  - block prefill no longer reopens the studio with AI recommendation already active
  - the final active modal-open path force-starts with `useAiRecommendedProfile: false`

Behavioral intent:

- users can still turn AI recommendation on for the current session and generate with it
- generated blocks may still record that they were produced under AI recommendation mode
- but reopening the studio always starts from manual mode unless the user explicitly clicks AI recommendation again

Follow-up deployment:

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `5efd28b`
- commit message: `Keep visualization AI recommendation opt-in only`

Follow-up validation status:

- syntax checks passed
- rebundle passed
- hosted bundle redeployed
- manual browser validation pending from user

## Scene Image Memo Prompt-First Follow-Up

The user reported that the remodeled scene-image studio was still filling `장면 설명 메모` with the whole page context for certain already-rendered images, instead of showing the prompt that belonged to the selected image placeholder itself.

Observed problem:

- opening the scene-image studio from a rendered image could still pass a full `extractContextFromDOM(...)` dump into the memo textarea
- the modal accepted that incoming text as the default memo content
- this made the left memo field noisy, harder to edit, and semantically wrong for "edit this specific image"

Root cause:

- `Ailey/src/03_core/123_core_initializer_vision_logic.js` still opened the image studio from overlay controls by passing page-level DOM context
- `Ailey/src/03_core/125_core_initializer_vision_ui.js` treated the incoming text as the prefill source instead of preferring prompt data already stored on the selected image block
- newly generated images created from the studio did not consistently persist a dedicated memo/source prompt back onto the target image block, so later edits had no reliable block-local prompt to reopen from

Implementation notes:

- `Ailey/src/03_core/125_core_initializer_vision_ui.js` now resolves image-studio memo prefill in prompt-first order:
  - `data-studio-prompt`
  - then `data-prompt`
  - then the incoming fallback text
- the same file now stores the normalized scene memo back onto the target/generated image block so later reopen actions stay image-local
- the image-studio "include current screen context" toggle still works, but appended DOM context is now treated as an explicit temporary add-on instead of the default memo source
- `Ailey/src/03_core/123_core_initializer_vision_logic.js` now opens the studio from image overlay controls with the block's stored prompt first, only falling back to page context for older legacy blocks with no prompt metadata
- `Ailey/src/02_utils/013_utils_block_renderer.js` now opens rehydrated image placeholders the same way, preferring stored prompt metadata over nearby paragraph scraping

Behavioral intent:

- opening the scene-image studio for an existing image should feel like "edit this image's own scene prompt"
- page-level context should only appear when the user explicitly asks for it through the dedicated toggle
- once the user edits and regenerates an image, the new scene memo should remain attached to that image block for the next reopen

Follow-up deployment:

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `0e4031f`
- commit message: `Use image placeholder prompt for scene studio prefill`

Follow-up validation status:

- syntax checks passed
- rebundle passed
- hosted bundle redeployed
- manual browser validation pending from user
