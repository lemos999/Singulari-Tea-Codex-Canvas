/* --- Ailey & Bailey Canvas --- */
// File: 004_shell_part5_panel_vision_debugger.js
// Version: 3.0 (Clean Vision Weaver Surface)
// Description: Provides the Vision Weaver floating panel and its settings modal.

const SHELL_PART_5 = `
    <div id="vision-weaver-panel" class="draggable-panel">
        <div class="panel-header">
            <span>장면 이미지 생성</span>
            <div class="panel-controls">
                <button id="vision-weaver-settings-btn" class="panel-control-btn" title="설정">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
                        <path d="M12,8A4,4 0 0,1 16,12A4,4 0 0,1 12,16A4,4 0 0,1 8,12A4,4 0 0,1 12,8M12,10A2,2 0 0,0 10,12A2,2 0 0,0 12,14A2,2 0 0,0 14,12A2,2 0 0,0 12,10M19.03,7.39L20.45,5.97C20,5.46 19.54,5 19.03,4.55L17.61,5.97C16.07,4.74 14.12,4 12,4C9.88,4 7.93,4.74 6.39,5.97L5,4.55C4.5,5 4,5.46 3.55,5.97L4.97,7.39C3.74,8.93 3,10.88 3,13C3,15.12 3.74,17.07 4.97,18.61L3.55,20.03C4,20.54 4.5,21 5,21.45L6.39,20.03C7.93,21.26 9.88,22 12,22C14.12,22 16.07,21.26 17.61,20.03L19.03,21.45C19.54,21 20,20.54 20.45,20.03L19.03,18.61C20.26,17.07 21,15.12 21,13C21,10.88 20.26,8.93 19.03,7.39Z" />
                    </svg>
                </button>
                <button class="panel-control-btn panel-minimize-btn" title="최소화">
                    <svg viewBox="0 0 24 24" width="18" height="18">
                        <path d="M20,14H4V10H20" />
                    </svg>
                </button>
                <button class="panel-control-btn panel-maximize-btn" title="최대화">
                    <span class="icon-maximize">
                        <svg viewBox="0 0 24 24" width="16" height="16">
                            <path d="M4,4H20V20H4V4M6,8V18H18V8H6Z" />
                        </svg>
                    </span>
                    <span class="icon-restore">
                        <svg viewBox="0 0 24 24" width="16" height="16">
                            <path d="M4,8H8V4H20V16H16V20H4V8M16,8V14H18V6H10V8H16M6,10V18H14V10H6Z" />
                        </svg>
                    </span>
                </button>
                <button class="panel-control-btn close-btn" title="닫기">
                    <svg viewBox="0 0 24 24" width="22" height="22">
                        <path d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z" />
                    </svg>
                </button>
            </div>
        </div>
        <div id="vision-weaver-content">
            <div class="vision-weaver-controls">
                <button id="quick-generate-btn" class="vision-weaver-btn">
                    <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
                        <path d="M7,2V13H10V22L17,10H13L17,2H7Z" />
                    </svg>
                    <span>빠른 생성</span>
                </button>
            </div>
            <div id="image-panel-status"></div>
            <div id="image-display-area">
                <p style="color: #666; text-align: center;">생성된 이미지가 여기에 표시됩니다.</p>
            </div>
        </div>
    </div>

    <div id="vision-weaver-settings-modal" class="custom-modal-overlay">
        <div class="custom-modal vision-weaver-settings">
            <h3>장면 이미지 설정</h3>

            <div class="settings-section">
                <label for="active-preset-select">참조 이미지 프리셋</label>
                <div class="preset-main-controls">
                    <select id="active-preset-select">
                        <option value="none">사용 안 함</option>
                        <option value="1">프리셋 1</option>
                        <option value="2">프리셋 2</option>
                        <option value="3">프리셋 3</option>
                        <option value="4">프리셋 4</option>
                        <option value="5">프리셋 5</option>
                    </select>
                </div>
                <div id="preset-editor-container">
                    <div class="preset-url-group">
                        <label for="preset-url-main">메인 참조 이미지</label>
                        <div class="preset-url-input-wrapper">
                            <input type="text" id="preset-url-main" data-type="main" placeholder="대표 참조 이미지 URL을 입력하세요">
                            <div class="preset-preview" data-type="main"></div>
                            <button class="modal-btn preset-url-fetch" data-type="main">불러오기</button>
                        </div>
                    </div>
                    <div class="preset-url-group">
                        <label for="preset-url-face">얼굴 참조 이미지</label>
                        <div class="preset-url-input-wrapper">
                            <input type="text" id="preset-url-face" data-type="face" placeholder="얼굴 참고 이미지 URL을 입력하세요">
                            <div class="preset-preview" data-type="face"></div>
                            <button class="modal-btn preset-url-fetch" data-type="face">불러오기</button>
                        </div>
                    </div>
                    <div class="preset-url-group">
                        <label for="preset-url-clothing">의상 참조 이미지</label>
                        <div class="preset-url-input-wrapper">
                            <input type="text" id="preset-url-clothing" data-type="clothing" placeholder="의상 참고 이미지 URL을 입력하세요">
                            <div class="preset-preview" data-type="clothing"></div>
                            <button class="modal-btn preset-url-fetch" data-type="clothing">불러오기</button>
                        </div>
                    </div>
                </div>
                <small>프리셋을 선택하면 각 URL을 참조 이미지로 함께 사용합니다.</small>
            </div>

            <div class="settings-section">
                <label for="auto-generate-mode-select">자동 생성</label>
                <select id="auto-generate-mode-select">
                    <option value="off">끄기</option>
                    <option value="quick">빠른 생성</option>
                </select>
                <small>문단을 감지했을 때 빠른 생성만 자동으로 실행합니다.</small>
            </div>

            <div class="settings-section">
                <label for="image-api-select">이미지 생성 API</label>
                <div class="api-choice">
                    <span>장면 이미지 생성</span>
                    <select id="image-api-select">
                        <option value="universal">범용 API</option>
                        <option value="personal">개인 API</option>
                    </select>
                </div>
                <small>개인 API는 개인 설정이 준비된 경우에만 사용됩니다.</small>
            </div>

            <div class="custom-modal-actions">
                <button id="reset-all-presets-btn" class="modal-btn cancel">프리셋 초기화</button>
                <button id="vision-settings-close-btn" class="modal-btn">닫기</button>
            </div>
        </div>
    </div>
`;
