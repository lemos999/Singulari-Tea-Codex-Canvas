# Report: Compact Indicator And Hover Toolbar Overlay

- Timestamp: 2026-04-14 22:37 KST
- Work plan: `plan/20260414-223400--work-plan--compact-indicator-and-hover-toolbar-overlay--v01.md`

## What Changed

### 1. Compact visibility

- Auto-compact now leaves a visible signal when it actually runs.
- The send path emits a small toast saying the chat memory was compacted.
- The resulting AI answer now carries compact metadata so the response meta row shows a compact chip such as `메모리 압축 20개`.

### 2. Hover toolbar overlay

- Message actions no longer push the message card downward on desktop hover.
- The toolbar now renders as an absolute overlay anchored to the message container.
- Desktop AI messages float the toolbar outside on the right.
- Desktop user messages float the toolbar outside on the left.
- Mobile/touch mode still works, but the toolbar stays absolute so the message height does not change.

## Files Changed

- `Ailey/src/04_features_chat/215_chat_orchestrator.js`
- `Ailey/src/04_features_chat/216_chat_context_compaction.js`
- `Ailey/src/04_features_chat/224_chat_ui_messages_element_factory.js`
- `Ailey/src/04_features_chat/225_chat_ui_messages_toolbar.js`
- `Ailey/src_css/009_message_toolbar.css`
- `Ailey/src_css/022_chat_messages.css`
- `visual-tests/validate_compaction_indicator_and_toolbar_overlay.mjs`

## Validation

- Script: `visual-tests/validate_compaction_indicator_and_toolbar_overlay.mjs`
- Result dir: `visual-tests/compaction-toolbar-overlay-2026-04-14T13-33-01-349Z`
- Summary: `visual-tests/compaction-toolbar-overlay-2026-04-14T13-33-01-349Z/validation-summary.txt`

Key checks:

- `compactCallCount=1`
- `compactToastVisible=true`
- `compactMetaVisible=true`
- `desktopToolbarPosition=absolute`
- `desktopHeightStableOnHover=true`
- `mobileToolbarPosition=absolute`
- `mobileHeightStable=true`
- `pageErrorCount=0`
- `consoleErrorCount=0`
