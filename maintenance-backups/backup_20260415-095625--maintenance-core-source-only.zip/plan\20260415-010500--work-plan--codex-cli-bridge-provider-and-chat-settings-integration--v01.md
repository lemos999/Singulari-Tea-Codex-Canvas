Plan Type: implementation
Workstream: codex-cli-bridge-provider-and-chat-settings-integration
Version: v01
Status: Active
Created: 2026-04-15 01:05 KST
Updated: 2026-04-15 01:05 KST
Related:
- `plan/20260415-003900--work-plan--codex-oauth-feasibility-and-chat-settings-integration--v01.md`
- `plan/20260415-004000--codex-oauth-feasibility-report--v01.md`
Current Completion: 20%
Completed Work:
- Root backup completed before implementation.
- Direct browser-to-ChatGPT backend OAuth path was ruled out due to CORS.
- `codex.exe exec` was smoke-tested successfully with a minimal prompt.
- Current preset, provider, and chat transport surfaces were mapped.
Remaining Work:
- Implement localhost bridge backed by Codex CLI.
- Add a new bridge-backed provider/preset mode in chat settings.
- Wire bridge transport into the existing chat runtime.
- Validate local HTML and canvas-hosted pages against the same localhost bridge.
- Publish bundle changes only after the bridge path is confirmed stable.
Blockers:
- Browser runtime cannot spawn local processes, so the bridge must be an explicit local helper process.
Next Step:
- Implement the local bridge and integrate a rollback-safe provider mode into API settings.

# Scoreboard

- Current Score: 45
- Score Source: provisional
- Last Updated: 2026-04-15 01:05 KST
- Score Rationale: The correct transport path is now known and a working local bridge strategy has been validated conceptually, but the user-facing integration is not yet implemented.
- What Improved:
- The design now has a real transport target instead of a blocked browser OAuth flow.
- The bridge path preserves current API-key presets instead of replacing them.
- What Remains Unsatisfactory:
- No product code is wired yet.
- Bridge startup still depends on a separate local process.
- Next Actions Required To Raise Or Maintain The Score:
- Ship the bridge, preset mode, and transport wiring.
- Validate both local HTML and canvas/remote bundle pages on the same machine.
- Score History:
- 2026-04-15 01:05 KST | 45 | provisional | Direct browser OAuth ruled out, Codex CLI bridge path validated and approved for implementation.

# Objective

Add a second connection mode alongside the existing API-key flow:

- existing: direct API-key presets
- new: `Codex OAuth (Local Bridge)` presets

The result must work from both:

- local HTML/runtime mode
- canvas/remote-bundle mode running in the browser on the same machine

# User Intent

The user wants chat settings to support Codex/GPT OAuth in addition to the existing API-key presets. The user explicitly wants the feature to work in both local and canvas contexts, and wants rollback safety if the result is unstable.

# Constraints

- Browser pages cannot directly call the ChatGPT Codex backend because the backend rejects this app origin at the CORS layer.
- Browser pages cannot safely access or store Codex OAuth tokens directly.
- Existing API-key presets must keep working unchanged.
- Existing session/history/auto-compact behavior must remain intact.
- The new mode must fail clearly when the bridge is offline instead of pretending to be connected.
- The smallest safe assumption is that the user can run a local helper process on the same machine.

# Root Backup

- Completed before implementation.
- Archive: `backup_20260415-002809--pre-openai-oauth-pass.zip`

# Approved Design

## 1. Transport model

Introduce a localhost bridge process that exposes a narrow HTTP API:

- `GET /health`
- `GET /v1/models`
- `POST /v1/chat`

The bridge will:

- run locally on the user machine
- use the already-installed `codex.exe`
- rely on the existing ChatGPT/Codex login already present in the local Codex environment
- never expose OAuth tokens to the browser runtime

## 2. Browser integration model

Add a new provider family:

- `openai_codex_bridge`

This provider will be selectable from API settings and persisted like other presets, but it will use:

- bridge URL
- selected model
- bridge availability state

instead of:

- API key text entry

## 3. Runtime behavior

For this provider:

- model verification becomes bridge health + model discovery
- chat requests become localhost bridge calls
- canvas and local HTML both use the same browser fetch path to localhost

## 4. Failure handling

If the bridge is not running or not logged in:

- verification must fail with a clear status message
- send attempts must return a specific actionable error
- existing presets remain selectable and unaffected

# Work Plan

1. Create a local bridge implementation under the main source tree using only standard Node modules where practical.
2. Add provider helpers and preset persistence support for `openai_codex_bridge`.
3. Extend the API settings UI so the user can create and verify bridge presets without API keys.
4. Extend chat transport so the new provider routes to the bridge while preserving current history, compaction, and message metadata behavior.
5. Bundle, validate local and canvas browser flows, then publish runtime assets and document operation and rollback.

# Validation Plan

## Bridge

- Health endpoint returns ready state.
- Models endpoint returns at least the locally available Codex-capable models.
- Minimal chat request returns a response body without leaking tokens.

## Settings UI

- User can create a bridge preset.
- Verification populates model selector from the bridge.
- Active preset switching still works for API-key presets and universal mode.

## Chat runtime

- A bridge-backed preset can send a normal text message successfully.
- Auto-compact and history limit behavior still run before the provider call.
- Failure state is clear when the bridge is stopped.

## Local + canvas

- Local HTML using local bundle can talk to the bridge.
- Canvas/remote-bundle page on the same machine can talk to the bridge through localhost with CORS.

# Rollback Plan

If any regression appears:

1. Revert the bridge provider wiring and UI references.
2. Remove the bridge provider from preset selection surfaces.
3. Rebuild bundles.
4. Restore the last known-good publish bundle.

Because the new provider is additive, rollback should not require touching existing API-key provider behavior.

# Design Notes

- The bridge should run from an ASCII-safe working directory rather than the current workspace to avoid Unicode-path websocket/header issues seen during Codex CLI smoke tests.
- The browser should treat the bridge like a separate provider, not like an OpenAI API-key variant.
- The bridge should use a narrow, deterministic prompt contract for chat transport and not attempt to mirror every Codex CLI feature.
