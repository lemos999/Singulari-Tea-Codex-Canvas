# Chat Receive Pipeline Deep Review Report

Date: 2026-04-14
Workspace: `c:\Users\Lemos\Desktop\새 폴더 (2)`
Target: visualization regeneration / `[System] Visualization Engine` receive pipeline

## Scope

- Deep-review why visualization responses could appear truncated in chat.
- Reduce needless request multiplication under Gemini `429` / `503`.
- Preserve quota by avoiding pointless recovery retries when the provider is overloaded.
- Rebuild bundle and verify against `태양계의 파노라마.html`.

## Root Cause

This was not a single parser bug. It was a combined failure mode:

1. Provider-side partial or unavailable responses were not always treated as fatal unless the caller explicitly requested strict completion handling.
2. Visualization recovery always attempted a second `[FORMAT_RECOVERY]` pass even when the first failure was clearly provider-side (`429`, `503`, timeout, overload), which could double request usage without improving the result.
3. Google REST retry logic retried the same model internally several times by default, which made one user action consume more provider calls than expected.
4. When the provider did succeed, the system needed stronger completion/fallback metadata so the visualization path could distinguish:
   - valid closed HTML code blocks
   - incomplete provider output
   - temporary provider overload

## Changes

### `Ailey/src/04_features_chat/213_chat_api_service.js`

- Added configurable Google retry limit plumbing.
- Internal `_retryLimit` is now stripped from the request body and used only for transport retry control.
- `_fetchGoogleRestJson(...)` now accepts a caller-defined retry limit instead of always using the global default.

### `Ailey/src/04_features_chat/215_chat_orchestrator.js`

- Expanded Google fallback detection to include timeout / network-style failure strings.
- Added `apiRetryLimit` passthrough from `responseHandlingOptions` into the Google request config.
- Refactored the `google_paid` streaming branch to support ordered model fallback candidates.
- On model failure:
  - temporary streaming UI is removed
  - fallback is attempted only for retryable provider failures
  - final failure is surfaced once the candidate set is exhausted
- Usage accounting is now attributed to the actual model used.

### `Ailey/src/03_core/121_core_initializer_visualization.js`

- Added `getVisualizationFallbackModels()` to source fallback candidates from the active preset.
- Added `shouldRetryVisualizationFormatRecovery(...)` so format-recovery only runs for format-like failures, not for provider overload/quota failures.
- Visualization regeneration now calls `programmaticChatSendDetailed(...)` with:
  - `requireCompleteResponse: true`
  - `fallbackModels: ...`
  - `apiRetryLimit: 0`
- Result: one visualization regeneration no longer fans out into repeated same-model retries plus pointless format recovery when the provider is simply overloaded.

## Verification

### Static validation

- `node --check Ailey/src/04_features_chat/213_chat_api_service.js`
- `node --check Ailey/src/04_features_chat/215_chat_orchestrator.js`
- `node --check Ailey/src/03_core/121_core_initializer_visualization.js`
- `node .\Ailey\bundler.js`

### Browser validation

Artifacts:

- `visual-tests/visualization-receive-pipeline-2026-04-13T22-20-48/validation.json`
- `visual-tests/visualization-receive-pipeline-2026-04-13T22-20-48/validation-summary.txt`
- `visual-tests/visualization-receive-pipeline-2026-04-13T22-20-48/01-initial-runtime.png`
- `visual-tests/visualization-receive-pipeline-2026-04-13T22-20-48/02-system-session-after-probe.png`

Observed final result:

- `finishReason = STOP`
- `isComplete = true`
- `contentLength = 10554`
- `fenceCount = 2`
- `extractedLength = 10542`
- `latestSavedAiLength = 10554`
- UI summary label = `Visualization Fragment`
- `pageErrorCount = 0`
- `requestFailureCount = 0`

This confirms the final probe completed with a closed fenced HTML fragment and saved/rendered the full response instead of a truncated prefix.

## Quota / Retry Notes

- An earlier single-call probe hit `503 high demand`, which confirmed that provider overload was a live part of the failure envelope.
- The pipeline now avoids repeated same-model retries for visualization regeneration by setting `apiRetryLimit: 0` on that path.
- Format recovery is now skipped for provider overload/quota/timeout failures.

## Deployment Intent

- Publish updated `bundle/main.js`
- Publish updated `bundle/main.css`

## Assumptions

- The active local Gemini preset remains the user-controlled source of truth.
- Visualization/system tasks may use fallback models only when the active preset exposes them.
- Preserving quota is more important than aggressively auto-retrying provider-side overload failures.
