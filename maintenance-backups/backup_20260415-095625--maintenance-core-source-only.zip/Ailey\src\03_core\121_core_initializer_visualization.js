
/* --- Ailey & Bailey Canvas --- */
// File: 121_core_initializer_visualization.js
// Version: 6.0 (Raw HTML Protocol)
// Description: Replaced JSON parsing logic with direct HTML code block extraction. This aligns the API visualization flow with the stable .cc canvas generation method, preventing JSON syntax errors.

const ENFORCED_VISUALIZATION_BATCH_SIZE = 1;

const VISUALIZATION_OPTION_LABELS = {
    goals: {
        explain: '설명형',
        explore: '탐색형',
        simulate: '시뮬레이션',
        map: '공간·지도',
        relate: '관계형',
        present: '요약·발표형',
        story: '서사형'
    },
    families: {
        comparison: '비교·랭킹',
        timeline: '타임라인·순서',
        flow: '과정·흐름',
        network: '네트워크·관계',
        map: '지도·공간',
        science: '과학·분석',
        dashboard: '대시보드·모니터링',
        diagram: '개념도·구조도',
        scene: '장면형·제너러티브'
    },
    renderers: {
        'ai-recommended': 'AI 추천',
        'stable-2d': '안정형 2D',
        'interactive-chart': '인터랙티브 차트',
        'svg-first': 'SVG 우선',
        'canvas-first': 'Canvas 우선',
        'scene-3d': '3D 장면',
        'map-engine': '지도 엔진',
        'graph-engine': '관계형 그래프'
    },
    interactions: {
        low: '정적 중심',
        balanced: '균형형',
        high: '상호작용 강화'
    },
    complexities: {
        simple: '단순 명료',
        balanced: '균형형',
        ambitious: '풍부하고 실험적'
    },
    fallbacks: {
        'prefer-stable': '안정성 우선',
        balanced: '균형형',
        'prefer-ambitious': '표현력 우선'
    },
    audiences: {
        general: '일반',
        learner: '학습자',
        analyst: '분석자',
        presenter: '발표용'
    },
    presets: {
        custom: '직접 조정',
        'teach-clearly': '학습용 명료형',
        'stable-first': '안정성 우선',
        'interactive-lab': '인터랙티브 실험형',
        'dashboard-brief': '대시보드 브리핑',
        'story-scene': '서사 장면형',
        'scientific-rigor': '과학 분석형'
    }
};

const VISUALIZATION_PRESET_CONFIG = {
    'teach-clearly': {
        goal: 'explain',
        family: 'comparison',
        rendererStrategy: 'stable-2d',
        interactionLevel: 'balanced',
        complexityBias: 'simple',
        fallbackPolicy: 'prefer-stable',
        theme: '[학습용 클리어 보드]',
        educationalMode: true,
        worldsimMode: false,
        isSimulation: false,
        isSimpleMode: true,
        highContrastMode: true,
        exportSafeMode: true
    },
    'stable-first': {
        goal: 'present',
        family: 'dashboard',
        rendererStrategy: 'stable-2d',
        interactionLevel: 'low',
        complexityBias: 'simple',
        fallbackPolicy: 'prefer-stable',
        theme: '[표준 기본]',
        educationalMode: false,
        worldsimMode: false,
        isSimulation: false,
        isSimpleMode: true,
        highContrastMode: true,
        exportSafeMode: true
    },
    'interactive-lab': {
        goal: 'explore',
        family: 'science',
        rendererStrategy: 'canvas-first',
        interactionLevel: 'high',
        complexityBias: 'balanced',
        fallbackPolicy: 'balanced',
        theme: '[실험실 프로토타입]',
        educationalMode: true,
        worldsimMode: false,
        isSimulation: true,
        isSimpleMode: false,
        highContrastMode: true,
        exportSafeMode: false
    },
    'dashboard-brief': {
        goal: 'present',
        family: 'dashboard',
        rendererStrategy: 'interactive-chart',
        interactionLevel: 'balanced',
        complexityBias: 'balanced',
        fallbackPolicy: 'prefer-stable',
        theme: '[보고서형 대시보드]',
        educationalMode: false,
        worldsimMode: false,
        isSimulation: false,
        isSimpleMode: false,
        highContrastMode: true,
        exportSafeMode: true
    },
    'story-scene': {
        goal: 'story',
        family: 'scene',
        rendererStrategy: 'scene-3d',
        interactionLevel: 'balanced',
        complexityBias: 'ambitious',
        fallbackPolicy: 'balanced',
        theme: '[영화 장면형]',
        educationalMode: false,
        worldsimMode: true,
        isSimulation: true,
        isSimpleMode: false,
        highContrastMode: false,
        exportSafeMode: false
    },
    'scientific-rigor': {
        goal: 'explain',
        family: 'science',
        rendererStrategy: 'interactive-chart',
        interactionLevel: 'balanced',
        complexityBias: 'balanced',
        fallbackPolicy: 'prefer-stable',
        theme: '[과학 논문형]',
        educationalMode: true,
        worldsimMode: false,
        isSimulation: false,
        isSimpleMode: true,
        highContrastMode: true,
        exportSafeMode: true
    }
};

const VISUALIZATION_REFINEMENT_PRESETS = {
    simplify: {
        label: '더 쉽게 설명형으로',
        overrides: {
            presetKey: 'teach-clearly',
            goal: 'explain',
            family: 'comparison',
            rendererStrategy: 'stable-2d',
            interactionLevel: 'balanced',
            complexityBias: 'simple',
            fallbackPolicy: 'prefer-stable',
            educationalMode: true,
            highContrastMode: true,
            exportSafeMode: true,
            isSimpleMode: true
        },
        instruction: '[리파인먼트 요청]\n이번 결과를 더 쉽게 이해되는 학습형 시각화로 다시 구성해 주세요. 핵심 관계와 레이블을 더 명확하게 드러내고, 첫 화면에서 중요한 정보가 바로 보이게 해 주세요.'
    },
    interactive: {
        label: '더 상호작용적으로',
        overrides: {
            presetKey: 'interactive-lab',
            goal: 'explore',
            family: 'science',
            rendererStrategy: 'canvas-first',
            interactionLevel: 'high',
            complexityBias: 'balanced',
            fallbackPolicy: 'balanced',
            isSimulation: true,
            isSimpleMode: false,
            highContrastMode: true
        },
        instruction: '[리파인먼트 요청]\n이번 결과를 사용자가 직접 조작하며 탐색할 수 있도록 다시 만들어 주세요. 슬라이더, 토글, 드래그 등 의미 있는 상호작용을 우선해 주세요.'
    },
    stable: {
        label: '안정성 우선으로 재생성',
        overrides: {
            presetKey: 'stable-first',
            goal: 'present',
            family: 'dashboard',
            rendererStrategy: 'stable-2d',
            interactionLevel: 'low',
            complexityBias: 'simple',
            fallbackPolicy: 'prefer-stable',
            isSimulation: false,
            isSimpleMode: true,
            highContrastMode: true,
            exportSafeMode: true
        },
        instruction: '[리파인먼트 요청]\n이번 결과를 더 안정적이고 내보내기 친화적인 방식으로 다시 생성해 주세요. 복잡한 렌더러보다는 신뢰도 높은 2D 중심 접근을 우선해 주세요.'
    }
};

const VISUALIZATION_OPTION_LABELS_V2 = {
    goals: {
        explain: '개념 설명',
        explore: '직접 탐색',
        simulate: '변화 시뮬레이션',
        map: '지도·공간 해석',
        relate: '관계와 연결',
        present: '보고·발표',
        story: '이야기 장면'
    },
    families: {
        comparison: '비교와 차이',
        timeline: '순서와 시간',
        flow: '과정과 변화',
        network: '관계와 연결',
        map: '지도와 위치',
        science: '과학과 데이터',
        dashboard: '대시보드와 현황',
        diagram: '개념과 구조',
        scene: '장면과 세계관',
        hierarchy: '계층과 분류',
        causal: '원인과 결과',
        distribution: '분포와 통계',
        forecast: '예측과 전망',
        accessibility: '쉬운 이해와 접근성'
    },
    renderers: {
        'ai-recommended': '자동 추천',
        'stable-2d': '안정형 2D',
        'interactive-chart': '인터랙티브 차트',
        'svg-first': 'SVG·벡터',
        'canvas-first': 'Canvas·애니메이션',
        'scene-3d': '3D 장면',
        'map-engine': '지도 엔진',
        'graph-engine': '네트워크 엔진',
        'dom-infographic': 'DOM 인포그래픽',
        'hybrid-mixed': '혼합형 렌더',
        'table-matrix': '표·매트릭스'
    },
    interactions: {
        low: '정적 중심',
        guided: '가이드형',
        balanced: '균형형',
        high: '상호작용 강화'
    },
    complexities: {
        simple: '핵심만',
        balanced: '균형형',
        detailed: '정보 풍부',
        ambitious: '실험적 확장'
    },
    fallbacks: {
        'prefer-static-safe': '정적 대체 우선',
        'prefer-stable': '안정성 우선',
        balanced: '균형형',
        'prefer-ambitious': '표현력 우선'
    },
    audiences: {
        general: '일반 독자',
        learner: '학습자',
        analyst: '분석가',
        presenter: '발표용',
        executive: '의사결정자',
        'young-learner': '어린 학습자'
    },
    densities: {
        core: '핵심만',
        balanced: '균형형',
        detailed: '정보 풍부'
    },
    motions: {
        still: '정적',
        guided: '부드럽게',
        dynamic: '반응형',
        cinematic: '시네마틱'
    },
    addons: {
        off: '가급적 안 씀',
        auto: '필요할 때만',
        recommended: '추천 수준 사용',
        aggressive: '적극 활용'
    },
    presets: {
        custom: '직접 조정',
        'teach-clearly': '학습 설명형',
        'stable-first': '안정성 우선',
        'interactive-lab': '인터랙티브 실험실',
        'dashboard-brief': '대시보드 브리프',
        'story-scene': '서사 장면형',
        'scientific-rigor': '과학 분석형',
        'executive-brief': '의사결정 브리프',
        'accessibility-first': '접근성 우선',
        'map-explainer': '지도 설명형',
        'process-monitor': '과정 모니터링',
        'network-analyzer': '관계 분석형'
    }
};

const VISUALIZATION_PRESET_CONFIG_V2 = {
    'teach-clearly': {
        goal: 'explain',
        family: 'comparison',
        rendererStrategy: 'stable-2d',
        interactionLevel: 'guided',
        complexityBias: 'simple',
        fallbackPolicy: 'prefer-stable',
        audienceMode: 'learner',
        densityMode: 'core',
        motionMode: 'guided',
        addonPolicy: 'auto',
        theme: '[교과 설명형]',
        educationalMode: true,
        worldsimMode: false,
        isSimulation: false,
        isSimpleMode: true,
        highContrastMode: true,
        exportSafeMode: true
    },
    'stable-first': {
        goal: 'present',
        family: 'dashboard',
        rendererStrategy: 'stable-2d',
        interactionLevel: 'low',
        complexityBias: 'simple',
        fallbackPolicy: 'prefer-static-safe',
        audienceMode: 'general',
        densityMode: 'core',
        motionMode: 'still',
        addonPolicy: 'off',
        theme: '[표준 기본]',
        educationalMode: false,
        worldsimMode: false,
        isSimulation: false,
        isSimpleMode: true,
        highContrastMode: true,
        exportSafeMode: true
    },
    'interactive-lab': {
        goal: 'explore',
        family: 'science',
        rendererStrategy: 'canvas-first',
        interactionLevel: 'high',
        complexityBias: 'balanced',
        fallbackPolicy: 'balanced',
        audienceMode: 'learner',
        densityMode: 'balanced',
        motionMode: 'dynamic',
        addonPolicy: 'recommended',
        theme: '[실험실 프로토타입]',
        educationalMode: true,
        worldsimMode: false,
        isSimulation: true,
        isSimpleMode: false,
        highContrastMode: true,
        exportSafeMode: false
    },
    'dashboard-brief': {
        goal: 'present',
        family: 'dashboard',
        rendererStrategy: 'interactive-chart',
        interactionLevel: 'balanced',
        complexityBias: 'detailed',
        fallbackPolicy: 'prefer-stable',
        audienceMode: 'presenter',
        densityMode: 'detailed',
        motionMode: 'guided',
        addonPolicy: 'auto',
        theme: '[보고서형 대시보드]',
        educationalMode: false,
        worldsimMode: false,
        isSimulation: false,
        isSimpleMode: false,
        highContrastMode: true,
        exportSafeMode: true
    },
    'story-scene': {
        goal: 'story',
        family: 'scene',
        rendererStrategy: 'scene-3d',
        interactionLevel: 'balanced',
        complexityBias: 'ambitious',
        fallbackPolicy: 'balanced',
        audienceMode: 'general',
        densityMode: 'balanced',
        motionMode: 'cinematic',
        addonPolicy: 'aggressive',
        theme: '[서사 장면형]',
        educationalMode: false,
        worldsimMode: true,
        isSimulation: true,
        isSimpleMode: false,
        highContrastMode: false,
        exportSafeMode: false
    },
    'scientific-rigor': {
        goal: 'explain',
        family: 'science',
        rendererStrategy: 'interactive-chart',
        interactionLevel: 'balanced',
        complexityBias: 'detailed',
        fallbackPolicy: 'prefer-stable',
        audienceMode: 'analyst',
        densityMode: 'detailed',
        motionMode: 'guided',
        addonPolicy: 'recommended',
        theme: '[과학 논문형]',
        educationalMode: true,
        worldsimMode: false,
        isSimulation: false,
        isSimpleMode: true,
        highContrastMode: true,
        exportSafeMode: true
    },
    'executive-brief': {
        goal: 'present',
        family: 'dashboard',
        rendererStrategy: 'dom-infographic',
        interactionLevel: 'low',
        complexityBias: 'simple',
        fallbackPolicy: 'prefer-static-safe',
        audienceMode: 'executive',
        densityMode: 'core',
        motionMode: 'still',
        addonPolicy: 'off',
        theme: '[경영 브리프]',
        educationalMode: false,
        worldsimMode: false,
        isSimulation: false,
        isSimpleMode: true,
        highContrastMode: true,
        exportSafeMode: true
    },
    'accessibility-first': {
        goal: 'explain',
        family: 'accessibility',
        rendererStrategy: 'dom-infographic',
        interactionLevel: 'guided',
        complexityBias: 'simple',
        fallbackPolicy: 'prefer-static-safe',
        audienceMode: 'young-learner',
        densityMode: 'core',
        motionMode: 'still',
        addonPolicy: 'off',
        theme: '[접근성 우선]',
        educationalMode: true,
        worldsimMode: false,
        isSimulation: false,
        isSimpleMode: true,
        highContrastMode: true,
        exportSafeMode: true
    },
    'map-explainer': {
        goal: 'map',
        family: 'map',
        rendererStrategy: 'map-engine',
        interactionLevel: 'guided',
        complexityBias: 'balanced',
        fallbackPolicy: 'prefer-stable',
        audienceMode: 'learner',
        densityMode: 'balanced',
        motionMode: 'guided',
        addonPolicy: 'recommended',
        theme: '[지리 브리프]',
        educationalMode: true,
        worldsimMode: false,
        isSimulation: false,
        isSimpleMode: false,
        highContrastMode: true,
        exportSafeMode: true
    },
    'process-monitor': {
        goal: 'simulate',
        family: 'flow',
        rendererStrategy: 'hybrid-mixed',
        interactionLevel: 'balanced',
        complexityBias: 'detailed',
        fallbackPolicy: 'prefer-stable',
        audienceMode: 'analyst',
        densityMode: 'detailed',
        motionMode: 'dynamic',
        addonPolicy: 'recommended',
        theme: '[운영 모니터]',
        educationalMode: false,
        worldsimMode: false,
        isSimulation: true,
        isSimpleMode: false,
        highContrastMode: true,
        exportSafeMode: true
    },
    'network-analyzer': {
        goal: 'relate',
        family: 'network',
        rendererStrategy: 'graph-engine',
        interactionLevel: 'high',
        complexityBias: 'detailed',
        fallbackPolicy: 'balanced',
        audienceMode: 'analyst',
        densityMode: 'detailed',
        motionMode: 'dynamic',
        addonPolicy: 'aggressive',
        theme: '[관계 분석형]',
        educationalMode: false,
        worldsimMode: false,
        isSimulation: false,
        isSimpleMode: false,
        highContrastMode: true,
        exportSafeMode: false
    }
};

const VISUALIZATION_REFINEMENT_PRESETS_V2 = {
    simplify: {
        label: '더 쉽게 설명형으로',
        overrides: {
            presetKey: 'teach-clearly',
            goal: 'explain',
            family: 'comparison',
            rendererStrategy: 'stable-2d',
            interactionLevel: 'guided',
            complexityBias: 'simple',
            fallbackPolicy: 'prefer-stable',
            audienceMode: 'learner',
            densityMode: 'core',
            motionMode: 'guided',
            addonPolicy: 'auto',
            educationalMode: true,
            highContrastMode: true,
            exportSafeMode: true,
            isSimpleMode: true
        },
        instruction: '[리파인먼트 요청]\n이번 결과를 더 쉽게 이해되는 학습용 시각화로 다시 구성해 주세요. 핵심 관계와 레이블을 더 명확하게 드러내고, 첫 화면에서 중요한 정보가 바로 보이게 해주세요.'
    },
    interactive: {
        label: '더 상호작용적으로',
        overrides: {
            presetKey: 'interactive-lab',
            goal: 'explore',
            family: 'science',
            rendererStrategy: 'canvas-first',
            interactionLevel: 'high',
            complexityBias: 'balanced',
            fallbackPolicy: 'balanced',
            audienceMode: 'learner',
            densityMode: 'balanced',
            motionMode: 'dynamic',
            addonPolicy: 'recommended',
            isSimulation: true,
            isSimpleMode: false,
            highContrastMode: true
        },
        instruction: '[리파인먼트 요청]\n이번 결과를 사용자가 직접 조작하고 탐색할 수 있도록 다시 만들어 주세요. 슬라이더, 토글, 클릭, 드래그 중 안정적인 상호작용을 우선해 주세요.'
    },
    stable: {
        label: '안정성 우선으로 재생성',
        overrides: {
            presetKey: 'stable-first',
            goal: 'present',
            family: 'dashboard',
            rendererStrategy: 'stable-2d',
            interactionLevel: 'low',
            complexityBias: 'simple',
            fallbackPolicy: 'prefer-static-safe',
            audienceMode: 'general',
            densityMode: 'core',
            motionMode: 'still',
            addonPolicy: 'off',
            isSimulation: false,
            isSimpleMode: true,
            highContrastMode: true,
            exportSafeMode: true
        },
        instruction: '[리파인먼트 요청]\n이번 결과를 더 안정적이고 내보내기 친화적인 방식으로 다시 생성해 주세요. 복잡한 렌더링보다 읽기 쉬운 2D 중심 구성을 우선해 주세요.'
    }
};

function escapeVisualizationSummaryHtml(value) {
    return String(value || '').replace(/[&<>"']/g, (char) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    }[char]));
}

function getVisualizationLabel(group, value) {
    return VISUALIZATION_OPTION_LABELS_V2[group]?.[value] || VISUALIZATION_OPTION_LABELS[group]?.[value] || value || '미지정';
}

function getVisualizationFormDefaults() {
    const settings = normalizeVisualizationSettings(userApiSettings.visualizationSettings);
    const lastUsedForm = settings.lastUsedForm || {};
    const useRemembered = settings.rememberLastVisualizationForm;

    return {
        goal: useRemembered ? (lastUsedForm.goal || settings.defaultGoal) : settings.defaultGoal,
        family: useRemembered ? (lastUsedForm.family || settings.defaultFamily) : settings.defaultFamily,
        rendererStrategy: useRemembered ? (lastUsedForm.rendererStrategy || settings.defaultRendererStrategy) : settings.defaultRendererStrategy,
        theme: useRemembered ? (lastUsedForm.theme || settings.defaultTheme) : settings.defaultTheme,
        interactionLevel: useRemembered ? (lastUsedForm.interactionLevel || settings.defaultInteractionLevel) : settings.defaultInteractionLevel,
        complexityBias: useRemembered ? (lastUsedForm.complexityBias || settings.defaultComplexityBias) : settings.defaultComplexityBias,
        fallbackPolicy: useRemembered ? (lastUsedForm.fallbackPolicy || settings.defaultFallbackPolicy) : settings.defaultFallbackPolicy,
        audienceMode: useRemembered ? (lastUsedForm.audienceMode || settings.defaultAudienceMode) : settings.defaultAudienceMode,
        densityMode: useRemembered ? (lastUsedForm.densityMode || settings.defaultDensityMode) : settings.defaultDensityMode,
        motionMode: useRemembered ? (lastUsedForm.motionMode || settings.defaultMotionMode) : settings.defaultMotionMode,
        addonPolicy: useRemembered ? (lastUsedForm.addonPolicy || settings.defaultAddonPolicy) : settings.defaultAddonPolicy,
        // AI recommendation is a deliberate per-open action.
        // It should not silently reactivate from remembered form state.
        useAiRecommendedProfile: false,
        presetKey: useRemembered ? (lastUsedForm.presetKey || settings.defaultPresetKey) : settings.defaultPresetKey,
        libraries: useRemembered && Array.isArray(lastUsedForm.libraries) ? [...lastUsedForm.libraries] : [],
        description: '',
        educationalMode: settings.educationalMode,
        worldsimMode: settings.worldsimMode,
        isSimulation: false,
        isSimpleMode: false,
        includeAllDom: false,
        autoGenerateOnLoad: settings.autoGenerateOnLoad,
        highContrastMode: settings.preferHighContrast,
        exportSafeMode: settings.preferExportSafe,
        rememberLastVisualizationForm: settings.rememberLastVisualizationForm
    };
}

function sanitizeVisualizationLibraries(libraries) {
    return Array.isArray(libraries)
        ? [...new Set(libraries.filter((item) => typeof item === 'string' && item.trim()))]
        : [];
}

function normalizeVisualizationGenerationOptions(options = {}) {
    const defaults = getVisualizationFormDefaults();
    const merged = {
        ...defaults,
        ...(options || {})
    };

    return {
        libraries: sanitizeVisualizationLibraries(merged.libraries),
        description: typeof merged.description === 'string' ? merged.description : '',
        goal: typeof merged.goal === 'string' && merged.goal ? merged.goal : defaults.goal,
        family: typeof merged.family === 'string' && merged.family ? merged.family : defaults.family,
        rendererStrategy: typeof merged.rendererStrategy === 'string' && merged.rendererStrategy ? merged.rendererStrategy : defaults.rendererStrategy,
        theme: typeof merged.theme === 'string' && merged.theme ? merged.theme : defaults.theme,
        interactionLevel: typeof merged.interactionLevel === 'string' && merged.interactionLevel ? merged.interactionLevel : defaults.interactionLevel,
        complexityBias: typeof merged.complexityBias === 'string' && merged.complexityBias ? merged.complexityBias : defaults.complexityBias,
        fallbackPolicy: typeof merged.fallbackPolicy === 'string' && merged.fallbackPolicy ? merged.fallbackPolicy : defaults.fallbackPolicy,
        audienceMode: typeof merged.audienceMode === 'string' && merged.audienceMode ? merged.audienceMode : defaults.audienceMode,
        densityMode: typeof merged.densityMode === 'string' && merged.densityMode ? merged.densityMode : defaults.densityMode,
        motionMode: typeof merged.motionMode === 'string' && merged.motionMode ? merged.motionMode : defaults.motionMode,
        addonPolicy: typeof merged.addonPolicy === 'string' && merged.addonPolicy ? merged.addonPolicy : defaults.addonPolicy,
        useAiRecommendedProfile: !!merged.useAiRecommendedProfile,
        presetKey: typeof merged.presetKey === 'string' && merged.presetKey ? merged.presetKey : defaults.presetKey,
        educationalMode: !!merged.educationalMode,
        worldsimMode: !!merged.worldsimMode,
        isSimulation: !!merged.isSimulation,
        isSimpleMode: !!merged.isSimpleMode,
        includeAllDom: !!merged.includeAllDom,
        autoGenerateOnLoad: !!merged.autoGenerateOnLoad,
        highContrastMode: merged.highContrastMode !== false,
        exportSafeMode: merged.exportSafeMode !== false,
        rememberLastVisualizationForm: merged.rememberLastVisualizationForm !== false
    };
}

function buildVisualizationUserContent(options, promptForAI) {
    const normalizedOptions = normalizeVisualizationGenerationOptions(options);
    const selectedLibraries = normalizedOptions.libraries.length > 0
        ? normalizedOptions.libraries.join(', ')
        : 'AI 추천';

    let userContent = `--- GENERATION BRIEF ---\n`;
    userContent += `Goal: ${getVisualizationLabel('goals', normalizedOptions.goal)}\n`;
    userContent += `Family: ${getVisualizationLabel('families', normalizedOptions.family)}\n`;
    userContent += `Renderer Strategy: ${getVisualizationLabel('renderers', normalizedOptions.rendererStrategy)}\n`;
    userContent += `Interaction Level: ${getVisualizationLabel('interactions', normalizedOptions.interactionLevel)}\n`;
    userContent += `Complexity Bias: ${getVisualizationLabel('complexities', normalizedOptions.complexityBias)}\n`;
    userContent += `Fallback Policy: ${getVisualizationLabel('fallbacks', normalizedOptions.fallbackPolicy)}\n`;
    userContent += `Audience Mode: ${getVisualizationLabel('audiences', normalizedOptions.audienceMode)}\n`;
    userContent += `Density Mode: ${getVisualizationLabel('densities', normalizedOptions.densityMode)}\n`;
    userContent += `Motion Profile: ${getVisualizationLabel('motions', normalizedOptions.motionMode)}\n`;
    userContent += `Addon Policy: ${getVisualizationLabel('addons', normalizedOptions.addonPolicy)}\n`;
    userContent += `AI Recommendation Mode: ${normalizedOptions.useAiRecommendedProfile ? 'On' : 'Off'}\n`;
    userContent += `Preset: ${getVisualizationLabel('presets', normalizedOptions.presetKey)}\n`;
    userContent += `Theme Pack: ${normalizedOptions.theme}\n`;
    userContent += `Libraries: ${selectedLibraries}\n`;
    userContent += `Educational Mode: ${normalizedOptions.educationalMode ? 'On' : 'Off'}\n`;
    userContent += `Worldsim Mode: ${normalizedOptions.worldsimMode ? 'On' : 'Off'}\n`;
    userContent += `Simulation Mode: ${normalizedOptions.isSimulation ? 'On' : 'Off'}\n`;
    userContent += `Simple Mode: ${normalizedOptions.isSimpleMode ? 'On' : 'Off'}\n`;
    userContent += `High Contrast Preference: ${normalizedOptions.highContrastMode ? 'On' : 'Off'}\n`;
    userContent += `Export Safe Preference: ${normalizedOptions.exportSafeMode ? 'On' : 'Off'}\n`;
    if (normalizedOptions.includeAllDom) {
        userContent += `Current Scene Context: Included\n`;
    }
    userContent += `--- END GENERATION BRIEF ---\n\n`;
    userContent += `--- REQUEST & DATA ---\n${promptForAI}`;
    return userContent;
}

function persistVisualizationFormPreferences(options) {
    if (!userApiSettings.visualizationSettings) {
        userApiSettings.visualizationSettings = normalizeVisualizationSettings();
    }

    const normalizedOptions = normalizeVisualizationGenerationOptions(options);
    const settings = normalizeVisualizationSettings(userApiSettings.visualizationSettings);

    settings.educationalMode = normalizedOptions.educationalMode;
    settings.worldsimMode = normalizedOptions.worldsimMode;
    settings.autoGenerateOnLoad = normalizedOptions.autoGenerateOnLoad;
    settings.preferHighContrast = normalizedOptions.highContrastMode;
    settings.preferExportSafe = normalizedOptions.exportSafeMode;
    settings.rememberLastVisualizationForm = normalizedOptions.rememberLastVisualizationForm;
    settings.defaultGoal = normalizedOptions.goal;
    settings.defaultFamily = normalizedOptions.family;
    settings.defaultRendererStrategy = normalizedOptions.rendererStrategy;
    settings.defaultTheme = normalizedOptions.theme;
    settings.defaultInteractionLevel = normalizedOptions.interactionLevel;
    settings.defaultComplexityBias = normalizedOptions.complexityBias;
    settings.defaultFallbackPolicy = normalizedOptions.fallbackPolicy;
    settings.defaultAudienceMode = normalizedOptions.audienceMode;
    settings.defaultDensityMode = normalizedOptions.densityMode;
    settings.defaultMotionMode = normalizedOptions.motionMode;
    settings.defaultAddonPolicy = normalizedOptions.addonPolicy;
    settings.defaultUseAiRecommendedProfile = false;
    settings.defaultPresetKey = normalizedOptions.presetKey;
    settings.lastUsedForm = {
        goal: normalizedOptions.goal,
        family: normalizedOptions.family,
        rendererStrategy: normalizedOptions.rendererStrategy,
        theme: normalizedOptions.theme,
        interactionLevel: normalizedOptions.interactionLevel,
        complexityBias: normalizedOptions.complexityBias,
        fallbackPolicy: normalizedOptions.fallbackPolicy,
        audienceMode: normalizedOptions.audienceMode,
        densityMode: normalizedOptions.densityMode,
        motionMode: normalizedOptions.motionMode,
        addonPolicy: normalizedOptions.addonPolicy,
        // AI recommendation should not be restored automatically on the next modal open.
        useAiRecommendedProfile: false,
        presetKey: normalizedOptions.presetKey,
        libraries: [...normalizedOptions.libraries]
    };
    settings.batchGenerationSize = ENFORCED_VISUALIZATION_BATCH_SIZE;

    userApiSettings.visualizationSettings = settings;

    if (typeof debouncedSaveUserSettings === 'function') {
        debouncedSaveUserSettings();
    } else if (typeof saveUserSettingsToFirebase === 'function') {
        saveUserSettingsToFirebase(true);
    }
}

function buildVisualizationPrefillFromBlockData(blockData = {}, elementToReplace = null) {
    const base = normalizeVisualizationGenerationOptions(blockData.generationOptions || {});
    const description = blockData.originalPrompt || blockData.prompt || '';

    if (!blockData.generationOptions && blockData.htmlContent && (blockData.htmlContent.includes('requestAnimationFrame') || blockData.htmlContent.includes('function draw()'))) {
        base.isSimulation = true;
    }

    const noteId = blockData.noteId || elementToReplace?.closest('#recall-content-area')?.dataset.noteId || null;

    return {
        ...base,
        description,
        noteId,
        // Existing block metadata may say the scene was generated through AI recommendation,
        // but reopening the studio should still start from manual mode until the user turns it on again.
        useAiRecommendedProfile: false
    };
}

async function handleVisualizationIntentRefinement(originalBlockData, elementToReplace, refinementKey) {
    const preset = VISUALIZATION_REFINEMENT_PRESETS_V2[refinementKey] || VISUALIZATION_REFINEMENT_PRESETS[refinementKey];
    if (!preset || !originalBlockData || !elementToReplace) return;

    const baseOptions = buildVisualizationPrefillFromBlockData(originalBlockData, elementToReplace);
    const mergedOptions = normalizeVisualizationGenerationOptions({
        ...baseOptions,
        ...preset.overrides,
        description: `${preset.instruction}\n\n${baseOptions.description || ''}`.trim()
    });

    await _generateAndPlaceVisualization(
        mergedOptions,
        elementToReplace,
        true,
        baseOptions.noteId || null
    );
}
window.handleVisualizationIntentRefinement = handleVisualizationIntentRefinement;

function resolveVisualizationPlaceholderDisplayMode(targetElement) {
    const resolvedMode = targetElement?.dataset?.placeholderDisplayResolved;
    const explicitMode = targetElement?.dataset?.placeholderDisplay;
    const rawMode = String(resolvedMode || explicitMode || '').trim().toLowerCase();
    return rawMode === 'slot' ? 'slot' : 'block';
}

function mountVisualizationBlock(vizBlockData, targetElement) {
    if (!targetElement) return null;

    const displayMode = resolveVisualizationPlaceholderDisplayMode(targetElement);
    if (vizBlockData?.prompt) {
        targetElement.dataset.prompt = vizBlockData.prompt;
    }
    targetElement.dataset.blockData = JSON.stringify(vizBlockData);
    targetElement.dataset.placeholderDisplayResolved = displayMode;

    if (
        typeof window.stageVisualizationBlockTransaction === 'function'
        && typeof window.commitStagedVisualizationTransaction === 'function'
    ) {
        targetElement.classList.remove('type-visualization-error');

        if (displayMode === 'slot') {
            targetElement.classList.remove(
                'type-visualization-placeholder',
                'type-visualization-placeholder-slot',
                'type-visualization-error'
            );
            targetElement.classList.add('content-section', 'type-visualization', 'type-visualization-slot');
        } else {
            targetElement.classList.remove(
                'type-visualization-placeholder',
                'type-visualization-loading',
                'type-visualization-error'
            );
            targetElement.classList.add('content-section', 'type-visualization');
        }

        Promise.resolve().then(async () => {
            const transaction = await window.stageVisualizationBlockTransaction(vizBlockData, targetElement);
            const committedElement = window.commitStagedVisualizationTransaction(targetElement, transaction);
            if (committedElement && typeof attachVisualizationNotePin === 'function') {
                attachVisualizationNotePin(committedElement, vizBlockData?.noteId || null, vizBlockData);
            }
        }).catch((error) => {
            console.error('Failed to commit visualization transaction:', error);
            if (!targetElement?.isConnected) return;
            targetElement.className = 'content-section type-visualization type-visualization-error';
            renderVisualizationFailureState(targetElement, '시각화 렌더링 실패', error.message);
        });

        return targetElement;
    }

    if (displayMode !== 'slot') {
        return renderBlock(vizBlockData);
    }

    targetElement.dataset.placeholderDisplayResolved = 'slot';

    targetElement.classList.remove(
        'type-visualization-loading',
        'type-visualization-placeholder',
        'type-visualization-placeholder-slot',
        'type-visualization-error'
    );
    targetElement.classList.add('content-section', 'type-visualization', 'type-visualization-slot');
    targetElement.innerHTML = '';

    if (typeof renderVisualizationBlock === 'function') {
        renderVisualizationBlock(vizBlockData, targetElement);
        return targetElement;
    }

    throw new Error('Visualization renderer not loaded.');
}

function stripVisualizationMarkdownFenceArtifacts(content = '') {
    return String(content || '')
        .replace(/^\s*```[^\n]*\r?\n?/, '')
        .replace(/\r?\n?\s*```\s*$/, '')
        .trim();
}

function looksLikeVisualizationHtmlFragment(content = '') {
    const normalized = stripVisualizationMarkdownFenceArtifacts(content);
    if (!normalized) return false;

    const structuralSignals = [
        /<(div|section|article|figure|svg|canvas|style|script|table|ul|ol|p|span|h[1-6])\b/i,
        /\bv(?:izContainer|iz[A-Z_-])/,
        /\bdocument\.createElement\(/,
        /\b(innerHTML|appendChild|querySelector)\(/,
        /\b(d3\.|echarts|Plotly|new\s+Chart|ApexCharts|vegaEmbed|mermaid|L\.map|maplibregl|ol\.Map|THREE\.|p5\b|cytoscape|vis\.Network|gridjs|Tabulator|G2\.)/
    ];

    return structuralSignals.some((pattern) => pattern.test(normalized));
}

function collectVisualizationResponseCodeBlocks(responseText = '') {
    const blocks = [];
    const fenceRegex = /```([^\n`]*)?\r?\n?([\s\S]*?)\r?\n?```/g;
    let match;

    while ((match = fenceRegex.exec(String(responseText || ''))) !== null) {
        blocks.push({
            label: String(match[1] || '').trim().toLowerCase(),
            content: stripVisualizationMarkdownFenceArtifacts(match[2] || '')
        });
    }

    return blocks;
}

function extractVisualizationHtmlFromJsonLikePayload(content = '') {
    const normalized = stripVisualizationMarkdownFenceArtifacts(content);
    if (!normalized || !/^[\[{]/.test(normalized)) {
        return '';
    }

    try {
        const parsed = JSON.parse(normalized);
        const queue = [parsed];
        const preferredKeys = new Set([
            'html',
            'htmlContent',
            'code',
            'markup',
            'fragment',
            'visualization',
            'visualizationHtml',
            'content',
            'result'
        ]);

        while (queue.length > 0) {
            const current = queue.shift();
            if (typeof current === 'string') {
                const candidate = stripVisualizationMarkdownFenceArtifacts(current);
                if (looksLikeVisualizationHtmlFragment(candidate)) {
                    return candidate;
                }
                continue;
            }

            if (Array.isArray(current)) {
                current.forEach((value) => queue.push(value));
                continue;
            }

            if (!current || typeof current !== 'object') {
                continue;
            }

            const preferredEntries = [];
            const fallbackEntries = [];
            Object.entries(current).forEach(([key, value]) => {
                if (preferredKeys.has(key)) preferredEntries.push(value);
                else fallbackEntries.push(value);
            });

            [...preferredEntries, ...fallbackEntries].forEach((value) => queue.push(value));
        }
    } catch (error) {
        trace("Visualization", "extract.jsonWrapper.parseFailed", { error: error.message }, {}, "WARN");
    }

    return '';
}

function normalizeVisualizationResponseCandidate(content = '') {
    const normalized = stripVisualizationMarkdownFenceArtifacts(content);
    if (!normalized) return '';

    const jsonResolved = extractVisualizationHtmlFromJsonLikePayload(normalized);
    if (jsonResolved) {
        return jsonResolved;
    }

    return normalized;
}

function chooseBestVisualizationHtmlCandidate(responseText = '') {
    const blocks = collectVisualizationResponseCodeBlocks(responseText);
    const scored = blocks
        .map((block) => {
            const normalizedContent = normalizeVisualizationResponseCandidate(block.content);
            const sourceType = normalizedContent !== stripVisualizationMarkdownFenceArtifacts(block.content) ? 'json-wrapper' : 'direct';
            return { ...block, content: normalizedContent, sourceType };
        })
        .filter((block) => looksLikeVisualizationHtmlFragment(block.content))
        .map((block, index) => {
            let score = 0;
            if (block.label === 'html') score += 100;
            else if (!block.label) score += 50;
            else if (['xml', 'svg', 'markup', 'javascript', 'js', 'md', 'markdown'].includes(block.label)) score += 20;
            else if (block.label === 'json') score += 40;
            if (block.sourceType === 'json-wrapper') score += 25;
            score += Math.min(block.content.length, 2000) / 2000;

            return { ...block, index, score };
        })
        .sort((left, right) => right.score - left.score || left.index - right.index);

    if (scored.length > 0) {
        return {
            htmlContent: scored[0].content,
            source: `fenced:${scored[0].label || 'generic'}`,
            codeBlockCount: blocks.length
        };
    }

    const rawCandidate = normalizeVisualizationResponseCandidate(responseText);
    if (looksLikeVisualizationHtmlFragment(rawCandidate)) {
        return {
            htmlContent: rawCandidate,
            source: rawCandidate === stripVisualizationMarkdownFenceArtifacts(responseText) ? 'raw-fragment' : 'raw-json-wrapper',
            codeBlockCount: blocks.length
        };
    }

    return null;
}

function extractVisualizationHtmlBlocks(responseText = '') {
    const blocks = collectVisualizationResponseCodeBlocks(responseText)
        .map((block) => normalizeVisualizationResponseCandidate(block.content))
        .filter((block) => looksLikeVisualizationHtmlFragment(block));

    if (blocks.length > 0) {
        return blocks;
    }

    const fallback = chooseBestVisualizationHtmlCandidate(responseText);
    return fallback?.htmlContent ? [fallback.htmlContent] : [];
}

function buildVisualizationExtractionError(responseText = '') {
    const codeBlocks = collectVisualizationResponseCodeBlocks(responseText);
    const trimmed = String(responseText || '').trim();
    const hasUnclosedFence = (trimmed.match(/```/g) || []).length % 2 === 1;

    if (hasUnclosedFence) {
        return 'AI 응답이 중간에서 끊겨 코드 블록이 완전히 닫히지 않았습니다.';
    }
    if (codeBlocks.length > 0) {
        return 'AI 응답에 코드 블록은 있었지만, 시각화용 HTML 조각으로 확인되지 않았습니다.';
    }
    return 'AI 응답에서 시각화용 HTML 코드 블록을 찾지 못했습니다.';
}

function buildVisualizationResponseErrorMessage(responseResult, responseText = '', fallbackMessage = '') {
    const providerIssue = String(responseResult?.responseIssue || '').trim();
    if (providerIssue) {
        return providerIssue;
    }

    if (responseResult?.responseMeta?.finishReason && typeof window._describeGoogleResponseIssue === 'function') {
        const described = window._describeGoogleResponseIssue(responseResult.responseMeta, responseText);
        if (described) {
            return described;
        }
    }

    return fallbackMessage || buildVisualizationExtractionError(responseText);
}

function getVisualizationFallbackModels() {
    try {
        const activePreset = userApiSettings?.apiPresets?.find((preset) => preset?.id === userApiSettings?.activePresetId);
        if (!activePreset || activePreset.provider !== 'google_paid') {
            return [];
        }

        const activeModel = String(activePreset.selectedModel || '').trim();
        const availableModels = Array.isArray(activePreset.availableModels) ? activePreset.availableModels : [];

        return [...new Set(
            availableModels
                .map((item) => String(item || '').trim())
                .filter((item) => item && item !== activeModel)
        )].slice(0, 2);
    } catch (error) {
        trace("Visualization", "fallbackModels.resolveFailed", { error: error.message }, {}, "WARN");
        return [];
    }
}

function shouldRetryVisualizationFormatRecovery(error) {
    const message = String(error?.message || error || '').toLowerCase();
    if (!message) return true;

    if (
        message.includes('429')
        || message.includes('quota')
        || message.includes('resource exhausted')
        || message.includes('503')
        || message.includes('high demand')
        || message.includes('try again later')
        || message.includes('unavailable')
        || message.includes('overloaded')
        || message.includes('timeout')
        || message.includes('timed out')
        || message.includes('failed to fetch')
        || message.includes('networkerror')
    ) {
        return false;
    }

    return true;
}

async function requestVisualizationResponseWithRecovery(systemSessionId, userContent, systemInstruction, options = {}) {
    const mode = options?.mode || 'single';
    const expectedCount = Number(options?.expectedCount || 1);
    const recoveryInstruction = `

[FORMAT_RECOVERY]
Your previous response was incomplete or invalid for the host runtime.
Return only closed Markdown html code blocks.
Do not add prose.
Make sure the code block fence is closed and the fragment is complete.
`;

    let lastError = null;

    for (let attempt = 0; attempt < 2; attempt += 1) {
        try {
            const responseResult = await programmaticChatSendDetailed(
                systemSessionId,
                attempt === 0 ? userContent : `${userContent}${recoveryInstruction}`,
                systemInstruction,
                true,
                {
                    returnDetails: true,
                    requireCompleteResponse: true,
                    fallbackModels: getVisualizationFallbackModels(),
                    apiRetryLimit: 0
                }
            );

            if (mode === 'batch') {
                const htmlBlocks = extractVisualizationHtmlBlocks(responseResult.content);
                if (htmlBlocks.length >= expectedCount) {
                    return { ...responseResult, htmlBlocks };
                }

                lastError = new Error(buildVisualizationResponseErrorMessage(
                    responseResult,
                    responseResult.content,
                    `AI 응답에서 ${expectedCount}개의 시각화 코드 블록을 안정적으로 확인하지 못했습니다.`
                ));
                if (!shouldRetryVisualizationFormatRecovery(lastError)) {
                    break;
                }
                continue;
            }

            const bestCandidate = chooseBestVisualizationHtmlCandidate(responseResult.content);
            if (bestCandidate?.htmlContent) {
                return { ...responseResult, htmlContent: bestCandidate.htmlContent };
            }

            lastError = new Error(buildVisualizationResponseErrorMessage(
                responseResult,
                responseResult.content,
                buildVisualizationExtractionError(responseResult.content)
            ));
            if (!shouldRetryVisualizationFormatRecovery(lastError)) {
                break;
            }
        } catch (error) {
            lastError = error;
            if (!shouldRetryVisualizationFormatRecovery(error)) {
                break;
            }
        }
    }

    throw lastError || new Error('AI 응답을 시각화 코드로 확정하지 못했습니다.');
}

function renderVisualizationFailureState(targetElement, title, message) {
    if (!targetElement) return;

    targetElement.classList.remove('type-visualization-loading');
    targetElement.classList.add('type-visualization-error');
    targetElement.innerHTML = `
        <div class="viz-error-card">
            <div class="viz-error-kicker">Visualization Guard</div>
            <h3 class="viz-error-title">${String(title || '시각화 실패')}</h3>
            <p class="viz-error-message">${String(message || '시각화 결과를 확인할 수 없습니다.')}</p>
        </div>
    `;
    const noteElement = document.createElement('div');
    noteElement.className = 'viz-error-note';
    noteElement.textContent = '응답이 중간 종료되었거나 코드 블록 형식이 깨지면 이 안내가 표시됩니다. 모델을 바꾸거나 다시 시도하면 복구될 수 있습니다.';
    const cardElement = targetElement.querySelector('.viz-error-card');
    cardElement?.appendChild(noteElement);

    const blockData = (() => {
        try {
            return targetElement.dataset.blockData ? JSON.parse(targetElement.dataset.blockData) : {};
        } catch (error) {
            trace("Visualization", "errorCard.blockDataParseFailed", { error: error.message }, {}, "WARN");
            return {};
        }
    })();

    const prompt = String(
        blockData?.originalPrompt
        || blockData?.prompt
        || targetElement.dataset.prompt
        || ''
    ).trim();
    const hasSavedVisualization = !!String(blockData?.htmlContent || '').trim();
    const canRegenerate = hasSavedVisualization || !!prompt;
    const canCodeFix = hasSavedVisualization || !!prompt;

    if (!cardElement || (!canRegenerate && !canCodeFix)) {
        return;
    }

    const actionsElement = document.createElement('div');
    actionsElement.className = 'viz-error-actions';

    if (canRegenerate) {
        const regenerateButton = document.createElement('button');
        regenerateButton.type = 'button';
        regenerateButton.className = 'viz-error-action-btn primary';
        regenerateButton.textContent = '다시 생성';
        regenerateButton.addEventListener('click', async () => {
            const regenerationOptions = normalizeVisualizationGenerationOptions(blockData?.generationOptions || {});
            if (!regenerationOptions.description) {
                regenerationOptions.description = prompt;
            }

            if (hasSavedVisualization && typeof window.handleRegenerateVisualization === 'function') {
                await window.handleRegenerateVisualization(blockData, targetElement);
                return;
            }

            if (!regenerationOptions.description || typeof window._generateAndPlaceVisualization !== 'function') {
                showModal('재생성에 필요한 프롬프트를 찾을 수 없습니다.', () => {});
                return;
            }

            await window._generateAndPlaceVisualization(
                regenerationOptions,
                targetElement,
                true,
                blockData?.noteId || null
            );
        });
        actionsElement.appendChild(regenerateButton);
    }

    if (canCodeFix) {
        const codeFixButton = document.createElement('button');
        codeFixButton.type = 'button';
        codeFixButton.className = 'viz-error-action-btn';
        codeFixButton.textContent = 'AI 코드 수정';
        codeFixButton.addEventListener('click', () => {
            if (typeof handleCodeFixRequest !== 'function') return;
            const codeFixPayload = hasSavedVisualization
                ? blockData
                : {
                    type: 'visualization-placeholder',
                    prompt,
                    generationOptions: blockData?.generationOptions || {}
                };
            handleCodeFixRequest(codeFixPayload, targetElement);
        });
        actionsElement.appendChild(codeFixButton);
    }

    cardElement.appendChild(actionsElement);
}

function buildVisualizationLoadingMarkup(message) {
    return `
        <div class="media-loading-state">
            <div class="loading-animation" aria-hidden="true">
                <div class="dot"></div>
                <div class="dot"></div>
                <div class="dot"></div>
            </div>
        </div>
    `;
}

function showVisualizationPendingOverlay(targetElement, message) {
    if (!targetElement) return;
    clearVisualizationPendingOverlay(targetElement);

    targetElement.classList.add('viz-pending');
    const overlay = document.createElement('div');
    overlay.className = 'viz-pending-overlay';
    overlay.innerHTML = `
        <div class="viz-pending-chip">
            <div class="loading-animation" aria-hidden="true">
                <div class="dot"></div>
                <div class="dot"></div>
                <div class="dot"></div>
            </div>
            <span>${String(message || '새 시각화를 준비하는 중...')}</span>
        </div>
    `;
    targetElement.appendChild(overlay);
}

function showVisualizationPendingOverlay(targetElement, message) {
    if (!targetElement) return;
    clearVisualizationPendingOverlay(targetElement);

    targetElement.classList.add('viz-pending');
    const overlay = document.createElement('div');
    overlay.className = 'viz-pending-overlay';
    overlay.innerHTML = `
        <div class="viz-pending-chip">
            <div class="loading-animation" aria-hidden="true">
                <div class="dot"></div>
                <div class="dot"></div>
                <div class="dot"></div>
            </div>
        </div>
    `;
    targetElement.appendChild(overlay);
}

function clearVisualizationPendingOverlay(targetElement) {
    if (!targetElement) return;
    targetElement.classList.remove('viz-pending');
    targetElement.querySelector(':scope > .viz-pending-overlay')?.remove();
}

window.extractVisualizationHtmlBlocks = extractVisualizationHtmlBlocks;
window.chooseBestVisualizationHtmlCandidate = chooseBestVisualizationHtmlCandidate;

async function _generateAndPlaceVisualization(options, targetElement, replace = false, noteId = null, disableScroll = false) {
    const normalizedOptions = normalizeVisualizationGenerationOptions(options);
    let promptForAI = normalizedOptions.description.trim();

    if (!promptForAI) {
        trace("Visualization", "generate.emptyPrompt", { action: "Extracting context from DOM" });
        promptForAI = extractContextFromDOM('learning-content');
    }

    if (!promptForAI) {
        showModal("시각화할 내용이 없습니다. 내용을 입력해주세요.", () => {});
        return;
    }

    const placeholder = targetElement; 
    placeholder.classList.add('type-visualization-loading');
    placeholder.innerHTML = buildVisualizationLoadingMarkup();
    
    if (!disableScroll) {
        placeholder.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    let systemSessionId;
    try {
        const visualizerTemplate = promptTemplatesCache.find(p => p.name === "Data Visualizer");
        if (!visualizerTemplate) throw new Error("Could not find 'Data Visualizer' prompt template.");

        systemSessionId = await findOrCreateSystemSession('[System] Visualization Engine');
        if (!systemSessionId) throw new Error("Could not create or find system session for visualization.");
        
        const systemInstruction = visualizerTemplate.promptText;
        
        const userContent = buildVisualizationUserContent(normalizedOptions, promptForAI);
        
        const responseResult = await requestVisualizationResponseWithRecovery(
            systemSessionId,
            userContent,
            systemInstruction,
            { mode: 'single' }
        );
        const htmlContent = responseResult.htmlContent || '';

        if (!htmlContent) {
            console.error("AI Response did not contain valid visualization HTML:", responseResult.content);
            throw new Error(buildVisualizationResponseErrorMessage(responseResult, responseResult.content));
        }
        
        const vizBlockData = {
            type: 'visualization',
            htmlContent: htmlContent,
            originalPrompt: promptForAI,
            generationOptions: normalizedOptions,
            noteId: noteId || null
        };

        if (targetElement && targetElement.dataset.prompt) {
            vizBlockData.prompt = targetElement.dataset.prompt;
        }

        const transaction = await window.stageVisualizationBlockTransaction(vizBlockData, placeholder);
        const newBlockElement = window.commitStagedVisualizationTransaction(placeholder, transaction);
        if (newBlockElement) {
            if (noteId) {
                const pinButton = newBlockElement.querySelector('[data-action="pin"]');
                if (pinButton) {
                    pinButton.addEventListener('click', async () => {
                        if (typeof archiveVisualizationToNote === 'function') {
                            const success = await archiveVisualizationToNote(noteId, vizBlockData, placeholder);
                            if (success) {
                                pinButton.classList.add('pinned');
                                pinButton.title = '노트에 저장됨';
                                pinButton.innerHTML = `<svg viewBox="0 0 24 24"><path d="M16,12V4H17V2H7V4H8V12L6,14V16H11.2V22H12.8V16H18V14L16,12M10,12V4H14V12L15.2,13.2L14.8,14H9.2L8.8,13.2L10,12Z"></path></svg>`; 
                            }
                        }
                    });
                }
            } else {
                 const pinButton = newBlockElement.querySelector('[data-action="pin"]');
                 if(pinButton) pinButton.style.display = 'none';
            }
        } else {
            throw new Error("Failed to render the visualization block.");
        }
        
        persistVisualizationFormPreferences(normalizedOptions);

    } catch (error) {
        console.error("Failed to generate/place visualization:", error);
        placeholder.className = 'content-section type-visualization-placeholder type-visualization-error';
        renderVisualizationFailureState(placeholder, '시각화 생성 실패', error.message);
        return;
        const contentDiv = placeholder.querySelector('.placeholder-content');
        const actionsDiv = placeholder.querySelector('.placeholder-actions');

        if (contentDiv) {
            contentDiv.innerHTML = `<p>${'시각화 자료 생성 실패: ' + error.message}</p>`;
        } else {
            placeholder.innerHTML = `<div class="placeholder-content"><p>${'시각화 자료 생성 실패: ' + error.message}</p></div>`;
        }
        if (actionsDiv) {
            actionsDiv.style.display = 'none';
        }
    } finally {
        if (systemSessionId && typeof clearSessionMessages === 'function') {
            try {
                await clearSessionMessages(systemSessionId);
            } catch (clearError) {
                trace("Visualization", "generate.clearSession.failed", { error: clearError.message }, {}, "WARN");
            }
        }
    }
}
window._generateAndPlaceVisualization = _generateAndPlaceVisualization;

async function handleRegenerateVisualization(originalBlockData, elementToReplace) {
    let promptForRegeneration = originalBlockData ? (originalBlockData.originalPrompt || originalBlockData.prompt) : null;
    const baseGenerationOptions = normalizeVisualizationGenerationOptions(originalBlockData?.generationOptions || {});

    if (!promptForRegeneration && elementToReplace) {
        const precedingBlock = elementToReplace.previousElementSibling;
        if (precedingBlock && precedingBlock.classList.contains('content-section')) {
            promptForRegeneration = precedingBlock.innerText.replace(/\n[🎨📊]$/, '').trim();
            trace("Regenerate", "prompt.fallback", { source: "previousElementSibling", length: promptForRegeneration.length });
        }
    }

    if (!originalBlockData || !promptForRegeneration || !originalBlockData.htmlContent) {
        showModal("재생성에 필요한 원본 프롬프트 또는 코드가 없습니다.", () => {});
        trace("Regenerate", "start.fail", { reason: "Missing prompt data in block" });
        return;
    }
    trace("Regenerate", "start.success", { promptLength: promptForRegeneration.length });

    showVisualizationPendingOverlay(elementToReplace, 'AI가 새로운 방식으로 재구성 중...');
    
    elementToReplace.innerHTML = `<div class="media-loading-state"><div class="loading-animation" aria-hidden="true"><div class="dot"></div><div class="dot"></div><div class="dot"></div></div></div>`;

    let systemSessionId;
    try {
        const visualizerTemplate = promptTemplatesCache.find(p => p.name === "Data Visualizer");
        if (!visualizerTemplate) throw new Error("Data Visualizer 템플릿을 찾을 수 없습니다.");
        
        systemSessionId = await findOrCreateSystemSession('[System] Visualization Engine');
        if (!systemSessionId) throw new Error("시스템 세션을 생성하거나 찾을 수 없습니다.");
        
        const systemInstruction = visualizerTemplate.promptText;
        const userContent = `
[REGENERATION_TASK]
The user wants to regenerate a visualization with a completely new style.

--- PREVIOUS GENERATION BRIEF ---
${buildVisualizationUserContent(baseGenerationOptions, '[기존 요청 요약]')}

--- PREVIOUS PROMPT & DATA ---
${promptForRegeneration}

--- PREVIOUSLY GENERATED CODE (DO NOT REUSE) ---
\`\`\`html
${originalBlockData.htmlContent}
\`\`\`

--- NEW INSTRUCTION ---
Based on the "PREVIOUS PROMPT & DATA", generate a NEW visualization. Your new code and approach MUST be significantly different from the "PREVIOUSLY GENERATED CODE". Be creative and explore a different library, chart type, or visual style.
Return ONLY the code block.
`;
        
        const responseResult = await requestVisualizationResponseWithRecovery(
            systemSessionId,
            userContent,
            systemInstruction,
            { mode: 'single' }
        );
        const htmlContent = responseResult.htmlContent || '';

        if (!htmlContent) throw new Error(buildVisualizationResponseErrorMessage(responseResult, responseResult.content));
        
        const newVizBlockData = {
            type: 'visualization',
            htmlContent: htmlContent,
            originalPrompt: promptForRegeneration,
            generationOptions: baseGenerationOptions
        };
        if (originalBlockData.noteId) {
            newVizBlockData.noteId = originalBlockData.noteId;
        }
        if (originalBlockData.prompt) {
            newVizBlockData.prompt = originalBlockData.prompt;
        }
        
        const newBlockElement = mountVisualizationBlock(newVizBlockData, elementToReplace);
        if (newBlockElement) {
            if (newBlockElement !== elementToReplace) {
                elementToReplace.replaceWith(newBlockElement);
            }
            trace("Regenerate", "success.rendered");
        } else {
            throw new Error("새로운 시각화 블록을 렌더링하는데 실패했습니다.");
        }
    } catch (error) {
        console.error("Failed to regenerate visualization:", error);
        trace("Regenerate", "error", { error: error.message }, {}, "ERROR");
        showModal(`재생성 실패: ${error.message}`, () => {});
        
        elementToReplace.className = `${originalClassName} type-visualization-error`;
        renderVisualizationFailureState(elementToReplace, '재생성 실패', error.message);
        return;
        elementToReplace.innerHTML = `<div class="placeholder-content"><p>${'재생성 실패: ' + error.message}</p></div>`;
    } finally {
        if (systemSessionId && typeof clearSessionMessages === 'function') {
            try {
                await clearSessionMessages(systemSessionId);
            } catch (clearError) {
                trace("Regenerate", "clearSession.failed", { error: clearError.message }, {}, "WARN");
            }
        }
    }
}
window.handleRegenerateVisualization = handleRegenerateVisualization;

function attachVisualizationNotePin(targetElement, noteId, vizBlockData) {
    if (!targetElement) return;

    const pinButton = targetElement.querySelector('[data-action="pin"]');
    if (!pinButton) return;

    if (!noteId) {
        pinButton.style.display = 'none';
        return;
    }

    pinButton.addEventListener('click', async () => {
        if (typeof archiveVisualizationToNote !== 'function') return;
        const success = await archiveVisualizationToNote(noteId, vizBlockData, targetElement);
        if (!success) return;

        pinButton.classList.add('pinned');
        pinButton.title = '노트에 저장됨';
        pinButton.innerHTML = `<svg viewBox="0 0 24 24"><path d="M16,12V4H17V2H7V4H8V12L6,14V16H11.2V22H12.8V16H18V14L16,12M10,12V4H14V12L15.2,13.2L14.8,14H9.2L8.8,13.2L10,12Z"></path></svg>`;
    });
}

_generateAndPlaceVisualization = async function(options, targetElement, replace = false, noteId = null, disableScroll = false) {
    const normalizedOptions = normalizeVisualizationGenerationOptions(options);
    let promptForAI = normalizedOptions.description.trim();

    if (!promptForAI) {
        trace("Visualization", "generate.emptyPrompt", { action: "Extracting context from DOM" });
        promptForAI = extractContextFromDOM('learning-content');
    }

    if (!promptForAI) {
        showModal("시각화할 내용이 없습니다. 내용을 입력해 주세요.", () => {});
        return;
    }

    const placeholder = targetElement;
    placeholder.classList.add('type-visualization-loading');
    placeholder.innerHTML = buildVisualizationLoadingMarkup();

    if (!disableScroll) {
        placeholder.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    let systemSessionId;
    try {
        const visualizerTemplate = promptTemplatesCache.find(p => p.name === "Data Visualizer");
        if (!visualizerTemplate) throw new Error("Could not find 'Data Visualizer' prompt template.");

        systemSessionId = await findOrCreateSystemSession('[System] Visualization Engine');
        if (!systemSessionId) throw new Error("Could not create or find system session for visualization.");

        const responseResult = await requestVisualizationResponseWithRecovery(
            systemSessionId,
            buildVisualizationUserContent(normalizedOptions, promptForAI),
            visualizerTemplate.promptText,
            { mode: 'single' }
        );
        const htmlContent = responseResult.htmlContent || '';

        if (!htmlContent) {
            console.error("AI Response did not contain valid visualization HTML:", responseResult.content);
            throw new Error(buildVisualizationResponseErrorMessage(responseResult, responseResult.content));
        }

        const vizBlockData = {
            type: 'visualization',
            htmlContent,
            originalPrompt: promptForAI,
            generationOptions: normalizedOptions,
            noteId: noteId || null
        };

        if (targetElement?.dataset?.prompt) {
            vizBlockData.prompt = targetElement.dataset.prompt;
        }

        const transaction = await window.stageVisualizationBlockTransaction(vizBlockData, placeholder);
        const committedElement = window.commitStagedVisualizationTransaction(placeholder, transaction);
        if (!committedElement) {
            throw new Error("Failed to render the visualization block.");
        }

        attachVisualizationNotePin(committedElement, noteId, vizBlockData);
        persistVisualizationFormPreferences(normalizedOptions);
    } catch (error) {
        console.error("Failed to generate/place visualization:", error);
        placeholder.className = 'content-section type-visualization-placeholder type-visualization-error';
        renderVisualizationFailureState(placeholder, '시각화 생성 실패', error.message);
    } finally {
        if (systemSessionId && typeof clearSessionMessages === 'function') {
            try {
                await clearSessionMessages(systemSessionId);
            } catch (clearError) {
                trace("Visualization", "generate.clearSession.failed", { error: clearError.message }, {}, "WARN");
            }
        }
    }
};
window._generateAndPlaceVisualization = _generateAndPlaceVisualization;

handleRegenerateVisualization = async function(originalBlockData, elementToReplace) {
    let promptForRegeneration = originalBlockData ? (originalBlockData.originalPrompt || originalBlockData.prompt) : null;
    const baseGenerationOptions = normalizeVisualizationGenerationOptions(originalBlockData?.generationOptions || {});

    if (!promptForRegeneration && elementToReplace) {
        const precedingBlock = elementToReplace.previousElementSibling;
        if (precedingBlock && precedingBlock.classList.contains('content-section')) {
            promptForRegeneration = precedingBlock.innerText.replace(/\n[?렓?뱤]$/, '').trim();
            trace("Regenerate", "prompt.fallback", { source: "previousElementSibling", length: promptForRegeneration.length });
        }
    }

    if (!originalBlockData || !promptForRegeneration || !originalBlockData.htmlContent) {
        showModal("재생성에 필요한 원본 프롬프트 또는 코드가 없습니다.", () => {});
        trace("Regenerate", "start.fail", { reason: "Missing prompt data in block" });
        return;
    }

    trace("Regenerate", "start.success", { promptLength: promptForRegeneration.length });
    showVisualizationPendingOverlay(elementToReplace, 'AI가 새로운 방식으로 재구성 중...');

    let systemSessionId;
    try {
        const visualizerTemplate = promptTemplatesCache.find(p => p.name === "Data Visualizer");
        if (!visualizerTemplate) throw new Error("Data Visualizer 템플릿을 찾을 수 없습니다.");

        systemSessionId = await findOrCreateSystemSession('[System] Visualization Engine');
        if (!systemSessionId) throw new Error("시스템 세션을 생성하거나 찾을 수 없습니다.");

        const userContent = `
[REGENERATION_TASK]
The user wants to regenerate a visualization with a completely new style.

--- PREVIOUS GENERATION BRIEF ---
${buildVisualizationUserContent(baseGenerationOptions, '[기존 요청 요약]')}

--- PREVIOUS PROMPT & DATA ---
${promptForRegeneration}

--- PREVIOUSLY GENERATED CODE (DO NOT REUSE) ---
\`\`\`html
${originalBlockData.htmlContent}
\`\`\`

--- NEW INSTRUCTION ---
Based on the "PREVIOUS PROMPT & DATA", generate a NEW visualization. Your new code and approach MUST be significantly different from the "PREVIOUSLY GENERATED CODE". Be creative and explore a different library, chart type, or visual style.
Return ONLY the code block.
`;

        const responseResult = await requestVisualizationResponseWithRecovery(
            systemSessionId,
            userContent,
            visualizerTemplate.promptText,
            { mode: 'single' }
        );
        const htmlContent = responseResult.htmlContent || '';
        if (!htmlContent) {
            throw new Error(buildVisualizationResponseErrorMessage(responseResult, responseResult.content));
        }

        const newVizBlockData = {
            type: 'visualization',
            htmlContent,
            originalPrompt: promptForRegeneration,
            generationOptions: baseGenerationOptions
        };
        if (originalBlockData.noteId) newVizBlockData.noteId = originalBlockData.noteId;
        if (originalBlockData.prompt) newVizBlockData.prompt = originalBlockData.prompt;

        const transaction = await window.stageVisualizationBlockTransaction(newVizBlockData, elementToReplace);
        clearVisualizationPendingOverlay(elementToReplace);
        const committedElement = window.commitStagedVisualizationTransaction(elementToReplace, transaction);
        if (!committedElement) {
            throw new Error("새로운 시각화 블록을 렌더링하지 못했습니다.");
        }

        attachVisualizationNotePin(committedElement, newVizBlockData.noteId || null, newVizBlockData);
        trace("Regenerate", "success.rendered");
    } catch (error) {
        console.error("Failed to regenerate visualization:", error);
        trace("Regenerate", "error", { error: error.message }, {}, "ERROR");
        clearVisualizationPendingOverlay(elementToReplace);
        showModal(`재생성 실패: ${error.message}`, () => {});
        if (typeof showToastNotification === 'function') {
            showToastNotification('재생성에 실패해 기존 시각화를 유지했습니다.', '', `viz-regenerate-preserved-${Date.now()}`);
        }
    } finally {
        if (systemSessionId && typeof clearSessionMessages === 'function') {
            try {
                await clearSessionMessages(systemSessionId);
            } catch (clearError) {
                trace("Regenerate", "clearSession.failed", { error: clearError.message }, {}, "WARN");
            }
        }
    }
};
window.handleRegenerateVisualization = handleRegenerateVisualization;

handleBatchVisualizationGeneration = async function(baseOptions, placeholders) {
    if (!placeholders || placeholders.length === 0) {
        showToastNotification("묶음 생성할 시각화 영역이 없습니다.", "", "batch-gen-empty");
        return;
    }

    trace("Visualization.Batch", "start", { total: placeholders.length, size: placeholders.length });
    const chunk = placeholders;

    chunk.forEach((placeholder) => {
        placeholder.innerHTML = buildVisualizationLoadingMarkup();
        placeholder.classList.add('type-visualization-loading');
        placeholder.classList.remove('type-visualization-placeholder');
    });

    const combinedPrompt = chunk.map((placeholder, index) => {
        const prompt = placeholder.dataset.prompt || '데이터를 기반으로 적절한 시각화를 생성';
        return `--- VISUALIZATION REQUEST ${index + 1} ---\n${prompt}`;
    }).join('\n\n');

    const finalUserContent = `
[BATCH_VISUALIZATION_TASK]
Generate ${chunk.length} distinct visualization HTML code blocks.

${combinedPrompt}

Return exactly ${chunk.length} fenced html code blocks in the same order as the requests.
`;

    let systemSessionId;
    try {
        const visualizerTemplate = promptTemplatesCache.find(p => p.name === "Data Visualizer");
        if (!visualizerTemplate) throw new Error("Could not find 'Data Visualizer' prompt template.");

        systemSessionId = await findOrCreateSystemSession('[System] Visualization Engine');
        if (!systemSessionId) throw new Error("Could not create or find system session for visualization.");

        const responseResult = await requestVisualizationResponseWithRecovery(
            systemSessionId,
            finalUserContent,
            visualizerTemplate.promptText,
            { mode: 'batch', expectedCount: chunk.length }
        );

        const matches = extractVisualizationHtmlBlocks(responseResult.content);
        if (!matches || matches.length === 0) {
            throw new Error(buildVisualizationResponseErrorMessage(responseResult, responseResult.content));
        }

        if (matches.length !== chunk.length) {
            console.warn(`AI returned ${matches.length} visualizations, but ${chunk.length} were expected.`);
        }

        for (let i = 0; i < chunk.length; i++) {
            const placeholder = chunk[i];
            const match = matches[i];

            if (placeholder && match) {
                const vizData = {
                    type: 'visualization',
                    htmlContent: match.trim(),
                    originalPrompt: placeholder.dataset.prompt || '',
                    prompt: placeholder.dataset.prompt,
                    generationOptions: normalizeVisualizationGenerationOptions(baseOptions)
                };

                const transaction = await window.stageVisualizationBlockTransaction(vizData, placeholder);
                const committedElement = window.commitStagedVisualizationTransaction(placeholder, transaction);
                if (!committedElement) {
                    throw new Error(`Failed to render visualization block for index ${i}`);
                }
            } else if (placeholder) {
                placeholder.className = 'content-section type-visualization-placeholder type-visualization-error';
                renderVisualizationFailureState(placeholder, '묶음 생성 실패', 'AI가 이 항목의 시각화 코드를 안정적으로 반환하지 않았습니다.');
            }
        }
    } catch (error) {
        console.error("Batch visualization generation failed for a chunk:", error);
        chunk.forEach((placeholder) => {
            if (!placeholder) return;
            placeholder.className = 'content-section type-visualization-placeholder type-visualization-error';
            renderVisualizationFailureState(placeholder, '묶음 생성 실패', error.message);
        });
        throw error;
    } finally {
        if (systemSessionId && typeof clearSessionMessages === 'function') {
            try {
                await clearSessionMessages(systemSessionId);
            } catch (clearError) {
                trace("Visualization.Batch", "clearSession.failed", { error: clearError.message }, {}, "WARN");
            }
        }
    }
};

async function handleBatchVisualizationGeneration(baseOptions, placeholders) {
    if (!placeholders || placeholders.length === 0) {
        showToastNotification("묶음 생성할 시각화 영역이 없습니다.", "", "batch-gen-empty");
        return;
    }

    trace("Visualization.Batch", "start", { total: placeholders.length, size: placeholders.length });

    const chunk = placeholders; 

    chunk.forEach(p => {
        p.innerHTML = `<div class="media-loading-state"><div class="loading-animation" aria-hidden="true"><div class="dot"></div><div class="dot"></div><div class="dot"></div></div></div>`;
        p.classList.add('type-visualization-loading');
        p.classList.remove('type-visualization-placeholder');
    });

    const combinedPrompt = chunk.map((p, index) => {
        const prompt = p.dataset.prompt || '데이터를 기반으로 적절한 시각화를 생성';
        return `--- VISUALIZATION REQUEST ${index + 1} ---\n${prompt}`;
    }).join('\n\n');

    const finalUserContent = `
[MULTIPLE VISUALIZATION REQUEST]
Generate distinct HTML code blocks for exactly ${chunk.length} visualization requests below.
Output each visualization in its own \`\`\`html ... \`\`\` block.
Do not wrap them in JSON. Return them sequentially.

${combinedPrompt}
`;

    let systemSessionId;
    try {
        const visualizerTemplate = promptTemplatesCache.find(p => p.name === "Data Visualizer");
        if (!visualizerTemplate) throw new Error("Data Visualizer template not found.");
        
        systemSessionId = await findOrCreateSystemSession('[System] Visualization Engine');
        if (!systemSessionId) throw new Error("Could not find/create system session.");
        
        const systemInstruction = visualizerTemplate.promptText;
        const optionsForAI = buildVisualizationUserContent(baseOptions, finalUserContent);

        const responseResult = await requestVisualizationResponseWithRecovery(
            systemSessionId,
            optionsForAI,
            systemInstruction,
            { mode: 'batch', expectedCount: chunk.length }
        );

        // [MODIFIED] Batch Extraction Logic (Multiple Code Blocks)
        // We use the recovered response result to find all occurrences of code blocks
        const matches = responseResult.htmlBlocks || [];
        
        if (!matches || matches.length === 0) {
             throw new Error(buildVisualizationResponseErrorMessage(responseResult, responseResult.content));
        }

        if (matches.length !== chunk.length) {
            console.warn(`AI returned ${matches.length} visualizations, but ${chunk.length} were expected.`);
        }

        for (let i = 0; i < chunk.length; i++) {
            const placeholder = chunk[i];
            // Use optional chaining/bounds check in case of count mismatch
            const match = matches[i];
            
            if (placeholder && match) {
                const htmlContent = match.trim();
                const vizData = {
                    type: 'visualization',
                    htmlContent: htmlContent,
                    originalPrompt: placeholder.dataset.prompt || '',
                    prompt: placeholder.dataset.prompt,
                    generationOptions: normalizeVisualizationGenerationOptions(baseOptions)
                };

                const newBlockElement = mountVisualizationBlock(vizData, placeholder);
                if (newBlockElement) {
                    if (newBlockElement !== placeholder) {
                        placeholder.replaceWith(newBlockElement);
                    }
                } else {
                     throw new Error(`Failed to render visualization block for index ${i}`);
                }
            } else {
                if (placeholder) {
                    placeholder.className = 'content-section type-visualization-placeholder type-visualization-error';
                    renderVisualizationFailureState(placeholder, '묶음 생성 실패', 'AI가 이 항목의 시각화 코드를 안정적으로 반환하지 않았습니다.');
                }
            }
        }
    } catch (error) {
        console.error("Batch visualization generation failed for a chunk:", error);
        chunk.forEach(p => {
            if (p) {
                p.className = 'content-section type-visualization-placeholder type-visualization-error';
                renderVisualizationFailureState(p, '묶음 생성 실패', error.message);
                return;
                const contentDiv = p.querySelector('.placeholder-content');
                const actionsDiv = p.querySelector('.placeholder-actions');
        
                if (contentDiv) {
                    contentDiv.innerHTML = `<p>묶음 생성 실패: ${error.message}</p>`;
                } else {
                    p.innerHTML = `<div class="placeholder-content"><p>묶음 생성 실패: ${error.message}</p></div>`;
                }
                if (actionsDiv) {
                    actionsDiv.style.display = 'none';
                }
            }
        });
        throw error;
    } finally {
        if (systemSessionId && typeof clearSessionMessages === 'function') {
            try {
                await clearSessionMessages(systemSessionId);
            } catch (clearError) {
                trace("Visualization.Batch", "clearSession.failed", { error: clearError.message }, {}, "WARN");
            }
        }
    }
}


async function handleAddVisualization(prefilledText, targetElement, noteId = null) {
    if (!prefilledText) {
        const confirmed = await new Promise(resolve => {
            showModal("시각화할 텍스트가 없습니다. 빈 상태로 시각화 옵션을 여시겠습니까?", () => resolve(true), () => resolve(false));
        });
        if (!confirmed) return;
    }

    if (!targetElement) {
        console.error("handleAddVisualization requires a targetElement for insertion.");
        showModal("시각화 자료를 삽입할 위치를 찾을 수 없습니다.", () => {});
        return;
    }

    const prefilledOptions = { description: prefilledText || '' };

    openVisualizationOptionsModal(prefilledOptions, (options) => {
        _generateAndPlaceVisualization(options, targetElement, false, noteId);
    }, targetElement);
}

async function handleModifyVisualization(originalBlockData, elementToReplace) {
    if (!originalBlockData || !elementToReplace) return;

    const noteId = originalBlockData.noteId || elementToReplace.closest('#recall-content-area')?.dataset.noteId || null;

    const prefilledDescription = originalBlockData.originalPrompt || originalBlockData.prompt || '';

    const prefilledOptions = {
        libraries: ['AI 추천'], 
        description: prefilledDescription,
        isSimulation: false, 
    };
    
    if (originalBlockData.htmlContent && (originalBlockData.htmlContent.includes('requestAnimationFrame') || originalBlockData.htmlContent.includes('function draw()'))) {
        prefilledOptions.isSimulation = true;
    }

    openVisualizationOptionsModal(prefilledOptions, (newOptions) => {
        _generateAndPlaceVisualization(newOptions, elementToReplace, true, noteId);
    }, elementToReplace);
}

function openVisualizationOptionsModal(prefilledOptions, onConfirm, targetElement = null) {
    if (!visualizationOptionsModalOverlay) return;

    const { description = '' } = prefilledOptions;
    const modal = visualizationOptionsModalOverlay;

    const vizOptionsTextarea = document.getElementById('viz-options-textarea');
    const vizOptionsCancelBtn = document.getElementById('viz-options-cancel-btn');
    const vizOptionsGenerateBtn = document.getElementById('viz-options-generate-btn');
    const batchSizeInput = document.getElementById('viz-batch-size-input');
    const addPresetPromptBtn = document.getElementById('viz-add-preset-prompt');

    let handleBatchSizeChange;
    let handleAddPresetPrompt;

    vizOptionsTextarea.value = description;
    vizOptionsTextarea.readOnly = false;
    if (batchSizeInput) {
        const batchOptionsContainer = batchSizeInput.closest('#viz-batch-options');
        const batchOptionsLabel = batchOptionsContainer?.querySelector('label');
        const batchOptionsHint = batchOptionsContainer?.querySelector('small');

        batchSizeInput.value = String(ENFORCED_VISUALIZATION_BATCH_SIZE);
        batchSizeInput.min = String(ENFORCED_VISUALIZATION_BATCH_SIZE);
        batchSizeInput.max = String(ENFORCED_VISUALIZATION_BATCH_SIZE);
        batchSizeInput.readOnly = true;
        batchSizeInput.disabled = true;
        batchSizeInput.title = 'Visualization generation is currently enforced as single-item only for stability.';
        if (batchOptionsLabel) {
            batchOptionsLabel.textContent = '시각화 생성 단위';
        }
        if (batchOptionsHint) {
            batchOptionsHint.textContent = '안정화 모드에서는 시각화를 한 번에 1개씩만 생성합니다. 출력 정합성과 DOM 내부 배치를 우선합니다.';
        }

        if (userApiSettings.visualizationSettings?.batchGenerationSize !== ENFORCED_VISUALIZATION_BATCH_SIZE) {
            userApiSettings.visualizationSettings.batchGenerationSize = ENFORCED_VISUALIZATION_BATCH_SIZE;
            if (typeof debouncedSaveUserSettings === 'function') {
                debouncedSaveUserSettings();
                trace("Settings", "viz.batchSize.enforced", { newSize: ENFORCED_VISUALIZATION_BATCH_SIZE });
            }
        }
    }

    const mainTabContainer = modal.querySelector('.viz-main-tabs');
    const mainTabButtons = modal.querySelectorAll('.viz-main-tab-btn');
    const mainTabPanels = modal.querySelectorAll('.viz-main-tab-panel');

    const libTabButtons = modal.querySelectorAll('.viz-library-container .viz-tab-btn');
    const libTabPanels = modal.querySelectorAll('.viz-library-container .viz-tab-panel');
    const libraryButtons = modal.querySelectorAll('.option-btn[data-library]');

    const themeButtons = modal.querySelectorAll('#viz-theme-options .option-btn[data-theme]');
    const autoGenerateToggle = modal.querySelector('#viz-auto-generate-toggle');
    const educationalModeBtn = modal.querySelector('#viz-educational-mode');
    const worldsimModeBtn = modal.querySelector('#viz-worldsim-mode');

    
    const prefilledLibraries = prefilledOptions.libraries || [];
    const isSimulation = prefilledOptions.isSimulation || false;
    
    mainTabButtons.forEach(btn => btn.classList.remove('active'));
    mainTabPanels.forEach(panel => panel.classList.remove('active'));
    modal.querySelector('[data-main-tab="libraries"]').classList.add('active');
    modal.querySelector('#viz-main-tab-libraries').classList.add('active');

    libraryButtons.forEach(btn => btn.classList.remove('active'));
    themeButtons.forEach(btn => btn.classList.remove('active'));
    modal.querySelector('#viz-include-all-dom').classList.remove('active');
    
    const simModeBtn = modal.querySelector('#viz-simulation-mode');
    if(simModeBtn) simModeBtn.classList.toggle('active', isSimulation);

    const simpleModeBtn = modal.querySelector('#viz-simple-mode');
    if(simpleModeBtn) simpleModeBtn.classList.remove('active');

    if (autoGenerateToggle) autoGenerateToggle.classList.toggle('active', !!userApiSettings.visualizationSettings?.autoGenerateOnLoad);
    if (educationalModeBtn) educationalModeBtn.classList.toggle('active', !!userApiSettings.visualizationSettings?.educationalMode);
    if (worldsimModeBtn) worldsimModeBtn.classList.toggle('active', !!userApiSettings.visualizationSettings?.worldsimMode);

    const defaultThemeBtn = modal.querySelector('#viz-theme-options .option-btn[data-theme="[🎨 기본]"]');
    if (defaultThemeBtn) defaultThemeBtn.classList.add('active');

    if (prefilledLibraries.length === 0 || prefilledLibraries.includes('AI 추천')) {
        modal.querySelector('[data-library="AI 추천"]').classList.add('active');
    } else {
        modal.querySelector('[data-library="AI 추천"]').classList.remove('active');
        libraryButtons.forEach(btn => {
            if (prefilledLibraries.includes(btn.dataset.library)) btn.classList.add('active');
        });
    }

    const firstSelectedLib = prefilledLibraries.find(lib => lib !== 'AI 추천');
    let activeTabSet = false;
    if (firstSelectedLib) {
        const selectedBtn = Array.from(libraryButtons).find(btn => btn.dataset.library === firstSelectedLib);
        if (selectedBtn) {
            const panel = selectedBtn.closest('.viz-library-container .viz-tab-panel');
            if (panel) {
                const tabId = panel.id.replace('viz-tab-', '');
                const tabBtn = modal.querySelector(`.viz-library-container .viz-tab-btn[data-tab="${tabId}"]`);
                if (tabBtn) {
                    libTabButtons.forEach(btn => btn.classList.remove('active'));
                    libTabPanels.forEach(p => p.classList.remove('active'));
                    tabBtn.classList.add('active');
                    panel.classList.add('active');
                    activeTabSet = true;
                }
            }
        }
    }
    if (!activeTabSet) {
        libTabButtons.forEach(btn => btn.classList.remove('active'));
        libTabPanels.forEach(p => p.classList.remove('active'));
        if (libTabButtons[0]) libTabButtons[0].classList.add('active');
        if (libTabPanels[0]) libTabPanels[0].classList.add('active');
    }

    handleAddPresetPrompt = () => {
        const presetPrompt = targetElement?.dataset.prompt?.trim();
        if (presetPrompt) {
            const currentText = vizOptionsTextarea.value.trim();
            const promptIdentifier = '[미리 설정된 프롬프트]';
            if (currentText.includes(promptIdentifier)) {
                showToastNotification("ℹ️ 프롬프트가 이미 추가되어 있습니다.", "", `preset-prompt-exists-${Date.now()}`);
                return;
            }
            const promptBlock = `${promptIdentifier}\n${presetPrompt}\n\n---\n\n`;
            vizOptionsTextarea.value = promptBlock + currentText;
            vizOptionsTextarea.focus();
            vizOptionsTextarea.scrollTop = 0;
            showToastNotification("✅ 설정된 프롬프트를 추가했습니다.", "", `preset-prompt-added-${Date.now()}`);
        } else {
            showToastNotification("ℹ️ 추가할 미리 설정된 프롬프트가 없습니다.", "", `preset-prompt-none-${Date.now()}`);
        }
    };

    const handleMainTabSwitch = (e) => {
        const tabBtn = e.target.closest('.viz-main-tab-btn');
        if (!tabBtn) return;
        
        const targetTab = tabBtn.dataset.mainTab;
        mainTabButtons.forEach(btn => btn.classList.remove('active'));
        mainTabPanels.forEach(panel => panel.classList.remove('active'));
        
        tabBtn.classList.add('active');
        const targetPanel = modal.querySelector(`#viz-main-tab-${targetTab}`);
        if (targetPanel) targetPanel.classList.add('active');
    };

    const handleModalInteraction = (e) => {
        const libTabBtn = e.target.closest('.viz-library-container .viz-tab-btn');
        const optionBtn = e.target.closest('.option-btn');

        if (libTabBtn) {
            libTabButtons.forEach(btn => btn.classList.remove('active'));
            libTabPanels.forEach(panel => panel.classList.remove('active'));
            libTabBtn.classList.add('active');
            const targetPanel = document.getElementById(`viz-tab-${libTabBtn.dataset.tab}`);
            if (targetPanel) targetPanel.classList.add('active');
        } else if (optionBtn) {
            const isThemeButton = optionBtn.closest('#viz-theme-options');
            const isLibraryButton = optionBtn.hasAttribute('data-library');
            const isGlobalButton = optionBtn.closest('#viz-global-options');
            const isAiButton = optionBtn.dataset.library === 'AI 추천';

            if (isThemeButton) {
                themeButtons.forEach(btn => btn.classList.remove('active'));
                optionBtn.classList.add('active');
            } else if (isGlobalButton) {
                if (isAiButton) {
                    libraryButtons.forEach(btn => btn.classList.remove('active'));
                    optionBtn.classList.add('active');
                } else if (['viz-auto-generate-toggle', 'viz-educational-mode', 'viz-worldsim-mode'].includes(optionBtn.id)) {
                    const isActive = optionBtn.classList.toggle('active');
                    const settingKey = {
                        'viz-auto-generate-toggle': 'autoGenerateOnLoad',
                        'viz-educational-mode': 'educationalMode',
                        'viz-worldsim-mode': 'worldsimMode'
                    }[optionBtn.id];
                    
                    if (userApiSettings.visualizationSettings && settingKey) {
                        userApiSettings.visualizationSettings[settingKey] = isActive;
                    }
                    saveUserSettingsToFirebase(true);
                } else {
                    optionBtn.classList.toggle('active');
                    if (optionBtn.id === 'viz-include-all-dom' && optionBtn.classList.contains('active')) {
                        const currentText = vizOptionsTextarea.value.trim();
                        const domContent = extractContextFromDOM('learning-content');
                        const separator = '\n\n---\n[현재 장면 전체 내용]:\n';
                        vizOptionsTextarea.value = currentText ? `${currentText}${separator}${domContent}` : domContent;
                    }
                }
            } else if (isLibraryButton) {
                const aiButton = modal.querySelector('[data-library="AI 추천"]');
                aiButton.classList.remove('active');
                optionBtn.classList.toggle('active');
                const anyOtherActive = Array.from(libraryButtons).some(btn => btn.classList.contains('active') && btn.dataset.library !== 'AI 추천');
                if (!anyOtherActive) {
                    aiButton.classList.add('active');
                }
            }
        }
    };
    
    if (addPresetPromptBtn) {
        const hasPresetPrompt = targetElement?.dataset.prompt?.trim();
        addPresetPromptBtn.style.display = hasPresetPrompt ? 'inline-flex' : 'none';
        addPresetPromptBtn.addEventListener('click', handleAddPresetPrompt);
    }
    
    mainTabContainer.addEventListener('click', handleMainTabSwitch);
    modal.addEventListener('click', handleModalInteraction);

    const close = () => {
        modal.style.display = 'none';
        mainTabContainer.removeEventListener('click', handleMainTabSwitch);
        modal.removeEventListener('click', handleModalInteraction);
        if (batchSizeInput && handleBatchSizeChange) {
            batchSizeInput.removeEventListener('input', handleBatchSizeChange);
        }
        if (addPresetPromptBtn && handleAddPresetPrompt) {
            addPresetPromptBtn.removeEventListener('click', handleAddPresetPrompt);
        }
        vizOptionsGenerateBtn.onclick = null;
        vizOptionsCancelBtn.onclick = null;
    };

    vizOptionsCancelBtn.onclick = close;
    
    vizOptionsGenerateBtn.onclick = () => {
        const batchSize = ENFORCED_VISUALIZATION_BATCH_SIZE;
        
        const getOptions = () => {
            const selectedLibraries = Array.from(modal.querySelectorAll('.option-btn.active[data-library]')).map(btn => btn.dataset.library);
            const userDescription = vizOptionsTextarea.value;
            const isSimulation = modal.querySelector('#viz-simulation-mode').classList.contains('active');
            const isSimpleMode = modal.querySelector('#viz-simple-mode')?.classList.contains('active');
            const isEducationalMode = modal.querySelector('#viz-educational-mode').classList.contains('active');
            const isWorldsimMode = modal.querySelector('#viz-worldsim-mode').classList.contains('active');
            
            const activeThemeButton = modal.querySelector('#viz-theme-options .option-btn.active[data-theme]');
            const theme = activeThemeButton ? activeThemeButton.dataset.theme : '[🎨 기본]';
            
            let finalDescription = '';
            if (isEducationalMode) {
                finalDescription += '[🎓 교육 자료]\n\n';
            }
            if (isWorldsimMode) {
                finalDescription += '[🌍 월드 시뮬]\n\n';
            }
            if (theme !== '[🎨 기본]') {
                finalDescription += `${theme}\n\n`;
            }
            finalDescription += userDescription;

            return {
                libraries: selectedLibraries,
                description: finalDescription,
                isSimulation: isSimulation,
                isSimpleMode: isSimpleMode
            };
        };
        
        if (targetElement) {
            const collectedOptions = getOptions();
            onConfirm(collectedOptions);
            close();
            return;
        }

        if (batchSize > 1) {
            const placeholderCount = document.querySelectorAll('.type-visualization-placeholder').length;
            showChoiceModal(
                '묶음 생성 확인',
                `'묶음 생성'은 현재 페이지의 모든 시각화 영역(${placeholderCount}개)에 대해 묶음 크기(${batchSize})로 생성을 시작합니다. 계속하시겠습니까?`,
                [
                    {
                        id: 'batch-gen-confirm',
                        text: '생성하기',
                        class: 'confirm',
                        action: () => {
                            const collectedOptions = getOptions();
                            close();
                            handleBatchVisualizationGeneration(collectedOptions, document.querySelectorAll('.type-visualization-placeholder'));
                        }
                    },
                    {
                        id: 'batch-gen-cancel',
                        text: '취소',
                        class: 'cancel',
                        action: () => {}
                    }
                ]
            );
        } else {
            const collectedOptions = getOptions();
            onConfirm(collectedOptions);
            close();
        }
    };

    highestZIndex++;
    modal.style.zIndex = highestZIndex;
    modal.style.display = 'flex';
}

// Final active summary/collection overrides for AI recommendation mode.
function collectVisualizationOptionsFromModal(modal) {
    const aiToggle = modal.querySelector('#viz-ai-recommend-toggle');
    if (aiToggle?.classList.contains('active')) {
        if (!modal.__vizAiRecommendation) {
            refreshVisualizationAiRecommendation(modal, modal.__vizAiTargetElement || null);
        }
        return normalizeVisualizationGenerationOptions({
            ...(modal.__vizAiRecommendation?.options || getVisualizationModalRawOptions(modal)),
            useAiRecommendedProfile: true
        });
    }

    return getVisualizationModalRawOptions(modal);
}

function renderVisualizationSelectionSummary(modal) {
    const summaryNode = modal.querySelector('#viz-selection-summary');
    if (!summaryNode) return;

    const options = collectVisualizationOptionsFromModal(modal);
    const selectedLibraries = options.libraries.length > 0 ? options.libraries.join(', ') : 'AI 추천';
    const safetyBadges = [];
    const aiReasons = options.useAiRecommendedProfile ? (modal.__vizAiRecommendation?.reasons || []) : [];
    const sourceLabel = options.useAiRecommendedProfile ? 'AI 추천 구성' : '수동 커스텀 구성';

    if (options.highContrastMode) safetyBadges.push('고대비');
    if (options.exportSafeMode) safetyBadges.push('내보내기 안전');
    if (options.isSimpleMode) safetyBadges.push('단순 모드');
    if (options.isSimulation) safetyBadges.push('시뮬레이션');
    if (options.educationalMode) safetyBadges.push('교육형');
    if (options.worldsimMode) safetyBadges.push('몰입형');
    if (options.useAiRecommendedProfile) safetyBadges.push('AI 추천');

    const safetyText = safetyBadges.length > 0 ? safetyBadges.join(' · ') : '기본';
    const requestPreview = options.description
        ? options.description.slice(0, 160)
        : '추가 요청이 없으면 현재 문맥과 사용자가 입력한 본문을 기준으로 생성합니다.';

    summaryNode.innerHTML = `
        <div class="viz-summary-list">
            <div class="viz-summary-item">
                <strong>구성 출처</strong>
                <span>${sourceLabel}</span>
            </div>
            <div class="viz-summary-item">
                <strong>목표</strong>
                <span>${getVisualizationLabel('goals', options.goal)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>계열</strong>
                <span>${getVisualizationLabel('families', options.family)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>렌더링 전략</strong>
                <span>${getVisualizationLabel('renderers', options.rendererStrategy)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>프리셋</strong>
                <span>${getVisualizationLabel('presets', options.presetKey)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>세부 라이브러리</strong>
                <span>${selectedLibraries}</span>
            </div>
            <div class="viz-summary-item">
                <strong>안전/동작</strong>
                <span>${safetyText}</span>
            </div>
        </div>
        <div class="viz-review-note">
            ${getVisualizationLabel('interactions', options.interactionLevel)} / ${getVisualizationLabel('complexities', options.complexityBias)} / ${getVisualizationLabel('fallbacks', options.fallbackPolicy)} 조합으로 생성합니다.
            <br>
            테마: ${options.theme}
            <br>
            요청 미리보기: ${escapeVisualizationSummaryHtml(requestPreview)}
            ${aiReasons.length > 0 ? `<br><br><strong>AI 추천 기준:</strong> ${escapeVisualizationSummaryHtml(aiReasons.join(' / '))}` : ''}
        </div>
    `;
}

// Keep the AI-recommendation-aware modal behavior as the final active definition.
function collectVisualizationOptionsFromModal(modal) {
    const aiToggle = modal.querySelector('#viz-ai-recommend-toggle');
    if (aiToggle?.classList.contains('active')) {
        if (!modal.__vizAiRecommendation) {
            refreshVisualizationAiRecommendation(modal, modal.__vizAiTargetElement || null);
        }
        return normalizeVisualizationGenerationOptions({
            ...(modal.__vizAiRecommendation?.options || getVisualizationModalRawOptions(modal)),
            useAiRecommendedProfile: true
        });
    }

    return getVisualizationModalRawOptions(modal);
}

function renderVisualizationSelectionSummary(modal) {
    const summaryNode = modal.querySelector('#viz-selection-summary');
    if (!summaryNode) return;

    const options = collectVisualizationOptionsFromModal(modal);
    const selectedLibraries = options.libraries.length > 0 ? options.libraries.join(', ') : 'AI 추천';
    const safetyBadges = [];

    if (options.highContrastMode) safetyBadges.push('고대비');
    if (options.exportSafeMode) safetyBadges.push('내보내기 안전');
    if (options.isSimpleMode) safetyBadges.push('단순 모드');
    if (options.isSimulation) safetyBadges.push('시뮬레이션');
    if (options.educationalMode) safetyBadges.push('교육형');
    if (options.worldsimMode) safetyBadges.push('몰입형');
    if (options.useAiRecommendedProfile) safetyBadges.push('AI 추천');

    const safetyText = safetyBadges.length > 0 ? safetyBadges.join(' · ') : '기본';
    const requestPreview = options.description
        ? options.description.slice(0, 160)
        : '추가 요청이 없으면 현재 문맥과 사용자가 입력한 본문을 기준으로 생성합니다.';
    const aiReasons = options.useAiRecommendedProfile ? (modal.__vizAiRecommendation?.reasons || []) : [];

    summaryNode.innerHTML = `
        <div class="viz-summary-list">
            <div class="viz-summary-item">
                <strong>목표</strong>
                <span>${getVisualizationLabel('goals', options.goal)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>계열</strong>
                <span>${getVisualizationLabel('families', options.family)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>렌더 방식</strong>
                <span>${getVisualizationLabel('renderers', options.rendererStrategy)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>대상 독자</strong>
                <span>${getVisualizationLabel('audiences', options.audienceMode)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>정보 밀도</strong>
                <span>${getVisualizationLabel('densities', options.densityMode)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>움직임</strong>
                <span>${getVisualizationLabel('motions', options.motionMode)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>프리셋</strong>
                <span>${getVisualizationLabel('presets', options.presetKey)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>라이브러리</strong>
                <span>${selectedLibraries}</span>
            </div>
            <div class="viz-summary-item">
                <strong>안전/동작</strong>
                <span>${safetyText}</span>
            </div>
        </div>
        <div class="viz-review-note">
            ${getVisualizationLabel('interactions', options.interactionLevel)} / ${getVisualizationLabel('complexities', options.complexityBias)} / ${getVisualizationLabel('fallbacks', options.fallbackPolicy)} 조합으로 생성합니다.
            <br>
            테마: ${options.theme}
            <br>
            요청 미리보기: ${escapeVisualizationSummaryHtml(requestPreview)}
            ${aiReasons.length > 0 ? `<br><br><strong>AI 추천 기준:</strong> ${escapeVisualizationSummaryHtml(aiReasons.join(' / '))}` : ''}
        </div>
    `;
}

function openVisualizationOptionsModal(prefilledOptions, onConfirm, targetElement = null) {
    if (!visualizationOptionsModalOverlay) return;

    const modal = visualizationOptionsModalOverlay;
    modal.__vizAiTargetElement = targetElement || null;
    const mergedOptions = normalizeVisualizationGenerationOptions({
        ...getVisualizationFormDefaults(),
        ...(prefilledOptions || {}),
        description: typeof prefilledOptions?.description === 'string' ? prefilledOptions.description : ''
    });

    const vizOptionsTextarea = modal.querySelector('#viz-options-textarea');
    const vizOptionsCancelBtn = modal.querySelector('#viz-options-cancel-btn');
    const vizOptionsGenerateBtn = modal.querySelector('#viz-options-generate-btn');
    const batchSizeInput = modal.querySelector('#viz-batch-size-input');
    const addPresetPromptBtn = modal.querySelector('#viz-add-preset-prompt');
    const aiRecommendToggle = modal.querySelector('#viz-ai-recommend-toggle');
    const toggleButtons = [
        'viz-educational-mode',
        'viz-worldsim-mode',
        'viz-simulation-mode',
        'viz-simple-mode',
        'viz-high-contrast-mode',
        'viz-export-safe-mode',
        'viz-include-all-dom',
        'viz-auto-generate-toggle',
        'viz-remember-form-toggle'
    ];

    let handleModalClick;
    let handleTextareaInput;
    let handlePresetPrompt;

    if (vizOptionsTextarea) {
        vizOptionsTextarea.value = mergedOptions.description || '';
        vizOptionsTextarea.readOnly = false;
    }

    if (batchSizeInput) {
        batchSizeInput.value = String(ENFORCED_VISUALIZATION_BATCH_SIZE);
        batchSizeInput.min = String(ENFORCED_VISUALIZATION_BATCH_SIZE);
        batchSizeInput.max = String(ENFORCED_VISUALIZATION_BATCH_SIZE);
        batchSizeInput.readOnly = true;
        batchSizeInput.disabled = true;
    }

    setVisualizationSingleChoice(modal, 'goal', mergedOptions.goal);
    setVisualizationSingleChoice(modal, 'family', mergedOptions.family);
    setVisualizationSingleChoice(modal, 'renderer', mergedOptions.rendererStrategy);
    setVisualizationSingleChoice(modal, 'interaction', mergedOptions.interactionLevel);
    setVisualizationSingleChoice(modal, 'audience', mergedOptions.audienceMode);
    setVisualizationSingleChoice(modal, 'complexity', mergedOptions.complexityBias);
    setVisualizationSingleChoice(modal, 'fallback', mergedOptions.fallbackPolicy);
    setVisualizationSingleChoice(modal, 'density', mergedOptions.densityMode);
    setVisualizationSingleChoice(modal, 'motion', mergedOptions.motionMode);
    setVisualizationSingleChoice(modal, 'addon', mergedOptions.addonPolicy);
    setVisualizationSingleChoice(modal, 'theme', mergedOptions.theme);
    setVisualizationSingleChoice(modal, 'preset', mergedOptions.presetKey);
    setVisualizationLibrarySelection(modal, mergedOptions.libraries);
    setVisualizationToggleState(modal, 'viz-educational-mode', mergedOptions.educationalMode);
    setVisualizationToggleState(modal, 'viz-worldsim-mode', mergedOptions.worldsimMode);
    setVisualizationToggleState(modal, 'viz-simulation-mode', mergedOptions.isSimulation);
    setVisualizationToggleState(modal, 'viz-simple-mode', mergedOptions.isSimpleMode);
    setVisualizationToggleState(modal, 'viz-high-contrast-mode', mergedOptions.highContrastMode);
    setVisualizationToggleState(modal, 'viz-export-safe-mode', mergedOptions.exportSafeMode);
    setVisualizationToggleState(modal, 'viz-include-all-dom', mergedOptions.includeAllDom);
    setVisualizationToggleState(modal, 'viz-auto-generate-toggle', mergedOptions.autoGenerateOnLoad);
    setVisualizationToggleState(modal, 'viz-remember-form-toggle', mergedOptions.rememberLastVisualizationForm);
    aiRecommendToggle?.classList.toggle('active', !!mergedOptions.useAiRecommendedProfile);

    if (!mergedOptions.presetKey || !(VISUALIZATION_PRESET_CONFIG_V2[mergedOptions.presetKey] || VISUALIZATION_PRESET_CONFIG[mergedOptions.presetKey])) {
        clearVisualizationPresetSelection(modal);
    }

    if (addPresetPromptBtn) {
        const hasPresetPrompt = targetElement?.dataset.prompt?.trim();
        addPresetPromptBtn.style.display = hasPresetPrompt ? 'inline-flex' : 'none';
        handlePresetPrompt = () => {
            const presetPrompt = targetElement?.dataset.prompt?.trim();
            if (!presetPrompt || !vizOptionsTextarea) return;

            const marker = '[영역 프롬프트]';
            if (vizOptionsTextarea.value.includes(marker)) {
                showToastNotification('영역 프롬프트가 이미 추가되어 있습니다.', '', `viz-preset-prompt-${Date.now()}`);
                return;
            }

            vizOptionsTextarea.value = `${marker}\n${presetPrompt}\n\n${vizOptionsTextarea.value}`.trim();
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            vizOptionsTextarea.focus();
            showToastNotification('영역 프롬프트를 세부 요청에 추가했습니다.', '', `viz-preset-prompt-added-${Date.now()}`);
        };
        addPresetPromptBtn.addEventListener('click', handlePresetPrompt);
    }

    handleTextareaInput = () => {
        refreshVisualizationAiRecommendation(modal, targetElement);
        renderVisualizationSelectionSummary(modal);
    };
    vizOptionsTextarea?.addEventListener('input', handleTextareaInput);

    handleModalClick = (event) => {
        const aiButton = event.target.closest('#viz-ai-recommend-toggle');
        if (aiButton) {
            aiButton.classList.toggle('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            return;
        }

        const presetButton = event.target.closest('[data-role="preset"]');
        if (presetButton) {
            applyVisualizationPresetToModal(modal, presetButton.dataset.preset);
            aiRecommendToggle?.classList.remove('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            return;
        }

        const choiceButton = event.target.closest('[data-role]');
        if (choiceButton) {
            const role = choiceButton.dataset.role;
            setVisualizationSingleChoice(modal, role, choiceButton.dataset[role]);
            if (role !== 'preset') {
                clearVisualizationPresetSelection(modal);
            }
            aiRecommendToggle?.classList.remove('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            return;
        }

        const libraryButton = event.target.closest('[data-library]');
        if (libraryButton) {
            libraryButton.classList.toggle('active');
            clearVisualizationPresetSelection(modal);
            aiRecommendToggle?.classList.remove('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            return;
        }

        const toggleButton = event.target.closest('.option-btn[id]');
        if (toggleButton && toggleButtons.includes(toggleButton.id)) {
            toggleButton.classList.toggle('active');
            clearVisualizationPresetSelection(modal);
            aiRecommendToggle?.classList.remove('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
        }
    };
    modal.addEventListener('click', handleModalClick);

    refreshVisualizationAiRecommendation(modal, targetElement);
    renderVisualizationSelectionSummary(modal);

    const close = () => {
        modal.style.display = 'none';
        modal.removeEventListener('click', handleModalClick);
        vizOptionsTextarea?.removeEventListener('input', handleTextareaInput);
        if (addPresetPromptBtn && handlePresetPrompt) {
            addPresetPromptBtn.removeEventListener('click', handlePresetPrompt);
        }
        vizOptionsGenerateBtn.onclick = null;
        vizOptionsCancelBtn.onclick = null;
    };

    vizOptionsCancelBtn.onclick = close;
    vizOptionsGenerateBtn.textContent = targetElement ? '재생성하기' : '생성하기';
    vizOptionsGenerateBtn.onclick = () => {
        const collectedOptions = aiRecommendToggle?.classList.contains('active')
            ? normalizeVisualizationGenerationOptions({
                ...(modal.__vizAiRecommendation?.options || getVisualizationModalRawOptions(modal)),
                useAiRecommendedProfile: true
            })
            : collectVisualizationOptionsFromModal(modal);
        persistVisualizationFormPreferences(collectedOptions);
        onConfirm(collectedOptions);
        close();
    };

    highestZIndex++;
    modal.style.zIndex = highestZIndex;
    modal.style.display = 'flex';
}

function getVisualizationModalRawOptions(modal) {
    const vizOptionsTextarea = modal.querySelector('#viz-options-textarea');
    const includeAllDom = modal.querySelector('#viz-include-all-dom')?.classList.contains('active');
    let description = vizOptionsTextarea?.value?.trim?.() || '';

    if (includeAllDom && typeof extractContextFromDOM === 'function') {
        const domContent = extractContextFromDOM('learning-content');
        if (domContent) {
            const contextBlock = `[현재 장면 전체 내용]\n${domContent}`;
            description = description ? `${description}\n\n---\n\n${contextBlock}` : contextBlock;
        }
    }

    return normalizeVisualizationGenerationOptions({
        libraries: Array.from(modal.querySelectorAll('[data-library].active')).map((button) => button.dataset.library),
        description,
        goal: getVisualizationSingleChoice(modal, 'goal', 'explain'),
        family: getVisualizationSingleChoice(modal, 'family', 'comparison'),
        rendererStrategy: getVisualizationSingleChoice(modal, 'renderer', 'ai-recommended'),
        theme: getVisualizationSingleChoice(modal, 'theme', '[표준 기본]'),
        interactionLevel: getVisualizationSingleChoice(modal, 'interaction', 'balanced'),
        audienceMode: getVisualizationSingleChoice(modal, 'audience', 'learner'),
        complexityBias: getVisualizationSingleChoice(modal, 'complexity', 'balanced'),
        fallbackPolicy: getVisualizationSingleChoice(modal, 'fallback', 'prefer-stable'),
        densityMode: getVisualizationSingleChoice(modal, 'density', 'balanced'),
        motionMode: getVisualizationSingleChoice(modal, 'motion', 'guided'),
        addonPolicy: getVisualizationSingleChoice(modal, 'addon', 'auto'),
        presetKey: modal.querySelector('[data-role="preset"].active')?.dataset.preset || 'custom',
        educationalMode: modal.querySelector('#viz-educational-mode')?.classList.contains('active'),
        worldsimMode: modal.querySelector('#viz-worldsim-mode')?.classList.contains('active'),
        isSimulation: modal.querySelector('#viz-simulation-mode')?.classList.contains('active'),
        isSimpleMode: modal.querySelector('#viz-simple-mode')?.classList.contains('active'),
        includeAllDom,
        autoGenerateOnLoad: modal.querySelector('#viz-auto-generate-toggle')?.classList.contains('active'),
        highContrastMode: modal.querySelector('#viz-high-contrast-mode')?.classList.contains('active'),
        exportSafeMode: modal.querySelector('#viz-export-safe-mode')?.classList.contains('active'),
        rememberLastVisualizationForm: modal.querySelector('#viz-remember-form-toggle')?.classList.contains('active'),
        useAiRecommendedProfile: modal.querySelector('#viz-ai-recommend-toggle')?.classList.contains('active')
    });
}

function pushVisualizationRecommendationReason(reasons, message) {
    if (!message) return;
    if (!reasons.includes(message)) {
        reasons.push(message);
    }
}

function addVisualizationRecommendationScore(scoreBag, key, delta, reasons, message) {
    if (!scoreBag[key]) scoreBag[key] = 0;
    scoreBag[key] += delta;
    if (message) pushVisualizationRecommendationReason(reasons, message);
}

function pickVisualizationRecommendation(scoreBag, fallbackKey) {
    const entries = Object.entries(scoreBag || {});
    if (entries.length === 0) return fallbackKey;
    entries.sort((a, b) => b[1] - a[1]);
    return entries[0][0] || fallbackKey;
}

function buildVisualizationAiRecommendation(seedText, baseOptions = {}) {
    const text = ` ${(seedText || '').toLowerCase()} `;
    const reasons = [];
    const scores = {
        goal: {},
        family: {},
        renderer: {},
        interaction: {},
        audience: {},
        complexity: {},
        fallback: {},
        density: {},
        motion: {},
        addon: {},
        preset: {},
        theme: {}
    };

    const hit = (pattern) => pattern.test(text);
    const score = (bucket, key, value, reason) => addVisualizationRecommendationScore(scores[bucket], key, value, reasons, reason);

    if (hit(/지도|위치|지역|국가|도시|경로|노선|해역|위도|경도|지리|공간/)) {
        score('goal', 'map', 6, '지리·위치 관련 키워드가 있어 공간/지도형 구성이 적합합니다.');
        score('family', 'map', 7, null);
        score('renderer', 'map-engine', 6, null);
        score('interaction', 'guided', 3, null);
        score('preset', 'map-explainer', 5, null);
        score('theme', '[지리 브리프]', 5, null);
        score('addon', 'recommended', 3, null);
    }

    if (hit(/관계|연결|네트워크|노드|링크|상호작용|인과|구조도|계통|트리/)) {
        score('goal', 'relate', 6, '관계·연결 표현이 중요해 관계형 분석 구성을 우선합니다.');
        score('family', 'network', 7, null);
        score('renderer', 'graph-engine', 6, null);
        score('interaction', 'high', 3, null);
        score('preset', 'network-analyzer', 5, null);
        score('theme', '[과학 논문형]', 4, null);
        score('audience', 'analyst', 3, null);
        score('density', 'detailed', 3, null);
        score('addon', 'aggressive', 4, null);
    }

    if (hit(/과정|흐름|단계|순서|절차|사이클|작동|전환|변화 과정/)) {
        score('goal', 'explain', 3, '과정·흐름 키워드가 있어 단계형 설명 구성이 적합합니다.');
        score('family', 'flow', 7, null);
        score('renderer', 'hybrid-mixed', 4, null);
        score('motion', 'guided', 3, null);
        score('preset', 'process-monitor', 4, null);
        score('theme', '[운영 모니터]', 3, null);
        score('addon', 'recommended', 2, null);
    }

    if (hit(/연대|연도|역사|변천|추이|시간순|타임라인|발전 과정/)) {
        score('goal', 'explain', 2, '시간 순서가 핵심이라 타임라인 중심 정리를 우선합니다.');
        score('family', 'timeline', 7, null);
        score('renderer', 'svg-first', 4, null);
        score('motion', 'guided', 2, null);
    }

    if (hit(/시뮬레이션|모사|모형|유체|입자|궤도|물리|동역학|실험|실시간|반응형/)) {
        score('goal', 'simulate', 8, '동적 변화와 모사가 중요해 시뮬레이션 지향 구성을 추천합니다.');
        score('family', 'science', 5, null);
        score('renderer', 'canvas-first', 5, null);
        score('interaction', 'high', 4, null);
        score('motion', 'dynamic', 5, null);
        score('preset', 'interactive-lab', 5, null);
        score('theme', '[실험실 프로토타입]', 4, null);
        score('addon', 'recommended', 4, null);
    }

    if (hit(/장면|서사|스토리|여정|몰입|시네마|장면형|내러티브/)) {
        score('goal', 'story', 8, '서사·장면 키워드가 있어 장면형 시각화가 더 잘 맞습니다.');
        score('family', 'scene', 8, null);
        score('renderer', 'scene-3d', 6, null);
        score('motion', 'cinematic', 6, null);
        score('preset', 'story-scene', 6, null);
        score('theme', '[서사 장면형]', 6, null);
        score('addon', 'aggressive', 4, null);
    }

    if (hit(/지표|현황|대시보드|모니터링|보고서|브리프|요약|KPI|리포트/)) {
        score('goal', 'present', 7, '요약·현황 전달 성격이 강해 발표/브리프형 구성을 우선합니다.');
        score('family', 'dashboard', 7, null);
        score('renderer', 'interactive-chart', 5, null);
        score('preset', 'dashboard-brief', 5, null);
        score('theme', '[보고서형 대시보드]', 5, null);
        score('audience', 'presenter', 3, null);
        score('motion', 'guided', 2, null);
    }

    if (hit(/임원|경영진|의사결정|결정권자|한눈에|브리핑/)) {
        score('goal', 'present', 5, '의사결정 맥락이 보여 경영 브리프형 구성이 적합합니다.');
        score('family', 'dashboard', 4, null);
        score('renderer', 'dom-infographic', 5, null);
        score('preset', 'executive-brief', 7, null);
        score('theme', '[경영 브리프]', 7, null);
        score('audience', 'executive', 7, null);
        score('complexity', 'simple', 3, null);
        score('density', 'core', 4, null);
        score('motion', 'still', 4, null);
        score('fallback', 'prefer-static-safe', 4, null);
        score('addon', 'off', 4, null);
    }

    if (hit(/쉽게|초등|입문|기초|학습|교육|설명|한눈에|직관/)) {
        score('goal', 'explain', 5, '학습·설명 맥락이 강해서 설명형 구성을 강화합니다.');
        score('family', 'accessibility', 5, null);
        score('renderer', 'dom-infographic', 4, null);
        score('preset', 'accessibility-first', 5, null);
        score('theme', '[접근성 우선]', 5, null);
        score('audience', 'young-learner', 4, null);
        score('complexity', 'simple', 4, null);
        score('density', 'core', 4, null);
        score('motion', 'still', 3, null);
        score('fallback', 'prefer-static-safe', 3, null);
        score('addon', 'off', 4, null);
    }

    if (hit(/자세히|상세|정밀|깊게|심층|세부|정교/)) {
        score('complexity', 'detailed', 5, '세부 정보 요청이 있어 정보 밀도와 분석 깊이를 높입니다.');
        score('density', 'detailed', 5, null);
        score('audience', 'analyst', 2, null);
        score('addon', 'recommended', 2, null);
    }

    if (hit(/정적|인쇄|출력|내보내기|캡처|pdf/)) {
        score('fallback', 'prefer-static-safe', 5, '내보내기·정적 결과를 고려해 더 안전한 렌더 경로를 우선합니다.');
        score('motion', 'still', 4, null);
        score('addon', 'off', 3, null);
    }

    const defaults = normalizeVisualizationGenerationOptions(baseOptions);
    const recommendation = {
        ...defaults,
        goal: pickVisualizationRecommendation(scores.goal, defaults.goal || 'explain'),
        family: pickVisualizationRecommendation(scores.family, defaults.family || 'comparison'),
        rendererStrategy: pickVisualizationRecommendation(scores.renderer, defaults.rendererStrategy || 'ai-recommended'),
        interactionLevel: pickVisualizationRecommendation(scores.interaction, defaults.interactionLevel || 'balanced'),
        audienceMode: pickVisualizationRecommendation(scores.audience, defaults.audienceMode || 'learner'),
        complexityBias: pickVisualizationRecommendation(scores.complexity, defaults.complexityBias || 'balanced'),
        fallbackPolicy: pickVisualizationRecommendation(scores.fallback, defaults.fallbackPolicy || 'prefer-stable'),
        densityMode: pickVisualizationRecommendation(scores.density, defaults.densityMode || 'balanced'),
        motionMode: pickVisualizationRecommendation(scores.motion, defaults.motionMode || 'guided'),
        addonPolicy: pickVisualizationRecommendation(scores.addon, defaults.addonPolicy || 'auto'),
        presetKey: pickVisualizationRecommendation(scores.preset, defaults.presetKey || 'teach-clearly'),
        theme: pickVisualizationRecommendation(scores.theme, defaults.theme || '[표준 기본]'),
        useAiRecommendedProfile: true
    };

    if (recommendation.presetKey === 'story-scene') {
        recommendation.worldsimMode = true;
        recommendation.isSimulation = true;
        recommendation.exportSafeMode = false;
    }
    if (recommendation.presetKey === 'interactive-lab' || recommendation.goal === 'simulate') {
        recommendation.isSimulation = true;
    }
    if (recommendation.presetKey === 'accessibility-first' || recommendation.presetKey === 'teach-clearly') {
        recommendation.educationalMode = true;
        recommendation.highContrastMode = true;
        recommendation.exportSafeMode = true;
        recommendation.isSimpleMode = true;
    }
    if (recommendation.fallbackPolicy === 'prefer-static-safe') {
        recommendation.highContrastMode = true;
        recommendation.exportSafeMode = true;
        recommendation.motionMode = 'still';
        recommendation.addonPolicy = 'off';
    }

    switch (recommendation.rendererStrategy) {
        case 'map-engine':
            recommendation.libraries = [recommendation.complexityBias === 'detailed' ? 'MapLibre GL JS' : 'Leaflet.js'];
            break;
        case 'graph-engine':
            recommendation.libraries = [recommendation.family === 'network' ? 'Cytoscape.js' : 'Mermaid'];
            break;
        case 'interactive-chart':
            recommendation.libraries = [recommendation.goal === 'present' ? 'ECharts' : 'Plotly.js'];
            break;
        case 'svg-first':
            recommendation.libraries = ['Pure SVG'];
            break;
        case 'canvas-first':
            recommendation.libraries = [recommendation.goal === 'simulate' ? 'p5.js' : 'Konva.js'];
            break;
        case 'scene-3d':
            recommendation.libraries = ['Three.js'];
            break;
        case 'dom-infographic':
            recommendation.libraries = ['DOM Cards'];
            break;
        case 'table-matrix':
            recommendation.libraries = ['Grid.js'];
            break;
        default:
            recommendation.libraries = [];
            break;
    }

    if (reasons.length === 0) {
        reasons.push('명시적인 구조 키워드가 약해 기본 안정형 설명 구성을 적용했습니다.');
    }

    return {
        options: normalizeVisualizationGenerationOptions(recommendation),
        reasons
    };
}

function applyVisualizationAiRecommendation(modal, recommendation) {
    const options = recommendation.options;
    modal.__vizAiRecommendation = recommendation;
    setVisualizationSingleChoice(modal, 'goal', options.goal);
    setVisualizationSingleChoice(modal, 'family', options.family);
    setVisualizationSingleChoice(modal, 'renderer', options.rendererStrategy);
    setVisualizationSingleChoice(modal, 'interaction', options.interactionLevel);
    setVisualizationSingleChoice(modal, 'audience', options.audienceMode);
    setVisualizationSingleChoice(modal, 'complexity', options.complexityBias);
    setVisualizationSingleChoice(modal, 'fallback', options.fallbackPolicy);
    setVisualizationSingleChoice(modal, 'density', options.densityMode);
    setVisualizationSingleChoice(modal, 'motion', options.motionMode);
    setVisualizationSingleChoice(modal, 'addon', options.addonPolicy);
    setVisualizationSingleChoice(modal, 'theme', options.theme);
    setVisualizationSingleChoice(modal, 'preset', options.presetKey);
    setVisualizationLibrarySelection(modal, options.libraries);
    setVisualizationToggleState(modal, 'viz-educational-mode', options.educationalMode);
    setVisualizationToggleState(modal, 'viz-worldsim-mode', options.worldsimMode);
    setVisualizationToggleState(modal, 'viz-simulation-mode', options.isSimulation);
    setVisualizationToggleState(modal, 'viz-simple-mode', options.isSimpleMode);
    setVisualizationToggleState(modal, 'viz-high-contrast-mode', options.highContrastMode);
    setVisualizationToggleState(modal, 'viz-export-safe-mode', options.exportSafeMode);
}

function setVisualizationAiControlsDisabled(modal, isDisabled) {
    modal.classList.toggle('viz-ai-locked', !!isDisabled);
    const lockNote = modal.querySelector('#viz-ai-lock-note');
    if (lockNote) {
        lockNote.hidden = !isDisabled;
    }
    const aiToggle = modal.querySelector('#viz-ai-recommend-toggle');
    modal.querySelectorAll('[data-role], [data-library], #viz-behavior-options .option-btn').forEach((button) => {
        if (button === aiToggle) return;
        button.disabled = !!isDisabled;
    });
}

function refreshVisualizationAiRecommendation(modal, targetElement = null) {
    const aiToggle = modal.querySelector('#viz-ai-recommend-toggle');
    const aiActive = aiToggle?.classList.contains('active');
    setVisualizationAiControlsDisabled(modal, aiActive);

    if (!aiActive) {
        modal.__vizAiRecommendation = null;
        return;
    }

    const rawOptions = getVisualizationModalRawOptions(modal);
    const seedText = [targetElement?.dataset.prompt || '', rawOptions.description || ''].filter(Boolean).join('\n\n');
    const recommendation = buildVisualizationAiRecommendation(seedText, rawOptions);
    applyVisualizationAiRecommendation(modal, recommendation);
}

function collectVisualizationOptionsFromModal(modal) {
    const aiToggle = modal.querySelector('#viz-ai-recommend-toggle');
    if (aiToggle?.classList.contains('active')) {
        if (!modal.__vizAiRecommendation) {
            refreshVisualizationAiRecommendation(modal, modal.__vizAiTargetElement || null);
        }
        return normalizeVisualizationGenerationOptions({
            ...(modal.__vizAiRecommendation?.options || getVisualizationModalRawOptions(modal)),
            useAiRecommendedProfile: true
        });
    }

    return getVisualizationModalRawOptions(modal);
}

function renderVisualizationSelectionSummary(modal) {
    const summaryNode = modal.querySelector('#viz-selection-summary');
    if (!summaryNode) return;

    const options = collectVisualizationOptionsFromModal(modal);
    const selectedLibraries = options.libraries.length > 0 ? options.libraries.join(', ') : 'AI 추천';
    const safetyBadges = [];

    if (options.highContrastMode) safetyBadges.push('고대비');
    if (options.exportSafeMode) safetyBadges.push('내보내기 안전');
    if (options.isSimpleMode) safetyBadges.push('단순 모드');
    if (options.isSimulation) safetyBadges.push('시뮬레이션');
    if (options.educationalMode) safetyBadges.push('교육형');
    if (options.worldsimMode) safetyBadges.push('몰입형');
    if (options.useAiRecommendedProfile) safetyBadges.push('AI 추천');

    const safetyText = safetyBadges.length > 0 ? safetyBadges.join(' · ') : '기본';
    const requestPreview = options.description
        ? options.description.slice(0, 160)
        : '추가 요청이 없으면 현재 문맥과 사용자가 입력한 본문을 기준으로 생성합니다.';
    const aiReasons = options.useAiRecommendedProfile ? (modal.__vizAiRecommendation?.reasons || []) : [];

    summaryNode.innerHTML = `
        <div class="viz-summary-list">
            <div class="viz-summary-item">
                <strong>목표</strong>
                <span>${getVisualizationLabel('goals', options.goal)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>계열</strong>
                <span>${getVisualizationLabel('families', options.family)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>렌더 방식</strong>
                <span>${getVisualizationLabel('renderers', options.rendererStrategy)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>대상 독자</strong>
                <span>${getVisualizationLabel('audiences', options.audienceMode)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>정보 밀도</strong>
                <span>${getVisualizationLabel('densities', options.densityMode)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>움직임</strong>
                <span>${getVisualizationLabel('motions', options.motionMode)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>프리셋</strong>
                <span>${getVisualizationLabel('presets', options.presetKey)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>라이브러리</strong>
                <span>${selectedLibraries}</span>
            </div>
            <div class="viz-summary-item">
                <strong>안전/행동</strong>
                <span>${safetyText}</span>
            </div>
        </div>
        <div class="viz-review-note">
            ${getVisualizationLabel('interactions', options.interactionLevel)} / ${getVisualizationLabel('complexities', options.complexityBias)} / ${getVisualizationLabel('fallbacks', options.fallbackPolicy)} 조합으로 생성합니다.
            <br>
            테마: ${options.theme}
            <br>
            요청 미리보기: ${escapeVisualizationSummaryHtml(requestPreview)}
            ${aiReasons.length > 0 ? `<br><br><strong>AI 추천 기준:</strong> ${escapeVisualizationSummaryHtml(aiReasons.join(' / '))}` : ''}
        </div>
    `;
}

function openVisualizationOptionsModal(prefilledOptions, onConfirm, targetElement = null) {
    if (!visualizationOptionsModalOverlay) return;

    const modal = visualizationOptionsModalOverlay;
    modal.__vizAiTargetElement = targetElement || null;
    const mergedOptions = normalizeVisualizationGenerationOptions({
        ...getVisualizationFormDefaults(),
        ...(prefilledOptions || {}),
        description: typeof prefilledOptions?.description === 'string' ? prefilledOptions.description : ''
    });

    const vizOptionsTextarea = modal.querySelector('#viz-options-textarea');
    const vizOptionsCancelBtn = modal.querySelector('#viz-options-cancel-btn');
    const vizOptionsGenerateBtn = modal.querySelector('#viz-options-generate-btn');
    const batchSizeInput = modal.querySelector('#viz-batch-size-input');
    const addPresetPromptBtn = modal.querySelector('#viz-add-preset-prompt');
    const aiRecommendToggle = modal.querySelector('#viz-ai-recommend-toggle');
    const toggleButtons = [
        'viz-educational-mode',
        'viz-worldsim-mode',
        'viz-simulation-mode',
        'viz-simple-mode',
        'viz-high-contrast-mode',
        'viz-export-safe-mode',
        'viz-include-all-dom',
        'viz-auto-generate-toggle',
        'viz-remember-form-toggle'
    ];

    let handleModalClick;
    let handleTextareaInput;
    let handlePresetPrompt;

    if (vizOptionsTextarea) {
        vizOptionsTextarea.value = mergedOptions.description || '';
        vizOptionsTextarea.readOnly = false;
    }

    if (batchSizeInput) {
        batchSizeInput.value = String(ENFORCED_VISUALIZATION_BATCH_SIZE);
        batchSizeInput.min = String(ENFORCED_VISUALIZATION_BATCH_SIZE);
        batchSizeInput.max = String(ENFORCED_VISUALIZATION_BATCH_SIZE);
        batchSizeInput.readOnly = true;
        batchSizeInput.disabled = true;
    }

    setVisualizationSingleChoice(modal, 'goal', mergedOptions.goal);
    setVisualizationSingleChoice(modal, 'family', mergedOptions.family);
    setVisualizationSingleChoice(modal, 'renderer', mergedOptions.rendererStrategy);
    setVisualizationSingleChoice(modal, 'interaction', mergedOptions.interactionLevel);
    setVisualizationSingleChoice(modal, 'audience', mergedOptions.audienceMode);
    setVisualizationSingleChoice(modal, 'complexity', mergedOptions.complexityBias);
    setVisualizationSingleChoice(modal, 'fallback', mergedOptions.fallbackPolicy);
    setVisualizationSingleChoice(modal, 'density', mergedOptions.densityMode);
    setVisualizationSingleChoice(modal, 'motion', mergedOptions.motionMode);
    setVisualizationSingleChoice(modal, 'theme', mergedOptions.theme);
    setVisualizationSingleChoice(modal, 'preset', mergedOptions.presetKey);
    setVisualizationLibrarySelection(modal, mergedOptions.libraries);
    setVisualizationToggleState(modal, 'viz-educational-mode', mergedOptions.educationalMode);
    setVisualizationToggleState(modal, 'viz-worldsim-mode', mergedOptions.worldsimMode);
    setVisualizationToggleState(modal, 'viz-simulation-mode', mergedOptions.isSimulation);
    setVisualizationToggleState(modal, 'viz-simple-mode', mergedOptions.isSimpleMode);
    setVisualizationToggleState(modal, 'viz-high-contrast-mode', mergedOptions.highContrastMode);
    setVisualizationToggleState(modal, 'viz-export-safe-mode', mergedOptions.exportSafeMode);
    setVisualizationToggleState(modal, 'viz-include-all-dom', mergedOptions.includeAllDom);
    setVisualizationToggleState(modal, 'viz-auto-generate-toggle', mergedOptions.autoGenerateOnLoad);
    setVisualizationToggleState(modal, 'viz-remember-form-toggle', mergedOptions.rememberLastVisualizationForm);
    aiRecommendToggle?.classList.toggle('active', !!mergedOptions.useAiRecommendedProfile);

    if (!mergedOptions.presetKey || !(VISUALIZATION_PRESET_CONFIG_V2[mergedOptions.presetKey] || VISUALIZATION_PRESET_CONFIG[mergedOptions.presetKey])) {
        clearVisualizationPresetSelection(modal);
    }

    if (addPresetPromptBtn) {
        const hasPresetPrompt = targetElement?.dataset.prompt?.trim();
        addPresetPromptBtn.style.display = hasPresetPrompt ? 'inline-flex' : 'none';
        handlePresetPrompt = () => {
            const presetPrompt = targetElement?.dataset.prompt?.trim();
            if (!presetPrompt || !vizOptionsTextarea) return;

            const marker = '[영역 프롬프트]';
            if (vizOptionsTextarea.value.includes(marker)) {
                showToastNotification('영역 프롬프트가 이미 추가되어 있습니다.', '', `viz-preset-prompt-${Date.now()}`);
                return;
            }

            vizOptionsTextarea.value = `${marker}\n${presetPrompt}\n\n${vizOptionsTextarea.value}`.trim();
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            vizOptionsTextarea.focus();
            showToastNotification('영역 프롬프트를 세부 요청에 추가했습니다.', '', `viz-preset-prompt-added-${Date.now()}`);
        };
        addPresetPromptBtn.addEventListener('click', handlePresetPrompt);
    }

    handleTextareaInput = () => {
        refreshVisualizationAiRecommendation(modal, targetElement);
        renderVisualizationSelectionSummary(modal);
    };
    vizOptionsTextarea?.addEventListener('input', handleTextareaInput);

    handleModalClick = (event) => {
        const aiButton = event.target.closest('#viz-ai-recommend-toggle');
        if (aiButton) {
            aiButton.classList.toggle('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            return;
        }

        const presetButton = event.target.closest('[data-role="preset"]');
        if (presetButton) {
            applyVisualizationPresetToModal(modal, presetButton.dataset.preset);
            aiRecommendToggle?.classList.remove('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            return;
        }

        const choiceButton = event.target.closest('[data-role]');
        if (choiceButton) {
            const role = choiceButton.dataset.role;
            setVisualizationSingleChoice(modal, role, choiceButton.dataset[role]);
            if (role !== 'preset') {
                clearVisualizationPresetSelection(modal);
            }
            aiRecommendToggle?.classList.remove('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            return;
        }

        const libraryButton = event.target.closest('[data-library]');
        if (libraryButton) {
            libraryButton.classList.toggle('active');
            clearVisualizationPresetSelection(modal);
            aiRecommendToggle?.classList.remove('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            return;
        }

        const toggleButton = event.target.closest('.option-btn[id]');
        if (toggleButton && toggleButtons.includes(toggleButton.id)) {
            toggleButton.classList.toggle('active');
            clearVisualizationPresetSelection(modal);
            aiRecommendToggle?.classList.remove('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
        }
    };
    modal.addEventListener('click', handleModalClick);

    refreshVisualizationAiRecommendation(modal, targetElement);
    renderVisualizationSelectionSummary(modal);

    const close = () => {
        modal.style.display = 'none';
        modal.removeEventListener('click', handleModalClick);
        vizOptionsTextarea?.removeEventListener('input', handleTextareaInput);
        if (addPresetPromptBtn && handlePresetPrompt) {
            addPresetPromptBtn.removeEventListener('click', handlePresetPrompt);
        }
        vizOptionsGenerateBtn.onclick = null;
        vizOptionsCancelBtn.onclick = null;
        modal.__vizAiRecommendation = null;
        modal.__vizAiTargetElement = null;
    };

    vizOptionsCancelBtn.onclick = close;
    vizOptionsGenerateBtn.textContent = targetElement ? '재생성하기' : '생성하기';
    vizOptionsGenerateBtn.onclick = () => {
        const collectedOptions = aiRecommendToggle?.classList.contains('active')
            ? normalizeVisualizationGenerationOptions({
                ...(modal.__vizAiRecommendation?.options || getVisualizationModalRawOptions(modal)),
                useAiRecommendedProfile: true
            })
            : collectVisualizationOptionsFromModal(modal);
        persistVisualizationFormPreferences(collectedOptions);
        onConfirm(collectedOptions);
        close();
    };

    highestZIndex++;
    modal.style.zIndex = highestZIndex;
    modal.style.display = 'flex';
}

function collectVisualizationOptionsFromModal(modal) {
    const vizOptionsTextarea = modal.querySelector('#viz-options-textarea');
    const includeAllDom = modal.querySelector('#viz-include-all-dom')?.classList.contains('active');
    let description = vizOptionsTextarea?.value?.trim?.() || '';

    if (includeAllDom && typeof extractContextFromDOM === 'function') {
        const domContent = extractContextFromDOM('learning-content');
        if (domContent) {
            const contextBlock = `[현재 장면 전체 내용]\n${domContent}`;
            description = description ? `${description}\n\n---\n\n${contextBlock}` : contextBlock;
        }
    }

    return normalizeVisualizationGenerationOptions({
        libraries: Array.from(modal.querySelectorAll('[data-library].active')).map((button) => button.dataset.library),
        description,
        goal: getVisualizationSingleChoice(modal, 'goal', 'explain'),
        family: getVisualizationSingleChoice(modal, 'family', 'comparison'),
        rendererStrategy: getVisualizationSingleChoice(modal, 'renderer', 'ai-recommended'),
        theme: getVisualizationSingleChoice(modal, 'theme', '[표준 기본]'),
        interactionLevel: getVisualizationSingleChoice(modal, 'interaction', 'balanced'),
        audienceMode: getVisualizationSingleChoice(modal, 'audience', 'learner'),
        complexityBias: getVisualizationSingleChoice(modal, 'complexity', 'balanced'),
        fallbackPolicy: getVisualizationSingleChoice(modal, 'fallback', 'prefer-stable'),
        densityMode: getVisualizationSingleChoice(modal, 'density', 'balanced'),
        motionMode: getVisualizationSingleChoice(modal, 'motion', 'guided'),
        addonPolicy: getVisualizationSingleChoice(modal, 'addon', 'auto'),
        presetKey: modal.querySelector('[data-role="preset"].active')?.dataset.preset || 'custom',
        educationalMode: modal.querySelector('#viz-educational-mode')?.classList.contains('active'),
        worldsimMode: modal.querySelector('#viz-worldsim-mode')?.classList.contains('active'),
        isSimulation: modal.querySelector('#viz-simulation-mode')?.classList.contains('active'),
        isSimpleMode: modal.querySelector('#viz-simple-mode')?.classList.contains('active'),
        includeAllDom,
        autoGenerateOnLoad: modal.querySelector('#viz-auto-generate-toggle')?.classList.contains('active'),
        highContrastMode: modal.querySelector('#viz-high-contrast-mode')?.classList.contains('active'),
        exportSafeMode: modal.querySelector('#viz-export-safe-mode')?.classList.contains('active'),
        rememberLastVisualizationForm: modal.querySelector('#viz-remember-form-toggle')?.classList.contains('active')
    });
}

function renderVisualizationSelectionSummary(modal) {
    const summaryNode = modal.querySelector('#viz-selection-summary');
    if (!summaryNode) return;

    const options = collectVisualizationOptionsFromModal(modal);
    const selectedLibraries = options.libraries.length > 0 ? options.libraries.join(', ') : 'AI 추천';
    const safetyBadges = [];

    if (options.highContrastMode) safetyBadges.push('고대비');
    if (options.exportSafeMode) safetyBadges.push('내보내기 안전');
    if (options.isSimpleMode) safetyBadges.push('단순 모드');
    if (options.isSimulation) safetyBadges.push('시뮬레이션');
    if (options.educationalMode) safetyBadges.push('교육형');
    if (options.worldsimMode) safetyBadges.push('몰입형');

    const safetyText = safetyBadges.length > 0 ? safetyBadges.join(' · ') : '기본';
    const requestPreview = options.description
        ? options.description.slice(0, 160)
        : '추가 요청이 없으면 현재 문맥과 사용자가 입력한 본문을 기준으로 생성합니다.';

    summaryNode.innerHTML = `
        <div class="viz-summary-list">
            <div class="viz-summary-item">
                <strong>목표</strong>
                <span>${getVisualizationLabel('goals', options.goal)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>계열</strong>
                <span>${getVisualizationLabel('families', options.family)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>렌더 방식</strong>
                <span>${getVisualizationLabel('renderers', options.rendererStrategy)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>대상 독자</strong>
                <span>${getVisualizationLabel('audiences', options.audienceMode)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>정보 밀도</strong>
                <span>${getVisualizationLabel('densities', options.densityMode)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>움직임</strong>
                <span>${getVisualizationLabel('motions', options.motionMode)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>프리셋</strong>
                <span>${getVisualizationLabel('presets', options.presetKey)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>라이브러리</strong>
                <span>${selectedLibraries}</span>
            </div>
            <div class="viz-summary-item">
                <strong>안전/행동</strong>
                <span>${safetyText}</span>
            </div>
        </div>
        <div class="viz-review-note">
            ${getVisualizationLabel('interactions', options.interactionLevel)} / ${getVisualizationLabel('complexities', options.complexityBias)} / ${getVisualizationLabel('fallbacks', options.fallbackPolicy)} 조합으로 생성합니다.
            <br>
            테마: ${options.theme}
            <br>
            요청 미리보기: ${escapeVisualizationSummaryHtml(requestPreview)}
        </div>
    `;
}

function openVisualizationOptionsModal(prefilledOptions, onConfirm, targetElement = null) {
    if (!visualizationOptionsModalOverlay) return;

    const modal = visualizationOptionsModalOverlay;
    modal.__vizAiTargetElement = targetElement || null;
    const mergedOptions = normalizeVisualizationGenerationOptions({
        ...getVisualizationFormDefaults(),
        ...(prefilledOptions || {}),
        description: typeof prefilledOptions?.description === 'string' ? prefilledOptions.description : ''
    });

    const vizOptionsTextarea = modal.querySelector('#viz-options-textarea');
    const vizOptionsCancelBtn = modal.querySelector('#viz-options-cancel-btn');
    const vizOptionsGenerateBtn = modal.querySelector('#viz-options-generate-btn');
    const batchSizeInput = modal.querySelector('#viz-batch-size-input');
    const addPresetPromptBtn = modal.querySelector('#viz-add-preset-prompt');
    const toggleButtons = [
        'viz-educational-mode',
        'viz-worldsim-mode',
        'viz-simulation-mode',
        'viz-simple-mode',
        'viz-high-contrast-mode',
        'viz-export-safe-mode',
        'viz-include-all-dom',
        'viz-auto-generate-toggle',
        'viz-remember-form-toggle'
    ];

    let handleModalClick;
    let handleTextareaInput;
    let handlePresetPrompt;

    if (vizOptionsTextarea) {
        vizOptionsTextarea.value = mergedOptions.description || '';
        vizOptionsTextarea.readOnly = false;
    }

    if (batchSizeInput) {
        batchSizeInput.value = String(ENFORCED_VISUALIZATION_BATCH_SIZE);
        batchSizeInput.min = String(ENFORCED_VISUALIZATION_BATCH_SIZE);
        batchSizeInput.max = String(ENFORCED_VISUALIZATION_BATCH_SIZE);
        batchSizeInput.readOnly = true;
        batchSizeInput.disabled = true;
    }

    setVisualizationSingleChoice(modal, 'goal', mergedOptions.goal);
    setVisualizationSingleChoice(modal, 'family', mergedOptions.family);
    setVisualizationSingleChoice(modal, 'renderer', mergedOptions.rendererStrategy);
    setVisualizationSingleChoice(modal, 'interaction', mergedOptions.interactionLevel);
    setVisualizationSingleChoice(modal, 'audience', mergedOptions.audienceMode);
    setVisualizationSingleChoice(modal, 'complexity', mergedOptions.complexityBias);
    setVisualizationSingleChoice(modal, 'fallback', mergedOptions.fallbackPolicy);
    setVisualizationSingleChoice(modal, 'density', mergedOptions.densityMode);
    setVisualizationSingleChoice(modal, 'motion', mergedOptions.motionMode);
    setVisualizationSingleChoice(modal, 'addon', mergedOptions.addonPolicy);
    setVisualizationSingleChoice(modal, 'theme', mergedOptions.theme);
    setVisualizationSingleChoice(modal, 'preset', mergedOptions.presetKey);
    setVisualizationLibrarySelection(modal, mergedOptions.libraries);
    setVisualizationToggleState(modal, 'viz-educational-mode', mergedOptions.educationalMode);
    setVisualizationToggleState(modal, 'viz-worldsim-mode', mergedOptions.worldsimMode);
    setVisualizationToggleState(modal, 'viz-simulation-mode', mergedOptions.isSimulation);
    setVisualizationToggleState(modal, 'viz-simple-mode', mergedOptions.isSimpleMode);
    setVisualizationToggleState(modal, 'viz-high-contrast-mode', mergedOptions.highContrastMode);
    setVisualizationToggleState(modal, 'viz-export-safe-mode', mergedOptions.exportSafeMode);
    setVisualizationToggleState(modal, 'viz-include-all-dom', mergedOptions.includeAllDom);
    setVisualizationToggleState(modal, 'viz-auto-generate-toggle', mergedOptions.autoGenerateOnLoad);
    setVisualizationToggleState(modal, 'viz-remember-form-toggle', mergedOptions.rememberLastVisualizationForm);

    if (!mergedOptions.presetKey || !(VISUALIZATION_PRESET_CONFIG_V2[mergedOptions.presetKey] || VISUALIZATION_PRESET_CONFIG[mergedOptions.presetKey])) {
        clearVisualizationPresetSelection(modal);
    }

    if (addPresetPromptBtn) {
        const hasPresetPrompt = targetElement?.dataset.prompt?.trim();
        addPresetPromptBtn.style.display = hasPresetPrompt ? 'inline-flex' : 'none';
        handlePresetPrompt = () => {
            const presetPrompt = targetElement?.dataset.prompt?.trim();
            if (!presetPrompt || !vizOptionsTextarea) return;

            const marker = '[영역 프롬프트]';
            if (vizOptionsTextarea.value.includes(marker)) {
                showToastNotification('영역 프롬프트가 이미 추가되어 있습니다.', '', `viz-preset-prompt-${Date.now()}`);
                return;
            }

            vizOptionsTextarea.value = `${marker}\n${presetPrompt}\n\n${vizOptionsTextarea.value}`.trim();
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            vizOptionsTextarea.focus();
            showToastNotification('영역 프롬프트를 세부 요청에 추가했습니다.', '', `viz-preset-prompt-added-${Date.now()}`);
        };
        addPresetPromptBtn.addEventListener('click', handlePresetPrompt);
    }

    handleTextareaInput = () => {
        refreshVisualizationAiRecommendation(modal, targetElement);
        renderVisualizationSelectionSummary(modal);
    };
    vizOptionsTextarea?.addEventListener('input', handleTextareaInput);

    handleModalClick = (event) => {
        const aiButton = event.target.closest('#viz-ai-recommend-toggle');
        if (aiButton) {
            aiButton.classList.toggle('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            return;
        }

        const presetButton = event.target.closest('[data-role="preset"]');
        if (presetButton) {
            applyVisualizationPresetToModal(modal, presetButton.dataset.preset);
            aiRecommendToggle?.classList.remove('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            return;
        }

        const choiceButton = event.target.closest('[data-role]');
        if (choiceButton) {
            const role = choiceButton.dataset.role;
            setVisualizationSingleChoice(modal, role, choiceButton.dataset[role]);
            if (role !== 'preset') {
                clearVisualizationPresetSelection(modal);
            }
            aiRecommendToggle?.classList.remove('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            return;
        }

        const libraryButton = event.target.closest('[data-library]');
        if (libraryButton) {
            libraryButton.classList.toggle('active');
            clearVisualizationPresetSelection(modal);
            aiRecommendToggle?.classList.remove('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            return;
        }

        const toggleButton = event.target.closest('.option-btn[id]');
        if (toggleButton && toggleButtons.includes(toggleButton.id)) {
            toggleButton.classList.toggle('active');
            clearVisualizationPresetSelection(modal);
            aiRecommendToggle?.classList.remove('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
        }
    };
    modal.addEventListener('click', handleModalClick);

    refreshVisualizationAiRecommendation(modal, targetElement);
    renderVisualizationSelectionSummary(modal);

    const close = () => {
        modal.style.display = 'none';
        modal.removeEventListener('click', handleModalClick);
        vizOptionsTextarea?.removeEventListener('input', handleTextareaInput);
        if (addPresetPromptBtn && handlePresetPrompt) {
            addPresetPromptBtn.removeEventListener('click', handlePresetPrompt);
        }
        vizOptionsGenerateBtn.onclick = null;
        vizOptionsCancelBtn.onclick = null;
    };

    vizOptionsCancelBtn.onclick = close;
    vizOptionsGenerateBtn.textContent = targetElement ? '재생성하기' : '생성하기';
    vizOptionsGenerateBtn.onclick = () => {
        const collectedOptions = aiRecommendToggle?.classList.contains('active')
            ? normalizeVisualizationGenerationOptions({
                ...(modal.__vizAiRecommendation?.options || getVisualizationModalRawOptions(modal)),
                useAiRecommendedProfile: true
            })
            : collectVisualizationOptionsFromModal(modal);
        persistVisualizationFormPreferences(collectedOptions);
        onConfirm(collectedOptions);
        close();
    };

    highestZIndex++;
    modal.style.zIndex = highestZIndex;
    modal.style.display = 'flex';
}

function clearVisualizationPresetSelection(modal) {
    modal.querySelectorAll('[data-role="preset"]').forEach((button) => button.classList.remove('active'));
}

function setVisualizationSingleChoice(modal, role, value) {
    const buttons = modal.querySelectorAll(`[data-role="${role}"]`);
    let matched = false;
    buttons.forEach((button) => {
        const isMatch = button.dataset[role] === value;
        button.classList.toggle('active', isMatch);
        if (isMatch) matched = true;
    });
    if (!matched && buttons[0]) {
        buttons[0].classList.add('active');
    }
}

function getVisualizationSingleChoice(modal, role, fallbackValue) {
    return modal.querySelector(`[data-role="${role}"].active`)?.dataset[role] || fallbackValue;
}

function setVisualizationToggleState(modal, id, isActive) {
    const button = modal.querySelector(`#${id}`);
    if (button) {
        button.classList.toggle('active', !!isActive);
    }
}

function setVisualizationLibrarySelection(modal, libraries) {
    const selectedLibraries = sanitizeVisualizationLibraries(libraries);
    modal.querySelectorAll('[data-library]').forEach((button) => {
        button.classList.toggle('active', selectedLibraries.includes(button.dataset.library));
    });
}

function applyVisualizationPresetToModal(modal, presetKey) {
    const preset = VISUALIZATION_PRESET_CONFIG_V2[presetKey] || VISUALIZATION_PRESET_CONFIG[presetKey];
    if (!preset) return;

    setVisualizationSingleChoice(modal, 'preset', presetKey);
    setVisualizationSingleChoice(modal, 'goal', preset.goal);
    setVisualizationSingleChoice(modal, 'family', preset.family);
    setVisualizationSingleChoice(modal, 'renderer', preset.rendererStrategy);
    setVisualizationSingleChoice(modal, 'interaction', preset.interactionLevel);
    setVisualizationSingleChoice(modal, 'audience', preset.audienceMode || 'general');
    setVisualizationSingleChoice(modal, 'complexity', preset.complexityBias);
    setVisualizationSingleChoice(modal, 'fallback', preset.fallbackPolicy);
    setVisualizationSingleChoice(modal, 'density', preset.densityMode || 'balanced');
    setVisualizationSingleChoice(modal, 'motion', preset.motionMode || 'guided');
    setVisualizationSingleChoice(modal, 'addon', preset.addonPolicy || 'auto');
    setVisualizationSingleChoice(modal, 'theme', preset.theme);
    setVisualizationToggleState(modal, 'viz-educational-mode', preset.educationalMode);
    setVisualizationToggleState(modal, 'viz-worldsim-mode', preset.worldsimMode);
    setVisualizationToggleState(modal, 'viz-simulation-mode', preset.isSimulation);
    setVisualizationToggleState(modal, 'viz-simple-mode', preset.isSimpleMode);
    setVisualizationToggleState(modal, 'viz-high-contrast-mode', preset.highContrastMode);
    setVisualizationToggleState(modal, 'viz-export-safe-mode', preset.exportSafeMode);
}

function collectVisualizationOptionsFromModal(modal) {
    const vizOptionsTextarea = modal.querySelector('#viz-options-textarea');
    const includeAllDom = modal.querySelector('#viz-include-all-dom')?.classList.contains('active');
    let description = vizOptionsTextarea?.value?.trim?.() || '';

    if (includeAllDom && typeof extractContextFromDOM === 'function') {
        const domContent = extractContextFromDOM('learning-content');
        if (domContent) {
            const contextBlock = `[현재 장면 전체 내용]\n${domContent}`;
            description = description ? `${description}\n\n---\n\n${contextBlock}` : contextBlock;
        }
    }

    return normalizeVisualizationGenerationOptions({
        libraries: Array.from(modal.querySelectorAll('[data-library].active')).map((button) => button.dataset.library),
        description,
        goal: getVisualizationSingleChoice(modal, 'goal', 'explain'),
        family: getVisualizationSingleChoice(modal, 'family', 'comparison'),
        rendererStrategy: getVisualizationSingleChoice(modal, 'renderer', 'ai-recommended'),
        theme: getVisualizationSingleChoice(modal, 'theme', '[표준 기본]'),
        interactionLevel: getVisualizationSingleChoice(modal, 'interaction', 'balanced'),
        audienceMode: getVisualizationSingleChoice(modal, 'audience', 'learner'),
        complexityBias: getVisualizationSingleChoice(modal, 'complexity', 'balanced'),
        fallbackPolicy: getVisualizationSingleChoice(modal, 'fallback', 'prefer-stable'),
        densityMode: getVisualizationSingleChoice(modal, 'density', 'balanced'),
        motionMode: getVisualizationSingleChoice(modal, 'motion', 'guided'),
        presetKey: modal.querySelector('[data-role="preset"].active')?.dataset.preset || 'custom',
        educationalMode: modal.querySelector('#viz-educational-mode')?.classList.contains('active'),
        worldsimMode: modal.querySelector('#viz-worldsim-mode')?.classList.contains('active'),
        isSimulation: modal.querySelector('#viz-simulation-mode')?.classList.contains('active'),
        isSimpleMode: modal.querySelector('#viz-simple-mode')?.classList.contains('active'),
        includeAllDom,
        autoGenerateOnLoad: modal.querySelector('#viz-auto-generate-toggle')?.classList.contains('active'),
        highContrastMode: modal.querySelector('#viz-high-contrast-mode')?.classList.contains('active'),
        exportSafeMode: modal.querySelector('#viz-export-safe-mode')?.classList.contains('active'),
        rememberLastVisualizationForm: modal.querySelector('#viz-remember-form-toggle')?.classList.contains('active')
    });
}

function renderVisualizationSelectionSummary(modal) {
    const summaryNode = modal.querySelector('#viz-selection-summary');
    if (!summaryNode) return;

    const options = collectVisualizationOptionsFromModal(modal);
    const selectedLibraries = options.libraries.length > 0 ? options.libraries.join(', ') : '자동 추천';
    const safetyBadges = [];

    if (options.highContrastMode) safetyBadges.push('고대비');
    if (options.exportSafeMode) safetyBadges.push('내보내기 안전');
    if (options.isSimpleMode) safetyBadges.push('단순 모드');
    if (options.isSimulation) safetyBadges.push('시뮬레이션');
    if (options.educationalMode) safetyBadges.push('교육형');
    if (options.worldsimMode) safetyBadges.push('세계관형');
    if (options.useAiRecommendedProfile) safetyBadges.push('AI 추천');

    const safetyText = safetyBadges.length > 0 ? safetyBadges.join(' · ') : '기본';
    const requestPreview = options.description
        ? options.description.slice(0, 160)
        : '자유 서술 요청이 없으면 현재 장면 맥락이나 사용자가 입력한 본문을 기준으로 생성합니다.';
    const aiReasons = options.useAiRecommendedProfile ? (modal.__vizAiRecommendation?.reasons || []) : [];
    const sourceLabel = options.useAiRecommendedProfile ? 'AI 추천 구성' : '직접 조정 구성';

    summaryNode.innerHTML = `
        <div class="viz-summary-list">
            <div class="viz-summary-item">
                <strong>구성 출처</strong>
                <span>${sourceLabel}</span>
            </div>
            <div class="viz-summary-item">
                <strong>목표</strong>
                <span>${getVisualizationLabel('goals', options.goal)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>계열</strong>
                <span>${getVisualizationLabel('families', options.family)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>렌더링 전략</strong>
                <span>${getVisualizationLabel('renderers', options.rendererStrategy)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>프리셋</strong>
                <span>${getVisualizationLabel('presets', options.presetKey)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>확장 기능</strong>
                <span>${getVisualizationLabel('addons', options.addonPolicy)}</span>
            </div>
            <div class="viz-summary-item">
                <strong>세부 라이브러리</strong>
                <span>${selectedLibraries}</span>
            </div>
            <div class="viz-summary-item">
                <strong>안전성·동작</strong>
                <span>${safetyText}</span>
            </div>
        </div>
        <div class="viz-review-note">
            ${getVisualizationLabel('interactions', options.interactionLevel)} / ${getVisualizationLabel('complexities', options.complexityBias)} / ${getVisualizationLabel('fallbacks', options.fallbackPolicy)} 조합으로 생성됩니다.
            <br>
            테마: ${options.theme}
            <br>
            요청 미리보기: ${escapeVisualizationSummaryHtml(requestPreview)}
            ${aiReasons.length > 0 ? `<br>AI 추천 기준: ${escapeVisualizationSummaryHtml(aiReasons.slice(0, 3).join(' / '))}` : ''}
        </div>
    `;
}

async function handleModifyVisualization(originalBlockData, elementToReplace) {
    if (!originalBlockData || !elementToReplace) return;

    const prefilledOptions = buildVisualizationPrefillFromBlockData(originalBlockData, elementToReplace);

    openVisualizationOptionsModal(prefilledOptions, (newOptions) => {
        _generateAndPlaceVisualization(newOptions, elementToReplace, true, prefilledOptions.noteId || null);
    }, elementToReplace);
}

function openVisualizationOptionsModal(prefilledOptions, onConfirm, targetElement = null) {
    if (!visualizationOptionsModalOverlay) return;

    const modal = visualizationOptionsModalOverlay;
    const mergedOptions = normalizeVisualizationGenerationOptions({
        ...getVisualizationFormDefaults(),
        ...(prefilledOptions || {}),
        useAiRecommendedProfile: false,
        description: typeof prefilledOptions?.description === 'string' ? prefilledOptions.description : ''
    });

    const vizOptionsTextarea = modal.querySelector('#viz-options-textarea');
    const vizOptionsCancelBtn = modal.querySelector('#viz-options-cancel-btn');
    const vizOptionsGenerateBtn = modal.querySelector('#viz-options-generate-btn');
    const batchSizeInput = modal.querySelector('#viz-batch-size-input');
    const addPresetPromptBtn = modal.querySelector('#viz-add-preset-prompt');
    const aiRecommendToggle = modal.querySelector('#viz-ai-recommend-toggle');
    const vizStudioSidebar = modal.querySelector('.viz-studio-sidebar');
    const vizStudioScroll = modal.querySelector('.viz-studio-scroll');
    const choiceButtons = modal.querySelectorAll('[data-role]');
    const libraryButtons = modal.querySelectorAll('[data-library]');
    const toggleButtons = [
        'viz-educational-mode',
        'viz-worldsim-mode',
        'viz-simulation-mode',
        'viz-simple-mode',
        'viz-high-contrast-mode',
        'viz-export-safe-mode',
        'viz-include-all-dom',
        'viz-auto-generate-toggle',
        'viz-remember-form-toggle'
    ];

    let handleModalClick;
    let handleTextareaInput;
    let handlePresetPrompt;

    const resetVisualizationStudioViewport = () => {
        if (vizStudioSidebar) {
            vizStudioSidebar.scrollTop = 0;
            vizStudioSidebar.scrollLeft = 0;
        }
        if (vizStudioScroll) {
            vizStudioScroll.scrollTop = 0;
            vizStudioScroll.scrollLeft = 0;
        }
        if (vizOptionsTextarea) {
            vizOptionsTextarea.scrollTop = 0;
        }
    };

    resetVisualizationStudioViewport();

    if (vizOptionsTextarea) {
        vizOptionsTextarea.value = mergedOptions.description || '';
        vizOptionsTextarea.readOnly = false;
    }

    if (batchSizeInput) {
        batchSizeInput.value = String(ENFORCED_VISUALIZATION_BATCH_SIZE);
        batchSizeInput.min = String(ENFORCED_VISUALIZATION_BATCH_SIZE);
        batchSizeInput.max = String(ENFORCED_VISUALIZATION_BATCH_SIZE);
        batchSizeInput.readOnly = true;
        batchSizeInput.disabled = true;
    }

    setVisualizationSingleChoice(modal, 'goal', mergedOptions.goal);
    setVisualizationSingleChoice(modal, 'family', mergedOptions.family);
    setVisualizationSingleChoice(modal, 'renderer', mergedOptions.rendererStrategy);
    setVisualizationSingleChoice(modal, 'interaction', mergedOptions.interactionLevel);
    setVisualizationSingleChoice(modal, 'audience', mergedOptions.audienceMode);
    setVisualizationSingleChoice(modal, 'complexity', mergedOptions.complexityBias);
    setVisualizationSingleChoice(modal, 'fallback', mergedOptions.fallbackPolicy);
    setVisualizationSingleChoice(modal, 'density', mergedOptions.densityMode);
    setVisualizationSingleChoice(modal, 'motion', mergedOptions.motionMode);
    setVisualizationSingleChoice(modal, 'theme', mergedOptions.theme);
    setVisualizationSingleChoice(modal, 'preset', mergedOptions.presetKey);
    setVisualizationLibrarySelection(modal, mergedOptions.libraries);
    setVisualizationToggleState(modal, 'viz-educational-mode', mergedOptions.educationalMode);
    setVisualizationToggleState(modal, 'viz-worldsim-mode', mergedOptions.worldsimMode);
    setVisualizationToggleState(modal, 'viz-simulation-mode', mergedOptions.isSimulation);
    setVisualizationToggleState(modal, 'viz-simple-mode', mergedOptions.isSimpleMode);
    setVisualizationToggleState(modal, 'viz-high-contrast-mode', mergedOptions.highContrastMode);
    setVisualizationToggleState(modal, 'viz-export-safe-mode', mergedOptions.exportSafeMode);
    setVisualizationToggleState(modal, 'viz-include-all-dom', mergedOptions.includeAllDom);
    setVisualizationToggleState(modal, 'viz-auto-generate-toggle', mergedOptions.autoGenerateOnLoad);
    setVisualizationToggleState(modal, 'viz-remember-form-toggle', mergedOptions.rememberLastVisualizationForm);
    aiRecommendToggle?.classList.toggle('active', !!mergedOptions.useAiRecommendedProfile);

    if (!mergedOptions.presetKey || !(VISUALIZATION_PRESET_CONFIG_V2[mergedOptions.presetKey] || VISUALIZATION_PRESET_CONFIG[mergedOptions.presetKey])) {
        clearVisualizationPresetSelection(modal);
    }

    if (addPresetPromptBtn) {
        const hasPresetPrompt = targetElement?.dataset.prompt?.trim();
        addPresetPromptBtn.style.display = hasPresetPrompt ? 'inline-flex' : 'none';
        handlePresetPrompt = () => {
            const presetPrompt = targetElement?.dataset.prompt?.trim();
            if (!presetPrompt || !vizOptionsTextarea) return;

            const marker = '[영역 프롬프트]';
            if (vizOptionsTextarea.value.includes(marker)) {
                showToastNotification('영역 프롬프트가 이미 추가되어 있습니다.', '', `viz-preset-prompt-${Date.now()}`);
                return;
            }

            vizOptionsTextarea.value = `${marker}\n${presetPrompt}\n\n${vizOptionsTextarea.value}`.trim();
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            vizOptionsTextarea.focus();
            showToastNotification('영역 프롬프트를 세부 요청에 추가했습니다.', '', `viz-preset-prompt-added-${Date.now()}`);
        };
        addPresetPromptBtn.addEventListener('click', handlePresetPrompt);
    }

    handleTextareaInput = () => {
        refreshVisualizationAiRecommendation(modal, targetElement);
        renderVisualizationSelectionSummary(modal);
    };
    vizOptionsTextarea?.addEventListener('input', handleTextareaInput);

    handleModalClick = (event) => {
        const aiButton = event.target.closest('#viz-ai-recommend-toggle');
        if (aiButton) {
            aiButton.classList.toggle('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            return;
        }

        const presetButton = event.target.closest('[data-role="preset"]');
        if (presetButton) {
            applyVisualizationPresetToModal(modal, presetButton.dataset.preset);
            aiRecommendToggle?.classList.remove('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            return;
        }

        const choiceButton = event.target.closest('[data-role]');
        if (choiceButton) {
            const role = choiceButton.dataset.role;
            setVisualizationSingleChoice(modal, role, choiceButton.dataset[role]);
            if (role !== 'preset') {
                clearVisualizationPresetSelection(modal);
            }
            aiRecommendToggle?.classList.remove('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            return;
        }

        const libraryButton = event.target.closest('[data-library]');
        if (libraryButton) {
            libraryButton.classList.toggle('active');
            clearVisualizationPresetSelection(modal);
            aiRecommendToggle?.classList.remove('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
            return;
        }

        const toggleButton = event.target.closest('.option-btn[id]');
        if (toggleButton && toggleButtons.includes(toggleButton.id)) {
            toggleButton.classList.toggle('active');
            clearVisualizationPresetSelection(modal);
            aiRecommendToggle?.classList.remove('active');
            refreshVisualizationAiRecommendation(modal, targetElement);
            renderVisualizationSelectionSummary(modal);
        }
    };
    modal.addEventListener('click', handleModalClick);

    refreshVisualizationAiRecommendation(modal, targetElement);
    renderVisualizationSelectionSummary(modal);

    const close = () => {
        modal.style.display = 'none';
        modal.removeEventListener('click', handleModalClick);
        vizOptionsTextarea?.removeEventListener('input', handleTextareaInput);
        if (addPresetPromptBtn && handlePresetPrompt) {
            addPresetPromptBtn.removeEventListener('click', handlePresetPrompt);
        }
        vizOptionsGenerateBtn.onclick = null;
        vizOptionsCancelBtn.onclick = null;
    };

    vizOptionsCancelBtn.onclick = close;
    vizOptionsGenerateBtn.textContent = targetElement ? '재생성하기' : '생성하기';
    vizOptionsGenerateBtn.onclick = () => {
        const collectedOptions = aiRecommendToggle?.classList.contains('active')
            ? normalizeVisualizationGenerationOptions({
                ...(modal.__vizAiRecommendation?.options || getVisualizationModalRawOptions(modal)),
                useAiRecommendedProfile: true
            })
            : collectVisualizationOptionsFromModal(modal);
        persistVisualizationFormPreferences(collectedOptions);
        onConfirm(collectedOptions);
        close();
    };

    highestZIndex++;
    modal.style.zIndex = highestZIndex;
    modal.style.display = 'flex';
    requestAnimationFrame(resetVisualizationStudioViewport);
}
