/* --- Ailey & Bailey Canvas --- */
// File: 210_chat_ui_actions.js
// Version: 2.0 (Multi Attachment Composer)
// Description: Handles user-facing send actions for the chat feature, including multi-attachment messages.

function getComposerAttachments() {
    return Array.isArray(stagedChatAttachments) ? stagedChatAttachments.map(attachment => ({ ...attachment })) : [];
}

function buildChatUserMessage(queryText, attachments) {
    const trimmedText = (queryText || '').trim();
    const hasAttachments = attachments.length > 0;
    const displayText = trimmedText || (hasAttachments ? `첨부 파일 ${attachments.length}개를 함께 보냅니다.` : '');

    const userMessage = {
        role: 'user',
        content: displayText,
        displayName: displayText,
        timestamp: firebase.firestore.FieldValue.serverTimestamp()
    };

    if (hasAttachments) {
        userMessage.attachments = attachments;
        userMessage.attachment = { ...attachments[0] };
    }

    return userMessage;
}

function sliceChatHistoryByLimit(messages, limit) {
    const normalizedLimit = normalizeChatHistoryLimitValue(limit, 20);
    if (normalizedLimit <= 0) return [];
    return Array.isArray(messages) ? messages.slice(-normalizedLimit) : [];
}

function getNewSessionTitleFromMessage(userMessage) {
    const attachments = normalizeChatMessageAttachments(userMessage);
    const titleSource = userMessage.displayName
        || userMessage.content
        || attachments.map(item => item.name).join(', ')
        || '새 대화';

    return titleSource.substring(0, 40) + (titleSource.length > 40 ? '...' : '');
}

async function handleQuickQuerySend() {
    if (!quickQueryInput) return;
    await handleChatSend({ inputElement: quickQueryInput });
}

async function handleChatSend({ inputElement }) {
    const isQuickQuery = inputElement && inputElement.id === 'quick-query-input';
    const element = inputElement || chatInput;
    if (!element || element.disabled) return;

    let hiddenContext = null;
    if (stagedHiddenContext) {
        hiddenContext = stagedHiddenContext;
        stagedHiddenContext = null;
    }

    const queryText = element.value.trim();
    const attachments = getComposerAttachments();

    if (!queryText && attachments.length === 0) {
        return;
    }

    const userMessage = buildChatUserMessage(queryText, attachments);

    if (typeof setChatAutoFollow === 'function') {
        setChatAutoFollow(true);
    }

    element.value = '';
    autoResizeTextarea(element);
    clearAllChatAttachments();

    const tempUserMessageForUI = { ...userMessage, timestamp: new Date() };

    const activePreset = userApiSettings.apiPresets.find(preset => preset.id === userApiSettings.activePresetId);
    const historyLimit = activePreset ? (activePreset.chatHistoryLimit ?? 20) : (userApiSettings.universalModelSettings?.chatHistoryLimit ?? 20);

    if (currentSessionId === 'temporary-chat' || (isQuickQuery && isQuickQueryTempMode)) {
        temporarySession.messages.push(tempUserMessageForUI);
        renderNewMessages([tempUserMessageForUI]);
        const historyForApi = sliceChatHistoryByLimit(temporarySession.messages, historyLimit);
        await sendQueryToAI(tempUserMessageForUI, historyForApi, 'temporary-chat', true, isQuickQuery, hiddenContext);
        return;
    }

    try {
        let sessionIdToUse;
        let historyForApi;

        if (!currentSessionId) {
            const newSessionData = {
                title: getNewSessionTitleFromMessage(userMessage),
                projectId: null,
                isPinned: false,
                createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
                contextSent: !!hiddenContext
            };

            const sessionRef = await chatSessionsCollectionRef.add(newSessionData);
            sessionIdToUse = sessionRef.id;
            await chatSessionsCollectionRef.doc(sessionIdToUse).collection('messages').add(userMessage);
            historyForApi = [userMessage];

            if (!isQuickQuery) {
                await selectSession(sessionIdToUse);
            } else {
                renderSidebarContent();
            }
        } else {
            sessionIdToUse = currentSessionId;
            const currentSession = localChatSessionsCache.find(session => session.id === sessionIdToUse);
            if (hiddenContext && currentSession && currentSession.contextSent) {
                hiddenContext = null;
            }

            const batch = db.batch();
            const sessionDocRef = chatSessionsCollectionRef.doc(sessionIdToUse);
            const messageDocRef = sessionDocRef.collection('messages').doc();
            batch.set(messageDocRef, userMessage);

            const updateData = { updatedAt: firebase.firestore.FieldValue.serverTimestamp() };
            if (hiddenContext) {
                updateData.contextSent = true;
            }

            batch.update(sessionDocRef, updateData);
            await batch.commit();
            historyForApi = historyLimit > 0
                ? (await fetchPastMessages(sessionIdToUse, null, historyLimit)).reverse()
                : [];
        }

        sendQueryToAI(userMessage, historyForApi, sessionIdToUse, false, isQuickQuery, hiddenContext);
    } catch (error) {
        console.error('Failed to prepare chat session or send message:', error);
        trace('Firestore', 'handleChatSend.error', { error: error.message }, {}, 'ERROR');
        showModal('메시지를 준비하거나 전송하는 중 문제가 발생했습니다.', () => {});
        if (chatInput) {
            chatInput.disabled = false;
            chatInput.placeholder = 'Ailey & Bailey에게 질문하기...';
        }
        if (chatSendBtn) {
            chatSendBtn.disabled = false;
        }
    }
}
