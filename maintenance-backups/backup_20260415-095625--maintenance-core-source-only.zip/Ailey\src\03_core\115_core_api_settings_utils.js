/* --- Ailey & Bailey Canvas --- */
// File: 115_core_api_settings_utils.js
// Version: 1.0 (New Module)
// Description: Contains utility functions for the API settings modal.

const CODEX_BRIDGE_PROVIDER = 'openai_codex_bridge';
const CODEX_BRIDGE_DEFAULT_URL = 'http://127.0.0.1:4317';

function isCodexBridgeProvider(provider) {
    return String(provider || '').trim() === CODEX_BRIDGE_PROVIDER;
}

function normalizeCodexBridgeUrl(url) {
    const rawValue = String(url || '').trim();
    if (!rawValue) return CODEX_BRIDGE_DEFAULT_URL;

    let normalizedValue = rawValue;
    if (!/^https?:\/\//i.test(normalizedValue)) {
        normalizedValue = `http://${normalizedValue}`;
    }

    try {
        const parsedUrl = new URL(normalizedValue);
        const pathname = parsedUrl.pathname === '/' ? '' : parsedUrl.pathname.replace(/\/+$/, '');
        return `${parsedUrl.origin}${pathname}`;
    } catch (error) {
        return '';
    }
}

function getProviderDisplayName(provider) {
    if (isCodexBridgeProvider(provider)) return 'Codex OAuth';
    if (provider === 'google_paid') return 'Google';
    if (provider === 'openai') return 'OpenAI';
    if (provider === 'openrouter') return 'OpenRouter';
    if (provider === 'anthropic') return 'Anthropic';
    if (provider === 'cerebras') return 'Cerebras';
    if (provider === 'groq') return 'Groq';
    if (provider === 'Google') return 'Google';
    return provider || 'Unverified';
}

function populateModelSelector(models, provider, selectedModel = null, selectId) {
    const modelSelect = document.getElementById(selectId);
    if (!modelSelect) return;

    modelSelect.innerHTML = '';
    const effectiveModels = models || [];
    if (provider && effectiveModels.length === 0) { if (provider === 'anthropic') { effectiveModels.push('claude-3-opus-20240229', 'claude-3-sonnet-20240229', 'claude-3-haiku-20240307'); } }
    
    if (effectiveModels.length > 0) {
        effectiveModels.forEach(modelId => {
            const option = document.createElement('option');
            option.value = modelId;
            option.textContent = modelId;
            if (modelId === selectedModel) {
                option.selected = true;
            }
            modelSelect.appendChild(option);
        });
        modelSelect.disabled = false;
    } else {
        const modelSearchInput = document.getElementById('api-model-search-input');
        const searchTerm = modelSearchInput ? modelSearchInput.value : '';
        const option = document.createElement('option');
        option.textContent = searchTerm ? '검색 결과 없음' : (provider ? '사용 가능한 모델 없음' : '키 검증 필요');
        modelSelect.appendChild(option);
        modelSelect.disabled = true;
    }
}

function detectProvider(key) {
    if (key.startsWith('sk-or-')) return 'openrouter';
    if (key.startsWith('sk-ant-api')) return 'anthropic';
    if (key.startsWith('sk-')) return 'openai';
    if (key.startsWith('gsk_')) return 'groq';
    if (key.startsWith('csk_') || key.startsWith('csk-') || key.startsWith('cb-')) return 'cerebras';
    if (key.length > 35 && key.startsWith('AIza')) return 'google_paid';
    return null;
}
