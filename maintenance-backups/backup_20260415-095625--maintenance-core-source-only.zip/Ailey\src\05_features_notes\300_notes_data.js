
/* --- Ailey & Bailey Canvas --- */
// File: 300_notes_data.js
// Version: 5.1 (Archive Consistency Fix)
// Description: Added `bypassCache` parameter to `getNoteContent` to ensure archiver reads the latest server data, preventing overwrite issues during rapid sequential updates.

const NOTES_PER_PAGE = 30;
const noteWriteQueueMap = new Map();
const noteLookupQueueMap = new Map();
const noteProjectLookupQueueMap = new Map();

function enqueueScopedTask(queueMap, key, task) {
    const previousTask = queueMap.get(key) || Promise.resolve();
    const nextTask = previousTask
        .catch(() => {})
        .then(task);

    queueMap.set(key, nextTask);
    nextTask.finally(() => {
        if (queueMap.get(key) === nextTask) {
            queueMap.delete(key);
        }
    });
    return nextTask;
}

function enqueueNoteWrite(noteId, task) {
    return enqueueScopedTask(noteWriteQueueMap, noteId, task);
}

async function replaceNoteContentSerial(noteId, newContent) {
    return enqueueNoteWrite(noteId, async () => {
        const normalizedContent = typeof newContent === 'string' ? newContent : '';
        await updateNoteContent(noteId, normalizedContent);
        return { updated: true, content: normalizedContent };
    });
}

async function appendNoteContentSerial(noteId, fragment, options = {}) {
    return enqueueNoteWrite(noteId, async () => {
        const appendFragment = typeof fragment === 'string' ? fragment : '';
        const dedupeMarker = options.dedupeMarker || null;
        const currentContent = await getNoteContent(noteId, true) || '';

        if (!appendFragment) {
            return { updated: false, content: currentContent, reason: 'empty-fragment' };
        }

        if (dedupeMarker && currentContent.includes(dedupeMarker)) {
            return { updated: false, content: currentContent, reason: 'duplicate-marker' };
        }

        const nextContent = `${currentContent}${appendFragment}`;
        if (nextContent === currentContent) {
            return { updated: false, content: currentContent, reason: 'unchanged' };
        }

        await updateNoteContent(noteId, nextContent);
        return { updated: true, content: nextContent };
    });
}

async function fetchMoreNotes() {
    if (!notesCollectionRef || !lastVisibleNoteTimestamp) return [];
    trace("Firestore", "note.fetchMore", {}, { lastVisibleNoteTimestamp });

    try {
        const query = notesCollectionRef
            .orderBy("updatedAt", "desc")
            .startAfter(lastVisibleNoteTimestamp)
            .limit(NOTES_PER_PAGE);
        
        const snapshot = await query.get();
        const newNotes = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

        if (newNotes.length > 0) {
            lastVisibleNoteTimestamp = newNotes[newNotes.length - 1].updatedAt;
            localNotesCache.push(...newNotes);
        }

        hasMoreNotes = newNotes.length === NOTES_PER_PAGE;
        trace("Firestore", "note.fetchMore.success", { fetched: newNotes.length }, { hasMoreNotes });
        return newNotes;
    } catch (error) {
        console.error("Error fetching more notes:", error);
        trace("Firestore", "note.fetchMore.error", { error: error.message }, {}, "ERROR");
        return [];
    }
}

async function addNote(content = '', title = '무제 노트', projectId = null) {
    if (!notesCollectionRef) return null;
    trace("Firestore", "note.add", { hasContent: !!content, title, projectId });
    try {
        const ref = await notesCollectionRef.add({
            title: title,
            content: content,
            projectId: projectId,
            isPinned: false,
            tags: [],
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        return ref.id;
    } catch (e) {
        console.error("새 메모 추가 실패:", e);
        trace("Firestore", "note.add.error", { error: e.message }, {}, "ERROR");
        return null;
    }
}

function deleteNote(noteId) {
    trace("UI", "note.delete.init", { noteId });
    showModal('이 메모를 영구적으로 삭제하시겠습니까?', () => {
        if (notesCollectionRef && noteId) {
            notesCollectionRef.doc(noteId).delete().catch(e => {
                console.error("메모 삭제 실패:", e);
                trace("Firestore", "note.delete.error", { noteId, error: e.message }, {}, "ERROR");
                alert("메모 삭제에 실패했습니다.");
            });
            if (currentNoteId === noteId) {
                switchView('list');
            }
        }
    });
}

async function renameNote(noteId, newTitle) {
    if (!newTitle?.trim() || !noteId || !notesCollectionRef) return;
    trace("Firestore", "note.rename", { noteId, newTitle });
    try {
        await notesCollectionRef.doc(noteId).update({
            title: newTitle.trim(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (error) {
        console.error("Error renaming note:", error);
        trace("Firestore", "note.rename.error", { noteId, error: error.message }, {}, "ERROR");
        alert("노트 이름 변경에 실패했습니다.");
    }
}

async function togglePin(noteId) {
    if (!notesCollectionRef) return;
    const note = localNotesCache.find(n => n.id === noteId);
    if (note) {
        trace("Firestore", "note.togglePin", { noteId, isPinned: !note.isPinned });
        try {
            await notesCollectionRef.doc(noteId).update({
                isPinned: !note.isPinned
            });
        } catch (error) {
            console.error("Error toggling pin:", error);
            trace("Firestore", "note.togglePin.error", { noteId, error: error.message }, {}, "ERROR");
            alert("노트 고정 상태 변경에 실패했습니다.");
        }
    }
}

async function moveNoteToProject(noteId, projectId) {
    if (!notesCollectionRef || !noteId) return;
    const targetProjectId = projectId === "null" ? null : projectId;
    trace("Firestore", "note.moveToProject", { noteId, targetProjectId });
    try {
        await notesCollectionRef.doc(noteId).update({
            projectId: targetProjectId,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (error) {
        console.error("Error moving note:", error);
        trace("Firestore", "note.moveToProject.error", { noteId, error: error.message }, {}, "ERROR");
        alert("노트 이동에 실패했습니다.");
    }
}

async function createNewNoteProject() {
    if (!noteProjectsCollectionRef) return;
    trace("Firestore", "noteProject.create");
    try {
        const newProjectRef = await noteProjectsCollectionRef.add({
            name: getNewNoteProjectDefaultName(),
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        newlyCreatedNoteProjectId = newProjectRef.id;
    } catch (error) {
        console.error("Error creating new note project:", error);
        trace("Firestore", "noteProject.create.error", { error: error.message }, {}, "ERROR");
        alert("새 폴더 생성에 실패했습니다.");
    }
}

async function renameNoteProject(projectId, newName) {
    if (!newName?.trim() || !projectId || !noteProjectsCollectionRef) return;
    trace("Firestore", "noteProject.rename", { projectId, newName });
    try {
        await noteProjectsCollectionRef.doc(projectId).update({
            name: newName.trim(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (error) {
        console.error("Error renaming note project:", error);
        trace("Firestore", "noteProject.rename.error", { projectId, error: error.message }, {}, "ERROR");
        alert("폴더 이름 변경에 실패했습니다.");
    }
}

async function updateNoteProject(projectId, data) {
    if (!projectId || !data || !noteProjectsCollectionRef) return;
    trace("Firestore", "noteProject.update", { projectId, dataKeys: Object.keys(data) });
    try {
        await noteProjectsCollectionRef.doc(projectId).update({
            ...data,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (error) {
        console.error("Error updating note project:", error);
        trace("Firestore", "noteProject.update.error", { projectId, error: error.message }, {}, "ERROR");
        throw error;
    }
}

async function deleteNoteProject(projectId) {
    const project = localNoteProjectsCache.find(p => p.id === projectId);
    if (!project) return;
    trace("UI", "noteProject.delete.init", { projectId, name: project.name });
    showModal(`폴더 '${project.name}'를 삭제하시겠습니까? 폴더 안의 모든 메모도 함께 영구적으로 삭제됩니다.`, async () => {
        try {
            const batch = db.batch();
            localNotesCache.filter(n => n.projectId === projectId).forEach(note => {
                batch.delete(notesCollectionRef.doc(note.id));
            });
            batch.delete(noteProjectsCollectionRef.doc(projectId));
            await batch.commit();
            trace("Firestore", "noteProject.delete.success", { projectId });
        } catch (error) {
            console.error("Error deleting note project:", error);
            trace("Firestore", "noteProject.delete.error", { projectId, error: error.message }, {}, "ERROR");
            alert("폴더 삭제에 실패했습니다.");
        }
    });
}

// --- [NEW] Archiver Helper Functions ---

async function findOrCreateNoteProjectByName(name) {
    if (!name || !noteProjectsCollectionRef) return null;
    return enqueueScopedTask(noteProjectLookupQueueMap, name, async () => {
        let project = localNoteProjectsCache.find(p => p.name === name);
        if (project) return project;

        const query = noteProjectsCollectionRef.where('name', '==', name).limit(1);
        const snapshot = await query.get();

        if (!snapshot.empty) {
            const doc = snapshot.docs[0];
            return { id: doc.id, ...doc.data() };
        }

        const newProjectRef = await noteProjectsCollectionRef.add({
            name: name,
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        return { id: newProjectRef.id, name: name };
    });
}

async function findOrCreateNoteByTitle(title, projectId) {
    if (!title || !notesCollectionRef) return null;
    const noteLookupKey = `${projectId || 'root'}::${title}`;
    return enqueueScopedTask(noteLookupQueueMap, noteLookupKey, async () => {
        let note = localNotesCache.find(n => n.title === title && n.projectId === projectId);
        if (note) return note;

        const query = notesCollectionRef.where('title', '==', title).where('projectId', '==', projectId).limit(1);
        const snapshot = await query.get();

        if (!snapshot.empty) {
            const doc = snapshot.docs[0];
            return { id: doc.id, ...doc.data() };
        }

        const newNoteId = await addNote('', title, projectId);
        return { id: newNoteId, title: title, projectId: projectId, content: '' };
    });
}

// [MODIFIED] Added bypassCache parameter to solve race conditions during sequential archiving
async function getNoteContent(noteId, bypassCache = false) {
    if (!noteId || !notesCollectionRef) return null;
    
    // If bypassCache is false, try cache first (default behavior for UI)
    if (!bypassCache) {
        const cachedNote = localNotesCache.find(n => n.id === noteId);
        if (cachedNote && typeof cachedNote.content === 'string') {
            return cachedNote.content;
        }
    }
    
    // Fetch directly from server (used for Archiving to ensure latest state)
    trace("Firestore", "note.getContent", { noteId, source: bypassCache ? 'server_enforced' : 'server_fallback' });
    const doc = await notesCollectionRef.doc(noteId).get();
    return doc.exists ? doc.data().content : null;
}

async function updateNoteContent(noteId, newContent) {
    if (!noteId || !notesCollectionRef) return;
    try {
        await notesCollectionRef.doc(noteId).update({
            content: newContent,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (e) {
        console.error("메모 내용 업데이트 실패:", e);
        trace("Firestore", "note.updateContent.error", { noteId, error: e.message }, {}, "ERROR");
        throw e;
    }
}

async function updateNoteProjectChunkSize(projectId, chunkSize) {
    if (!noteProjectsCollectionRef || !projectId) return;
    const size = parseInt(chunkSize, 10);
    if (isNaN(size) || chunkSize === '' || size < 1) {
        trace("Firestore", "noteProject.chunkSize.reset", { projectId });
        try {
            await noteProjectsCollectionRef.doc(projectId).update({
                chunkSize: firebase.firestore.FieldValue.delete(),
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            });
        } catch (error) {
            console.error("Error resetting note project chunk size:", error);
        }
    } else {
        trace("Firestore", "noteProject.chunkSize.set", { projectId, size });
        try {
            await noteProjectsCollectionRef.doc(projectId).update({
                chunkSize: size,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            });
        } catch (error) {
            console.error("Error updating note project chunk size:", error);
        }
    }
}

// [MODIFIED] Function to reset refinement state for a project, now includes learning_state
async function resetNoteProjectRefinementState(projectId) {
    const project = localNoteProjectsCache.find(p => p.id === projectId);
    if (!project || !noteProjectsCollectionRef) return;

    showModal(`'${project.name}' 폴더의 데이터 정제 기록을 초기화하시겠습니까? 다음 정제 시 모든 메모리를 처음부터 다시 처리하게 됩니다.`, async () => {
        try {
            await noteProjectsCollectionRef.doc(projectId).update({
                refinementState: firebase.firestore.FieldValue.delete(),
                learning_state: firebase.firestore.FieldValue.delete()
            });
            trace("Firestore", "refinement.resetState.success", { projectId });
            showToastNotification("✅ 정제 기록이 초기화되었습니다.", "", `refinement-reset-${Date.now()}`);
        } catch (error) {
            console.error("Error resetting refinement state:", error);
            trace("Firestore", "refinement.resetState.error", { projectId, error: error.message }, {}, "ERROR");
            alert("정제 기록 초기화에 실패했습니다.");
        }
    });
}

// [NEW] Function to set refinement start point to a specific note
async function setNoteProjectRefinementStart(projectId, fromNoteId) {
    const project = localNoteProjectsCache.find(p => p.id === projectId);
    const fromNote = localNotesCache.find(n => n.id === fromNoteId);
    if (!project || !fromNote || !noteProjectsCollectionRef) return;

    const message = `'${fromNote.title}' 메모부터 포함하여 이후의 모든 데이터를 다시 정제하시겠습니까? 기존 정제 기록이 이 지점으로 재설정됩니다.`;

    showModal(message, async () => {
        try {
            const notesInProject = localNotesCache
                .filter(n => n.projectId === projectId)
                .sort((a, b) => (a.createdAt?.toMillis() || 0) - (b.createdAt?.toMillis() || 0));

            const targetIndex = notesInProject.findIndex(n => n.id === fromNoteId);

            if (targetIndex === -1) {
                throw new Error("Target note not found in the project's sorted list.");
            }

            if (targetIndex === 0) {
                // If re-refining from the first note, it's the same as a full reset.
                await noteProjectsCollectionRef.doc(projectId).update({
                    refinementState: firebase.firestore.FieldValue.delete()
                });
                trace("Firestore", "refinement.resetState.full", { projectId, from: 'partial selection' });
            } else {
                // Set the start point to the timestamp of the note *before* the selected one.
                const previousNote = notesInProject[targetIndex - 1];
                const newTimestamp = previousNote.createdAt;
                
                const newRefinementState = {
                    ...project.refinementState, // Preserve targetSessionId if it exists
                    lastProcessedNoteTimestamp: newTimestamp,
                    lastRefinedAt: firebase.firestore.FieldValue.serverTimestamp()
                };

                await noteProjectsCollectionRef.doc(projectId).set({ refinementState: newRefinementState }, { merge: true });
                trace("Firestore", "refinement.resetState.partial", { projectId, toTimestamp: newTimestamp.toDate() });
            }

            showToastNotification("✅ 정제 시작점이 재설정되었습니다.", "'데이터 추출'을 눌러 다시 시작하세요.", `refinement-reset-partial-${Date.now()}`);

        } catch (error) {
            console.error("Error setting refinement start point:", error);
            trace("Firestore", "refinement.resetState.error", { projectId, error: error.message }, {}, "ERROR");
            alert("정제 시작점 설정에 실패했습니다.");
        }
    });
}


async function setManualRefinementState(projectId, noteId) {
    const project = localNoteProjectsCache.find(p => p.id === projectId);
    const note = localNotesCache.find(n => n.id === noteId);

    if (!project || !note || !note.createdAt || !noteProjectsCollectionRef) {
        const error = "프로젝트 또는 메모 정보를 찾을 수 없습니다.";
        trace("Refinement", "setManual.error", { projectId, noteId, reason: error }, {}, "ERROR");
        showModal(error, () => {});
        return;
    }
    
    try {
        const newTimestamp = note.createdAt;
        const currentState = project.refinementState || {};

        const newRefinementState = {
            ...currentState, // Preserve existing targetSessionId if it exists
            lastProcessedNoteTimestamp: newTimestamp,
            lastRefinedAt: firebase.firestore.FieldValue.serverTimestamp() // Mark this manual update
        };

        await noteProjectsCollectionRef.doc(projectId).set({ refinementState: newRefinementState }, { merge: true });
        
        trace("Firestore", "refinement.setManualState.success", { projectId, noteId, timestamp: newTimestamp.toDate() });
        showToastNotification("✅ 정제 기록이 설정되었습니다.", `'${note.title}'까지 처리된 것으로 기록됩니다.`, `refinement-manual-set-${Date.now()}`);

    } catch (error) {
        console.error("Error manually setting refinement state:", error);
        trace("Firestore", "refinement.setManualState.error", { projectId, error: error.message }, {}, "ERROR");
        showModal(`정제 기록 설정에 실패했습니다: ${error.message}`, () => {});
    }
}

async function archiveVisualizationToNote(noteId, vizBlockData) {
    if (!noteId || !vizBlockData) {
        showToastNotification("❌ 저장 실패", "필요한 정보가 없습니다.", `viz-archive-err-${Date.now()}`);
        return false;
    }
    trace("Archiver", "viz.archive.start", { noteId });

    try {
        const vizComment = `\n\n<!-- VIZ_DATA:${JSON.stringify(vizBlockData)} -->\n\n`;
        const result = await appendNoteContentSerial(noteId, vizComment, {
            dedupeMarker: vizComment.trim()
        });

        if (!result.updated && result.reason === 'duplicate-marker') {
            showToastNotification("ℹ️ 이미 저장됨", "같은 시각화 자료가 노트에 이미 있습니다.", `viz-archive-skip-${noteId}`);
            trace("Archiver", "viz.archive.skipDuplicate", { noteId });
            return true;
        }
        
        showToastNotification("✅ 시각화 자료 저장됨", "노트에 영구적으로 추가되었습니다.", `viz-archive-succ-${noteId}`);
        trace("Archiver", "viz.archive.success", { noteId });
        return true;
    } catch (error) {
        console.error("Failed to archive visualization:", error);
        trace("Archiver", "viz.archive.error", { noteId, error: error.message }, {}, "ERROR");
        showToastNotification("❌ 저장 실패", `데이터베이스 오류: ${error.message}`, `viz-archive-err-${Date.now()}`);
        return false;
    }
}
