﻿Plan Type: Work Plan
Workstream: Chat Unification And Live Visual Persistence
Version: v01
Created: 2026-04-14 01:20:00 +09:00
Last Updated: 2026-04-14 03:06:00 +09:00
Status: Completed

# User Understanding

The user wants four connected runtime changes.

First, remove the translation workspace surface from the renewed notes experience so it no longer appears as an active option in the archive workspace.

Second, redesign the chat panel so it feels visually unified with the renewed Ailey's Note workspace rather than looking like an older separate system. The goal is a shared design language, not a cosmetic one-off recolor.

Third, when a page is saved in live form and reopened, existing generated images and other visual support should not regenerate automatically. Live save should preserve the current visual state rather than re-triggering fresh generation on load.

Fourth, visualization and image surfaces should again expose the expected hover affordances on the right side, including actions such as fullscreen and regenerate where those actions are supported. The user reports that this overlay is currently missing in real usage and wants a proper root-cause fix, not a superficial patch.

# Scope

In scope:

- remove translation-workspace entry points from the notes archive workspace UI where they still appear
- redesign the chat panel shell and primary controls to match the renewed notes design language
- fix live-export persistence so saved visual assets are reused instead of re-generated on reopen
- restore media/visualization hover action overlays in runtime and verify them on a real exported page
- rebuild the runtime bundle, validate the affected workflows, and publish verified bundle changes to GitHub

Out of scope unless required by the above:

- changing the underlying translation engine behavior
- redesigning every app surface beyond notes/chat/runtime media controls
- changing the meaning of existing archive data formats

# Constraints And Invariants

- preserve current runtime shell ownership and existing major workflows unless explicitly removed
- keep notes archive and chat data models compatible with existing stored data
- do not break live export bootstrap compatibility
- do not cause visual assets to silently disappear in old saved exports
- prefer the smallest complete design that fixes the real runtime defects

# Phase Plan

## Phase 1: Scan And Root-Cause Analysis

Inspect the notes archive menu, chat panel shell and styles, live-export loader/persistence path, and visualization hover-control runtime. Identify the smallest safe intervention points and the trust boundaries between export artifacts, runtime hydration, and persisted media state.

## Phase 2: Remove Translation Workspace Surface

Remove translation workspace entry points from the renewed notes UI surface. Keep unrelated archive actions intact unless they are directly coupled to the removal.

## Phase 3: Unify Chat Design With Notes

Refactor the chat panel CSS and markup only as needed so it clearly shares the renewed notes workspace visual language. Keep the panel behavior stable while updating shell chrome, spacing, typography, button treatments, search/sidebar surfaces, and composer presentation.

## Phase 4: Preserve Saved Visual State In Live Exports

Trace how generated images and visualization state are serialized into live exports. Change the export or hydration path so reopening a live export preserves the already-resolved visual state and does not automatically regenerate assets unless the user explicitly asks for regeneration.

## Phase 5: Restore Hover Media Actions

Trace the runtime path that mounts hover controls for image and visualization surfaces. Fix the missing overlay so supported media surfaces show the expected right-side hover actions again, including fullscreen and regenerate where applicable.

## Phase 6: Verify, Review, Rebuild, And Publish

Validate on a real live-export page and runtime page that:

- translation workspace surface is gone
- chat redesign is visually unified and still functional
- saved visuals do not regenerate on reopen
- hover action overlays appear and function on supported visual/media surfaces
- no new page errors or console errors appear

Then rebuild the bundle and publish only the intended runtime bundle changes.

# Completion Notes

- translation workspace entry points were removed from the renewed notes/archive surface
- chat panel styling was unified with the renewed notes workspace language
- live export runtime now preserves existing generated media and skips automatic re-generation on reopen
- visualization hover controls were restored and image hover controls were redesigned into compact right-side quick actions with fullscreen, regenerate, options, and download affordances
- live export validation passed with media stability, hover-control presence, and no page errors
- verified bundle was published to GitHub as commit `7feccc9`

# Validation Strategy

Use browser-based validation against the reported exported page and the local runtime. Capture evidence for:

1. notes archive menu no longer showing translation workspace
2. chat panel visual redesign and retained core functionality
3. live export reload preserving visual state without regeneration
4. hover controls visible on media surfaces and actionability of at least the presence contract
5. no page errors and no critical console errors

# Risks

- the live-export persistence path may currently depend on placeholder regeneration for some artifact types, so the fix must distinguish between unresolved placeholders and already-resolved media
- chat restyling could inadvertently disturb sidebar layout or composer sizing if applied too broadly
- hover controls may be missing because of DOM structure, event wiring, or z-index layering; the fix needs to address the true cause rather than only CSS symptoms

# Rollback

Rollback remains safe because the work is runtime-bundle scoped. If needed, revert the source edits and rebuild the bundle; no data migration is planned.

# Scoreboard

Current Score: 50
Score Source: provisional
Last Updated: 2026-04-14 03:06:00 +09:00
Score Rationale: The requested runtime fixes were implemented, validated on the reported live-export path, and published successfully.
What Improved: Translation workspace UI is gone, chat styling is unified, live exports preserve resolved media, and both image and visualization hover controls are stable inside their frames.
What Remains Unsatisfactory: Residual console noise from third-party resources may still be worth a later cleanup pass, but there is no current blocker in the validated scenario.
What Should Happen Next To Raise Or Maintain The Score: Use the published bundle on a few more real pages and only reopen if a new runtime-specific regression appears.

## Score History

- 2026-04-14 01:20:00 +09:00 | Score: 44 | Source: provisional | Reason: Approved plan exists for the new chat-unification and live-visual-persistence work, but implementation has not started yet.
- 2026-04-14 03:06:00 +09:00 | Score: 50 | Source: provisional | Reason: Implementation, validation, and GitHub publish are complete for the approved runtime scope.
