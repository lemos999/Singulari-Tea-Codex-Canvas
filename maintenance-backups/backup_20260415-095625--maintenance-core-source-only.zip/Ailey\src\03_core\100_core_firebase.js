/* --- Ailey & Bailey Canvas --- */
// File: 100_core_firebase.js
// Version: 5.2 (Bottom Connection Toast)
// Description: Initializes Firebase in Canvas mode and LocalFirebaseShim in local mode while using a minimal bottom-floating connection toast.

async function initializeFirebase() {
    const isCanvasMode = typeof __firebase_config !== 'undefined';
    const unlockHeaderDock = () => {
        const toolContainer = document.querySelector('.fixed-tool-container');
        if (toolContainer && toolContainer.classList.contains('controls-disabled')) {
            toolContainer.classList.remove('controls-disabled');
        }
        return toolContainer;
    };

    try {
        window.__AILEY_RUNTIME_MODE__ = isCanvasMode ? 'canvas' : 'local';

        if (isCanvasMode) {
            const firebaseConfig = JSON.parse(__firebase_config);
            const initialAuthToken = typeof __initial_auth_token !== 'undefined' ? __initial_auth_token : null;

            if (!firebase.apps.length) {
                firebase.initializeApp(firebaseConfig);
            }

            const auth = firebase.auth();
            db = firebase.firestore();

            await auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL);

            try {
                db.settings({ experimentalForceLongPolling: true });
            } catch (error) {
                console.warn("Could not set Firestore long-polling.", error);
            }

            if (auth.currentUser) {
                console.log("User already signed in from persisted session.");
            } else if (initialAuthToken) {
                await auth.signInWithCustomToken(initialAuthToken).catch(async error => {
                    console.warn("Custom token sign-in failed, trying anonymous.", error);
                    await auth.signInAnonymously();
                });
            } else {
                await auth.signInAnonymously();
            }

            currentUser = auth.currentUser;
            if (!currentUser) {
                throw new Error("Firebase auth user not found.");
            }

            console.log("Firebase Authenticated. User UID:", currentUser.uid);
            const userPath = `artifacts/${appId}/users/${currentUser.uid}`;
            const chatHistoryPath = `${userPath}/chatHistories/global`;

            notesCollectionRef = db.collection(`${userPath}/notes`);
            noteProjectsCollectionRef = db.collection(`${userPath}/noteProjects`);
            tagsCollectionRef = db.collection(`${userPath}/noteTags`);
            noteTemplatesCollectionRef = db.collection(`${userPath}/noteTemplates`);
            userSettingsRef = db.collection(`${userPath}/settings`).doc('userSettings');
            chatSessionsCollectionRef = db.collection(`${chatHistoryPath}/sessions`);
            projectsCollectionRef = db.collection(`${chatHistoryPath}/projects`);
            promptTemplatesCollectionRef = db.collection(`${userPath}/promptTemplates`);
            canvasImageHistoryCollectionRef = db.collection(`${userPath}/canvasImageHistory`);
        } else {
            if (typeof LocalFirebaseShim === 'undefined') {
                throw new Error("LocalFirebaseShim is not available.");
            }

            LocalFirebaseShim.installFirebaseCompat();
            db = new LocalFirebaseShim();
            await db.initialize();

            currentUser = {
                uid: 'local-user',
                isAnonymous: false,
                providerData: [{ providerId: 'local' }]
            };

            notesCollectionRef = db.collection('notes');
            noteProjectsCollectionRef = db.collection('noteProjects');
            tagsCollectionRef = db.collection('noteTags');
            noteTemplatesCollectionRef = db.collection('noteTemplates');
            userSettingsRef = db.collection('settings').doc('userSettings');
            chatSessionsCollectionRef = db.collection('chatSessions');
            projectsCollectionRef = db.collection('projects');
            promptTemplatesCollectionRef = db.collection('promptTemplates');
            canvasImageHistoryCollectionRef = db.collection('canvasImageHistory');
        }

        await loadUserSettingsFromFirebase();
        unlockHeaderDock();
        await seedDefaultData();
        await initializeListeners();

        const toolContainer = document.querySelector('.fixed-tool-container');
        if (toolContainer) {
            toolContainer.classList.remove('controls-disabled');
            showConnectionToast(
                isCanvasMode ? "연결되었습니다." : "로컬 모드로 시작되었습니다.",
                isCanvasMode ? "이제 바로 작업할 수 있습니다." : "브라우저 로컬 저장소가 활성화되었습니다."
            );
        }

        setupSystemInfoWidget();
    } catch (error) {
        console.error("Firebase or local runtime initialization failed:", error);
        const chatMessages = document.getElementById('chat-messages');
        if (chatMessages) {
            chatMessages.innerHTML = isCanvasMode
                ? '<div>AI workspace connection failed.</div>'
                : '<div>Local mode initialization failed.</div>';
        }
    }
}
