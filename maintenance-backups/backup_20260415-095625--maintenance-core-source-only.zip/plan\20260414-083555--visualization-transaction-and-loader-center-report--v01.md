# Visualization Transaction And Loader Center Report

## Scope
- Prevent visualization blocks from disappearing while a new render is being prepared.
- Keep the image-generation loading indicator centered inside the authored frame instead of drifting to the top-left corner.
- Harden shared visualization mounting so older call paths do not immediately blank the target before a replacement is ready.

## Design Intent
- Treat visualization replacement as a transaction:
  - stage the new visualization off-screen
  - verify the staged mount is healthy
  - commit only after the staged mount is ready
- Keep the previously rendered visualization visible until commit succeeds.
- Standardize media loading states with a centered wrapper and label so slot-mode frames remain visually stable.

## Changed Files
- `Ailey/src/02_utils/013_utils_block_renderer.js`
  - Added staged visualization transaction helpers.
  - Rehydration of saved visualization blocks now stages before commit.
- `Ailey/src/03_core/121_core_initializer_visualization.js`
  - Added visualization loading/pending helpers.
  - Generation/regeneration paths now use staged commit helpers.
  - Shared `mountVisualizationBlock(...)` now prefers transaction-safe mounting when the staged helpers are available.
- `Ailey/src/03_core/123_core_initializer_vision_logic.js`
  - Clears loading-state classes after image success/failure.
- `Ailey/src/03_core/124_core_initializer_vision_handler.js`
  - Replaced raw dot markup with a centered loading-state wrapper and label.
- `Ailey/src_css/004_widget_visualization_options.css`
  - Added pending overlay styles for visualization regeneration.
- `Ailey/src_css/022_chat_messages.css`
  - Added shared media loading-state layout styles.
- `Ailey/src_css/028_image_placeholders.css`
  - Added centered loading-state behavior for generated-image frames, including slot mode.

## Verification
- Validation folder:
  - `visual-tests/storm-transaction-loader-validation-2026-04-13T23-35-22-234Z/`
- Key results:
  - `initialVisualizationVisible=true`
  - `originalRetainedDuringStaging=true`
  - `stagedVisualizationHealthy=true`
  - `committedVisualizationHealthy=true`
  - `imageLoaderCentered=true`
  - `pageErrorCount=0`
- Screenshots:
  - `01-initial.png`
  - `02-after-transaction-commit.png`
  - `03-loader-center.png`

## Residual Notes
- The storm page still emits non-blocking external warnings during local validation:
  - Tailwind CDN production warning
  - Three.js deprecation warning
  - one local 404 resource warning
- These warnings did not break the staged visualization flow or the centered image-loading state.
