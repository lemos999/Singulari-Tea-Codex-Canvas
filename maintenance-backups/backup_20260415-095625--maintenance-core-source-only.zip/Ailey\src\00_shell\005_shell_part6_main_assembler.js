/* --- Ailey & Bailey Canvas --- */
// File: 005_shell_part6_main_assembler.js
// Version: 4.0 (Core Shell + Composable Content Mount)
// Description: Preserves the always-on shell while separating core-shell mounting from content mounting.

const SHELL_PART_6 = `
    <main id="ai-content-placeholder"></main>
    <div id="portal-tooltip"></div>
    <input type="file" id="file-importer" accept=".json" style="display: none;">
    <input type="file" id="chat-file-input" accept=".txt,.md,.json,.csv,.tsv,.js,.ts,.py,.html,.css,.xml,.yaml,.yml,.pdf,.png,.jpg,.jpeg,.webp,.gif,.svg" multiple style="display: none;">
`;

const SHELL_HTML_BODY_TEMPLATE = SHELL_PART_1
    + SHELL_PART_2
    + (SHELL_PART_3_A + SHELL_PART_3_B + SHELL_PART_3_C + SHELL_PART_3_D + SHELL_PART_3_E + SHELL_PART_3_F)
    + SHELL_PART_4
    + SHELL_PART_5
    + SHELL_PART_6;

function createErrorBlock(error, blockData) {
    const errorDiv = document.createElement('div');
    errorDiv.style.border = '2px dashed red';
    errorDiv.style.padding = '15px';
    errorDiv.style.margin = '10px 0';
    errorDiv.style.backgroundColor = '#fff0f0';
    errorDiv.style.color = '#333';
    errorDiv.style.fontFamily = 'monospace';
    errorDiv.innerHTML = `
        <h4 style="margin-top:0; color: red;">Render error</h4>
        <p><strong>Message:</strong> ${error.name}: ${error.message}</p>
        <p><strong>Block data:</strong></p>
        <pre style="white-space: pre-wrap; word-break: break-all; background: #f5f5f5; padding: 10px; border-radius: 4px;">${JSON.stringify(blockData, null, 2)}</pre>
    `;
    return errorDiv;
}

function isOfficialCanvasRuntime() {
    const REQUIRED_SCRIPT_SOURCE = 'https://lemos999.github.io/Singulari-Tea-Codex-Canvas/';
    const isCanvasMode = typeof __firebase_config !== 'undefined';
    const isLiveExportRuntime = document.body?.dataset?.exportMode === 'live'
        && !!document.getElementById('exported-content');
    return isLiveExportRuntime
        || !isCanvasMode
        || document.documentElement.innerHTML.includes(REQUIRED_SCRIPT_SOURCE);
}

function applySavedThemePreference() {
    if (!document.body) return;
    document.body.classList.add('dark-mode');
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light') {
        document.body.classList.remove('dark-mode');
    }
}

function upsertCanvasMeta(canvasId_from_ai) {
    const resolvedCanvasId = canvasId_from_ai || 'global_fallback_id';
    let meta = document.querySelector('meta[name="canvas-id"]');
    if (!meta) {
        meta = document.createElement('meta');
        meta.name = 'canvas-id';
        document.head.appendChild(meta);
    }
    meta.content = resolvedCanvasId;
    canvasId = resolvedCanvasId;
    return meta;
}

function isCoreShellMounted() {
    return !!document.getElementById('immersive-header')
        && !!document.getElementById('chat-panel')
        && !!document.getElementById('notes-app-panel')
        && !!document.getElementById('ai-content-placeholder');
}

function ensureCoreShellMounted(options = {}) {
    const { forceRemount = false } = options;
    const shouldRemount = forceRemount || !isCoreShellMounted();

    if (shouldRemount) {
        document.body.innerHTML = SHELL_HTML_BODY_TEMPLATE;
        isCoreShellInitialized = false;
        areCoreShellBindingsInitialized = false;
    }

    applySavedThemePreference();
    rebindDOMElements();

    return {
        remounted: shouldRemount,
        placeholder: document.getElementById('ai-content-placeholder')
    };
}

function parseCanvasPayload(inputContent) {
    if (typeof inputContent === 'string' && inputContent.trim().startsWith('{')) {
        try {
            return JSON.parse(inputContent);
        } catch (e) {
            return null;
        }
    }

    if (typeof inputContent === 'object' && inputContent !== null) {
        return inputContent;
    }

    return null;
}

function normalizeCanvasHtmlInput(inputContent) {
    const htmlContent = typeof inputContent === 'string' ? inputContent : String(inputContent ?? '');
    const trimmed = htmlContent.trim();

    if (!/^<main\b/i.test(trimmed) || !/id\s*=\s*["']ai-content-placeholder["']/i.test(trimmed)) {
        return {
            htmlContent,
            layoutHint: null,
            placeholderAttrs: null
        };
    }

    try {
        const doc = new DOMParser().parseFromString(trimmed, 'text/html');
        const main = doc.querySelector('main#ai-content-placeholder');
        if (!main) {
            return {
                htmlContent,
                layoutHint: null,
                placeholderAttrs: null
            };
        }

        const placeholderAttrs = {};
        Array.from(main.attributes).forEach((attr) => {
            if (attr.name === 'id' || attr.name === 'style') return;
            placeholderAttrs[attr.name] = attr.value;
        });

        return {
            htmlContent: main.innerHTML.trim(),
            layoutHint: main.dataset.shellLayout || main.dataset.ccLayout || null,
            placeholderAttrs
        };
    } catch (error) {
        console.warn('Failed to normalize canvas HTML input.', error);
        return {
            htmlContent,
            layoutHint: null,
            placeholderAttrs: null
        };
    }
}

function looksLikeTailwindDrivenCanvas(inputContent) {
    if (typeof inputContent !== 'string') return false;

    return /class\s*=\s*["'][^"']*(?:\b(?:absolute|relative|fixed|grid|flex|items-center|justify-center|gap-\d+|space-y-\d+|rounded(?:-[\w\[\]-]+)?|shadow(?:-[\w\[\]-]+)?|mx-auto|max-w-[\w\[\]-]+|px-\d+|py-\d+|w-full|min-h-screen|text-[\w\[\]:/-]+|bg-[\w\[\]:/-]+|from-[\w\[\]:/-]+|to-[\w\[\]:/-]+|h-\[[^"']+\]|md:[\w\[\]:/-]+)\b)/i.test(inputContent);
}

function ensureCanvasHeadResource(resourceSelector, createNode) {
    if (document.head.querySelector(resourceSelector)) return;
    const node = createNode();
    if (node) {
        document.head.appendChild(node);
    }
}

function ensureCanvasCompatibilityResources(inputContent) {
    if (looksLikeTailwindDrivenCanvas(inputContent)) {
        ensureCanvasHeadResource('script[src*="cdn.tailwindcss.com"]', () => {
            const script = document.createElement('script');
            script.src = 'https://cdn.tailwindcss.com';
            script.defer = true;
            return script;
        });
    }

    if (typeof inputContent === 'string' && /data-lucide\s*=/i.test(inputContent)) {
        ensureCanvasHeadResource('script[src*="lucide"]', () => {
            const script = document.createElement('script');
            script.src = 'https://unpkg.com/lucide@latest';
            script.defer = true;
            script.onload = () => {
                try {
                    if (window.lucide && typeof window.lucide.createIcons === 'function') {
                        window.lucide.createIcons();
                    }
                } catch (error) {
                    console.warn('Lucide compatibility hydration failed.', error);
                }
            };
            return script;
        });
    }
}

function detectCanvasLayoutMode(inputContent, options = {}) {
    if (options.layoutMode) return options.layoutMode;
    if (typeof inputContent !== 'string') return 'standard';

    const trimmed = inputContent.trim();
    if (/data-(?:shell|cc)-layout\s*=\s*["'](?:free|raw|immersive)["']/i.test(trimmed)) {
        return 'free';
    }

    if (looksLikeTailwindDrivenCanvas(trimmed)) {
        return 'free';
    }

    return 'standard';
}

function createCanvasSurface(layoutMode, inputContent) {
    if (layoutMode === 'free') {
        if (typeof inputContent === 'string' && /id\s*=\s*["']learning-content["']/i.test(inputContent)) {
            const hostElement = document.createElement('div');
            hostElement.className = 'canvas-content-host';
            hostElement.dataset.contentLayout = 'free';
            hostElement.innerHTML = inputContent;
            const contentRoot = hostElement.querySelector('#learning-content') || hostElement;
            return { hostElement, contentRoot, ownsInjectedMarkup: true };
        }

        const contentRoot = document.createElement('div');
        contentRoot.id = 'learning-content';
        contentRoot.className = 'canvas-content-host';
        contentRoot.dataset.contentLayout = 'free';
        return { hostElement: contentRoot, contentRoot, ownsInjectedMarkup: false };
    }

    const wrapper = document.createElement('div');
    wrapper.className = 'wrapper';
    const container = document.createElement('div');
    container.className = 'container';
    container.id = 'learning-content';
    wrapper.appendChild(container);
    return { hostElement: wrapper, contentRoot: container, ownsInjectedMarkup: false };
}

function mountLegacyJsonPayload(jsonData, placeholder) {
    currentCanvasLayoutMode = 'standard';
    currentDataPayload = jsonData;
    trace('System', 'PayloadStored', { canvasId: jsonData.canvasId || canvasId, type: 'JSON' });

    const surface = createCanvasSurface('standard');
    const contentRoot = surface.contentRoot;

    jsonData.contentBlocks.forEach((block, index) => {
        try {
            const blockElement = renderBlock(block, index);
            if (blockElement) contentRoot.appendChild(blockElement);
        } catch (error) {
            contentRoot.appendChild(createErrorBlock(error, block));
        }
    });

    placeholder.innerHTML = '';
    placeholder.appendChild(surface.hostElement);

    return {
        title: jsonData.title,
        contentRoot
    };
}

function mountCanvasHtml(inputContent, placeholder, options = {}) {
    const normalized = normalizeCanvasHtmlInput(inputContent);
    const htmlContent = normalized.htmlContent;
    ensureCanvasCompatibilityResources(inputContent);
    const layoutMode = detectCanvasLayoutMode(htmlContent, {
        ...options,
        layoutMode: options.layoutMode || normalized.layoutHint || null
    });
    currentCanvasLayoutMode = layoutMode;

    if (normalized.placeholderAttrs) {
        ['data-subject', 'data-concept', 'data-type', 'data-shell-layout', 'data-cc-layout'].forEach((attrName) => {
            if (Object.prototype.hasOwnProperty.call(normalized.placeholderAttrs, attrName)) {
                placeholder.setAttribute(attrName, normalized.placeholderAttrs[attrName]);
            } else {
                placeholder.removeAttribute(attrName);
            }
        });
    }

    currentDataPayload = {
        type: 'html_source',
        rawHtml: htmlContent,
        canvasId,
        title: options.title
    };

    trace('System', 'PayloadStored', { canvasId, type: 'HTML', layout: layoutMode });

    const surface = createCanvasSurface(layoutMode, htmlContent);
    if (!surface.ownsInjectedMarkup) {
        surface.contentRoot.innerHTML = htmlContent;
    }

    placeholder.innerHTML = '';
    placeholder.appendChild(surface.hostElement);

    if (typeof renderLatexInNode === 'function') {
        renderLatexInNode(surface.contentRoot);
    }

    if (typeof hydrateDOM === 'function') {
        hydrateDOM(surface.contentRoot);
    } else {
        console.warn('hydrateDOM function not found.');
    }

    if (window.lucide && typeof window.lucide.createIcons === 'function') {
        try {
            window.lucide.createIcons();
        } catch (error) {
            console.warn('Lucide icon hydration skipped after mount.', error);
        }
    }

    return {
        title: options.title,
        contentRoot: surface.contentRoot,
        layoutMode
    };
}

function mountCanvasContent(inputContent, options = {}) {
    const shellState = ensureCoreShellMounted({ forceRemount: !!options.forceRemountShell });
    const placeholder = shellState.placeholder;

    if (!placeholder) {
        throw new Error('Canvas placeholder was not mounted.');
    }

    const jsonData = parseCanvasPayload(inputContent);
    if (jsonData && jsonData.contentBlocks) {
        return mountLegacyJsonPayload(jsonData, placeholder);
    }

    return mountCanvasHtml(inputContent, placeholder, options);
}

function renderCanvasRuntime(inputContent, title_from_ai, canvasId_from_ai, options = {}) {
    if (!isOfficialCanvasRuntime()) {
        document.body.innerHTML =
            '<div style="font-family: sans-serif; text-align: center; padding: 40px; color: #888;">' +
            '<h1>Access Denied</h1>' +
            '<p>This application can only be run from the official deployment environment.</p>' +
            '<p>This runtime is restricted to the official deployment.</p>' +
            '</div>';
        return;
    }

    try {
        upsertCanvasMeta(canvasId_from_ai);
        const result = mountCanvasContent(inputContent, {
            title: title_from_ai,
            layoutMode: options.layoutMode,
            forceRemountShell: options.forceRemountShell
        });

        document.title = result.title || title_from_ai || document.title;
        const coreBootstrap = typeof initializeCoreFeatures === 'function'
            ? initializeCoreFeatures
            : window.initializeCoreFeatures;

        if (typeof coreBootstrap !== 'function') {
            throw new Error('initializeCoreFeatures is not defined');
        }

        coreBootstrap();
    } catch (error) {
        console.error('Fatal Error in renderCanvasRuntime:', error);
        const placeholder = document.getElementById('ai-content-placeholder');
        if (placeholder) {
            placeholder.innerHTML = '';
            placeholder.appendChild(createErrorBlock(error, { raw: inputContent }));
        }
    }
}

function renderAppShell(inputContent, title_from_ai, canvasId_from_ai) {
    renderCanvasRuntime(inputContent, title_from_ai, canvasId_from_ai);
}

if (typeof window !== 'undefined') {
    window.ensureCoreShellMounted = ensureCoreShellMounted;
    window.mountCanvasContent = mountCanvasContent;
    window.renderCanvasRuntime = renderCanvasRuntime;
    window.renderAppShell = renderAppShell;
}
