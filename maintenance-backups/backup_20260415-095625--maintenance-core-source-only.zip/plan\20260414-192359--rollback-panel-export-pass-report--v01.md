## Summary

직전 `panel clamp + live-export-only` 패스를 롤백했다. 원복 범위는 export header 단순화와 panel restore clamp 로직이며, 목적은 로드 실패 이전 상태로 되돌리는 것이다.

## Rolled back

- `Ailey/src/00_shell/000_shell_template.js`
  - direct live export button 제거
  - 기존 export dropdown 구조 복원

- `Ailey/src/02_utils/013_utils_panel_manager.js`
  - latest viewport clamp helper / resize reclamp / post-mount clamp 제거
  - 이전 panel state apply 흐름으로 복원

- `Ailey/src/03_core/120_core_main_initializer.js`
  - direct live export binding 제거
  - export dropdown toggle / static export / live export handlers 복원

- `Ailey/src_css/010_widget_header_addons.css`
  - export wrapper 스타일 복원
  - tool button reset 추가분 제거

## Bundle

- `Ailey/bundle/main.js`
- `Ailey/bundle/main.css`

## Validation

lightweight rollback harness로 shell bootstrap 재확인:

- `chatPanel=true`
- `notesPanel=true`
- `pageErrors=[]`
- `consoleErrors=[]`

검증은 local bundle을 직접 참조하는 임시 harness로 수행했고, 최소 조건인 shell mount 정상화만 확인했다.

## Publish

- publish repo bundle synced
- ready for rollback commit / push
