/* --- Ailey & Bailey Canvas --- */
// File: 112_core_api_settings_ui_structure.js
// Version: 4.0 (Compact Memory Toggle)
// Description: Builds the API preset workspace modal with advanced settings for context, sampling, grounding, and thinking budget.

function createApiSettingsModal() {
    const modal = document.createElement('div');
    modal.id = 'api-settings-modal-overlay';
    modal.className = 'custom-modal-overlay';
    modal.innerHTML = `
        <div class="custom-modal api-settings-modal">
            <div class="api-settings-layout">
                <div class="api-preset-list-container">
                    <div class="api-preset-list-header">
                        <span class="api-panel-kicker">Model Workspace</span>
                        <h3>API 프리셋</h3>
                        <p class="api-panel-helper">활성 연결을 전환하고 모델, 키, 사용량을 한곳에서 관리합니다.</p>
                    </div>
                    <div id="api-preset-list"></div>
                    <button id="api-add-new-preset-btn" class="notes-btn api-add-preset-btn" style="width: 100%;">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z" /></svg>
                        <span>새 프리셋 추가</span>
                    </button>
                </div>
                <div class="api-preset-editor-container">
                    <div class="api-editor-header">
                        <div class="api-editor-heading">
                            <span class="api-panel-kicker">Preset Editor</span>
                            <h3 id="api-editor-title">프리셋 편집</h3>
                            <p id="api-editor-status-text" class="api-editor-status-text">프리셋을 선택하면 연결 정보, 모델 구성, 토큰/생성 설정을 여기에서 조정할 수 있습니다.</p>
                        </div>
                        <div id="api-editor-active-chip" class="api-editor-active-chip">선택됨</div>
                    </div>
                    <div class="api-settings-tabs">
                        <button class="api-settings-tab-btn active" data-tab="basic">기본 설정</button>
                        <button class="api-settings-tab-btn" data-tab="advanced">고급 설정</button>
                        <button class="api-settings-tab-btn" data-tab="usage">사용량</button>
                    </div>
                    <div class="api-settings-tab-panels">
                        <div id="api-settings-tab-basic" class="api-settings-tab-panel active">
                            <div class="api-form-section">
                                <label for="api-preset-name-input">프리셋 이름</label>
                                <input type="text" id="api-preset-name-input" placeholder="예: 개인용 OpenAI">
                            </div>
                            <div class="api-form-section">
                                <label for="api-key-input">API 키</label>
                                <div class="api-key-wrapper">
                                    <input type="password" id="api-key-input" placeholder="sk-..., gsk_...">
                                    <button id="verify-api-key-btn">키 검증 및 모델 불러오기</button>
                                </div>
                                <div id="api-key-status"></div>
                            </div>
                            <div class="api-form-section">
                                <label for="api-model-select">사용 모델</label>
                                <input type="search" id="api-model-search-input" placeholder="모델 이름 검색..." style="margin-bottom: 8px; display: none;">
                                <select id="api-model-select" disabled></select>
                            </div>
                        </div>
                        <div id="api-settings-tab-advanced" class="api-settings-tab-panel">
                            <div class="api-form-section">
                                <label for="max-output-tokens-input">최대 출력 토큰</label>
                                <input type="number" id="max-output-tokens-input" placeholder="65536">
                                <small>모델이 한 번에 생성할 수 있는 최대 응답 길이를 제한합니다.</small>
                            </div>
                            <div class="api-form-section">
                                <label for="chat-history-limit-input">참조할 이전 대화 수</label>
                                <input type="number" id="chat-history-limit-input" min="0" max="100" step="1" placeholder="20">
                                <small>0으로 두면 이전 대화를 문맥으로 사용하지 않습니다.</small>
                            </div>
                            <div class="api-form-section">
                                <div class="api-slider-group">
                                    <label for="chat-auto-compact-toggle">이전 대화 오토 컴팩트</label>
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="chat-auto-compact-toggle" checked>
                                        <span class="slider"></span>
                                    </label>
                                </div>
                                <small>기본값은 켜짐입니다. 참조 한도만큼 대화가 쌓이면 이전 문맥을 압축 메모리로 정리해 계속 참조합니다.</small>
                            </div>
                            <div class="api-form-section">
                                <div class="api-slider-group">
                                    <label for="api-temperature-slider">온도 (Temperature)</label>
                                    <span id="api-temperature-value">1.00</span>
                                </div>
                                <input type="range" id="api-temperature-slider" min="0" max="2" step="0.01" value="1">
                                <small>낮을수록 보수적이고 높을수록 창의적인 응답이 생성됩니다.</small>
                            </div>
                            <div class="api-form-section">
                                <div class="api-slider-group">
                                    <label for="api-top-p-slider">Top P</label>
                                    <span id="api-top-p-value">0.95</span>
                                </div>
                                <input type="range" id="api-top-p-slider" min="0" max="1" step="0.01" value="0.95">
                                <small>낮을수록 더 좁은 후보만 골라 안정적인 응답을 만듭니다.</small>
                            </div>
                            <div class="api-form-section grounding-toggle-section" style="display: none;">
                                <div class="api-slider-group">
                                    <label for="google-grounding-toggle">Google Search Grounding 사용</label>
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="google-grounding-toggle">
                                        <span class="slider"></span>
                                    </label>
                                </div>
                                <small>최신 정보가 필요한 응답에서 Google 검색을 함께 사용합니다.</small>
                            </div>
                            <div class="api-form-section thinking-budget-section" style="display: none;">
                                <div class="api-slider-group">
                                    <label for="thinking-budget-toggle">Thinking Budget 사용</label>
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="thinking-budget-toggle">
                                        <span class="slider"></span>
                                    </label>
                                </div>
                                <div id="thinking-budget-controls" class="disabled">
                                    <div class="api-slider-group">
                                        <label for="api-thinking-budget-slider">값</label>
                                        <span id="api-thinking-budget-value">0</span>
                                    </div>
                                    <input type="range" id="api-thinking-budget-slider" min="0" max="32768" step="128" value="0">
                                </div>
                                <small>복잡한 추론에 더 많은 토큰을 배정할 때 사용합니다.</small>
                            </div>
                        </div>
                        <div id="api-settings-tab-usage" class="api-settings-tab-panel">
                            <div class="api-form-section token-usage-section">
                                <label>누적 사용량</label>
                                <div id="token-usage-display-grid"></div>
                                <button id="reset-token-usage-btn">사용량 초기화</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-modal-actions">
                <button id="api-settings-delete-btn" class="modal-btn cancel">프리셋 삭제</button>
                <button id="api-settings-cancel-btn" class="modal-btn">닫기</button>
                <button id="api-settings-save-btn" class="modal-btn confirm">저장 및 활성화</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}
