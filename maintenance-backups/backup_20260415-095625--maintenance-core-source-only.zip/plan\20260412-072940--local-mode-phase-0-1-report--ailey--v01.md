# Ailey Local Mode Phase 0-1 Report

- Artifact Type: implementation-report
- Created: 2026-04-12 07:29:40 +09:00
- Scope: Execute Phase 0 and Phase 1 from `20260412-070400--local-mode-plan--ailey--v01.md`
- Status: completed

---

## Summary

Phase 0 and Phase 1 are now implemented in source.

- Added `LocalFirebaseShim` as a Firestore-like local persistence layer.
- Split runtime initialization into Canvas mode and Local mode.
- Removed the host-lock guard for Local mode while preserving the Canvas guard.
- Rebuilt `bundle/main.js` and `bundle/main.css` successfully after the source changes.

---

## Implemented Changes

### 1. `src/01_state/002_local_firebase_shim.js`

Added a new local storage shim with the following behavior:

- IndexedDB-backed persistence in browser environments.
- Automatic in-memory fallback when `indexedDB` is unavailable, which also enables Node smoke testing.
- Firestore-like collection, document, query, batch, and snapshot APIs.
- Compatibility shims for `firebase.firestore.FieldValue` and `firebase.firestore.Timestamp`.
- Query support for `where`, `orderBy`, `limit`, and `startAfter`.
- Listener support for `onSnapshot()` and `QuerySnapshot.docChanges()`.
- Subcollection support through path-based document storage.

### 2. `src/03_core/100_core_firebase.js`

Reworked initialization flow:

- `typeof __firebase_config !== 'undefined'` is now the runtime switch.
- Canvas mode keeps the Firebase auth + Firestore path.
- Local mode now installs the shim compatibility layer, creates a local user, and wires all collection refs to local collections.
- Shared post-init steps now run in both modes:
  `loadUserSettingsFromFirebase()`, `seedDefaultData()`, `initializeListeners()`, and `setupSystemInfoWidget()`.

### 3. `src/00_shell/005_shell_part6_main_assembler.js`

Adjusted the deployment guard:

- Canvas mode still enforces the official deployment source check.
- Local mode bypasses that guard so a local entry page can call `renderAppShell()` later in Phase 2.

---

## Verification

Executed checks:

1. `node --check Ailey/src/01_state/002_local_firebase_shim.js`
2. `node --check Ailey/src/03_core/100_core_firebase.js`
3. `node --check Ailey/src/00_shell/005_shell_part6_main_assembler.js`
4. Node smoke test for local shim behavior:
   add/get/update, `arrayUnion`, query filtering, ordering, `startAfter`, batch writes, subcollections, and listener callbacks
5. `node ./bundler.js` in `Ailey`

Observed result:

- All syntax checks passed.
- The shim smoke test passed.
- Bundling completed successfully and regenerated `bundle/main.js` and `bundle/main.css`.

---

## Residual Risks

- Phase 2 is still pending, so there is no dedicated local `index.html` entry point yet.
- Browser-level Local mode UX was not manually exercised in a real DOM session during this phase.
- The shim currently implements the Firestore surface used by the repo; unsupported Firestore features outside that surface are still intentionally absent.

---

## Next Recommended Step

Proceed to Phase 2:

- add a local entry page,
- boot `renderAppShell()` outside Gemini Canvas,
- and validate Local mode in an actual browser session.
