# Work Plan: User Message Toolbar Anchor Fix

- Timestamp: 2026-04-14 22:51 KST
- Type: narrow fix
- Status: completed
- Scope: correct the hover/tap action toolbar position for user-authored chat messages without changing compact indicators or other chat behaviors

## Understanding

The current hover action toolbar for user messages appears at the far left edge of the chat area instead of next to the user bubble. The likely cause is a desktop-only `user-toolbar` CSS override that anchors the toolbar to the left side of the full-width row container.

## Goals

- Keep the toolbar overlay behavior with no message layout shift.
- Place user-message actions near the user bubble instead of the far left edge.
- Preserve mobile tap behavior.
- Validate before publishing.

## Steps

1. Remove the desktop-only left-side anchor override for `.message-toolbar.user-toolbar`. Completed.
2. Rebuild the bundle and run a focused harness that checks user-message toolbar geometry on desktop and mobile. Completed.
3. Publish only if the toolbar remains overlayed, stable, and visually anchored near the user message. Completed.

## Rollback Boundary

- `Ailey/src_css/009_message_toolbar.css`
- `Ailey/bundle/main.css`
- `visual-tests/validate_user_message_toolbar_anchor.mjs`

## Scoreboard

- Current score: 100
- Score source: user
- Last updated: 2026-04-14 22:51 KST
- Score rationale: user previously awarded 100 and the active request is a narrow follow-up polish fix
- What improved: prior compaction and overlay work is accepted
- What remains unsatisfactory: user-message toolbar anchor is visibly wrong on desktop
- Next score action: keep 100 by fixing the anchor without regressing hover stability or mobile behavior

### Score History

- 2026-04-14 22:51 KST | 100 | user | carried forward from the previously accepted pass; current request is a narrow refinement

## Verification

- `visual-tests/user-message-toolbar-anchor-2026-04-14T13-50-32-856Z/validation-summary.txt`
- Desktop: `desktopToolbarNearRightSide=true`
- Desktop: `desktopToolbarNotFarLeft=true`
- Desktop: `desktopHeightStableOnHover=true`
- Mobile: `mobileToolbarNearMessage=true`
- Mobile: `mobileHeightStable=true`
- Runtime: `pageErrorCount=0`, `consoleErrorCount=0`
