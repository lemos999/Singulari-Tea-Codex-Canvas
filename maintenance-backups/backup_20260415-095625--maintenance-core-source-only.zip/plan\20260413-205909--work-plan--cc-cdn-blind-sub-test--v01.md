Plan Type: Work Plan
Workstream: Blind `/sub` validation of `.cc` head-level CDN freedom
Version: v01
Status: Completed
Created: 2026-04-13 20:59:09 +09:00
Last Updated: 2026-04-13 21:42:00 +09:00
Supersedes or Related Plan: Related `plan/20260413-203935--work-plan--cc-cdn-head-expansion--v01.md`; Related `plan/20260413-203935--cc-cdn-head-expansion-report--v01.md`
Current Completion State: The blind `/sub` batch, original runtime renders, late audits, bounded prompt repair, and targeted re-verification are complete. The original batch soft-failed because two technical artifacts used a brittle Tailwind CDN bootstrap. After prompt hardening and targeted rerun verification, the workstream is accepted as a pass after bounded repair.
Completed So Far: The `/sub` run kit was created, two blind generation workers produced four artifacts, the artifacts were landed into `visual-tests/`, local runtime screenshots and DOM checks were captured, late audit findings were written, `cc_universal_module_mm.md` was hardened for safe CDN bootstrap and stronger free-layout signaling, and the affected technical pages were revalidated through a safe-bootstrap rerun.
Remaining Work: No implementation work remains inside this run. The next meaningful step is user-side live usage, followed by another targeted fix only if a new real runtime issue appears.
Current Blockers: No active blocker remains. Residual risk is limited to runtime display-state differences for chat and notes panels on some technical pages, which stayed mounted but hidden by default during technical-page reruns.
Next Step: Deliver the final report and wait for live user feedback.

# Scoreboard

Current Score: 50 / 100
Score Source: provisional
Last Updated: 2026-04-13 21:42:00 +09:00
Score Rationale: The user still has not given an explicit score, so the score remains provisionally capped at `50` by contract. Quality confidence improved materially because the blind batch exposed a real defect, the prompt was repaired in a bounded way, and the targeted rerun removed the original pageerror on both affected technical artifacts.
What Improved:
1. The prompt now has an explicit safe pattern for CDN global bootstrap instead of relying on fragile implied behavior.
2. The run now has real blind evidence across four subject families, not just handcrafted fixtures.
3. The original technical failure was repaired and the targeted rerun verified that the pageerror disappeared.
What Remains Unsatisfactory:
1. The repaired prompt has not yet been re-run through a second full blind worker batch; the repair was verified through a targeted rerun instead.
2. The technical pair still defaults chat and notes panels to hidden runtime state, even though the panels remain mounted.
3. CDN breadth is proven, but the technical pair still leans on a narrower Tailwind plus Bootstrap Icons stack than the route and field-guide pair.
Actions To Raise Or Maintain The Score:
1. Let the user try the repaired prompt in live use.
2. If a new failure appears, prefer a bounded repair plus targeted rerun again before widening scope.
3. If the user wants higher confidence, run one more full blind worker batch after the prompt hardening.

Score History:
1. 2026-04-13 20:59:09 +09:00 | score 50 | source provisional | New approved blind `/sub` validation run opened for the broadened `.cc` CDN contract.
2. 2026-04-13 21:42:00 +09:00 | score 50 | source provisional | Blind batch completed, bounded prompt repair landed, and targeted safe-bootstrap rerun removed the original technical pageerrors.

# Objective

Determine whether the current `cc_universal_module_mm.md` actually causes blind `.cc` artifacts to take advantage of head-level CDN freedom, including Tailwind and non-Tailwind CDN resources, while preserving the runtime-owned shell and avoiding quiet regression into generic article scaffolds or full standalone-page takeovers.

This run is not a gentle smoke test. It should pressure the prompt in at least four materially different subject families and require reviewers to score both the expressive upside and the shell-safety downside. If the batch materially fails, the run should repair the prompt and rerun within this same workstream as long as the fix remains bounded and evidence-led.

# Confirmed Facts

The current prompt now allows broad head-level CDN use, explicitly states that there is no CDN whitelist, and permits full Tailwind CDN use plus other public CDN assets.

The current prompt still preserves `.cc` as the only public trigger and still frames the canonical bootstrap shell as the required handoff skeleton.

The user wants a real blind `/sub` test rather than another parent-authored fixture-only check.

The user explicitly wants maximum reasoning and is willing to spend time on a recursive repair loop if needed.

# Working Assumptions

The safest assumption is that a strong pass requires at least four blind artifacts across distinct composition families rather than one or two cherry-picked wins.

The next safest assumption is that the batch should include at least one route or geography topic, one comparative topic, one natural-history or cultural topic, and one system or protocol topic, because those families pressure different parts of the prompt.

Another safe assumption is that generators should be blinded from previous validation fixtures to reduce prompt contamination and self-fulfilling outputs.

The final safe assumption is that a material failure means either:

1. CDN freedom is not used when it would obviously help,
2. the same house layout keeps reappearing,
3. the artifact tries to behave like a standalone full-page app instead of a runtime-mounted `.cc` payload,
4. shell surfaces become unreadable or conceptually erased,
5. the page depends on unstable or credentialed surfaces for core reading flow.

# Planned Validation Matrix

Topic family targets:

1. route / geography / expansion or travel system
2. comparison-heavy concept pair
3. natural-history or culture-led subject
4. protocol, system, or process-heavy subject

Success signals:

1. at least some artifacts visibly use head-level CDN resources beyond the baseline shell
2. at least one artifact uses Tailwind CDN meaningfully
3. at least one artifact uses another CDN resource such as an icon library, animation library, or helper script
4. shell selectors remain present after render
5. the batch shows real page-shape variety rather than one scaffold repeated
6. none of the artifacts duplicates or impersonates runtime-owned chrome

Failure signals:

1. every artifact stays on plain bundle-only styling despite the prompt allowing more
2. generated pages add CDN resources but still collapse into the same scaffold
3. generated pages use CDN resources in ways that conceptually erase the runtime shell
4. generated pages rely on blocked or credentialed external flows for the main reading path
5. comparison topics do not visibly stage contrast
6. route or place topics do not become spatial

# Execution Design

Execution mode will be `mixed`.

Stage 1:

Two parallel blind generation workers, each responsible for two prompts and returning final `.cc` HTML artifacts only.

Stage 2:

The parent lands the artifacts into the primary workspace under a run-specific `visual-tests/` directory, renders them through the local runtime path, and captures screenshots plus DOM evidence.

Stage 3:

Two late read-only auditors run in parallel:

1. composition and freedom auditor
2. shell safety and runtime ownership auditor

If either auditor returns a material fail, the parent will decide whether the fix is bounded enough to repair immediately and rerun.

# Definition Of Done

This run is complete when:

1. the blind generation batch exists on disk,
2. runtime renders and screenshots exist,
3. late audit verdicts exist,
4. any material issue has either been repaired and rerun or clearly documented as an open blocker,
5. the final acceptance record says whether the prompt truly passes this harsher blind test.
