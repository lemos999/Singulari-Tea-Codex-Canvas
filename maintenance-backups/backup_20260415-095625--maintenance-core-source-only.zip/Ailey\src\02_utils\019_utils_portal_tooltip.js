/* --- Ailey & Bailey Canvas --- */
// File: 019_utils_portal_tooltip.js
// Version: 1.0
// Description: Manages a single, global "portal" tooltip to avoid clipping issues.

function initializePortalTooltip() {
    const tooltipElement = document.getElementById('portal-tooltip');
    if (!tooltipElement) {
        console.warn('Portal tooltip element not found. Tooltips will not function.');
        return;
    }

    let hideTimeout;

    const showTooltip = (event) => {
        clearTimeout(hideTimeout);
        const target = event.target.closest('[data-tooltip]');
        if (!target) {
            // If moving from a tooltip-enabled element to one without, hide it
            if (tooltipElement.classList.contains('visible')) {
                 hideTooltip();
            }
            return;
        }

        const tooltipText = target.getAttribute('data-tooltip');
        if (!tooltipText) return;

        tooltipElement.textContent = tooltipText;
        positionTooltip(event, target, tooltipElement);

        if (!tooltipElement.classList.contains('visible')) {
            tooltipElement.classList.add('visible');
        }
    };

    const hideTooltip = () => {
        // A small delay prevents flickering when moving between adjacent elements
        hideTimeout = setTimeout(() => {
            tooltipElement.classList.remove('visible');
        }, 50);
    };

    const positionTooltip = (event, target, tooltip) => {
        const targetRect = target.getBoundingClientRect();
        
        const gap = 10;
        // Start by assuming the tooltip is above the target
        let top = targetRect.top - tooltip.offsetHeight - gap;
        let left = targetRect.left + (targetRect.width / 2) - (tooltip.offsetWidth / 2);

        // If tooltip goes off the top of the screen, place it below the target
        if (top < 5) {
            top = targetRect.bottom + gap;
        }

        // Prevent going off the left/right edges
        if (left < 5) {
            left = 5;
        }
        if (left + tooltip.offsetWidth > window.innerWidth - 5) {
            left = window.innerWidth - tooltip.offsetWidth - 5;
        }

        tooltip.style.top = `${top}px`;
        tooltip.style.left = `${left}px`;
    };

    // Use event delegation on the body for performance and to catch dynamically added elements
    document.body.addEventListener('mouseover', showTooltip);
    document.body.addEventListener('mouseout', hideTooltip);
    
    // Also track mousemove to reposition if necessary (useful for multi-line tooltips)
    document.body.addEventListener('mousemove', (e) => {
        if(tooltipElement.classList.contains('visible')) {
            const target = e.target.closest('[data-tooltip]');
             if (target) {
                positionTooltip(e, target, tooltipElement);
            }
        }
    });

    trace("System", "PortalTooltipInitialized");
}
