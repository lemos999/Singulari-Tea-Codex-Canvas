﻿# Work Plan: Roll Back Official Runtime Hardening To Maintenance Backup

- Timestamp: 2026-04-15 07:02 KST
- Owner: Codex
- User approval: granted in request
- Type: rollback
- Status: completed
- Scope: restored the curated maintenance source set from `backup_20260415-055900--maintenance-core-source-only.zip` and republished the restored runtime

## Understanding

The user wanted the recent official-runtime hardening and address obfuscation removed and asked for a rollback to the earlier curated maintenance backup archive. The rollback target was the named maintenance backup, not the entire workspace.

## Completed So Far

- Inspected `backup_20260415-055900--maintenance-core-source-only.zip` and confirmed it contained the curated source, CSS, vendor, plan, and publish bundle files required for rollback.
- Extracted the archive to a staging directory and restored the curated maintenance set back into the workspace.
- Restored these hardening-affected files from the backup snapshot:
  - `Ailey/src/00_shell/005_shell_part6_main_assembler.js`
  - `Ailey/src/02_utils/018_utils_html_exporter.js`
  - `Ailey/src/03_core/120_core_main_initializer.js`
  - `Singulari-Tea-Codex-Canvas-pr/bundle/main.js`
- Confirmed the hardening helper names no longer exist in the restored source.
- Confirmed the restored source files and publish `main.js` exactly match the extracted backup snapshot by SHA-256 hash.
- Pushed the publish-repo rollback to `lemos999/Singulari-Tea-Codex-Canvas` on `main` as commit `361b353`.

## Verification

- Archive content check: the named backup contained the rollback target files.
- Source hardening marker check: `rg -n "getOfficialRuntimeBase|enforceOfficialRuntimeAccess|LIVE_EXPORT_BUNDLE_BASE_SEGMENTS|official-runtime"` returned no matches in the restored hardening-affected files.
- Hash equality check:
  - `Ailey/src/00_shell/005_shell_part6_main_assembler.js` matches extracted backup hash.
  - `Ailey/src/02_utils/018_utils_html_exporter.js` matches extracted backup hash.
  - `Ailey/src/03_core/120_core_main_initializer.js` matches extracted backup hash.
  - `Singulari-Tea-Codex-Canvas-pr/bundle/main.js` matches extracted backup hash.
- Publish repo status before commit showed only `bundle/main.js` changed.
- Publish push succeeded: `3ed3a46..361b353  main -> main`.

## Remaining Work

- Await user confirmation that the restored runtime behaves as expected.
- If a later hardening pass is revisited, use a safer bounded design with explicit rollback notes.

## Rollback Boundary

- `plan/`
- `Ailey/src/`
- `Ailey/src_css/`
- `Ailey/vendor/`
- `Ailey/dist/katex-styles.js`
- `Ailey/bundler.js`
- `Ailey/package.json`
- `Ailey/package-lock.json`
- `Ailey/index.html`
- `Singulari-Tea-Codex-Canvas-pr/bundle/main.js`
- `Singulari-Tea-Codex-Canvas-pr/bundle/main.css`
- `Singulari-Tea-Codex-Canvas-pr/katex.min.css`
- `Singulari-Tea-Codex-Canvas-pr/.github/workflows/static.yml`

## Scoreboard

- Current score: 50
- Score source: provisional
- Last updated: 2026-04-15 07:08 KST
- Score rationale: the requested rollback is complete and published, but user confirmation is still pending
- What improved: the workspace and publish runtime now match the named maintenance backup snapshot
- What remains unsatisfactory: runtime behavior still needs user confirmation after deployment
- Next score action: confirm restored behavior with the user and only reopen hardening if there is a new approved plan

### Score History

- 2026-04-15 07:02 KST | 50 | provisional | approved rollback to maintenance backup opened
- 2026-04-15 07:08 KST | 50 | provisional | curated rollback completed and published as commit 361b353
