# Work Plan

Plan Type: Implementation / Refactor / Bundle Reduction
Workstream: Chat Surface Cleanup + Notes Surface Cohesion + Main Bundle Slimming
Version: v01
Status: Completed
Created: 2026-04-13 02:48:22 +09:00
Last Updated: 2026-04-13 03:23:08 +09:00
Related Plan:
- `plan/20260413-013404--chat-surface-refactor-plan--ailey--v01.md`
- `plan/20260413-022832--work-plan--cc-direct-visualization-code-contract--v01.md`
Supersedes: None

Current Completion State:
- User-approved workstream has been implemented.
- Chat surface slimming is complete.
- Notes surface cohesion pass is complete.
- Deprecated notes wrappers and empty CSS shims have been removed.
- Runtime vendor loading has been introduced for Toast UI editor, Prism, and Leaflet.
- Bundle has been rebuilt successfully.
- Syntax and bundle integrity checks have passed.
- Structure documentation has been reconciled with the current notes module layout.

Completed So Far:
- Recorded baseline production bundle size:
  - `Ailey/bundle/main.js` = 2,948,715 bytes
- Reworked the runtime vendor strategy:
  - kept eager core vendors to `firebase-*`, `katex`, `marked`, and `fabric`
  - moved `toastui-editor-all.min.js`, `toastui-editor-plugin-code-syntax-highlight-all.min.js`, `prism.min.js`, and `leaflet.js` behind runtime loaders
- Added `Ailey/src/02_utils/021_utils_vendor_loader.js` for:
  - bundle-relative asset resolution
  - script fallback loading
  - cached runtime gating for Toast UI, Prism, Leaflet, and Fabric
- Updated map rendering to lazy-load Leaflet and instantiate the marker icon only after runtime availability.
- Updated notes editor and recall viewer to lazy-load Toast UI and Prism on first use.
- Updated chat markdown rendering to lazy-load Prism when needed.
- Moved attachment summary responsibility from the helper row to the attachment tray title.
- Slimmed chat surface spacing across:
  - `020_chat_panel_base.css`
  - `021_chat_sidebar.css`
  - `022_chat_messages.css`
  - `023_chat_input.css`
  - `024_chat_controls_modals.css`
- Modernized notes surface spacing across:
  - `015_notes_panel_base.css`
  - `016_notes_list_view.css`
  - `017_notes_editor_view.css`
  - `018_notes_recall_viewer.css`
  - `019_notes_job_ui.css`
- Removed deprecated files:
  - `Ailey/src_css/005_chat.css`
  - `Ailey/src_css/006_notes.css`
  - `Ailey/src/05_features_notes/312_notes_drawing_toolbar.js`
  - `Ailey/src/05_features_notes/330_notes_utils.js`
  - `Ailey/src/05_features_notes/342_notes_job_ui.js`
  - `Ailey/src/05_features_notes/343_notes_utils.js`
  - `Ailey/src/05_features_notes/350_notes_highlights.js`
  - `Ailey/src/05_features_notes/351_notes_highlights.js`
- Rebuilt bundle successfully:
  - `Ailey/bundle/main.js` = 1,756,886 bytes
  - delta = -1,191,829 bytes
  - reduction = 40.4%
- Verified syntax with:
  - `node --check` on edited source files
  - `node --check Ailey/bundle/main.js`
- Updated documentation to match the refactored notes directory:
  - `Ailey/project-structure.txt`

Remaining Work:
1. Optional browser-level manual validation of:
   - opening notes editor after cold start
   - recall editor toggle
   - first syntax-highlighted chat message
   - first map block render
Current Blockers:
- None for code or build.
- Remaining risk is runtime validation in a live browser session, which was not executed in this turn.

Next Step:
- Hand the implementation back for user validation.
- If needed, run browser-first smoke checks and optionally clean up `project-structure.txt`.

Scoreboard:
- Current plan score: 91 / 100
- Confidence rationale:
  - Build succeeded after refactor.
  - Source and bundle syntax checks passed.
  - Bundle reduction is material and measurable.
  - Remaining uncertainty is limited to manual browser interaction coverage.

Score History:
- 2026-04-13 02:48:22 +09:00
  - Score: 42 / 100
  - Reason: Fresh plan created after approval, repo scanned, no implementation yet.
- 2026-04-13 03:19:31 +09:00
  - Score: 91 / 100
  - Reason: Refactor implemented, bundle rebuilt, size delta recorded, syntax checks passed, only manual browser validation remains.

## Objective

Deliver a behavior-preserving refactor that makes the chat input area visibly slimmer and more coherent, modernizes the notes surface so it feels aligned with the current chat shell, and reduces `main.js` as far as reasonably possible without sacrificing current features.

The user explicitly asked for:
- chat input cleanup
- removal of bottom helper text
- smaller composer padding / height
- a thinner and more coherent chat surface overall
- maximum practical bundle reduction
- inspection of vendor + legacy co-bundling
- unused / legacy cleanup
- lazy-load consideration for heavy features
- bundle structure review itself
- notes surface cleanup
- code and file-name integration when beneficial
- retention of current functionality

This means the work is not a cosmetic-only pass. It is a production refactor with three linked goals:
1. reduce visual bulk
2. reduce architectural redundancy
3. reduce bootstrap weight

## Constraints

The following constraints are mandatory:

1. Preserve current features.
   This includes at least:
   - chat send
   - multiline input
   - drag-drop and paste attachments
   - session sidebar
   - API settings and prompt managers
   - notes list/editor/recall flows
   - backup/import/export surfaces
   - drawing tools
   - document translation and batch job UIs
   - rendered content bootstrap through `renderAppShell`

2. Avoid destructive cleanup.
   No blind deletion of “small” or “duplicate-looking” files without verifying references or replacing them safely.

3. Keep rollout incremental.
   Prefer small coherent refactors over a giant rename storm. If naming consolidation is useful, do it where the dependency graph is clear and the surface is already being edited.

4. Maintain startup correctness.
   If lazy loading is introduced, it must not break:
   - local bootstrap in `index.html`
   - exported HTML relying on `bundle/main.js`
   - user interactions that assume a library is ready on demand

5. Maintain export safety.
   This workspace already exports live and static HTML. Any bundler or runtime split must preserve those contracts or degrade gracefully.

## Baseline Findings

### 1. Chat surface

Current chat shell is defined in:
- `Ailey/src/00_shell/003_shell_part4_panel_notes_chat.js`

Important current structure:
- `#chat-panel`
- `#chat-main-view`
- `.chat-messages`
- `#chat-composer-shell`
- `#attached-file-display`
- `form#chat-form.chat-input-form`
- `.chat-composer-meta`
- `#chat-attachment-hint`

Implication:
- The helper text is not runtime-critical. It is a dedicated shell element and can be removed cleanly if no JS depends on it.
- The composer is currently visually padded twice:
  - shell padding in `#chat-composer-shell`
  - form padding in `.chat-input-form`
  - textarea padding in `#chat-input`
- Surface slimming can happen without behavior change by editing shell markup and CSS only, unless some JS assumes the helper element exists.

### 2. Notes surface

Notes shell is co-located in the same shell file:
- `Ailey/src/00_shell/003_shell_part4_panel_notes_chat.js`

But visual shell base is much thinner in:
- `Ailey/src_css/015_notes_panel_base.css`

Implication:
- The notes panel likely accumulated older styles in multiple deeper CSS files, while the shell-level coherence remained under-specified.
- This is a good candidate for shell-level cleanup first, then selective cleanup of deeper view styles if needed.

### 3. Bundle structure

Bundler is in:
- `Ailey/bundler.js`

Current bundler behavior:
- embeds KaTeX styles JS
- concatenates a fixed vendor load order directly into the main bundle
- concatenates all regular source files
- bundles ESM files into an IIFE with esbuild
- minifies with terser

Current vendor load order includes:
- firebase-app-compat.js
- firebase-auth-compat.js
- firebase-firestore-compat.js
- toastui-editor-all.min.js
- prism.min.js
- toastui-editor-plugin-code-syntax-highlight-all.min.js
- katex.min.js
- marked.min.js
- fabric.js
- leaflet.js

Implication:
- Initial `main.js` carries all editor, syntax highlight, math, drawing, map, and firestore surfaces even when the first user action needs only shell bootstrap.
- Biggest size wins are more likely to come from vendor deferral than from shaving small app files.
- However, vendor splitting must be runtime-safe and export-safe.

### 4. Notes duplicate / legacy indicators

The notes feature directory contains both large primary files and several tiny similarly named companions:
- `342_notes_job_ui.js` = 177 bytes
- `344_notes_job_ui.js` = 14940 bytes
- `343_notes_utils.js` = 176 bytes
- `345_notes_utils.js` = 3916 bytes
- `350_notes_highlights.js` = 181 bytes
- `351_notes_highlights.js` = 253 bytes

Observed facts:
- file hashes are different, so they are not literal duplicates
- tiny size strongly suggests wrappers, placeholders, leftovers, or redirect shims

Implication:
- This is a likely cleanup opportunity, but only after reference inspection.
- A safe tactic is:
  - identify call sites
  - determine which names are canonical
  - merge or retire the shim variants

## Design Intent

This refactor should follow the smallest complete design:

### A. Chat surface

Goal:
- make the composer feel denser and more refined without removing capabilities

Expected changes:
- remove helper text row under composer
- reduce composer shell padding
- reduce form padding
- reduce textarea min-height and button footprint slightly
- tighten message/composer separation if needed
- rebalance panel header / control spacing only if it materially improves thinness

Non-goals:
- do not redesign the whole chat product
- do not change behavior or interaction model unless needed for correctness

### B. Notes surface

Goal:
- make notes feel visually part of the same system as chat

Expected changes:
- add stronger shell-level sizing, spacing, and cohesion
- modernize panel body spacing
- normalize header/body transitions
- inspect whether note list/editor/recall surfaces share outdated duplicated styles or wrapper code
- remove or consolidate obvious legacy helper files if safe

Non-goals:
- do not invent a new notes product
- do not rewrite editor or recall logic unless needed for cleanup

### C. Bundle reduction

Goal:
- reduce bootstrap JS size while preserving existing behavior

Preferred order of attack:
1. Remove or merge unneeded legacy app files.
2. Reduce eager vendor loading where the dependency is interaction-gated.
3. Keep bootstrap-safe core runtime eager.
4. Rebuild and measure.

Likely candidates for lazy loading:
- Toast UI editor and syntax highlight plugin
- Prism
- Fabric drawing
- Leaflet
- Possibly KaTeX runtime, depending on immediate render needs

Likely candidates to keep eager:
- shell bootstrap
- panel wiring
- chat core
- message rendering helpers
- content block rendering core if initial page render depends on it
- whichever markdown or sanitization pipeline is needed immediately on first content render
- firebase core if startup immediately reads user/session state

## Assumptions

Safe working assumptions for this plan:

1. The user wants implementation now, not another proposal round.
2. The user prefers runtime-preserving refactor over risky architecture rewrite.
3. Exported and local HTML both matter.
4. A measurable bundle reduction is required, not merely rearranged source code.
5. File renaming is allowed when it improves clarity and can be done safely, but it is not mandatory if the dependency graph makes rename riskier than value.

## Execution Sequence

### Phase 1. Lock baseline and reference graph

Actions:
- inspect JS references to:
  - `chat-attachment-hint`
  - duplicate notes files
  - heavy vendor globals
- inspect the build graph and startup path
- create a backup before functional edits

Exit criteria:
- we know what can be removed or deferred safely

### Phase 2. Chat surface cleanup

Actions:
- remove bottom helper text from shell if unreferenced
- tighten composer markup and CSS
- reduce visual weight of input shell, buttons, and surrounding spacing
- ensure attachment tray still displays correctly

Exit criteria:
- chat panel remains fully functional
- composer looks thinner and more coherent

### Phase 3. Notes surface cohesion pass

Actions:
- strengthen notes shell styles
- align notes spacing with chat styling language
- review and simplify any legacy wrapper files in notes when safe

Exit criteria:
- notes panel no longer feels visually outdated relative to chat

### Phase 4. Bundle slimming

Actions:
- inspect source references for duplicate / shim notes files
- consolidate or remove safe legacy files
- add runtime-safe lazy loading for noncritical heavy vendors
- update bundler to emit a smaller initial bundle while preserving current contracts

Exit criteria:
- rebuilt bundle smaller than baseline
- bootstrap still succeeds

### Phase 5. Verification

Actions:
- rebuild assets
- check for syntax errors
- verify known runtime entrypoints
- record size delta
- document residual risks

Exit criteria:
- work is ready for user validation

## Risks and Mitigations

### Risk 1. Lazy loading breaks first-use flows

Example:
- notes editor opens before Toast UI is loaded
- drawing toggle fires before Fabric is ready

Mitigation:
- gate each heavy feature behind an idempotent loader
- make loaders resolve once and cache the promise
- ensure UI actions await readiness before proceeding

### Risk 2. Duplicate notes files are still referenced indirectly

Mitigation:
- inspect references before delete
- if a legacy name is still imported or expected, convert it into a minimal compatibility shim instead of hard deletion

### Risk 3. Exported HTML assumes vendor globals at page start

Mitigation:
- keep runtime loader inside the main bundle
- load deferred vendor files from stable local relative paths
- preserve global names after load

### Risk 4. CSS slimming causes overflow or cramped mobile layout

Mitigation:
- preserve attachment tray flex behavior
- keep textarea auto-resize
- maintain mobile overrides

## Verification Checklist

- Chat panel opens and closes.
- Chat sidebar collapse still works.
- Chat send on Enter still works.
- Shift+Enter multiline still works.
- File attach button still works.
- Drag-drop into composer still works.
- Paste into composer still works.
- Attachment tray renders and clears correctly.
- Notes panel opens and closes.
- Notes list view still renders.
- Note editor still opens.
- Recall viewer still opens for qualifying notes.
- Translation project modal still works.
- Drawing tools still initialize when needed.
- Export paths still resolve.
- `renderAppShell()` remains exposed.
- `bundle/main.js` is smaller than baseline, or if not, the plan records exactly why and what blocked a safe reduction.

## Definition of Done

This workstream is done when:
- chat composer helper text is removed
- chat surface is visibly slimmer and more coherent
- notes surface is cleaned up enough to match the current system language
- obvious safe code / file consolidation has been completed
- main bundle is reduced meaningfully without losing current features
- final notes include exact files changed, key assumptions, verification performed, and any remaining rollback risk
