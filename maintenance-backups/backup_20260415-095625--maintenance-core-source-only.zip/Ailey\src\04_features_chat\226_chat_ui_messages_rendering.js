/* --- Ailey & Bailey Canvas --- */
// File: 226_chat_ui_messages_rendering.js
// Version: 1.2 (Conditional Collapse Flag)
// Description: Passes the `isNewlyArrived` flag to element factories to control the initial collapsed/expanded state of messages.

function renderChatMessages(sessionData) {
    if (!chatMessages || !sessionData) return;
    if (chatWelcomeMessage) chatWelcomeMessage.style.display = 'none';
    const messages = sessionData.messages || [];
    const fragment = document.createDocumentFragment();
    messages.forEach((msg, index) => {
        let element;
        if (msg.role === 'user') {
            element = createUserMessageElement(msg, false);
        } else if (msg.role === 'ai') {
            element = createAiMessageContainer(msg, index, false);
        }
        if (element) {
            fragment.appendChild(element);
        }
    });
    if (fragment.children.length > 0) {
        chatMessages.innerHTML = '';
        chatMessages.appendChild(fragment);
        autoScrollChat(true);
    }
}

function renderNewMessages(messages) {
    if(messages && messages.length > 0) {
        const msg = messages[0];
        trace("UI.Render", "renderNewMessages.exec", { count: messages.length, role: msg.role }, { sessionId: currentSessionId, msgId: getMessageId(msg) });
    }
    if (!chatMessages) return;
    if (chatWelcomeMessage) chatWelcomeMessage.style.display = 'none';
    const fragment = document.createDocumentFragment();
    messages.forEach((msg, index) => {
        let element;
        if (msg.role === 'user') {
            element = createUserMessageElement(msg, true);
        } else if (msg.role === 'ai') {
            element = createAiMessageContainer(msg, index, true);
        }
        if (element) {
            fragment.appendChild(element);
        }
    });
    chatMessages.appendChild(fragment);
    const shouldForceScroll = messages.some(msg => msg.role === 'user');
    autoScrollChat(shouldForceScroll);
}

function prependMessages(messages) {
    if (!chatMessages || messages.length === 0) return;
    trace("UI", "prependMessages.start", { count: messages.length });

    const fragment = document.createDocumentFragment();
    messages.forEach((msg) => {
        const msgId = getMessageId(msg);
        // [FIX] Duplication Guard Clause
        if (document.querySelector(`.chat-message[data-message-id="${msgId}"]`)) {
            trace("UI", "prependMessages.duplicateSkip", { msgId: msgId.substring(0,10) }, {}, "WARN");
            return;
        }

        let element;
        if (msg.role === 'user') element = createUserMessageElement(msg, false);
        else if (msg.role === 'ai') element = createAiMessageContainer(msg, 0, false);
        
        if (element) fragment.appendChild(element);
    });

    if (fragment.children.length > 0) {
        const oldScrollHeight = chatMessages.scrollHeight;
        chatMessages.prepend(fragment);
        const newScrollHeight = chatMessages.scrollHeight;
        chatMessages.scrollTop += (newScrollHeight - oldScrollHeight);
    }
}

function renderFinalMessage(finalMsg, sessionId) {
    if (!chatMessages) return;
    
    // Remove initial loading bubble (identified by data-message-id)
    const loadingContainer = chatMessages.querySelector(`.ai-response-container[data-message-id="${sessionId}"]`);
    if (loadingContainer) {
        loadingContainer.remove();
    }

    // Remove temporary streaming bubble (identified by new data attribute)
    const streamingContainer = chatMessages.querySelector(`.ai-response-container[data-streaming-session-id="${sessionId}"]`);
    if (streamingContainer) {
        streamingContainer.remove();
    }

    // [SIMPLIFIED] Directly create and append the final message container.
    const newContainer = createAiMessageContainer(finalMsg, -1, true);
    chatMessages.appendChild(newContainer);

    const streamInfo = activeStreams[currentSessionId];
    if (streamInfo) {
        streamInfo.isComplete = true;
        delete activeStreams[currentSessionId];
    }
    autoScrollChat();
    renderSidebarContent(); // Update sidebar to remove loading indicator
}
