# Work Plan

Plan Type: Work Plan
Workstream: Universal `.cc/.ccc` module validation, compression, and recursive refinement
Version: v01
Status: Completed
Created: 2026-04-13 04:03:09 +09:00
Last Updated: 2026-04-13 04:18:12 +09:00
Related Plan:
- `plan/20260413-024822--work-plan--chat-notes-bundle-cohesion-refactor--v01.md`
Supersedes: None

Current Completion State:
- The user approved a `/sub` validation run with maximum reasoning.
- The current English universal module exists at `cc_universal_module_mm.md`.
- The current Korean translation exists at `cc_universal_module_mm_ko.md`.
- The English module has been rewritten into a single serialized insertion payload.
- The latest parent-measured English module size is 4588 characters, which is within the user's stated target ceiling.
- Two read-only high-reasoning workers completed both initial failure analysis and final acceptance revalidation.
- The current approved scope is complete and accepted.

Completed So Far:
- Extracted the existing `.cc/.ccc` contract from the host-specific Ailey prompt.
- Built an initial host-agnostic English module and a separate Korean translation file.
- Confirmed that the current English module attempts to preserve the host prompt's semantic identity while defining `.cc` standard-mode rendering and `.ccc` freestyle rendering.
- Confirmed the initial English module length at 5605 characters and documented the budget failure.
- Confirmed that the upcoming validation must cover trigger handling, placeholder quality, heading hierarchy, semantic emphasis through `strong`, section structure, and host-prompt inheritance.
- Confirmed that the validation must be strict rather than impressionistic and must continue recursively when the module fails objective checks.
- Ran a parallel `/sub` validation with a simulation analyst and a strict MM/spec auditor.
- Captured initial fail verdicts covering size, MM packaging, host leakage, and shell-fidelity gaps.
- Rewrote the English module into a single payload, removed wrapper scaffolding, removed named Ailey workflow leakage, and restored missing hard constraints.
- Re-measured the rewritten module at 4376 characters, then tightened it further to 4588 characters while restoring `keyword-list`, Tailwind body-class intent, graceful API-key handling, and standalone-safe follow-up placement.
- Captured final pass verdicts from both workers.
- Preserved static and worker evidence under `subagent-runs/20260413-040309-cc-module-validation/`.

Remaining Work:
1. None for the approved English-module validation scope.
2. Optional future follow-up: sync `cc_universal_module_mm_ko.md` to the final accepted English module if translation parity is desired.

Current Blockers:
- No active blockers remain for the approved scope.

Next Step:
- Deliver the accepted result and evidence summary to the user.

Objective

The objective of this run is not merely to shorten the universal module or to produce plausible-looking HTML. The objective is to establish whether the current English universal `.cc/.ccc` module can be inserted into an arbitrary host prompt and still cause that host to produce compliant canvas output that preserves host semantics while obeying the `.cc` and `.ccc` contract. The module must be improved until it reaches a practical balance among correctness, transferability, strictness, and compactness. The explicit user target is a reusable universal prompt module with a desired size ceiling of 5000 characters. The acceptance bar therefore includes both behavioral correctness and text-budget discipline.

Scope

This workstream includes prompt analysis, prompt compression, prompt validation, evidence preservation, and edits to the English universal module file. It may also include updates to the Korean translation file if the English module changes materially and translation parity becomes valuable. The workstream does not require changing the Ailey host prompt itself unless a reference comparison is needed for understanding. It does not require deploying new bundles or changing GitHub assets. It does not require browser automation unless later validation reveals that static structural review cannot settle an important ambiguity.

Primary Deliverables

The primary deliverables are an improved `cc_universal_module_mm.md`, preserved validation evidence under `subagent-runs/`, an updated active plan with score history, and a concise final report that states whether the module passed strict validation, where it still remains weak if it did not fully pass, and how close it came to the 5000-character target. Secondary deliverables may include a synchronized Korean translation and compact validation artifacts showing sample merged prompts and generated output excerpts.

User Constraints

The user explicitly requested `/sub` with maximum reasoning for the validation. The user wants strict checking, including whether visualization placeholders are called correctly, whether image placeholders are called correctly, whether header hierarchy and visual distinction feel right, whether `strong` tags are used well, and whether the universal module should be improved recursively when it underperforms. The user wants the universal prompt itself to stay below 5000 characters as a target. The user also framed this as a generic reusable module, so host-specific assumptions must be treated as defects unless they are unavoidable and explicitly justified.

Hidden Rules And Consistency Requirements

The hidden rule underneath the visible request is that a universal module fails if it works only when the host prompt already resembles the Ailey environment. The module must therefore describe a rendering overlay rather than a content engine tied to specific Ailey engines, menu names, or pedagogical states. Another hidden rule is that a transfer module should not rely on vague beauty claims; it should induce concrete structural behavior. A further hidden rule is that placeholder quality must be validated semantically rather than simply counted. A page with one `image-placeholder` and one `visualization-placeholder` may still fail if the prompts are too generic, are not section-specific, or do not reflect the host semantics. There is also a latent MM-quality rule: if the module requires too much explanatory scaffolding outside the insertion block, it weakens the claim of being a drop-in serialized module. Finally, the 5000-character ceiling creates a compression-vs-control tradeoff that must be handled deliberately rather than by removing important constraints at random.

Technical Approach

The most appropriate technical approach is a supervised prompt-evaluation loop. The parent session will prepare merged test prompts composed of one arbitrary host prompt plus the current universal module and a concrete `.cc` or `.ccc` request. Read-only high-reasoning subagents will be used for independent generation and strict review. One worker will focus on forward simulation of outputs from merged prompts. Another worker will focus on strict specification audit, transferability assessment, and compression recommendations. The parent will compare findings, patch the universal module in the primary workspace, measure length again, and rerun the simulation-and-audit loop as needed. The parent remains the only writer in the primary workspace unless a later stage clearly benefits from a bounded writable worker, which is not currently necessary.

Why Delegation Is Justified

Delegation is justified because the user explicitly requested `/sub`, the evaluation requires both forward simulation and independent audit, and the quality bar depends on catching subtle prompt defects that are easier to surface through parallel high-reasoning perspectives than through a single-pass self-judgment. The writable surface is small, so the safest pattern is read-only delegated evaluation plus parent-owned integration. This reduces merge risk while still honoring the explicit multi-agent request.

Phased Work Sequence

Phase 1 establishes the evidence structure, pre-launch report, and current baseline. This includes the current module length, the current host-agnostic claims, and the exact criteria to be tested. Phase 2 launches the read-only workers, one aimed at merged-prompt simulation and one aimed at strict audit. Phase 3 collects the generated artifacts, extracts concrete failures and borderline cases, and ranks them by impact on universality and quality. Phase 4 compresses and refines the module in the primary workspace while preserving critical shell requirements, placeholder requirements, host-inheritance behavior, and `.cc/.ccc` trigger logic. Phase 5 reruns the same validation pattern against the revised module and measures both behavior and character count. Phase 6 closes the loop either by accepting the module as sufficiently validated or by documenting the remaining gap and the next best compression move.

Validation Strategy

Validation will be organized around explicit checks rather than vague impressions. For trigger handling, the merged prompt must keep normal text behavior without `.cc` or `.ccc`, activate standard mode for `.cc`, and activate freestyle mode for `.ccc`. For standard mode, the generated result must include a single HTML5 document with the expected shell pieces, including title, canvas-id, font links, CSS links, script link, loader, `ai-content-placeholder`, semantic header, keywords area, structured sections, summary section, and the `renderAppShell` bootstrap script. For freestyle mode, the generated result must include a single standalone HTML5 file with Tailwind, Font Awesome, font links, custom style space, bespoke content layout, image ids, visualData array, image generation functions, download function, and automatic `DOMContentLoaded` execution. For placeholder quality, each placeholder prompt must be section-specific and semantically bound to the section content rather than generic. For heading hierarchy, the result must use `h1`, `h2`, and `h3` coherently. For emphasis density, each paragraph should use `strong` tags to elevate meaningful terms rather than random nouns. For transferability, the host prompt’s own role and semantic style should still be visible in the content. For MM discipline, the insertion payload should trend toward dense serialized prose and minimal auxiliary scaffolding. For size control, the final English module should be measured directly and compared against the target ceiling of 5000 characters.

Definition Of Done

This run is complete when the English module has been tested against arbitrary host-prompt composition through a supervised `/sub` loop, the resulting outputs have been audited against the strict criteria, the module has been iteratively improved if needed, the final English module size has been measured, the evidence files have been saved, and the final result clearly states whether the module passed, partially passed, or still failed the acceptance bar. If the final module remains above 5000 characters but the remaining path to reduction is clear and documented, the run may still be considered partially successful, but it should not be represented as fully meeting the stated target.

Risks

The first major risk is false confidence from simulated outputs that appear structurally correct while quietly under-specifying placeholder quality. The second major risk is over-compression that cuts critical structural guarantees and causes the module to become shorter but less reliable. The third risk is host-specific leakage from the original Ailey contract, especially around educational state logic, menu assumptions, or culturally specific output defaults. The fourth risk is MM purity drift, where the file wrapper becomes acceptable to a human editor but less suitable as a true serialized insertion payload. The fifth risk is using too narrow a host prompt and thereby overfitting the universal module to one style of host.

Open Questions

The main open question is how much of the shell detail can be compressed without materially reducing compliance. Another open question is whether the final deliverable should keep a tiny wrapper heading in the file or whether the insertion payload itself should become the only content. A further open question is whether the translation file should be updated in lockstep with every English revision during this run or only after the English module stabilizes.

Acceptance Criteria

The module should pass trigger-routing logic for `.cc` and `.ccc`. The simulated `.cc` output should contain the required standard shell structure and semantically appropriate placeholders. The simulated `.ccc` output should contain the required freestyle shell structure and utility controls. The generated content should still look like it belongs to the arbitrary host prompt. Section hierarchy and semantic emphasis should be coherent. Placeholder prompts should be specific and meaningful. The English module should be measured and, ideally, reduced to 5000 characters or fewer. The final report must be evidence-based and not rely on intuition alone.

Final Outcome Against Acceptance Criteria

- Trigger-routing logic: passed by worker review.
- Standard `.cc` shell preservation: passed with restored hard constraints.
- Freestyle `.ccc` shell preservation: passed with standalone-safe follow-up handling.
- Arbitrary-host preservation: passed with a residual mild house-style caveat.
- Heading and emphasis discipline: passed by rule restoration and review.
- Placeholder specificity expectations: passed at the module-contract level.
- Size target: passed at 4588 characters.
- Evidence-based reporting: completed.

Fallback And Repair Logic

If the first validation reveals serious universality flaws, the parent will perform a structural rewrite rather than incremental trimming. If the first validation shows mostly good behavior but too much length, the parent will preserve the logic and compress wording. If independent worker reports conflict, the parent will resolve the conflict by replaying the exact failing criterion against the merged prompt and taking the smaller rule that still preserves compliance. If the first arbitrary host prompt is not sufficiently diagnostic, a second host prompt with a different tone or task frame may be added in the same run.

Operational Notes

All delegated workers for this run should be read-only and should not modify the primary workspace. The parent should remain the only writer for module refinement so the workspace history stays predictable. Evidence should be written under a new `subagent-runs/` directory keyed to this validation run. The current score should begin as a conservative provisional score because the user has approved execution but has not rated quality yet.

Scoreboard

Current Score: 50
Score Source: provisional
Last Updated: 2026-04-13 04:18:12 +09:00
Score Rationale: The approved scope is complete, the module passed worker revalidation, and the size target is met. The plan score remains capped at 50 because no explicit user score has been given and the local workflow requires provisional scores to stay at or below that cap.
What Improved:
- The workstream has a clear acceptance bar.
- The initial universal module already exists.
- The `/sub` validation requirement is understood and scoped.
- The universal module now fits under the size ceiling.
- The initial fail reasons were converted into concrete fixes and verified passes.
What Remains Unsatisfactory:
- No blocking issue remains inside the approved scope.
- Translation parity with the Korean companion file is not yet guaranteed after the final English rewrite.
Actions To Raise Or Maintain The Score:
- Wait for an explicit user score if one is given.
- Keep the accepted English module stable unless a new host-compatibility defect appears.
- Sync the Korean translation in a future follow-up if needed.

Score History

- 2026-04-13 04:03:09 +09:00 | score 45 | source provisional | Initial approved execution state. The request is clear, the artifact exists, but strict validation has not started and the module already exceeds the stated text-budget target.
- 2026-04-13 04:18:12 +09:00 | score 50 | source provisional | Scope completed. The module passed worker revalidation and the size target is met, but provisional scoring remains capped at 50 until the user provides an explicit score.
