














/* --- Ailey & Bailey Canvas --- */
// File: 018_utils_html_exporter.js
// Version: 3.7 (Heading Level Fix)
// Description: Updated '_parseLearningNoteToContentBlocks' to parse '###' headings as level 3 (H3) instead of H2, fixing inconsistent styling in exported HTML files.

/**
 * This function is a copy from 315_notes_recall_viewer.js to avoid complex refactoring.
 * It parses the specific Markdown format of a turn/snapshot into structured content blocks.
 * @param {string} turnMarkdown - The markdown content of a single turn or snapshot.
 * @returns {Array<Object>} An array of content block objects for rendering.
 */
function _parseTurnMarkdownToContentBlocks(turnMarkdown) {
    const contentBlocks = [];

    const mainTitleMatch = turnMarkdown.match(/### @mainTitle: (.*)/);
    const mainSubtitleMatch = turnMarkdown.match(/### @mainSubtitle: (.*)/);
    const turnMatch = turnMarkdown.match(/## \[\s?턴\s?(\d+)\s?\]/);
    const snapshotMatch = turnMarkdown.match(/## \[📸 스냅샷: (.*?)\]/);
    
    let headerTitle = "기록";
    if (mainTitleMatch && mainTitleMatch[1]) {
        headerTitle = mainTitleMatch[1].trim();
    } else if (snapshotMatch && snapshotMatch[1]) {
        headerTitle = snapshotMatch[1].trim();
    } else if (turnMatch && turnMatch[1]) {
        headerTitle = `턴 ${turnMatch[1]}`;
    }

    const headerBlock = { type: 'main-header', title: headerTitle };

    if (snapshotMatch && snapshotMatch[1]) {
        if (mainTitleMatch && mainTitleMatch[1]) {
            headerBlock.subtitle = `📸 스냅샷: ${snapshotMatch[1].trim()}`;
        }
    }
    else if (mainSubtitleMatch && mainSubtitleMatch[1]) {
        headerBlock.subtitle = mainSubtitleMatch[1].trim();
    }
    
    contentBlocks.push(headerBlock);

    const headingMatch = turnMarkdown.match(/### @heading: (.*)/);
    let headingText = '**현재 상황**'; // Default fallback
    if (headingMatch && headingMatch[1]) {
        headingText = headingMatch[1].trim();
    }
    
    contentBlocks.push({ type: 'heading', level: 2, text: headingText });

    const userChoiceMatch = turnMarkdown.match(/### 사용자 선택\s*\n> ([\s\S]*?)(?=\n\n---|\n###|$)/);
    if (userChoiceMatch && userChoiceMatch[1].trim()) {
        contentBlocks.push({ type: 'blockquote', content: `**사용자 선택:** ${userChoiceMatch[1].trim()}` });
    }

    const narrativeMatch = turnMarkdown.match(/### 생성된 서사\s*\n([\s\S]*?)(?=\n\n---|\n###|$)/);
    if (narrativeMatch && narrativeMatch[1].trim()) {
        contentBlocks.push({ type: 'paragraph', content: narrativeMatch[1].trim() });
        contentBlocks.push({ type: 'generated-image-placeholder' });
    }

    contentBlocks.push({ type: 'horizontal-rule' });

    const dashboardBlock = { type: 'status_dashboard', modules: [] };
    const statusMatch = turnMarkdown.match(/### 상태 정보\s*\n([\s\S]*?)(?=\n\n---|\n###|$)/);
    if (statusMatch && statusMatch[1].trim()) {
        const statusContent = statusMatch[1].trim();
        const moduleParts = statusContent.split(/\s*\*\*(.*?)\*\*\s*\n/);
        
        for (let i = 1; i < moduleParts.length; i += 2) {
            const title = moduleParts[i];
            const itemsText = moduleParts[i + 1];
            if (!title || !itemsText) continue;

            const module = { title: title, items: [] };
            if (title.includes('상태')) module.icon = '❤️';
            if (title.includes('신체')) module.icon = '🧘';
            if (title.includes('환경')) module.icon = '🌍';
            if (title.includes('정보')) module.icon = '👤';
            if (title.includes('시간')) module.icon = '🕰️';
            if (title.includes('감각')) module.icon = '👁️';
            if (title.includes('사건')) module.icon = '📜';

            const itemLines = itemsText.trim().split('\n');
            itemLines.forEach(line => {
                const itemMatch = line.match(/- \*\*(.*?):\*\* (.*)/);
                if (itemMatch) {
                    module.items.push({ term: itemMatch[1].trim(), definition: itemMatch[2].trim() });
                }
            });
            dashboardBlock.modules.push(module);
        }
    }
    
    const scanMatch = turnMarkdown.match(/### 주변 탐색\s*\n([\s\S]*?)(?=\n\n---|\n###|$)/);
    if (scanMatch && scanMatch[1].trim()) {
        dashboardBlock.modules.push({ title: "주변 탐색", icon: "🔍", scan_table_markdown: scanMatch[1].trim() });
    }

    if (dashboardBlock.modules.length > 0) contentBlocks.push(dashboardBlock);
    contentBlocks.push({ type: 'horizontal-rule' });

    const choicesMatch = turnMarkdown.match(/### 제시된 선택지\s*\n([\s\S]*?)$/);
    if (choicesMatch && choicesMatch[1].trim()) {
        const choiceItems = choicesMatch[1].trim().split('\n').map(line => line.replace(/^\d+\.\s*/, '').trim());
        contentBlocks.push({
            type: 'ordered-list',
            items: choiceItems
        });
    }

    return contentBlocks;
}

function _parseLearningNoteToContentBlocks(markdown) {
    if (!markdown) return [];

    const blocks = [];
    const lines = markdown.split('\n');

    let currentParagraphLines = [];

    const pushParagraph = () => {
        if (currentParagraphLines.length > 0) {
            blocks.push({ type: 'paragraph', content: currentParagraphLines.join('\n').trim() });
            currentParagraphLines = [];
        }
    };

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const trimmedLine = line.trim();

        if (trimmedLine === '') {
            pushParagraph();
            continue;
        }

        if (trimmedLine.startsWith('**키워드:**')) {
            pushParagraph();
            const keywords = trimmedLine.substring('**키워드:**'.length).split(',').map(kw => kw.trim()).filter(Boolean);
            blocks.push({ type: 'keywords', keywords });
        } else if (trimmedLine.startsWith('### ')) {
            pushParagraph();
            // [MODIFIED] Use Level 3 for '###' headings to match standard H3 styling (underline) instead of H2 styling (bar).
            blocks.push({ type: 'heading', level: 3, text: trimmedLine.substring(4) });
            blocks.push({ type: 'generated-image-placeholder' });
            blocks.push({ type: 'visualization-placeholder' });
        } else if (trimmedLine === '---') {
            pushParagraph();
            blocks.push({ type: 'horizontal-rule' });
        } else if (trimmedLine.startsWith('> ')) {
            pushParagraph();
            let bqLines = [trimmedLine.substring(2)];
            while (i + 1 < lines.length && lines[i + 1].trim().startsWith('> ')) {
                i++;
                bqLines.push(lines[i].trim().substring(2));
            }
            blocks.push({ type: 'blockquote', content: bqLines.join('\n') });
        } else if (trimmedLine.startsWith('**') && trimmedLine.endsWith('**') && !trimmedLine.includes('키워드')) {
             pushParagraph();
             let summaryTitle = trimmedLine;
             let summaryContent = [];
             while(i + 1 < lines.length && lines[i + 1].trim() !== '' && !lines[i + 1].trim().match(/^(###\s|---|>|`|\*\*키워드:\*\*)/)) {
                 i++;
                 summaryContent.push(lines[i]);
             }
             blocks.push({ type: 'summary', title: summaryTitle, content: summaryContent.join('\n') });
        } else if (trimmedLine.match(/^\d+\.\s/)) { // Ordered list
            pushParagraph();
            let listItems = [trimmedLine.replace(/^\d+\.\s/, '')];
            while(i + 1 < lines.length && lines[i+1].trim().match(/^\d+\.\s/)) {
                i++;
                listItems.push(lines[i].trim().replace(/^\d+\.\s/, ''));
            }
            blocks.push({ type: 'ordered-list', items: listItems });
        } else if (trimmedLine.match(/^-\s/)) { // Unordered list
            pushParagraph();
            let listItems = [trimmedLine.replace(/-\s/, '')];
            while(i + 1 < lines.length && lines[i+1].trim().match(/^-\s/)) {
                i++;
                listItems.push(lines[i].trim().replace(/-\s/, ''));
            }
            blocks.push({ type: 'unordered-list', items: listItems });
        }
        else {
            currentParagraphLines.push(line);
        }
    }

    pushParagraph();

    return blocks;
}

const LIVE_EXPORT_BUNDLE_BASE = 'https://lemos999.github.io/Singulari-Tea-Codex-Canvas';
const LIVE_EXPORT_REQUIRED_HEAD_LINKS = [
    {
        href: 'https://fonts.googleapis.com/css2?family=Gowun+Batang:wght@400;700&family=Noto+Serif+KR:wght@400;600&display=swap',
        markup: '<link href="https://fonts.googleapis.com/css2?family=Gowun+Batang:wght@400;700&family=Noto+Serif+KR:wght@400;600&display=swap" rel="stylesheet">'
    },
    {
        href: `${LIVE_EXPORT_BUNDLE_BASE}/bundle/main.css`,
        markup: `<link rel="stylesheet" href="${LIVE_EXPORT_BUNDLE_BASE}/bundle/main.css">`
    },
    {
        href: `${LIVE_EXPORT_BUNDLE_BASE}/katex.min.css`,
        markup: `<link rel="stylesheet" href="${LIVE_EXPORT_BUNDLE_BASE}/katex.min.css">`
    },
    {
        href: 'https://uicdn.toast.com/editor/latest/toastui-editor.min.css',
        markup: '<link rel="stylesheet" href="https://uicdn.toast.com/editor/latest/toastui-editor.min.css">'
    }
];
const LIVE_EXPORT_REQUIRED_HEAD_SCRIPTS = [
    {
        src: `${LIVE_EXPORT_BUNDLE_BASE}/bundle/main.js`,
        markup: `<script defer src="${LIVE_EXPORT_BUNDLE_BASE}/bundle/main.js"><\/script>`
    }
];

function _escapeHtmlForExport(value) {
    return String(value || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function _copyIframeSrcdocForExport(originalRoot, cloneRoot) {
    if (!originalRoot || !cloneRoot) return;

    const originalIframes = originalRoot.querySelectorAll('iframe');
    const clonedIframes = cloneRoot.querySelectorAll('iframe');

    originalIframes.forEach((iframe, index) => {
        if (clonedIframes[index] && iframe.srcdoc) {
            clonedIframes[index].setAttribute('srcdoc', iframe.srcdoc);
        }
    });
}

function _normalizeExportResourceUrl(value) {
    const rawValue = String(value || '').trim();
    if (!rawValue) return '';

    try {
        return new URL(rawValue, window.location.href).href;
    } catch (error) {
        return rawValue;
    }
}

function _shouldPreserveHeadNodeForLiveExport(node) {
    if (!node || node.nodeType !== Node.ELEMENT_NODE) return false;

    const tagName = node.tagName.toLowerCase();
    if (tagName === 'title') return false;

    if (tagName === 'meta') {
        if (node.hasAttribute('charset')) return false;
        const metaName = (node.getAttribute('name') || '').trim().toLowerCase();
        if (metaName === 'viewport') return false;
    }

    if (tagName === 'style' && node.dataset?.vizStyleOwner) {
        return false;
    }

    if (tagName === 'script' && node.dataset?.vizRuntimeScript === 'true') {
        return false;
    }

    return tagName === 'meta'
        || tagName === 'link'
        || tagName === 'style'
        || tagName === 'script';
}

function _buildLiveExportHeadMarkup(title) {
    const headNodes = [];
    const existingLinkHrefs = new Set();
    const existingScriptSrcs = new Set();

    Array.from(document.head.children).forEach((node) => {
        if (!_shouldPreserveHeadNodeForLiveExport(node)) return;

        const tagName = node.tagName.toLowerCase();
        if (tagName === 'link') {
            const href = node.getAttribute('href');
            if (href) {
                existingLinkHrefs.add(_normalizeExportResourceUrl(href));
            }
        }

        if (tagName === 'script') {
            const src = node.getAttribute('src');
            if (src) {
                existingScriptSrcs.add(_normalizeExportResourceUrl(src));
            }
        }

        headNodes.push(node.outerHTML);
    });

    LIVE_EXPORT_REQUIRED_HEAD_LINKS.forEach((entry) => {
        const normalizedHref = _normalizeExportResourceUrl(entry.href);
        if (!existingLinkHrefs.has(normalizedHref)) {
            headNodes.push(entry.markup);
        }
    });

    LIVE_EXPORT_REQUIRED_HEAD_SCRIPTS.forEach((entry) => {
        const normalizedSrc = _normalizeExportResourceUrl(entry.src);
        if (!existingScriptSrcs.has(normalizedSrc)) {
            headNodes.push(entry.markup);
        }
    });

    return [
        '<meta charset="utf-8">',
        '<meta name="viewport" content="width=device-width, initial-scale=1">',
        `<title>${_escapeHtmlForExport(title)}</title>`,
        ...headNodes
    ].join('\n    ');
}

function _downloadHtmlForExport(finalHtml, filename) {
    const blob = new Blob([finalHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.download = filename.replace(/[/\\?%*:|"<>]/g, '-');
    anchor.href = url;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
}


window.exportToHtml = async function(options) {
    const { type, id } = options;
    const toastId = `export-html-${Date.now()}`;
    showProgressToast('HTML 파일 생성 준비 중...', toastId);

    try {
        let content = '';
        let title = '';
        let filename = '';
        let bodyContent = '';
        
        updateProgressToast('콘텐츠 수집 중...', toastId);
        
        if (type === 'note') {
            const note = localNotesCache.find(n => n.id === id);
            if (!note) throw new Error('해당 노트를 찾을 수 없습니다.');
            content = await getNoteContent(note.id) || '';
            title = note.title;
            filename = `[노트] ${title}.html`;

            if (note.title.startsWith('[학습]')) {
                const blocks = _parseLearningNoteToContentBlocks(content);
                blocks.forEach(block => {
                    const element = renderBlock(block);
                    if (element) {
                        bodyContent += element.outerHTML;
                    }
                });
            } else {
                const memoryBlocks = content.split(/(?=## \[(?:턴|📸 스냅샷:))/).filter(chunk => chunk.trim() !== '');
                memoryBlocks.forEach(markdown => {
                    const blocks = _parseTurnMarkdownToContentBlocks(markdown);
                    blocks.forEach(block => {
                        const element = renderBlock(block);
                        if (element) {
                            bodyContent += element.outerHTML;
                        }
                    });
                });
            }

        } else if (type === 'folder') {
            const project = localNoteProjectsCache.find(p => p.id === id);
            if (!project) throw new Error('해당 폴더를 찾을 수 없습니다.');
            
            const allNotesInProject = localNotesCache.filter(n => n.projectId === id);
            const hasNarrativeNotes = allNotesInProject.some(note => note.content && (note.content.includes('## [턴') || note.content.includes('## [📸 스냅샷:')));
            const hasLearningNotes = allNotesInProject.some(note => note.title.startsWith('[학습]'));

            title = `[폴더] ${project.name}`;
            filename = title + '.html';

            if (hasNarrativeNotes) {
                updateProgressToast('서사 노트 수집 중...', toastId);
                const notesInProject = allNotesInProject
                    .filter(n => n.content && (n.content.includes('## [턴') || n.content.includes('## [📸 스냅샷:')))
                    .sort((a, b) => (a.createdAt?.toMillis() || 0) - (b.createdAt?.toMillis() || 0));
                
                const contentPromises = notesInProject.map(note => getNoteContent(note.id));
                const allContents = await Promise.all(contentPromises);
                content = allContents.join('\n\n');
                
                const memoryBlocks = content.split(/(?=## \[(?:턴|📸 스냅샷:))/).filter(chunk => chunk.trim() !== '');
                
                memoryBlocks.forEach(markdown => {
                    const blocks = _parseTurnMarkdownToContentBlocks(markdown);
                    blocks.forEach(block => {
                        const element = renderBlock(block);
                        if (element) {
                            bodyContent += element.outerHTML;
                        }
                    });
                });
            } else if (hasLearningNotes) {
                updateProgressToast('학습 노트 수집 중...', toastId);
                const notesInProject = allNotesInProject
                    .filter(n => n.title.startsWith('[학습]'))
                    .sort((a, b) => a.title.localeCompare(b.title, 'ko', { numeric: true }));

                const contentPromises = notesInProject.map(note => getNoteContent(note.id));
                const allContents = await Promise.all(contentPromises);
                
                notesInProject.forEach((note, index) => {
                    const noteContent = allContents[index] || '';
                    const blocks = _parseLearningNoteToContentBlocks(noteContent);
                    const headerBlock = { type: 'main-header', title: note.title.replace('[학습]', '').trim() };
                    const finalBlocks = [headerBlock, ...blocks];

                    finalBlocks.forEach(block => {
                        const element = renderBlock(block);
                        if (element) {
                            bodyContent += element.outerHTML;
                        }
                    });
                    
                    if (index < notesInProject.length - 1) {
                         bodyContent += '<hr style="margin: 40px 0; border-top: 1px solid #EAE0D3;">';
                    }
                });
            } else {
                throw new Error('폴더에 회상 가능한 노트가 없습니다.');
            }
        }

        updateProgressToast('최종 HTML 파일 조립 중...', toastId);
        const finalHtml = `
            <!DOCTYPE html>
            <html lang="ko">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>${title.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</title>
                <link href="https://fonts.googleapis.com/css2?family=Gowun+Batang:wght@400;700&family=Noto+Serif+KR:wght@400;600&display=swap" rel="stylesheet">
                <link rel="stylesheet" href="https://lemos999.github.io/Singulari-Tea-Codex-Canvas/bundle/main.css">
                <link rel="stylesheet" href="https://lemos999.github.io/Singulari-Tea-Codex-Canvas/katex.min.css">
                <link rel="stylesheet" href="https://uicdn.toast.com/editor/latest/toastui-editor.min.css" />
                <style>
                    /* Hiding interactive elements that are not functional in the static export */
                    body { padding-top: 20px !important; }
                    #immersive-header, .fixed-tool-container, .draggable-panel { display: none !important; }
                    .generated-image-wrapper:hover .image-overlay-controls,
                    .viz-hover-btn, .img-gen-hover-btn, .viz-controls-group, .map-accordion-header { cursor: default; }
                    .image-overlay-controls, .map-toggle-icon { display: none !important; }
                </style>
            </head>
            <body class="${document.body.className}">
                <main class="wrapper">
                    <div class="container" id="learning-content">
                        ${bodyContent}
                    </div>
                </main>
                <script defer src="https://lemos999.github.io/Singulari-Tea-Codex-Canvas/bundle/main.js"><\/script>
            </body>
            </html>
        `;

        const blob = new Blob([finalHtml], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.download = filename.replace(/[/\\?%*:|"<>]/g, '-');
        a.href = url;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        hideProgressToast(toastId);

    } catch (error) {
        console.error("HTML export failed:", error);
        hideProgressToast(toastId);
        showModal(`HTML 내보내기 실패: ${error.message}`, () => {});
    }
}

window.exportRecallViewerAsHtml = async function(title) {
    const toastId = `export-recall-html-${Date.now()}`;
    showProgressToast('실시간 화면 캡처 중...', toastId);
    trace("Export", "recallViewer.start", { title });

    try {
        const contentArea = document.getElementById('recall-content-area');
        if (!contentArea) {
            throw new Error('회상 뷰어 콘텐츠 영역을 찾을 수 없습니다.');
        }

        updateProgressToast('HTML 파일 조립 및 재구성 스크립트 생성 중...', toastId);
        
        const contentClone = contentArea.cloneNode(true);
        
        const vizDataArray = [];
        const vizElements = contentClone.querySelectorAll('.type-visualization');
        
        vizElements.forEach((vizElement, index) => {
            if (vizElement.dataset.blockData) {
                try {
                    vizDataArray.push(vizElement.dataset.blockData);
                    vizElement.innerHTML = ''; // Clear content
                    vizElement.id = 'viz-rehydration-target-' + index; // Set unique ID for rehydration
                } catch(e) {
                    console.warn('Could not process visualization block for export:', e);
                    vizElement.innerHTML = '<p style="color:red;">[오류] 이 시각화 자료를 내보낼 수 없습니다.</p>';
                }
            }
        });
        
        // Remove interactive hover/overlay buttons from the cloned content
        contentClone.querySelectorAll('.viz-hover-btn, .img-gen-hover-btn, .image-overlay-controls, .viz-controls-group').forEach(btn => btn.remove());
        const bodyContent = contentClone.innerHTML;
        
        const rehydrationScript = `
            <script>
            document.addEventListener('DOMContentLoaded', () => {
                const vizDataArray = [${vizDataArray.join(',\n')}];
                if (vizDataArray.length === 0) return;

                const rehydrationInterval = setInterval(() => {
                    if (typeof renderVisualizationBlock === 'function') {
                        clearInterval(rehydrationInterval);
                        console.log(\`Found \${vizDataArray.length} visualizations to rehydrate.\`);
                        vizDataArray.forEach((blockData, index) => {
                            const targetElement = document.getElementById('viz-rehydration-target-' + index);
                            if (targetElement) {
                                try {
                                    renderVisualizationBlock(blockData, targetElement);
                                } catch (e) {
                                    console.error('Error rehydrating visualization #' + index, e);
                                    if(targetElement) targetElement.innerHTML = '<p style="color:red;">[오류] 이 시각화 자료를 다시 렌더링하는 데 실패했습니다.</p>';
                                }
                            } else {
                                console.warn('Target for visualization #' + index + ' not found.');
                            }
                        });
                    }
                }, 100);

                setTimeout(() => clearInterval(rehydrationInterval), 10000); // Failsafe timeout
            });
            <\/script>
        `;

        const finalHtml = `
            <!DOCTYPE html>
            <html lang="ko">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>${title.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</title>
                <link href="https://fonts.googleapis.com/css2?family=Gowun+Batang:wght@400;700&family=Noto+Serif+KR:wght@400;600&display=swap" rel="stylesheet">
                <link rel="stylesheet" href="https://lemos999.github.io/Singulari-Tea-Codex-Canvas/bundle/main.css">
                <link rel="stylesheet" href="https://lemos999.github.io/Singulari-Tea-Codex-Canvas/katex.min.css">
                <link rel="stylesheet" href="https://uicdn.toast.com/editor/latest/toastui-editor.min.css" />
                <style>
                    body { padding-top: 20px !important; }
                    #immersive-header, .fixed-tool-container, .draggable-panel, .panel-header { display: none !important; }
                    main.wrapper { display: block !important; max-width: 1100px; margin: 20px auto; }
                    .type-visualization { min-height: 200px; } /* Prevent layout shift before rehydration */
                </style>
            </head>
            <body class="${document.body.className}">
                <main class="wrapper" style="display: block; max-width: 1100px; margin: 20px auto;">
                    <div class="container" id="learning-content">
                        ${bodyContent}
                    </div>
                </main>
                <script defer src="https://lemos999.github.io/Singulari-Tea-Codex-Canvas/bundle/main.js"><\/script>
                ${rehydrationScript}
            </body>
            </html>
        `;

        const blob = new Blob([finalHtml], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        const filename = `${title}.html`.replace(/[/\\?%*:|"<>]/g, '-');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        trace("Export", "recallViewer.success.interactive", { title, filename, vizCount: vizDataArray.length });

    } catch (error) {
        console.error("Recall viewer HTML export failed:", error);
        trace("Export", "recallViewer.error", { error: error.message }, {}, "ERROR");
        showModal(`HTML 내보내기 실패: ${error.message}`, () => {});
    } finally {
        hideProgressToast(toastId);
    }
}

window.exportMainContentAsHtml = async function(title) {
    const toastId = `export-main-html-${Date.now()}`;
    showProgressToast('실시간 화면 캡처 중...', toastId);
    trace("Export", "mainContent.start", { title });

    try {
        const contentArea = document.getElementById('ai-content-placeholder');
        if (!contentArea) {
            throw new Error('메인 콘텐츠 영역을 찾을 수 없습니다.');
        }

        updateProgressToast('HTML 파일 조립 중...', toastId);
        
        const contentClone = contentArea.cloneNode(true);
        
        // Find all original iframes to get their srcdoc
        const originalIframes = contentArea.querySelectorAll('.type-visualization iframe');
        const clonedIframes = contentClone.querySelectorAll('.type-visualization iframe');

        // Create a map for easy lookup
        const originalSrcDocs = {};
        originalIframes.forEach(iframe => {
            originalSrcDocs[iframe.id] = iframe.srcdoc;
        });

        // Apply the srcdoc to the cloned iframes
        clonedIframes.forEach(iframe => {
            if (originalSrcDocs[iframe.id]) {
                iframe.setAttribute('srcdoc', originalSrcDocs[iframe.id]);
            }
        });
        
        // Remove interactive hover/overlay buttons from the cloned content
        contentClone.querySelectorAll('.viz-hover-btn, .img-gen-hover-btn, .image-overlay-controls, .viz-controls-group').forEach(btn => btn.remove());
        const bodyContent = contentClone.innerHTML;
        
        const finalHtml = `
            <!DOCTYPE html>
            <html lang="ko">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>${title.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</title>
                <link href="https://fonts.googleapis.com/css2?family=Gowun+Batang:wght@400;700&family=Noto+Serif+KR:wght@400;600&display=swap" rel="stylesheet">
                <link rel="stylesheet" href="https://lemos999.github.io/Singulari-Tea-Codex-Canvas/bundle/main.css">
                <link rel="stylesheet" href="https://lemos999.github.io/Singulari-Tea-Codex-Canvas/katex.min.css">
                <link rel="stylesheet" href="https://uicdn.toast.com/editor/latest/toastui-editor.min.css" />
                <style>
                    body { padding-top: 20px !important; }
                    #immersive-header, .fixed-tool-container, .draggable-panel, .panel-header { display: none !important; }
                    .type-visualization { min-height: 200px; }
                </style>
            </head>
            <body class="${document.body.className}">
                <main id="ai-content-placeholder">
                    ${bodyContent}
                </main>
                <!-- Rehydration script is no longer needed with srcdoc inlining -->
            </body>
            </html>
        `;

        const blob = new Blob([finalHtml], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        const filename = `${title}.html`.replace(/[/\\?%*:|"<>]/g, '-');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        trace("Export", "mainContent.success.wysiwyg", { title, filename, vizCount: clonedIframes.length });

    } catch (error) {
        console.error("Main content HTML export failed:", error);
        trace("Export", "mainContent.error", { error: error.message }, {}, "ERROR");
        showModal(`HTML 내보내기 실패: ${error.message}`, () => {});
    } finally {
        hideProgressToast(toastId);
    }
}

window.exportAsLiveHtml = async function(options = {}) {
    const toastId = `export-live-${Date.now()}`;
    showProgressToast('Live HTML export 준비 중..', toastId);
    trace("Export", "liveHtml.start", { title: options.title || document.title || 'Ailey Canvas' });

    try {
        const contentArea = document.getElementById('ai-content-placeholder');
        if (!contentArea) {
            throw new Error('메인 콘텐츠 영역을 찾을 수 없습니다.');
        }

        updateProgressToast('현재 화면 콘텐츠 수집 중..', toastId);

        const contentClone = contentArea.cloneNode(true);
        _copyIframeSrcdocForExport(contentArea, contentClone);

        contentClone.querySelectorAll('.type-visualization').forEach(viz => {
            if (viz.dataset.blockData) {
                viz.innerHTML = '';
                delete viz.dataset.hydrated;
            }
        });

        contentClone.querySelectorAll('.viz-hover-btn, .img-gen-hover-btn, .image-overlay-controls, .viz-controls-group').forEach(button => button.remove());

        const canvasHtml = contentClone.outerHTML.trim();
        const title = options.title || document.title || 'Ailey Canvas';
        const filename = `${title}.html`;
        const bodyClassName = document.body.className || '';
        const canvasIdHint = document.querySelector('meta[name="canvas-id"]')?.content || 'exported-root';
        const liveExportHeadMarkup = _buildLiveExportHeadMarkup(title);

        updateProgressToast('실행형 HTML 조립 중..', toastId);

        const finalHtml = `
<!DOCTYPE html>
<html lang="ko">
<head>
    ${liveExportHeadMarkup}
    <style>
        body {
            margin: 0;
            min-height: 100vh;
        }

        #initial-loader {
            display: grid;
            place-items: center;
            min-height: 100vh;
            padding: 24px;
            text-align: center;
            font-family: "Segoe UI", sans-serif;
            line-height: 1.6;
        }
    </style>
</head>
<body class="${_escapeHtmlForExport(bodyClassName)}" data-export-mode="live">
    <div id="initial-loader">
        <div>
            <h1>${_escapeHtmlForExport(title)}</h1>
            <p>Loading exported Ailey workspace...</p>
        </div>
    </div>
    <template id="exported-content">
${canvasHtml}
    </template>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var template = document.getElementById('exported-content');
        var loader = document.getElementById('initial-loader');
        var exportedHtml = template ? template.innerHTML : '';

        if (typeof renderAppShell !== 'function') {
            document.body.innerHTML = '<div id="initial-loader"><div><h1>Live export bootstrap failed</h1><p>bundle/main.js did not expose renderAppShell().</p></div></div>';
            return;
        }

        renderAppShell(exportedHtml, ${JSON.stringify(title)}, ${JSON.stringify(canvasIdHint)});

        if (loader && loader.parentNode) {
            loader.remove();
        }
    });
    <\/script>
</body>
</html>`;

        _downloadHtmlForExport(finalHtml, filename);
        trace("Export", "liveHtml.success", { title, filename });
    } catch (error) {
        console.error("Live HTML export failed:", error);
        trace("Export", "liveHtml.error", { error: error.message }, {}, "ERROR");
        showModal(`실행형 HTML 내보내기 실패: ${error.message}`, () => {});
    } finally {
        hideProgressToast(toastId);
    }
}
