/* --- Ailey & Bailey Canvas --- */
// File: 234_chat_session_manager.js
// Version: 2.0 (Clean Session Flow)
// Description: Manages session selection, temporary chat mode, and chat surface resets with cleaner UX copy.

function setTempChatMode(isActive) {
    trace('setTempChatMode.called', { isActive });
    if (isQuickQueryTempMode === isActive) return;

    isQuickQueryTempMode = isActive;

    quickQueryTempToggle?.classList.toggle('active', isActive);
    tempSessionToggle?.classList.toggle('active', isActive);

    if (quickQueryInput) {
        quickQueryInput.placeholder = isActive ? '임시 질문 (기록 안 됨)...' : '빠른 질문...';
    }

    if (!isActive) {
        temporarySession = typeof createEmptyTemporarySession === 'function'
            ? createEmptyTemporarySession()
            : { messages: [], contextSent: false, compactionState: null };
    }

    handleNewChat(isActive);
}

function resetSessionState() {
    if (typeof teardownChatScrollListener === 'function') {
        teardownChatScrollListener();
    }

    currentSessionState = {
        isLoadingMore: false,
        hasMoreMessages: true,
        oldestMessageTimestamp: null,
        lastMessageTimestamp: null,
        autoFollow: true,
        isUserNearBottom: true
    };

    if (unsubscribeFromMessages) {
        unsubscribeFromMessages();
        unsubscribeFromMessages = null;
    }

    trace('State', 'resetSessionState', {}, { newState: currentSessionState });
}

async function selectSession(sessionId) {
    isContextlessMode = false;
    contextToggleBtn?.classList.remove('active');
    clearAllChatAttachments?.();

    trace('UI.Session', 'selectSession.start', { new: sessionId, old: currentSessionId }, { sessionId });
    if (sessionId === currentSessionId || !sessionId) {
        return;
    }

    setTempChatMode(false);
    resetSessionState();

    const previousSessionId = currentSessionId;
    if (previousSessionId && activeStreams[previousSessionId] && activeStreams[previousSessionId].isRendering) {
        activeStreams[previousSessionId].isRendering = false;
    }

    let sessionData = localChatSessionsCache.find(session => session.id === sessionId);
    if (!sessionData) {
        await new Promise(resolve => setTimeout(resolve, 100));
        sessionData = localChatSessionsCache.find(session => session.id === sessionId);
        if (!sessionData) {
            trace('UI.Session', 'selectSession.error', { reason: 'Session not in cache', sessionId }, {}, 'ERROR');
            return;
        }
    }

    completedButUnseenResponses.delete(sessionId);

    if (chatMessages) chatMessages.innerHTML = '';
    Object.values(activeTimers).forEach(timerGroup => timerGroup.forEach(clearInterval));

    currentSessionId = sessionId;
    renderSidebarContent();

    if (chatWelcomeMessage) chatWelcomeMessage.style.display = 'none';
    if (chatMessages) chatMessages.style.display = 'flex';

    const activePreset = userApiSettings.apiPresets.find(preset => preset.id === userApiSettings.activePresetId);
    const provider = activePreset ? activePreset.provider : 'universal';

    const initialMessages = await fetchPastMessages(sessionId, null);
    const sessionInCache = localChatSessionsCache.find(session => session.id === sessionId);
    if (sessionInCache) {
        sessionInCache.messages = initialMessages.slice().reverse();
    }

    currentSessionState.hasMoreMessages = initialMessages.length >= MESSAGES_PER_PAGE;
    if (initialMessages.length > 0) {
        currentSessionState.oldestMessageTimestamp = initialMessages[initialMessages.length - 1].timestamp;
        currentSessionState.lastMessageTimestamp = initialMessages[0].timestamp;
    }

    if (!(provider === 'google_paid' && chatMessages && chatMessages.querySelector('.chat-message'))) {
        renderChatMessages({ messages: initialMessages.slice().reverse() });
    }

    if (typeof setupChatScrollListener === 'function') {
        setupChatScrollListener();
    }
    listenToNewMessages(sessionId);

    if (chatSessionTitle) {
        chatSessionTitle.textContent = sessionData.title || '새 대화';
    }

    const isBlocked = pendingResponses.has(sessionId);
    if (chatInput) {
        chatInput.disabled = isBlocked;
        chatInput.placeholder = isBlocked ? '응답을 기다리는 중...' : 'Ailey & Bailey에게 질문하기...';
    }
    if (chatSendBtn) {
        chatSendBtn.disabled = isBlocked;
    }
    if (!isBlocked && chatInput) {
        chatInput.focus();
    }
}

function handleNewChat(isTemporary = false) {
    isContextlessMode = false;
    contextToggleBtn?.classList.remove('active');
    clearAllChatAttachments?.();

    if (isTemporary) {
        if (currentSessionId === 'temporary-chat') {
            if (temporarySession.messages.length > 0) {
                renderChatMessages(temporarySession);
            }
            return;
        }
        temporarySession = typeof createEmptyTemporarySession === 'function'
            ? createEmptyTemporarySession()
            : { messages: [], contextSent: false, compactionState: null };
    }

    currentSessionId = isTemporary ? 'temporary-chat' : null;
    tempSessionToggle?.classList.toggle('active', isTemporary);

    resetSessionState();

    Object.values(activeTimers).forEach(timerGroup => timerGroup.forEach(clearInterval));
    renderSidebarContent();

    if (chatMessages) chatMessages.innerHTML = '';
    if (chatWelcomeMessage) chatWelcomeMessage.style.display = 'flex';

    if (chatSessionTitle) {
        chatSessionTitle.textContent = isTemporary ? '임시 대화' : 'Ailey & Bailey';
    }

    if (chatInput) {
        chatInput.disabled = false;
        chatInput.value = '';
        chatInput.placeholder = isTemporary ? '이 대화는 저장되지 않습니다...' : 'Ailey & Bailey에게 질문하기...';
    }
    if (chatSendBtn) {
        chatSendBtn.disabled = false;
    }
}
