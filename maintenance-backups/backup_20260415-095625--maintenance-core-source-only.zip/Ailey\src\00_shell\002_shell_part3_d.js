/* --- Ailey & Bailey Canvas --- */
// File: 002_shell_part3_d.js
// Version: 1.0 (Modularization)
// Description: Contains the HTML for the Image Generation Studio modal (Part 1: Layout and Style Tab).

const SHELL_PART_3_D = `
    <div id="image-generation-options-modal-overlay" class="custom-modal-overlay">
        <div class="custom-modal image-generation-options-modal">
            <div class="img-gen-studio-header">
                <div class="img-gen-studio-title-block">
                    <p class="img-gen-studio-kicker">SCENE IMAGE STUDIO</p>
                    <h3>장면 이미지 스튜디오</h3>
                    <p class="img-gen-studio-subtitle">그림 스타일, 화면 구도, 조명, 재료감, 색 분위기를 한 번에 정리하고 바로 생성합니다.</p>
                </div>
                <div class="img-gen-studio-quick-note">
                    <strong>빠른 흐름</strong>
                    <span>장면 설명을 적고, 오른쪽에서 그림 스타일과 화면 구도를 고른 뒤 빠르게 생성하거나 정교하게 생성하면 됩니다.</span>
                </div>
            </div>
            <div class="img-gen-studio-layout">
                <div class="img-gen-studio-left">
                    <div class="img-gen-options-section img-gen-side-card">
                        <label for="img-gen-search-input">옵션 빠른 찾기</label>
                        <input type="search" id="img-gen-search-input" class="img-gen-search-bar" placeholder="예: 유화, 클로즈업, 황금 시간대...">
                    </div>
                     <div class="img-gen-options-section img-gen-global-options img-gen-side-card">
                         <label>생성 기본 옵션</label>
                         <div class="global-options-wrapper">
                             <div class="option-btn-group" id="img-gen-global-options">
                                <button class="option-btn" id="img-gen-include-all-dom" data-tooltip="현재 화면의 제목, 서사, 상태 정보까지 함께 읽어 장면 맥락을 더 넓게 반영합니다.">현재 화면 맥락까지 포함</button>
                                <button class="option-btn" id="img-gen-remember-options-toggle" data-tooltip="선택한 옵션(그림 스타일, 구도, 조명 등)을 기억하고, 다음 생성 때 같은 취향을 다시 불러옵니다.">
                                    <svg viewBox="0 0 24 24" width="16" height="16"><path d="M17,3H7A2,2 0 0,0 5,5V21L12,18L19,21V5C19,3.89 18.1,3 17,3Z"></path></svg>
                                    <span>마지막 선택 기억</span>
                                </button>
                                <button class="option-btn" id="img-gen-disable-text-toggle" data-tooltip="이미지 안에 글자, 말풍선, 문자 요소가 생기지 않도록 강하게 요청합니다."><svg viewBox="0 0 24 24" width="16" height="16"><path d="M22.1,3.9L20.1,2L2,20.1L3.9,22.1L22.1,3.9M22,4V16C22,17.1 21.1,18 20,18H6L2,22V4C2,2.9 2.9,2 4,2H20C21.1,2 22,2.9 22,4Z"></path></svg><span>이미지 속 글자 끄기</span></button>
                            </div>
                            <div id="img-gen-studio-upload-section">
                                <input type="file" id="img-gen-studio-file-input" style="display: none;" accept="image/*">
                                <div id="img-gen-studio-preview-wrapper">
                                     <div id="img-gen-studio-preview"></div>
                                     <button id="img-gen-studio-remove-btn" title="이미지 제거">&times;</button>
                                </div>
                                <button id="img-gen-studio-upload-btn" class="option-btn" title="참조 이미지 업로드">
                                    <svg viewBox="0 0 24 24" width="16" height="16"><path d="M9,16V10H5L12,3L19,10H15V16H9M5,20V18H19V20H5Z"></path></svg>
                                </button>
                            </div>
                        </div>
                        <p class="img-gen-side-note">참조 이미지를 올리면 장면 톤, 재질, 색 분위기를 맞추는 데 도움이 됩니다.</p>
                    </div>
                    <div class="img-gen-options-section img-gen-side-card img-gen-prompt-card">
                        <label for="img-gen-options-textarea">장면 설명 메모</label>
                        <textarea id="img-gen-options-textarea" placeholder="생성할 이미지에 대해 자유롭게 서술해주세요..."></textarea>
                    </div>
                </div>
                <div class="img-gen-studio-right">
                    <div class="img-gen-tab-intro">오른쪽에서 원하는 그림 스타일, 화면 구도, 조명, 재료감, 색 분위기를 눌러 장면 성격을 빠르게 조합합니다.</div>
                    <div class="img-gen-tabs-new">
                        <button class="img-gen-tab-btn active" data-tab="style" data-tooltip="그림 전체의 미술 스타일과 표현 계열을 고릅니다.">🎨<span class="tab-text">그림 스타일</span></button>
                        <button class="img-gen-tab-btn" data-tab="composition" data-tooltip="대상의 크기, 카메라 각도, 화면 구도를 정합니다.">📷<span class="tab-text">화면 구도</span></button>
                        <button class="img-gen-tab-btn" data-tab="lighting" data-tooltip="시간대, 조명 방향, 장면 분위기를 조절합니다.">💡<span class="tab-text">조명</span></button>
                        <button class="img-gen-tab-btn" data-tab="medium" data-tooltip="표면 재료, 공예 질감, 표현 재료감을 고릅니다.">🧱<span class="tab-text">재료감</span></button>
                        <button class="img-gen-tab-btn" data-tab="palette" data-tooltip="톤, 채도, 색 조합과 전체 색 분위기를 정합니다.">🌈<span class="tab-text">색 분위기</span></button>
                    </div>
                    <div class="img-gen-tab-panels-new">
                        <!-- Art Style Tab -->
                        <div id="img-gen-tab-style" class="img-gen-tab-panel active">
                            <div class="accordion-container">
                                <div class="accordion-header">붓질과 회화 스타일</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="oil painting" data-tooltip="두껍고 풍부한 질감의 유화">유화</button>
                                    <button class="option-btn" data-prompt="watercolor painting" data-tooltip="부드럽고 투명한 느낌의 수채화">수채화</button>
                                    <button class="option-btn" data-prompt="acrylic painting" data-tooltip="선명하고 빠르게 마르는 아크릴화">아크릴화</button>
                                    <button class="option-btn" data-prompt="gouache painting" data-tooltip="불투명하고 무광택 느낌의 과슈">과슈</button>
                                    <button class="option-btn" data-prompt="fresco painting" data-tooltip="벽화에 사용되는 프레스코 기법">프레스코</button>
                                    <button class="option-btn" data-prompt="tempera painting" data-tooltip="계란 노른자를 이용한 템페라">템페라</button>
                                    <button class="option-btn" data-prompt="impasto" data-tooltip="물감을 두껍게 칠하는 임파스토">임파스토</button>
                                </div>
                            </div>
                            <div class="accordion-container">
                                <div class="accordion-header">선화와 판화 느낌</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="pen and ink drawing" data-tooltip="펜과 잉크를 사용한 세밀한 드로잉">펜화</button>
                                    <button class="option-btn" data-prompt="charcoal drawing" data-tooltip="부드럽고 깊이감 있는 목탄화">목탄화</button>
                                    <button class="option-btn" data-prompt="conte drawing" data-tooltip="정밀한 표현이 가능한 콘테 드로잉">콘테</button>
                                    <button class="option-btn" data-prompt="pastel drawing" data-tooltip="화사하고 부드러운 파스텔화">파스텔</button>
                                    <button class="option-btn" data-prompt="colored pencil drawing" data-tooltip="섬세하고 다채로운 색연필화">색연필</button>
                                    <button class="option-btn" data-prompt="etching" data-tooltip="날카로운 선이 특징인 동판화">에칭</button>
                                    <button class="option-btn" data-prompt="lithography" data-tooltip="평판 인쇄 방식의 석판화">리소그래피</button>
                                    <button class="option-btn" data-prompt="woodcut" data-tooltip="거칠고 강렬한 느낌의 목판화">목판화</button>
                                </div>
                            </div>
                             <div class="accordion-container">
                                <div class="accordion-header">디지털 · 현대 스타일</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn active" data-prompt="photorealistic" data-tooltip="사진처럼 극사실적인 스타일">사진처럼</button>
                                    <button class="option-btn" data-prompt="anime style" data-tooltip="일본 애니메이션 스타일">애니메이션</button>
                                    <button class="option-btn" data-prompt="2D vector art" data-tooltip="깔끔한 선과 면으로 구성된 벡터 아트">벡터 아트</button>
                                    <button class="option-btn" data-prompt="3D render" data-tooltip="3D 모델링으로 만든 렌더링 이미지">3D 렌더</button>
                                    <button class="option-btn" data-prompt="pixel art" data-tooltip="레트로 게임 감성의 픽셀 아트">픽셀 아트</button>
                                    <button class="option-btn" data-prompt="voxel art" data-tooltip="3D 픽셀인 복셀을 이용한 아트">복셀 아트</button>
                                    <button class="option-btn" data-prompt="glitch art" data-tooltip="디지털 오류를 미학적으로 표현">글리치 아트</button>
                                    <button class="option-btn" data-prompt="cyberpunk" data-tooltip="네온과 첨단 기술의 사이버펑크">사이버펑크</button>
                                    <button class="option-btn" data-prompt="steampunk" data-tooltip="증기기관 시대의 스팀펑크">스팀펑크</button>
                                </div>
                            </div>
                             <div class="accordion-container">
                                <div class="accordion-header">시대별 무드</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="baroque style" data-tooltip="웅장하고 극적인 바로크 양식">바로크</button>
                                    <button class="option-btn" data-prompt="renaissance painting" data-tooltip="고전적이고 균형잡힌 르네상스 회화">르네상스</button>
                                    <button class="option-btn" data-prompt="impressionism" data-tooltip="빛과 색채를 중시한 인상주의">인상주의</button>
                                    <button class="option-btn" data-prompt="expressionism" data-tooltip="감정을 강렬하게 표현하는 표현주의">표현주의</button>
                                    <button class="option-btn" data-prompt="surrealism" data-tooltip="초현실적이고 꿈 같은 장면의 초현실주의">초현실주의</button>
                                    <button class="option-btn" data-prompt="cubism" data-tooltip="대상을 여러 시점에서 본 듯한 입체주의">입체주의</button>
                                    <button class="option-btn" data-prompt="pop art" data-tooltip="대중 문화를 소재로 한 팝 아트">팝 아트</button>
                                    <button class="option-btn" data-prompt="minimalism" data-tooltip="단순함과 간결함을 추구하는 미니멀리즘">미니멀리즘</button>
                                    <button class="option-btn" data-prompt="art nouveau" data-tooltip="유려한 곡선과 장식적인 아르누보">아르누보</button>
                                </div>
                            </div>
                            <div class="accordion-container">
                                <div class="accordion-header">추천 조합</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="epic pixel art, luminous gold and deep indigo palette, high contrast, heavy dithering, emissive light" data-tooltip="웅장하고 마법적인 분위기의 픽셀 아트. 발광하는 금색과 깊은 남색을 사용합니다.">에픽 픽셀 아트</button>
                                    <button class="option-btn" data-prompt="dithering" data-tooltip="색상 전환을 부드럽게 만드는 레트로 스타일 기법입니다.">디더링</button>
                                    <button class="option-btn" data-prompt="architectural blueprint style, technical drawing" data-tooltip="기술 도면 스타일의 이미지를 생성합니다.">건축가 청사진</button>
                                    <button class="option-btn" data-prompt="catalog style, product photography, clean, informational" data-tooltip="제품 카탈로그처럼 피사체를 깔끔하고 명확하게 보여주는 스타일에 최적화되어 있습니다.">카탈로그 스타일</button>
                                </div>
                            </div>
                        </div>
`;
