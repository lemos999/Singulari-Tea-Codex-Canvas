Plan Type: Implementation Report
Workstream: Notes View Simplification and Archive/Memo Separation
Version: v01
Status: Completed
Created: 2026-04-14 23:59 KST
Related Plan: plan/20260414-234000--work-plan--notes-view-simplification-and-archive-separation--v01.md

# Summary

This pass removed the legacy Notes recall view toggles from the live runtime surface, simplified recall rendering onto the modern canonical path, and separated archive-like notes from ordinary memo notes in the Notes workspace. The change was kept within the Notes shell/state/render/CSS surface and published only after a focused validation pass succeeded.

# Root Backup

- `backup_20260414-233128--pre-notes-view-restructure.zip`

# Implementation Scope

## 1. Recall surface cleanup

- Removed recall compatibility/editor toggles from the live Notes runtime by removing those nodes during DOM rebind.
- Stopped binding removed toggle elements into global runtime state.
- Removed active runtime wiring for compatibility/editor toggle events.
- Simplified `renderTurn(...)` so learning-note recall uses the canonical structured block path only.

Touched files:

- `Ailey/src/01_state/001_state_globalVars.js`
- `Ailey/src/05_features_notes/315_notes_recall_viewer.js`
- `Ailey/src_css/019_notes_job_ui.css`
- `Ailey/src_css/018_notes_recall_viewer.css`

## 2. Notes list separation

- Added explicit archive-vs-memo classification helpers.
- Added a new separated Notes list render path.
- Split pinned notes into `고정 아카이브` and `고정 메모`.
- Split top-level unassigned notes into `일반 아카이브` and `일반 메모`.
- Grouped projects into `아카이브 폴더` or `메모 폴더` based on their stored note mix.
- For mixed projects, added separate internal `아카이브` and `메모` sections instead of one mixed note stack.

Touched files:

- `Ailey/src/05_features_notes/320_notes_ui.js`
- `Ailey/src_css/016_notes_list_view.css`

# Validation

Validation harness:

- `visual-tests/validate_notes_view_cleanup.js`

Validation output:

- `visual-tests/notes-view-cleanup-2026-04-14T14-58-42/validation.json`
- `visual-tests/notes-view-cleanup-2026-04-14T14-58-42/validation-summary.txt`
- `visual-tests/notes-view-cleanup-2026-04-14T14-58-42/01-notes-list-desktop.png`
- `visual-tests/notes-view-cleanup-2026-04-14T14-58-42/02-notes-recall-desktop.png`
- `visual-tests/notes-view-cleanup-2026-04-14T14-58-42/03-notes-list-mobile.png`

Observed results:

- `compatibilityTogglePresent=false`
- `recallEditorTogglePresent=false`
- `archiveSectionPresent=true`
- `memoSectionPresent=true`
- `archiveContainsLearning=true`
- `memoContainsMemo=true`
- `editorViewActiveForMemo=true`
- `memoDidNotRouteToRecall=true`
- `recallViewActive=true`
- `recallSearchPresent=true`
- `mobileCompatibilityTogglePresent=false`
- `mobileRecallEditorTogglePresent=false`
- `mobileArchiveSectionPresent=true`
- `mobileMemoSectionPresent=true`
- `pageErrorCount=0`
- `consoleErrorCount=0`

# Publish

Publish repo:

- `Singulari-Tea-Codex-Canvas-pr`

Published bundle files:

- `bundle/main.js`
- `bundle/main.css`

GitHub target:

- `lemos999/Singulari-Tea-Codex-Canvas`

Commit:

- `b489daf` — `Simplify Notes recall view and split archive groups`

# Residual Notes

- The shell template file still contains the old recall button markup, but the live runtime removes those nodes during DOM rebind and they no longer participate in behavior.
- One dead helper remains in `315_notes_recall_viewer.js`; it is now behaviorally inert and can be removed in a later source-only cleanup pass if desired.
