# Work Plan: Inline Message Actions Redesign

- Timestamp: 2026-04-14 23:03 KST
- Type: behavior and UI redesign
- Status: completed
- Scope: replace the floating message hover toolbar with bottom-integrated inline message actions that visually match the existing response meta line

## Understanding

The current side-floating action toolbar keeps causing clipping, anchoring, and affordance issues. The requested replacement is a stable inline action pattern that lives in the message footer area, visually aligned with the existing response metadata line such as duration, model, and compaction chips.

## Goals

- Remove the floating side toolbar pattern entirely.
- Render message actions in a bottom meta/action row that feels native to the existing response meta line.
- Keep copy, delete, and regenerate working.
- Support desktop and mobile with the same stable layout.
- Exclude the new inline action UI from archive extraction.

## Steps

1. Replace toolbar-specific rendering helpers with inline action markup helpers. Completed.
2. Integrate actions into AI response meta rows and add a matching footer row for user messages. Completed.
3. Remove hover/touch toolbar event wiring and switch to click delegation for inline action buttons. Completed.
4. Add archive ignore rules for the new inline action elements. Completed.
5. Validate desktop/mobile layout and action behavior, then publish if clean. Completed.

## Rollback Boundary

- `Ailey/src/04_features_chat/211_chat_actions.js`
- `Ailey/src/04_features_chat/224_chat_ui_messages_element_factory.js`
- `Ailey/src/04_features_chat/225_chat_ui_messages_toolbar.js`
- `Ailey/src/03_core/120_core_main_initializer.js`
- `Ailey/src/03_core/130_core_archiver.js`
- `Ailey/src_css/009_message_toolbar.css`
- `Ailey/src_css/022_chat_messages.css`
- `visual-tests/validate_inline_message_actions_redesign.mjs`

## Scoreboard

- Current score: 100
- Score source: user
- Last updated: 2026-04-14 23:03 KST
- Score rationale: user explicitly awarded 100 and asked for a follow-up polish redesign
- What improved: compacting and message actions are already functioning
- What remains unsatisfactory: side-floating action UI is visually unstable and clips at the edges
- Next score action: keep 100 by replacing it with a stable footer action row without breaking copy/delete/regenerate

### Score History

- 2026-04-14 23:03 KST | 100 | user | carried forward from the accepted prior pass; this is a redesign refinement

## Verification

- `visual-tests/inline-message-actions-2026-04-14T14-15-10-972Z/validation-summary.txt`
- `floatingToolbarPresent=false`
- `userActionsVisible=true`
- `aiActionsVisible=true`
- `userCopyWorked=true`
- `userDeleteWorked=true`
- `regenerateCalled=true`
- `mobileUserActionsVisible=true`
- `mobileAiActionsVisible=true`
- `pageErrorCount=0`
- `consoleErrorCount=0`
