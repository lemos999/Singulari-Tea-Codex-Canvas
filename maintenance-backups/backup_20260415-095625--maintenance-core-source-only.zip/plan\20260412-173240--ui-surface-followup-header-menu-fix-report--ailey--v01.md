# Ailey UI Surface Follow-up Report

- Artifact Type: implementation-report
- Created: 2026-04-12 17:32:40 +09:00
- Scope: fix post-cleanup manual-validation defects in exported/live UI header strings, chat icon rendering, and visualization overflow menu placement
- Related Plan: `20260412-161230--ui-surface-rationalization-plan--ailey--v01.md`

## User-Reported Defects

- Korean labels in the exported/live header UI were mojibake.
- The chat toggle button remained clickable, but its icon disappeared.
- The integrated `AI edit` submenu could open outside the visible boundary, making submenu items impossible to click.
- Visualization overflow actions were still labeled in English instead of Korean.

## Root Cause

### 1. Header source strings were already corrupted in the shell template

- `Ailey/src/00_shell/000_shell_template.js` contained corrupted Korean literals in button titles, placeholders, and export menu labels.
- The `chat-toggle-btn` markup had a broken `title` attribute that swallowed the inline SVG start tag, so the button still existed but the icon markup was invalid.

### 2. Context submenu placement assumed infinite space to the right

- `Ailey/src/02_utils/012_utils_context_menu.js` only clamped the top-level context menu to the viewport.
- Nested submenus in `Ailey/src_css/008_context_menu.css` always opened to the right with a fixed offset.
- When the visualization rail sat close to the right edge, submenu content rendered outside the visible area.

### 3. Visualization overflow UI still exposed untranslated labels

- `Ailey/src/02_utils/013_utils_block_renderer.js` had active user-facing labels such as `AI edit`, `Copy source`, `Expand`, `Regenerate`, and `More`.
- These were not aligned with the current Korean-facing product surface.

## Implemented Fix

### Header repair

- Rebuilt `Ailey/src/00_shell/000_shell_template.js` with valid Korean labels for:
  - quick query placeholder and template toggle
  - export dropdown items
  - notes/chat/theme/global snapshot tooltips
- Restored a valid `chat-toggle-btn` attribute boundary so the inline SVG renders again.

### Viewport-aware submenu behavior

- Replaced `Ailey/src/02_utils/012_utils_context_menu.js` with a viewport-aware implementation.
- Added submenu positioning logic that:
  - flips the submenu to the left when the right edge would overflow
  - aligns the submenu to the bottom when the lower edge would overflow
  - constrains submenu height to the visible viewport
- Extended `Ailey/src_css/008_context_menu.css` with:
  - `.open-left`
  - `.align-bottom`
  - `.submenu-visible`
  - max-width and max-height protections

### Korean UI label pass for visualization actions

- Updated user-facing overflow labels in `Ailey/src/02_utils/013_utils_block_renderer.js`:
  - `노트에 저장`
  - `AI 편집`
  - `옵션 조정 후 재생성`
  - `코드 문제 자동 수정`
  - `채팅으로 설명`
  - `소스 복사`
  - `HTML 복사`
  - `JSON 복사`
- Updated primary rail button titles to:
  - `확대 보기`
  - `다시 생성`
  - `더보기`
- Localized clipboard toasts and the explain-in-chat prompt.

## Verification

- `node --check Ailey/src/00_shell/000_shell_template.js`
- `node --check Ailey/src/02_utils/012_utils_context_menu.js`
- `node --check Ailey/src/02_utils/013_utils_block_renderer.js`
- `node Ailey/bundler.js`

All checks passed.

## Deployment

- Hosted bundle repo: `Singulari-Tea-Codex-Canvas`
- Branch: `main`
- Deployment commit: `0480ad9`
- Commit message: `Fix header labels and visualization menu placement`

## Remaining Validation

- User should retest the same exported/live HTML in the browser.
- Expected confirmations:
  - header export dropdown labels display correctly in Korean
  - chat icon renders again
  - `AI 편집` submenu stays inside the viewport near the right edge
  - visualization overflow actions remain clickable without crossing the boundary
