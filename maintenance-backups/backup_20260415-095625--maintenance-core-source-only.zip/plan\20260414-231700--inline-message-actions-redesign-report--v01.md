# Report: Inline Message Actions Redesign

- Timestamp: 2026-04-14 23:17 KST
- Status: completed

## What Changed

- Removed the floating side hover/tap toolbar pattern from chat message actions.
- Moved `copy`, `delete`, and `regenerate` into stable inline action rows rendered below each message.
- Kept AI response metadata and actions visually related so the footer feels like one coherent response-info surface.
- Added a matching compact footer row for user messages.
- Switched interaction handling to click delegation on inline action buttons.
- Excluded the new action UI from archive extraction.

## Why This Design

- Side toolbars kept clipping at the container edges and created repeated anchor and hover problems.
- A footer action row is stable on desktop and mobile, easier to discover, and avoids layout surprises.
- It matches the existing response meta line better than a floating side affordance.

## Validation

- Harness: `visual-tests/validate_inline_message_actions_redesign.mjs`
- Result folder: `visual-tests/inline-message-actions-2026-04-14T14-15-10-972Z`
- Results:
  - `floatingToolbarPresent=false`
  - `userActionsVisible=true`
  - `aiActionsVisible=true`
  - `userCopyWorked=true`
  - `userDeleteWorked=true`
  - `regenerateCalled=true`
  - `latestAiRemovedBeforeRegenerate=true`
  - `userActionsBelowMessage=true`
  - `aiActionsBelowMessage=true`
  - `aiMetaIncludesCompact=true`
  - `mobileUserActionsVisible=true`
  - `mobileAiActionsVisible=true`
  - `pageErrorCount=0`
  - `consoleErrorCount=0`

## Publish Surface

- `bundle/main.js`
- `bundle/main.css`
