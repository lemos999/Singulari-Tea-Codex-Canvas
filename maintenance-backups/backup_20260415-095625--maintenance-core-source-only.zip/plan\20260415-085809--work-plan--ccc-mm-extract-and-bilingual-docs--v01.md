# Work Plan

Plan Type: work-plan
Workstream: Extract `.ccc` canvas rules from the Ailey source prompt and serialize them into MM-style standalone reference documents
Version: v01
Status: Superseded
Created: 2026-04-15 08:58:09 +09:00
Last Updated: 2026-04-15 09:07:44 +09:00
Related Plan: `plan/20260415-080000--work-plan--canvas-mm-transformation--v01.md`
Superseded By: `plan/20260415-090744--revision-plan--ccc-generic-html-runtime-rules--v01.md`
Current Completion State: Original `.ccc` extraction completed, then superseded by a later approved revision that removes study-specific framing and rewrites the documents as generic HTML runtime rules
Completed So Far: The user approved the original extraction work. The source file sections governing `.ccc` activation, shared trigger gating, state mapping, freestyle shell requirements, visual-surface minimums, runtime functions, and post-generation compass behavior were identified. Existing MM-style reference material and a prior canvas MM transformation artifact were reviewed to calibrate tone and density. Two standalone Markdown documents were then created under `Ailey/`: one English MM-style `.ccc` extraction and one Korean counterpart with equivalent operational meaning. Both files were checked for presence and for explicit coverage of the main `.ccc` requirements, including state routing, `[M-UGE]` and `[M-1.5]`, Tailwind, Font Awesome, `visualData`, `Promise.all(...)`, `DOMContentLoaded`, the runtime functions, the model constant, and the mandatory post-generation compass behavior. After delivery, the user requested a narrower and more generic direction that removes study-oriented content and reframes `.ccc` as a generic HTML runtime rule set, so this plan is no longer the active delivery record.
Remaining Work: Follow the successor revision plan for the actual active direction
Current Blockers: None
Next Step: Continue under the successor revision plan and rewrite the documents to remove education-specific framing.

## Objective

Produce the smallest complete documentation change that satisfies the user request without altering the original source prompt. The user wants the `.ccc` material from `Ailey/Ailey & Bailey X_260304.md` separated out and reorganized using the MM narrative-serialization technique referenced through `promptmaker.md` and related MM artifacts. The output must be a new Markdown document, and the user then explicitly requested a second Markdown document in Korean as well. The result should therefore be two new standalone reference files that isolate the `.ccc` path and the minimum shared rules that are necessary to understand or execute that path, while excluding unrelated `.cc`-only transmutation details.

The design intent is to preserve operational truth while changing presentation form. This is not a creative rewrite of behavior. It is a documentation extraction and reshaping exercise. The original source remains the authority. The new files should read like dense, binding MM prose rather than like excerpted module notes, but they must still preserve trigger strictness, state logic, shell requirements, minimum visual obligations, runtime function contracts, and the mandatory text-based compass that follows the HTML artifact. The user emphasized that the work must be done delicately, so fidelity takes priority over compression bravado or stylistic novelty.

## Confirmed Facts

The `.ccc` path lives inside the `[M-C] Canvas Engine` portion of the source document. It is not a file extension and not a general topic tag. It is a literal trigger substring in user input. The source also includes higher-level no-canvas rules that make `.cc` or `.ccc` the only valid activation path for canvas or artifact generation. Within the canvas engine, the state matrix, the special rule for `.ccc` topic entry, the Path B freestyle protocol, the standalone HTML shell, the Tailwind and Font Awesome dependencies, the visual surface minimum, the `visualData` requirement, the runtime image generation functions, the save function, and the post-generation compass rule are all relevant to `.ccc`.

The source also contains many `.cc`-specific rules, especially the standard-mode transmutation guide and immutable shell details. Those should not be pulled into the new `.ccc`-only documents except where a shared upstream rule is required to make `.ccc` understandable. Examples of shared upstream rules that still matter are the binary canvas trigger lock, the dormant behavior when neither token is present, the state-matrix routing, and the special handling that a newly entered `.ccc` topic becomes State 1 and must end in the proposal compass rather than the gateway.

The reviewed MM-style material shows that the expected transformation is not a bullet summary. Instead, the content should be flattened into continuous imperative prose that narrates structures, tags, assets, and behavioral requirements in-line. The prior transformed canvas summary also demonstrates that dense paragraph serialization, explicit runtime descriptions, and exact asset URLs are acceptable and useful in this workspace.

## Assumptions

The smallest safe assumption is that the new documents should live beside the source under `Ailey/` rather than in a backup or plan directory, because the user asked for new Markdown files related to that prompt file and did not request archival placement elsewhere. Another safe assumption is that the first new file should be in English because the user first requested the MM-based reorganization and only then separately requested that one more Markdown file be created in Korean. A bilingual pair of files, one English and one Korean, best satisfies the wording without forcing the Korean version to replace the first deliverable.

Another safe assumption is that the Korean file should preserve operational meaning rather than perform a mechanically literal translation. The MM technique in this workspace values binding clarity and natural narrative force. Therefore the Korean document should read as a faithful Korean-native operational prompt narrative, not as awkward mirror text. At the same time, technical literals such as `.ccc`, `runImageGeneration()`, `downloadPage()`, `visualData`, `Promise.all(...)`, URLs, `<!DOCTYPE html>`, and key HTML tag names should remain exact where exactness matters for execution or interpretation.

A final important assumption is that the user wants extraction rather than source modification. The source file will therefore remain unchanged. Only new files and the required plan record will be written.

## Deliverables

The work will produce three artifacts. The first artifact is this active plan record. The second artifact will be an English MM-style reference document that isolates the `.ccc` contract and the minimum shared rules needed to operate it. The third artifact will be a Korean MM-style counterpart with equivalent operational scope and fidelity.

The target output filenames will be:

`Ailey/Ailey & Bailey X_260304_ccc_mm.md`

`Ailey/Ailey & Bailey X_260304_ccc_mm_ko.md`

These names are intentionally explicit, minimally invasive, and easy to relate back to the source file without implying that the source itself has been replaced or edited.

## Scope Boundaries

The new documents should include the parts of the source that directly govern `.ccc` behavior. That includes the global canvas safety dependency on literal trigger tokens, the canvas engine trigger lock, the shared logic reference protocol only to the extent it shapes `.ccc`, the state matrix and the `.ccc`-specific State 1 rule, the freestyle singularity protocol, the standalone freestyle shell contract, the minimum visual count and structured-visual requirement, the floating or fixed control panel requirement, the `visualData` minimum, the runtime image generation and download function behavior, the `DOMContentLoaded` execution hook, and the post-generation text compass rule.

The new documents should not include the full `.cc` transmutation guide, the `.cc` immutable shell, or unrelated prompt systems such as `.ff`, standard markdown sandwich rules, or non-canvas protocols except where the no-canvas trigger boundary is necessary to contextualize `.ccc`. This avoids accidental scope drift and respects the user request for `.ccc` content only.

The documents should not be rewritten into an abstract commentary about the system. They should remain directly usable as prompt logic or operator-facing reference. The prose may be MM-style, but the obligations must still feel executable.

## Transformation Strategy

The transformation approach should follow the MM principle of narrative serialization while keeping the extracted logic crisp and reviewable. The source content will first be mentally grouped into five functional layers: activation boundary, shared routing logic, `.ccc`-specific generation intent, `.ccc` shell and runtime contract, and mandatory post-generation follow-up. Those layers will then be re-expressed as dense imperative prose that removes list dependence but keeps explicit order and binding force.

The English version should preserve exact technical literals where execution or host compatibility depends on them. Exact URLs, function names, variable names, model name, and key HTML tags should stay literal. Behavioral rules that are only implied by combination in the source should be described conservatively and only when the implication is operationally necessary. For example, the fact that `.ccc` wins over `.cc` is best expressed indirectly through the exact trigger conditions rather than through a new doctrinal abstraction.

The Korean version should not simply mirror sentence by sentence if that makes the result stiff. It should preserve the same authority structure, sequence, and precision, but it can choose Korean-native connective logic so that the document remains readable and strong. Technical literals still remain unchanged where required. Care is especially needed around the distinction between preserving the host identity and changing the shell freedom, around state transitions, and around the instruction that the text-based compass is mandatory after HTML generation.

## Risks And Controls

The first risk is over-inclusion. Because `.ccc` depends on some shared rules, it would be easy to accidentally re-import too much `.cc` or general-canvas material. To control that, every paragraph in the new documents must answer one of two questions: does this rule directly govern `.ccc`, or is it the minimum shared precondition required to understand `.ccc` behavior. If the answer is neither, it should stay out.

The second risk is under-specification. MM compression can make documents feel elegant while silently dropping runtime-critical details. To control that, the new documents must explicitly retain the standalone HTML5 requirement, the no-build constraint, the Tailwind CDN requirement, the Font Awesome dependency, the image id requirement, the `visualData` minimum, the `TARGET_MODEL` constant, the network request shape in principle, the parallel image generation expectation, the save behavior, and the mandatory post-HTML compass step.

The third risk is translation drift between the English and Korean files. To control that, the Korean version should be derived from the same extracted rule inventory as the English version rather than improvised independently. The wording can be culturally natural, but the rule coverage should match. Verification will compare both files against the same checklist.

The fourth risk is false precision by paraphrase. If the prose becomes too editorial, it may blur what is mandatory versus what is descriptive. To control that, imperative language will be used consistently. Each paragraph should tell the reader what must happen, under what condition, and with what required outcome.

The fifth risk is placement ambiguity. If the files are saved outside the `Ailey/` directory, later lookup will be awkward. To control that, both output files will be created directly inside `Ailey/`.

## Work Sequence

Step one is to write the English MM-style extraction file. This should be the anchor version because the source rules are in English and the technical literals are easiest to preserve directly there. The English file should open with the activation boundary, move through state routing, then settle into the `.ccc` freestyle contract, and end with post-generation obligations. It should read as one continuous operational narrative rather than a chopped summary.

Step two is to write the Korean counterpart. The Korean file should follow the same logical sequence and coverage but be rewritten in Korean prose. Literal tokens, tag names, URLs, function names, variable names, and the model identifier will remain unchanged. Where the English phrasing relies on idiom, the Korean file should recast the sentence while preserving the same instruction strength.

Step three is to verify fidelity. Verification should not only check whether the files exist. It should confirm that the English and Korean documents both cover the trigger boundary, dormant fallback, state routing, the `.ccc` State 1 special rule, the immersive article or dashboard vs skill tree or galaxy map split, the standalone HTML5 rule, vanilla JavaScript and no-build constraints, Tailwind and Font Awesome dependencies, minimum visual-surface count, fixed controls, `<img id="...">` requirement, `visualData` minimum of at least three concrete entries, the key runtime functions, `Promise.all(...)`, `DOMContentLoaded`, and the mandatory text-based compass after the HTML artifact.

Step four is to update this plan record to reflect implementation and verification results, including the current completion state, remaining work, and the provisional score state.

## Validation Approach

Validation will be textual and behavior-oriented because this task is documentation authoring rather than software execution. The primary validation method is source-to-output coverage comparison. The source rules relevant to `.ccc` have already been isolated from the original document. Each target file should be checked against that inventory.

The English document passes validation only if it clearly contains all of the following: the requirement that `.ccc` must be a literal input trigger for canvas activation, the dormant fallback when triggers are absent, the reference to the shared state matrix, the rule that a newly entered `.ccc` topic is always State 1 and must end in the proposal compass, the role of Ailey as the preserved text persona, the difference between State 2 output and State 1 or State 3 output, the standalone HTML5 and vanilla JS constraints, Tailwind CSS via CDN, no React, no Vue, no JSX, no bundlers, the minimum visual-surface rule, the fixed control actions, the requirement that AI images use unique `<img id="...">` elements, the presence of `apiKey`, `TARGET_MODEL`, `visualData`, `generateSingleImage`, `runImageGeneration`, `downloadPage`, `Promise.all(...)`, `DOMContentLoaded`, and the mandatory post-generation text compass.

The Korean document passes validation only if it preserves the same rule inventory with the same sequencing and no loss of mandatory force, even though the prose is localized. Technical literals must remain intact where exactness matters. The Korean prose must not turn hard requirements into soft suggestions.

The plan passes acceptance when both files exist in `Ailey/`, both are clearly MM-style narrative serializations rather than bullet summaries, neither drifts into `.cc` standard-mode detail, and both cover the required `.ccc` operational contract with enough precision to be used as standalone references.

## Definition Of Done

This task is done when the following are all true. A new English Markdown file exists in `Ailey/` and contains a delicate but faithful MM-style extraction of the `.ccc` logic. A second Korean Markdown file exists in `Ailey/` and preserves the same logic with natural Korean operational prose. The original source file remains untouched. The active plan file reflects the finished state, what was created, what was verified, and whether any residual uncertainty remains. The residual uncertainty should ideally be limited to user preference on style density rather than to rule coverage or correctness.

## Notes On Design Intent

The smallest complete design for this request is documentation-only. No source edits are necessary, no helper scripts are necessary, and no subagents are necessary. The deliverables are self-contained reference files. This keeps risk low, preserves rollback safety, and aligns with the user request.

The documents should be helpful to future maintenance work. By extracting only `.ccc`, they reduce the cognitive overhead of reading the full mixed `.cc` and `.ccc` source. By using MM serialization, they match the transformation style already being explored in this workspace. By producing a Korean counterpart rather than leaving translation to a later step, they reduce rework and make comparison easier.

## Scoreboard

Current Score: 50
Score Source: provisional
Last Updated: 2026-04-15 09:07:44 +09:00
Score Rationale: The first requested extraction was delivered, but it is no longer the active target because the user then approved a material revision that removes study-specific framing and converts the documents into generic `.ccc` HTML runtime rules. This plan remains historically successful for its original scope but should no longer be treated as the active satisfaction record.
What Improved: The original bilingual extraction exists and served as the baseline for the next refinement.
What Remains Unsatisfactory: The active user preference has moved beyond this plan, so the current documents still need to be generalized under the successor plan.
What Should Happen Next To Raise Or Maintain The Score: Complete the generic-runtime rewrite under the successor plan and verify that educational vocabulary has been removed.

## Score History

- 2026-04-15 08:58:09 +09:00 | 45 | provisional | Approved planning state recorded after source review and before document authoring.
- 2026-04-15 09:01:41 +09:00 | 50 | provisional | English and Korean `.ccc` MM extraction documents were created and verified for core trigger, state, shell, runtime, and post-generation coverage.
- 2026-04-15 09:07:44 +09:00 | 50 | provisional | Plan superseded after the user approved a new direction to remove study-specific framing and rewrite the documents as generic `.ccc` HTML runtime rules.
