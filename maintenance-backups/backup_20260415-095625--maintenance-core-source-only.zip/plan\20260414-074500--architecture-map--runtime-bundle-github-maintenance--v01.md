Plan Type: architecture-map
Workstream: runtime-bundle-github-maintenance
Version: v01
Status: Active
Created: 2026-04-14 07:45 KST
Updated: 2026-04-14 07:45 KST
Related: `plan/20260414-072420--chat-receive-pipeline-deep-review-report--v01.md`
Current Completion: 100%
Completed Work:
- Mapped the source/build/publish/runtime chain used by `.cc`, local HTML exports, and the persistent shell.
- Documented why the GitHub publish step exists and what breaks if it is skipped.
- Added maintenance notes for bundle generation, GitHub Pages delivery, shell mounting, placeholders, and visualization/chat pipelines.
Remaining Work:
- None for this documentation pass.
Blockers:
- None.
Next Step:
- Use this map as the default maintenance reference before changing bundle delivery, bootstrap HTML, placeholder behavior, or publish flow.

# Scoreboard

- Current Score: 50
- Score Source: provisional
- Last Updated: 2026-04-14 07:45 KST
- Score Rationale: The requested architecture and maintenance map has been written, but the user has not yet confirmed that the level of detail is sufficient.
- What Improved: The runtime now has an explicit maintenance document that explains the build, publish, and mount path end to end.
- What Remains Unsatisfactory: The document has not yet been iterated based on maintainer feedback.
- Next Actions Required To Raise Or Maintain The Score:
- Use the map during the next maintenance task and add any missing operational detail discovered in practice.
- Score History:
- 2026-04-14 07:45 KST | 50 | provisional | Initial architecture maintenance map created.

# Objective

Document the actual runtime and deployment topology so future maintenance does not depend on memory or ad hoc reverse engineering.

This document answers:

1. Why we push to GitHub at all
2. Which directory is the source of truth for code edits
3. How the local source turns into the published runtime
4. How exported or local HTML files consume that runtime
5. Where chat, notes, placeholder, and visualization behavior actually live
6. Which layer to edit for each class of problem

# Why GitHub Publish Exists

GitHub is not used here as a generic backup. It is part of the runtime delivery path.

Most `.cc` artifacts and many local HTML files include the canonical shell assets directly from:

- `https://lemos999.github.io/Singulari-Tea-Codex-Canvas/bundle/main.js`
- `https://lemos999.github.io/Singulari-Tea-Codex-Canvas/bundle/main.css`

That means:

1. Local source edits in `Ailey/src` or `Ailey/src_css` do nothing by themselves for already-generated HTML artifacts.
2. The source must be bundled into `Ailey/bundle/main.js` and `Ailey/bundle/main.css`.
3. Those bundles must then be copied into the publish repository:
   `Singulari-Tea-Codex-Canvas-pr/bundle/`
4. The publish repository must be committed and pushed to GitHub.
5. GitHub Pages then serves the new runtime bundle to any HTML artifact that references those URLs.

If the GitHub push is skipped, the following files will still load the old runtime:

- local standalone `.html` artifacts that use the published bundle URL
- `.cc` outputs following the canonical shell contract
- live-export or extracted pages that preserve the same remote bundle references

In short:

- local source tree = editable implementation
- bundle output = deployable runtime artifact
- GitHub Pages = shared delivery channel used by the HTML pages

# Directory Roles

## 1. Main working source tree

Path:

- `Ailey/`

Key subdirectories:

- `Ailey/src/`
- `Ailey/src_css/`
- `Ailey/vendor/`
- `Ailey/bundle/`
- `Ailey/bundler.js`

Purpose:

- `src/` contains the JavaScript source modules
- `src_css/` contains the CSS source modules
- `vendor/` contains bundled third-party browser libraries
- `bundler.js` produces the minified runtime
- `bundle/` is the local build output used for testing before publish

## 2. Publish repository

Path:

- `Singulari-Tea-Codex-Canvas-pr/`

Purpose:

- thin publish repo for GitHub Pages delivery
- receives updated `bundle/main.js` and `bundle/main.css`
- is the repo that gets committed and pushed

## 3. Generated or test artifacts

Examples:

- `태양계의 파노라마.html`
- `태양계 시스템의 구조와 역학 (1).html`
- `대항해시대- 세계의 지평선을 넓히다.html`
- `visual-tests/...`

Purpose:

- consumer artifacts that mount the runtime
- verification fixtures
- reproductions for shell, fullscreen, placeholder, and chat behavior

# High-Level Topology

```text
Editable source
  └─ Ailey/
     ├─ src/
     ├─ src_css/
     ├─ vendor/
     └─ bundler.js
          |
          v
Local build output
  └─ Ailey/bundle/
     ├─ main.js
     └─ main.css
          |
          v
Publish copy
  └─ Singulari-Tea-Codex-Canvas-pr/bundle/
     ├─ main.js
     └─ main.css
          |
          v
GitHub push
  └─ github.com/lemos999/Singulari-Tea-Codex-Canvas
          |
          v
GitHub Pages delivery
  └─ https://lemos999.github.io/Singulari-Tea-Codex-Canvas/bundle/main.js
  └─ https://lemos999.github.io/Singulari-Tea-Codex-Canvas/bundle/main.css
          |
          v
HTML artifacts
  └─ local .html / live export / .cc pages
          |
          v
renderAppShell(...)
          |
          v
Persistent shell + mounted payload + placeholder hydration
```

# Runtime Mount Path

## Canonical shell contract

The `.cc` prompt contract requires HTML pages to include:

- the remote `main.css`
- the remote `main.js`
- a hidden `<main id="ai-content-placeholder">...</main>`
- a bootstrap call:
  `renderAppShell(c.outerHTML, document.title, canvasId)`

This contract is explicitly documented in:

- `cc_universal_module_mm.md`

## Mount responsibility

The core shell mount lives in:

- `Ailey/src/00_shell/005_shell_part6_main_assembler.js`

Key responsibility split:

1. `renderAppShell(...)`
   - entry point called by the HTML artifact
2. `ensureCoreShellMounted(...)`
   - guarantees persistent shell elements exist
3. `normalizeCanvasHtmlInput(...)`
   - unwraps a `<main id="ai-content-placeholder">...</main>` input when needed
4. `detectCanvasLayoutMode(...)`
   - decides `free` vs `standard`
5. `createCanvasSurface(...)`
   - builds the correct host container
6. payload mounting
   - inserts the artifact content into the shell-owned runtime

## Runtime shell vs payload ownership

```text
HTML artifact
  ├─ head resources
  ├─ loader
  └─ hidden #ai-content-placeholder
        |
        v
renderAppShell(...)
        |
        +-- runtime-owned shell
        |   ├─ top header
        |   ├─ chat panel
        |   ├─ notes panel
        |   ├─ tool overlays
        |   └─ global controls
        |
        +-- payload-owned mounted content
            ├─ learning-content or free-layout host
            ├─ content sections
            ├─ generated images
            ├─ visualization blocks
            └─ local support surfaces
```

Maintenance rule:

- shell bugs belong in shell source
- payload rendering bugs usually belong in the block renderer or placeholder pipeline
- do not “fix” shell issues by changing exported HTML structure unless the shell contract itself has changed

# Build Pipeline

The bundler lives in:

- `Ailey/bundler.js`

## What it does

1. Ensures required dev dependencies exist
2. Reads vendor libraries in fixed order
3. Reads source files from:
   - `src/00_shell`
   - `src/`
4. Separates regular files from ESM files
5. Bundles ESM files through `esbuild`
6. Concatenates everything
7. Minifies JavaScript through `terser`
8. Concatenates and minifies CSS through `postcss + cssnano`
9. Writes output to:
   - `Ailey/bundle/main.js`
   - `Ailey/bundle/main.css`

## Practical maintenance note

If you edit any of these:

- `Ailey/src/...`
- `Ailey/src_css/...`
- `Ailey/vendor/...`

you must rebuild:

```powershell
node .\Ailey\bundler.js
```

If you skip the rebuild, the runtime still uses stale bundle output.

# Publish Pipeline

## Why a separate publish repository exists

The working tree contains source, tests, backups, and many local artifacts. The publish repo is intentionally much thinner and safer for CDN-style delivery.

Publish repo path:

- `Singulari-Tea-Codex-Canvas-pr/`

## Publish steps

```text
Edit source in Ailey/src or Ailey/src_css
  -> run node Ailey/bundler.js
  -> copy Ailey/bundle/main.js to Singulari-Tea-Codex-Canvas-pr/bundle/main.js
  -> copy Ailey/bundle/main.css to Singulari-Tea-Codex-Canvas-pr/bundle/main.css
  -> git add / commit / push in Singulari-Tea-Codex-Canvas-pr
  -> GitHub Pages updates remote asset URLs
  -> HTML artifacts start loading the new runtime
```

## Why this is operationally useful

- keeps deployment scope tight
- avoids accidentally publishing local backups or experimental files
- makes rollback simple at the bundle level
- matches the fact that most HTML artifacts consume only the runtime bundle, not the full source tree

# Block Rendering And Placeholder Hydration

The central block rendering layer lives in:

- `Ailey/src/02_utils/013_utils_block_renderer.js`

This file is one of the most important maintenance surfaces in the system.

## It is responsible for

1. Rendering ordinary content blocks
2. Rendering visualization blocks from stored HTML fragments
3. Rendering image placeholders
4. Rendering visualization placeholders
5. Resolving placeholder display mode:
   - `slot`
   - `block`
6. Loading external visualization dependencies safely
7. Running visualization preflight repair and scoped execution
8. Wiring hover controls and overflow actions

## Important behavior split

```text
Stored block data
  ├─ visualization
  │   └─ htmlContent already exists
  │       -> renderVisualizationBlock(...)
  │
  ├─ visualization-placeholder
  │   └─ prompt exists, htmlContent absent
  │       -> generation / regeneration path
  │
  └─ generated-image-placeholder
      └─ image generation path
```

## Slot vs block

The placeholder/runtime stability contract is:

- `slot`
  - embedded inside a pre-authored frame
  - must not expand and cover nearby prose
- `block`
  - standalone support unit
  - may take its own section-sized space

Maintenance rule:

- layout breakage after generation is usually a placeholder presentation bug
- generation success but wrong frame behavior is usually a renderer bug, not a provider bug

# Visualization Generation And Regeneration Path

The generation orchestration lives in:

- `Ailey/src/03_core/121_core_initializer_visualization.js`

## This layer handles

1. turning user intent into a visualization request
2. calling the system visualization chat session
3. extracting closed fenced HTML blocks from model output
4. recovering from format errors
5. replacing placeholders with executable visualization blocks

## Recent reliability rules

This path now:

- requires complete model responses for visualization generation
- prefers closed fenced `html` blocks
- can use fallback models only when exposed by the active preset
- does not waste quota on format recovery when the actual failure is provider overload
- can lower transport retries for visualization-specific requests

## Mental model

```text
placeholder or regenerate action
  -> build visualization request
  -> send through system chat session
  -> receive model response
  -> validate completion and fences
  -> extract best HTML candidate
  -> renderVisualizationBlock(...)
```

If the response fails before extraction:

- provider issue -> surface provider failure
- format issue -> run bounded format recovery

# Chat Runtime Path

Relevant files:

- `Ailey/src/04_features_chat/213_chat_api_service.js`
- `Ailey/src/04_features_chat/215_chat_orchestrator.js`
- `Ailey/src/04_features_chat/223_chat_ui_messages_content.js`
- `Ailey/src/04_features_chat/224_chat_ui_messages_element_factory.js`

## Responsibility split

### `213_chat_api_service.js`

- provider transport
- Google REST request construction
- retry/backoff logic
- response metadata extraction
- completion metadata support

### `215_chat_orchestrator.js`

- session-level send/receive flow
- loading indicators
- AI message assembly
- completion enforcement
- provider fallback model handling
- programmatic system-session sends used by visualization regeneration

### `223_chat_ui_messages_content.js`

- markdown/code rendering
- code block labeling
- collapse behavior

### `224_chat_ui_messages_element_factory.js`

- visual message card composition
- warning/status cards for incomplete or suspicious responses

## Maintenance rule

If the user says “the AI stopped in the middle,” separate the problem into:

1. transport failure
2. completion detection
3. parser/extraction failure
4. UI collapse or rendering behavior

Do not assume it is only one of them.

# End-To-End Working Example

## Example: fix a visualization regeneration bug

```text
1. Edit source
   - usually 121_core_initializer_visualization.js
   - sometimes 213_chat_api_service.js or 215_chat_orchestrator.js

2. Rebuild
   - node .\Ailey\bundler.js

3. Verify locally
   - open the target HTML
   - reproduce regeneration
   - inspect visual-tests outputs if needed

4. Publish
   - copy updated bundle/main.js and bundle/main.css
     into Singulari-Tea-Codex-Canvas-pr/bundle/
   - commit and push that repo

5. Re-test a consumer HTML artifact
   - because the artifact loads the GitHub Pages bundle
```

## Example: fix a fullscreen hover-control bug

Start here:

- shell mounting or fullscreen host behavior:
  `Ailey/src/00_shell/...`
- visualization block toolbar or overlay behavior:
  `Ailey/src/02_utils/013_utils_block_renderer.js`
- related CSS:
  `Ailey/src_css/...`

# What To Edit For Common Problems

## Problem: “local source changed but the page still behaves the same”

Check:

1. Did `Ailey/bundler.js` run?
2. Did `Ailey/bundle/main.js` change?
3. Did the publish repo bundle get updated?
4. Was the publish repo pushed to GitHub?
5. Is the HTML file loading remote GitHub Pages assets or local substituted routes?

## Problem: “HTML looks right but shell panels behave wrong”

Likely layers:

- shell assembler
- panel logic
- shell CSS

Not usually:

- `.cc` prompt content

## Problem: “image or visualization generation covered nearby prose”

Likely layers:

- placeholder mode resolution
- `slot` vs `block`
- image fit / media fit
- renderer CSS

## Problem: “AI output was cut off”

Check in this order:

1. provider response status and retry logs
2. completion metadata
3. saved message length in history
4. fenced block extraction result
5. UI collapse state

# Safe Maintenance Checklist

Before changing runtime delivery:

1. Identify whether the issue is source-level, bundle-level, or publish-level.
2. Edit the narrowest responsible source file.
3. Rebuild with `node .\Ailey\bundler.js`.
4. Verify locally against a real HTML artifact.
5. If the HTML loads GitHub Pages assets, update the publish repo bundle.
6. Commit and push only the publish bundle unless a broader source commit is intentionally needed.
7. Keep a plan/report artifact in `plan/` when the change affects runtime behavior or maintenance assumptions.

# Files To Remember First

- Source shell mount:
  `Ailey/src/00_shell/005_shell_part6_main_assembler.js`
- Source block renderer:
  `Ailey/src/02_utils/013_utils_block_renderer.js`
- Source visualization orchestrator:
  `Ailey/src/03_core/121_core_initializer_visualization.js`
- Source chat transport:
  `Ailey/src/04_features_chat/213_chat_api_service.js`
- Source chat orchestrator:
  `Ailey/src/04_features_chat/215_chat_orchestrator.js`
- Build script:
  `Ailey/bundler.js`
- Local built runtime:
  `Ailey/bundle/main.js`
  `Ailey/bundle/main.css`
- Publish repo runtime:
  `Singulari-Tea-Codex-Canvas-pr/bundle/main.js`
  `Singulari-Tea-Codex-Canvas-pr/bundle/main.css`
- Delivery contract:
  `cc_universal_module_mm.md`

# Design Intent

The system is intentionally split into three layers:

1. editable source
2. deployable bundle
3. remotely delivered runtime

That split is not accidental overhead. It is what allows:

- reproducible local maintenance
- stable remote asset URLs for generated HTML
- bounded publish scope
- easier rollback of runtime regressions

If future maintenance preserves that separation, the system stays understandable.
