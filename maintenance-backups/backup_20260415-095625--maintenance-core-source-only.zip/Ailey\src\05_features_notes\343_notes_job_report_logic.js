/* --- Ailey & Bailey Canvas --- */
// File: 343_notes_job_report_logic.js
// Version: 2.1 (Learning Template Fix)
// Description: Modified report logic to use the current learning-project analyzer template instead of the removed chronicler template.

async function startComprehensiveReportProcess(projectId, chunkSizeInTurns = 30) {
    if (activeRefinementJob || activeReportJob) {
        showModal("이미 다른 데이터 정제 또는 보고서 생성 작업이 진행 중입니다.", () => {});
        return;
    }

    const originalActivePromptId = activePromptId;
    const toastId = `comprehensive-report-${Date.now()}`;
    trace("Report", "start", { projectId, chunkSizeInTurns });

    try {
        const project = localNoteProjectsCache.find(p => p.id === projectId);
        if (!project) throw new Error('폴더를 찾을 수 없습니다.');
        const isLearningProject = project.name.includes('[학습]');

        const notesInProject = localNotesCache
            .filter(n => n.projectId === projectId) // No content check needed here
            .sort((a, b) => (a.createdAt?.toMillis() || 0) - (b.createdAt?.toMillis() || 0));

        if (notesInProject.length === 0) throw new Error('보고서를 생성할 노트가 폴더에 없습니다.');
        
        const contentPromises = notesInProject.map(note => getNoteContent(note.id));
        const allContents = await Promise.all(contentPromises);
        const fullContent = allContents.join('\n\n---\n\n');

        let contentChunks;
        if (isLearningProject) {
            contentChunks = [fullContent];
        } else {
            const memoryBlocks = fullContent.split(/(?=## \[(?:턴|📸 스냅샷:))/).filter(chunk => chunk.trim() !== '');
            const turnChunks = [];
            for (let i = 0; i < memoryBlocks.length; i += chunkSizeInTurns) {
                turnChunks.push(memoryBlocks.slice(i, i + chunkSizeInTurns));
            }
            contentChunks = turnChunks.map(chunk => chunk.join('\n\n'));
        }

        const chroniclerTemplateName = isLearningProject ? 'Learning Module Analyzer' : 'Comprehensive Chronicler';
        const chroniclerTemplate = promptTemplatesCache.find(p => p.name === chroniclerTemplateName);
        if (!chroniclerTemplate) throw new Error(`"${chroniclerTemplateName}" 프롬프트 템플릿을 찾을 수 없습니다.`);
        
        const sessionTitle = `⚙️ ${project.name} 데이터 정제`;
        const sessionId = await findOrCreateSystemSession(sessionTitle);
        if (!sessionId) throw new Error("보고서용 채팅 세션을 생성/탐색할 수 없습니다.");
        
        togglePanel(chatPanel, true);
        await selectSession(sessionId);

        activeReportJob = {
            projectId: projectId, sessionId: sessionId, turnChunks: contentChunks, currentIndex: 0, retryCount: 0, processedMessageIds: new Set(),
            totalChunks: contentChunks.length, originalPromptId: originalActivePromptId, toastId: toastId, promptTemplateId: chroniclerTemplate.id, accumulatedResults: [],
        };
        
        showProgressToast(`AI 보고서 생성 중... (0/${activeReportJob.totalChunks}개 완료)`, toastId);
        
        setTimeout(() => { dispatchReportTask(0); }, 500);

    } catch (error) {
        console.error("Comprehensive report process failed:", error);
        trace("Report", "error", { error: error.message }, {}, "ERROR");
        if (activeReportJob) hideProgressToast(activeReportJob.toastId);
        activeReportJob = null;
        activePromptId = originalActivePromptId;
        showModal(`AI 종합 보고서 생성 실패: ${error.message}`, () => {});
    }
}

async function startSelectiveComprehensiveReportProcess(projectId, noteIds, chunkSizeInTurns = 30) {
    if (activeRefinementJob || activeReportJob) {
        showModal("이미 다른 데이터 정제 또는 보고서 생성 작업이 진행 중입니다.", () => {});
        return;
    }

    const originalActivePromptId = activePromptId;
    const toastId = `comprehensive-report-${Date.now()}`;
    trace("Report", "start.selective", { projectId, noteCount: noteIds.length, chunkSizeInTurns });

    try {
        const project = localNoteProjectsCache.find(p => p.id === projectId);
        if (!project) throw new Error('폴더를 찾을 수 없습니다.');
        const isLearningProject = project.name.includes('[학습]');

        const notesInProject = localNotesCache
            .filter(n => noteIds.includes(n.id))
            .sort((a, b) => (a.createdAt?.toMillis() || 0) - (b.createdAt?.toMillis() || 0));

        if (notesInProject.length === 0) throw new Error('보고서를 생성할 노트가 없습니다.');
        
        const contentPromises = notesInProject.map(note => getNoteContent(note.id));
        const allContents = await Promise.all(contentPromises);
        const fullContent = allContents.join('\n\n---\n\n');
        
        let contentChunks;
        if (isLearningProject) {
            contentChunks = [fullContent];
        } else {
            const memoryBlocks = fullContent.split(/(?=## \[(?:턴|📸 스냅샷:))/).filter(chunk => chunk.trim() !== '');
            const turnChunks = [];
            for (let i = 0; i < memoryBlocks.length; i += chunkSizeInTurns) {
                turnChunks.push(memoryBlocks.slice(i, i + chunkSizeInTurns));
            }
            contentChunks = turnChunks.map(chunk => chunk.join('\n\n'));
        }

        const chroniclerTemplateName = isLearningProject ? 'Learning Module Analyzer' : 'Comprehensive Chronicler';
        const chroniclerTemplate = promptTemplatesCache.find(p => p.name === chroniclerTemplateName);
        if (!chroniclerTemplate) throw new Error(`"${chroniclerTemplateName}" 프롬프트 템플릿을 찾을 수 없습니다.`);
        
        const sessionTitle = `⚙️ ${project.name} 데이터 정제`;
        const sessionId = await findOrCreateSystemSession(sessionTitle);
        if (!sessionId) throw new Error("보고서용 채팅 세션을 생성/탐색할 수 없습니다.");
        
        togglePanel(chatPanel, true);
        await selectSession(sessionId);

        activeReportJob = {
            projectId: projectId, sessionId: sessionId, turnChunks: contentChunks, currentIndex: 0, retryCount: 0, processedMessageIds: new Set(),
            totalChunks: contentChunks.length, originalPromptId: originalActivePromptId, toastId: toastId, promptTemplateId: chroniclerTemplate.id, accumulatedResults: [],
        };
        
        showProgressToast(`AI 보고서 생성 중... (0/${activeReportJob.totalChunks}개 완료)`, toastId);
        
        toggleSelectionMode(projectId);
        
        setTimeout(() => { dispatchReportTask(0); }, 500);

    } catch (error) {
        console.error("Selective comprehensive report process failed:", error);
        trace("Report", "error.selective", { error: error.message }, {}, "ERROR");
        if (activeReportJob) hideProgressToast(activeReportJob.toastId);
        activeReportJob = null;
        activePromptId = originalActivePromptId;
        toggleSelectionMode(projectId);
        showModal(`선택 항목 AI 종합 보고서 생성 실패: ${error.message}`, () => {});
    }
}

async function dispatchReportTask(index) {
    if (!activeReportJob || index >= activeReportJob.totalChunks) return;

    const { sessionId, turnChunks, totalChunks, toastId, promptTemplateId } = activeReportJob;

    try {
        updateProgressToast(`AI 보고서 생성 중... (${index + 1}/${totalChunks} 처리중)`, toastId);
        
        const chunkToProcess = turnChunks[index];
        const combinedChunkContent = chunkToProcess; // Already joined
        
        const chroniclerTemplate = promptTemplatesCache.find(p => p.id === promptTemplateId);
        if (!chroniclerTemplate) throw new Error('"Comprehensive Chronicler" 프롬프트 템플릿을 찾을 수 없습니다.');
        
        const systemInstruction = chroniclerTemplate.promptText;
        const userContent = `--- 데이터 시작 ---\n${combinedChunkContent}\n--- 데이터 끝 ---`;

        await programmaticChatSend(sessionId, userContent, systemInstruction);
    } catch (error) {
        console.error(`Error dispatching report task for index ${index}:`, error);
        handleReportStep({ content: `API 오류: programmaticChatSend failed - ${error.message}`, id: `dispatch-report-error-${Date.now()}` });
    }
}

async function handleReportStep(aiMessage) {
    if (!activeReportJob) return;

    if (aiMessage) {
        const msgId = getMessageId(aiMessage);
        if (activeReportJob.processedMessageIds.has(msgId)) {
            trace("Report", "step.ignore.duplicate", { msgId: msgId.substring(0, 10) });
            return;
        }
        activeReportJob.processedMessageIds.add(msgId);
        
        if (aiMessage.content && aiMessage.content.startsWith('**[시스템]**')) {
            trace("Report", "step.ignore.finalMessage", { sessionId: activeReportJob.sessionId });
            return;
        }

        const isError = aiMessage.content && aiMessage.content.includes("API 오류");

        if (isError) {
            activeReportJob.retryCount++;
            trace("Report", "step.failure", { retry: activeReportJob.retryCount, max: 3 });

            if (activeReportJob.retryCount >= 3) {
                hideProgressToast(activeReportJob.toastId);
                showModal(`AI 보고서 생성 실패: 3회 연속 오류가 발생하여 작업을 중단합니다.`, () => {});
                activePromptId = activeReportJob.originalPromptId;
                updateChatHeaderModelSelector();
                activeReportJob = null;
                return;
            }

            updateProgressToast(`API 오류 발생. 10초 후 재시도... (${activeReportJob.retryCount}/3)`, activeReportJob.toastId);
            setTimeout(() => { dispatchReportTask(activeReportJob.currentIndex); }, 10000);
            return;
        }

        activeReportJob.accumulatedResults.push(aiMessage.content || '');
        activeReportJob.retryCount = 0;
        activeReportJob.currentIndex++;
    }

    const { projectId, currentIndex, totalChunks, accumulatedResults, sessionId, originalPromptId, toastId } = activeReportJob;

    if (currentIndex >= totalChunks) {
        hideProgressToast(toastId);
        trace("Report", "job.complete.localCombine", { sessionId: sessionId, resultsCount: accumulatedResults.length });

        const finalCombinedContent = accumulatedResults.join('\n\n---\n\n');
        const finalAiMessageContent = `**[시스템]** AI 종합 보고서 생성이 완료되었습니다.\n\n---\n\n${finalCombinedContent}`;

        const finalAiMessage = { role: 'ai', content: finalAiMessageContent, timestamp: firebase.firestore.FieldValue.serverTimestamp() };

        const sessionDocRef = chatSessionsCollectionRef.doc(sessionId);
        await sessionDocRef.collection("messages").add(finalAiMessage);
        await sessionDocRef.update({ updatedAt: firebase.firestore.FieldValue.serverTimestamp() });
        
        trace("Report", "job.complete.success", { projectId });

        activePromptId = originalPromptId;
        updateChatHeaderModelSelector();
        activeReportJob = null;
        return;
    }

    dispatchReportTask(currentIndex);
}
