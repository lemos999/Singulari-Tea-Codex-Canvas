/* --- Ailey & Bailey Canvas --- */
// File: 213_chat_api_service.js
// Version: 7.6 (Google REST Fallback)
// Description: Uses direct REST calls for Gemini text generation to avoid SDK stalls in exported/runtime-embedded environments while preserving the existing chat contract.

let GoogleGenAI = null;
const GOOGLE_API_TIMEOUT_MS = 45000;
const GOOGLE_API_MAX_RETRIES = 3;
const GOOGLE_API_RETRY_STATUSES = new Set([429, 500, 503]);

function _coerceRetryDelayMs(value) {
    const numericValue = Number(value);
    if (!Number.isFinite(numericValue) || numericValue <= 0) {
        return 0;
    }
    return Math.min(Math.round(numericValue), 60000);
}

function _extractRetryAfterMsFromMessage(message = '') {
    const text = String(message || '');
    const retryMatch = text.match(/retry in\s+([0-9]+(?:\.[0-9]+)?)s/i);
    if (!retryMatch) {
        return 0;
    }
    return _coerceRetryDelayMs(Number(retryMatch[1]) * 1000);
}

function _extractRetryAfterMs(response, parsedBody, attempt = 0) {
    const headerValue = response?.headers?.get?.('retry-after');
    if (headerValue) {
        const secondsDelay = _coerceRetryDelayMs(Number(headerValue) * 1000);
        if (secondsDelay > 0) {
            return secondsDelay;
        }

        const retryDateMs = Date.parse(headerValue);
        if (Number.isFinite(retryDateMs)) {
            const dateDelay = _coerceRetryDelayMs(retryDateMs - Date.now());
            if (dateDelay > 0) {
                return dateDelay;
            }
        }
    }

    const bodyDelay = _extractRetryAfterMsFromMessage(parsedBody?.error?.message || parsedBody?.message || '');
    if (bodyDelay > 0) {
        return bodyDelay;
    }

    return _coerceRetryDelayMs(1500 * Math.pow(2, attempt));
}

function _extractGooglePrimaryCandidate(result) {
    if (!Array.isArray(result?.candidates) || result.candidates.length === 0) {
        return null;
    }
    return result.candidates[0] || null;
}

function _extractGoogleResponseMeta(result) {
    const candidate = _extractGooglePrimaryCandidate(result);
    if (!candidate) {
        return {
            finishReason: null,
            finishMessage: '',
            safetyRatings: [],
            citationMetadata: null
        };
    }

    return {
        finishReason: candidate.finishReason || null,
        finishMessage: candidate.finishMessage || '',
        safetyRatings: Array.isArray(candidate.safetyRatings) ? candidate.safetyRatings : [],
        citationMetadata: candidate.citationMetadata || null
    };
}

function _isGoogleResponseComplete(meta) {
    return !meta?.finishReason || meta.finishReason === 'STOP';
}

function _describeGoogleResponseIssue(meta, responseText = '') {
    const finishReason = String(meta?.finishReason || '').toUpperCase();
    const finishMessage = String(meta?.finishMessage || '').trim();
    const trimmedText = String(responseText || '').trim();
    const fenceCount = (trimmedText.match(/```/g) || []).length;

    if (finishReason === 'STOP' || !finishReason) {
        if (!trimmedText) {
            return 'AI 응답이 비어 있어 시각화 코드를 확인할 수 없습니다.';
        }
        if (fenceCount % 2 === 1) {
            return 'AI 응답이 중간에서 끊겨 코드 블록이 닫히지 않았습니다.';
        }
        return '';
    }

    const finishReasonMessages = {
        MAX_TOKENS: 'AI 응답이 최대 토큰 수에 도달해 중간에서 멈췄습니다.',
        SAFETY: 'AI 응답이 안전 정책 때문에 중간에서 차단되었습니다.',
        RECITATION: 'AI 응답이 재현 제한 때문에 완전하게 반환되지 않았습니다.',
        BLOCKLIST: 'AI 응답이 차단 규칙에 걸려 완전하게 반환되지 않았습니다.',
        PROHIBITED_CONTENT: 'AI 응답이 정책상 허용되지 않아 중간에서 중단되었습니다.',
        SPII: 'AI 응답에 민감 정보가 감지되어 중간에서 중단되었습니다.',
        OTHER: 'AI 응답이 정상 종료 전에 중단되었습니다.'
    };

    const baseMessage = finishReasonMessages[finishReason] || `AI 응답이 ${finishReason} 상태로 종료되어 완전하지 않을 수 있습니다.`;
    if (finishMessage) {
        return `${baseMessage}\n${finishMessage}`;
    }
    return baseMessage;
}

function isLocalDirectApiRuntime() {
    return (window.__AILEY_RUNTIME_MODE__ === 'local') || (typeof __firebase_config === 'undefined');
}

function ensureLocalApiCredentials(provider, apiKey) {
    const providersRequiringKeys = new Set([
        'google_paid',
        'universal',
        'openai',
        'openrouter',
        'anthropic',
        'cerebras',
        'groq'
    ]);

    if (!isLocalDirectApiRuntime() || !providersRequiringKeys.has(provider)) {
        return;
    }

    if (apiKey && String(apiKey).trim()) {
        return;
    }

    trace("API.Service", "MissingLocalApiCredentials", { provider }, {}, "WARN");
    if (typeof openApiSettingsModal === 'function') {
        setTimeout(() => {
            try {
                openApiSettingsModal();
            } catch (error) {
                console.warn("Failed to open API settings modal after missing key.", error);
            }
        }, 0);
    }

    throw new Error("Local mode requires an API preset with a valid key. Open Settings and add a Gemini or OpenAI-compatible preset.");
}

async function getGoogleGenAI() {
    if (GoogleGenAI) return GoogleGenAI;
    try {
        const genaiModule = await import('https://esm.run/@google/genai');
        GoogleGenAI = genaiModule.GoogleGenAI;
        trace("System", "GoogleGenAI.ModuleLoaded");
        return GoogleGenAI;
    } catch (e) {
        console.error("Failed to load Google GenAI module", e);
        trace("System", "GoogleGenAI.ModuleLoadFailed", { error: e.message }, {}, "ERROR");
        return null;
    }
}

function _buildGoogleRestRequest(apiKey, model, payload, config = {}) {
    const { tools, thinkingConfig, ...generationConfig } = config || {};
    const filteredGenerationConfig = {};

    Object.entries(generationConfig || {}).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
            filteredGenerationConfig[key] = value;
        }
    });

    if (thinkingConfig !== undefined && thinkingConfig !== null) {
        filteredGenerationConfig.thinkingConfig = thinkingConfig;
    }

    const body = {
        contents: payload,
        generationConfig: filteredGenerationConfig
    };

    if (Array.isArray(tools) && tools.length > 0) {
        body.tools = tools;
    }

    return {
        url: `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
        options: {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        }
    };
}

async function _fetchGoogleRestJson(url, options, retryLimit = GOOGLE_API_MAX_RETRIES) {
    const normalizedRetryLimit = Number.isFinite(Number(retryLimit))
        ? Math.max(0, Number(retryLimit))
        : GOOGLE_API_MAX_RETRIES;

    for (let attempt = 0; attempt <= normalizedRetryLimit; attempt += 1) {
        const controller = new AbortController();
        const timeoutHandle = window.setTimeout(() => controller.abort(), GOOGLE_API_TIMEOUT_MS);

        try {
            const response = await fetch(url, {
                ...options,
                signal: controller.signal
            });
            const responseText = await response.text();
            let parsedBody = null;

            try {
                parsedBody = responseText ? JSON.parse(responseText) : null;
            } catch (parseError) {
                trace("API.Gemini", "generateContent.parseFailed", { error: parseError.message }, {}, "WARN");
            }

            if (!response.ok) {
                const errorMessage = parsedBody?.error?.message || responseText || `Gemini API Error ${response.status}`;
                const isRetryable = GOOGLE_API_RETRY_STATUSES.has(response.status) && attempt < normalizedRetryLimit;

                if (isRetryable) {
                    const retryDelay = _extractRetryAfterMs(response, parsedBody, attempt);
                    trace("API.Gemini", "generateContent.retry", {
                        attempt: attempt + 1,
                        status: response.status,
                        retryDelay,
                        reason: parsedBody?.error?.message || responseText || null
                    }, {}, "WARN");
                    await new Promise((resolve) => window.setTimeout(resolve, retryDelay));
                    continue;
                }

                throw new Error(`Gemini API Error ${response.status}: ${errorMessage}`);
            }

            return parsedBody || {};
        } catch (error) {
            if (error?.name === 'AbortError') {
                throw new Error(`Gemini API request timed out after ${GOOGLE_API_TIMEOUT_MS / 1000}s.`);
            }
            throw error;
        } finally {
            window.clearTimeout(timeoutHandle);
        }
    }

    throw new Error('Gemini API request failed after retries.');
}

function _extractGoogleResponseText(result) {
    const parts = result?.candidates?.[0]?.content?.parts;
    if (!Array.isArray(parts)) return '';
    return parts
        .map((part) => part?.text || '')
        .filter(Boolean)
        .join('');
}

function _normalizeGoogleUsage(usageMetadata) {
    if (!usageMetadata) return null;
    return {
        prompt: usageMetadata.promptTokenCount || 0,
        completion: usageMetadata.candidatesTokenCount || 0
    };
}

async function _requestGoogleGenerateContent(apiKey, model, payload, config = {}) {
    ensureLocalApiCredentials('google_paid', apiKey);
    const { _retryLimit, ...requestConfig } = config || {};
    const { url, options } = _buildGoogleRestRequest(apiKey, model, payload, requestConfig);
    trace("API.Gemini", "generateContent.start", { model, transport: 'rest' });
    return await _fetchGoogleRestJson(url, options, _retryLimit);
}

async function _callGoogleGenAI(apiKey, model, payload, config) {
    const result = await _requestGoogleGenerateContent(apiKey, model, payload, config);
    const responseText = _extractGoogleResponseText(result);
    const responseMeta = _extractGoogleResponseMeta(result);
    trace("API.Gemini", "generateContent.success", {
        model,
        responseLength: responseText.length,
        finishReason: responseMeta.finishReason || 'STOP',
        transport: 'rest'
    });

    return {
        content: responseText,
        usage: _normalizeGoogleUsage(result?.usageMetadata),
        responseMeta,
        raw: result
    };
}

async function _fetchStreamFromApi(apiKey, model, payload, generationConfig, config) {
    const finalConfig = { ...generationConfig, ...config };
    trace("API.Service", "_fetchStreamFromApi.start", {
        model,
        client: 'Google_GenerateContent_REST_SingleChunk'
    });

    return (async function* () {
        const result = await _requestGoogleGenerateContent(apiKey, model, payload, finalConfig);
        yield {
            text: _extractGoogleResponseText(result),
            candidates: Array.isArray(result?.candidates) ? result.candidates : [],
            usageMetadata: result?.usageMetadata || null,
            responseMeta: _extractGoogleResponseMeta(result)
        };
    })();
}

function _buildApiRequest(provider, model, apiKey, messages, maxTokens, temperature, topP, useGrounding = false) {
    const generationConfig = {
        maxOutputTokens: Number(maxTokens) || 65536,
        temperature: temperature ?? 1,
        topP: topP ?? 0.95,
    };

    if (provider === 'universal') {
        const body = {
            contents: messages,
            generationConfig
        };

        if (useGrounding) {
            body.tools = [{ "googleSearch": {} }];
        }

        return {
            url: `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
            options: {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            }
        };
    }
    else if (provider === 'openai' || provider === 'openrouter' || provider === 'cerebras' || provider === 'groq') {
        const openAiMessages = messages.map(msg => {
            const contentParts = [];
            msg.parts.forEach(part => {
                if (part.text) {
                    contentParts.push({ type: 'text', text: part.text });
                    return;
                }
                if (part.inlineData?.mimeType?.startsWith('image/')) {
                    contentParts.push({
                        type: 'image_url',
                        image_url: {
                            url: `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`
                        }
                    });
                    return;
                }
                if (part.inlineData?.mimeType === 'application/pdf') {
                    contentParts.push({ type: 'text', text: '[PDF 첨부가 포함되었습니다.]' });
                }
            });

            const onlyText = contentParts.every(part => part.type === 'text');
            return {
                role: msg.role === 'model' ? 'assistant' : msg.role,
                content: onlyText ? contentParts.map(part => part.text).join('\n') : contentParts
            };
        });
        return {
            url: provider === 'openai' ? 'https://api.openai.com/v1/chat/completions' :
                provider === 'openrouter' ? 'https://openrouter.ai/api/v1/chat/completions' :
                    provider === 'cerebras' ? 'https://api.cerebras.ai/v1/chat/completions' : 'https://api.groq.com/openai/v1/chat/completions',
            options: {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + apiKey,
                    ...(provider === 'openrouter' && {
                        'HTTP-Referer': 'https://lemos999.github.io/ailey-bailey-canvas/',
                        'X-Title': 'Codex (Beta)'
                    })
                },
                body: JSON.stringify({
                    model: model,
                    messages: openAiMessages,
                    max_tokens: Number(maxTokens) || 65536,
                    temperature: temperature ?? 1,
                    top_p: topP ?? 0.95
                })
            }
        };
    }
    else if (provider === 'anthropic') {
        const anthropicMessages = messages.map(msg => {
            const content = [];
            msg.parts.forEach(part => {
                if (part.text) {
                    content.push({ type: 'text', text: part.text });
                    return;
                }
                if (part.inlineData?.mimeType?.startsWith('image/')) {
                    content.push({
                        type: 'image',
                        source: {
                            type: 'base64',
                            media_type: part.inlineData.mimeType,
                            data: part.inlineData.data
                        }
                    });
                    return;
                }
                if (part.inlineData?.mimeType === 'application/pdf') {
                    content.push({ type: 'text', text: '[PDF 첨부가 포함되었습니다.]' });
                }
            });

            return {
                role: msg.role === 'model' ? 'assistant' : msg.role,
                content
            };
        });
        return {
            url: 'https://api.anthropic.com/v1/messages',
            options: {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'x-api-key': apiKey,
                    'anthropic-version': '2023-06-01'
                },
                body: JSON.stringify({
                    model: model,
                    messages: anthropicMessages,
                    max_tokens: Number(maxTokens) || 65536,
                    temperature: temperature ?? 1,
                    top_p: topP ?? 0.95
                })
            }
        };
    }
    throw new Error('Unsupported provider for traditional fetch: ' + provider);
}

function _parseApiResponse(provider, result) {
    try {
        if (provider === 'universal') {
            const content = result.candidates[0]?.content?.parts[0]?.text || '';
            return { content, usage: null };
        }
        else if (provider === 'openai' || provider === 'openrouter' || provider === 'cerebras' || provider === 'groq') {
            return { content: result.choices[0].message.content, usage: { prompt: result.usage.prompt_tokens, completion: result.usage.completion_tokens } };
        }
        else if (provider === 'anthropic') {
            return { content: result.content[0].text, usage: { prompt: result.usage.input_tokens, completion: result.usage.output_tokens } };
        }
    } catch (error) {
        console.error(`Error parsing ${provider} response:`, error, result);
        return { content: 'API 응답을 파싱하는 중 오류가 발생했습니다.', usage: null };
    }
    return { content: '지원되지 않는 응답 형식입니다.', usage: null };
}

async function _fetchFromApi(provider, model, apiKey, payload, maxTokens, temperature, topP, useGrounding = false, thinkingBudget = null) {
    const clientType = provider === 'google_paid' ? 'Google_GenerateContent_REST' : 'Fetch_API';
    trace("API.Service", "_fetchFromApi.dispatch", { provider, model, client: clientType });
    ensureLocalApiCredentials(provider, apiKey);

    if (provider === 'google_paid') {
        const config = {
            maxOutputTokens: Number(maxTokens) || 65536,
            temperature: temperature ?? 1,
            topP: topP ?? 0.95,
        };
        if (useGrounding) {
            config.tools = [{ googleSearch: {} }];
        }
        if (thinkingBudget !== null && thinkingBudget >= 0) {
            config.thinkingConfig = { thinkingBudget: thinkingBudget };
        }
        return await _callGoogleGenAI(apiKey, model, payload, config);
    }

    const { url, options } = _buildApiRequest(provider, model, apiKey, payload, maxTokens, temperature, topP, useGrounding);
    const res = await fetch(url, options);
    if (!res.ok) {
        const errorBody = await res.text();
        throw new Error(`${provider} API Error ${res.status}: ${errorBody}`);
    }
    const result = await res.json();
    return _parseApiResponse(provider, result);
}

// [HCA] Expose service functions to the global scope for the orchestrator
window._fetchFromApi = _fetchFromApi;
window._fetchStreamFromApi = _fetchStreamFromApi;
window._isGoogleResponseComplete = _isGoogleResponseComplete;
window._describeGoogleResponseIssue = _describeGoogleResponseIssue;
