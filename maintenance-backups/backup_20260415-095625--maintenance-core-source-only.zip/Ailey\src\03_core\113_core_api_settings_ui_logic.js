/* --- Ailey & Bailey Canvas --- */
// File: 113_core_api_settings_ui_logic.js
// Version: 3.5 (Thinking Budget Model Expansion)
// Description: Updated the 'Thinking Budget' UI logic to explicitly support 'gemini-pro-latest', 'gemini-flash-lite-latest', and 'gemini-flash-latest' for 'google_paid' presets.

let isModelSearchListenerAttached = false;

function initializeModelSearch() {
    if (isModelSearchListenerAttached) return;

    const searchInput = document.getElementById('api-model-search-input');
    const modelSelect = document.getElementById('api-model-select');

    if (searchInput && modelSelect) {
        searchInput.addEventListener('input', () => {
            const fullListStr = modelSelect.dataset.fullList;
            if (!fullListStr) return;
            
            try {
                const fullList = JSON.parse(fullListStr);
                const searchTerm = searchInput.value.toLowerCase();
                const filtered = fullList.filter(m => m.toLowerCase().includes(searchTerm));
                
                const currentSelectedModel = modelSelect.value;
                const newSelectedModel = filtered.includes(currentSelectedModel) ? currentSelectedModel : null;

                populateModelSelector(filtered, null, newSelectedModel, 'api-model-select');
            } catch (e) {
                console.error("Failed to parse model list from data attribute:", e);
            }
        });
        isModelSearchListenerAttached = true;
    }
}

function renderApiPresetsList() {
    const listEl = document.getElementById('api-preset-list');
    if (!listEl) return;
    
    listEl.innerHTML = '';
    
    tempPresets.forEach(preset => {
        const item = document.createElement('div');
        item.className = 'api-preset-item';
        item.dataset.presetId = preset.id;
        if (preset.id === selectedPresetId) {
            item.classList.add('selected');
        }

        const isActive = (preset.isUniversal && userApiSettings.activePresetId === null) || preset.id === userApiSettings.activePresetId;
        item.innerHTML = `
            <span class="preset-name">${preset.name}</span>
            <span class="preset-provider">${preset.provider || '미검증'}</span>
            ${isActive ? '<span class="preset-active-indicator" title="활성 프리셋"></span>' : ''}
        `;
        item.addEventListener('click', () => handlePresetSelection(preset.id));
        listEl.appendChild(item);
    });
}

function renderApiPresetEditor(preset) {
    const modal = document.getElementById('api-settings-modal-overlay');
    if (!modal) return;

    initializeModelSearch();
    const modelSearchInput = modal.querySelector('#api-model-search-input');

    const titleEl = modal.querySelector('#api-editor-title');
    const nameInput = modal.querySelector('#api-preset-name-input');
    const keyInput = modal.querySelector('#api-key-input');
    const statusEl = modal.querySelector('#api-key-status');
    const modelSelect = modal.querySelector('#api-model-select');
    const maxTokensInput = modal.querySelector('#max-output-tokens-input');
    const historyLimitInput = modal.querySelector('#chat-history-limit-input');
    const autoCompactToggle = modal.querySelector('#chat-auto-compact-toggle');
    const deleteBtn = modal.querySelector('#api-settings-delete-btn');
    const verifyBtn = modal.querySelector('#verify-api-key-btn');
    const tempSlider = modal.querySelector('#api-temperature-slider');
    const tempValue = modal.querySelector('#api-temperature-value');
    const topPSlider = modal.querySelector('#api-top-p-slider');
    const topPValue = modal.querySelector('#api-top-p-value');
    const groundingSection = modal.querySelector('.grounding-toggle-section');
    const groundingToggle = modal.querySelector('#google-grounding-toggle');
    
    const thinkingBudgetSection = modal.querySelector('.thinking-budget-section');
    const thinkingBudgetToggle = modal.querySelector('#thinking-budget-toggle');
    const thinkingBudgetControls = modal.querySelector('#thinking-budget-controls');
    const thinkingBudgetSlider = modal.querySelector('#api-thinking-budget-slider');
    const thinkingBudgetValue = modal.querySelector('#api-thinking-budget-value');
    
    const advancedTabBtn = modal.querySelector('.api-settings-tab-btn[data-tab="advanced"]');
    const usageTabBtn = modal.querySelector('.api-settings-tab-btn[data-tab="usage"]');

    const updateGroundingVisibility = () => {
        const selectedModel = modelSelect.value || '';
        const isGroundable = selectedModel.includes('gemini');
        
        if (groundingSection) {
            groundingSection.style.display = isGroundable ? 'block' : 'none';
        }
    };

    const updateThinkingBudgetVisibility = () => {
        const selectedModel = modelSelect.value || '';
        const currentPreset = tempPresets.find(p => p.id === selectedPresetId);
        const provider = currentPreset ? currentPreset.provider : null;
        
        const isGoogleModel = provider === 'google_paid' || provider === 'Google';

        // --- [MODIFIED] Explicitly define models that support Thinking Budget ---
        const proModels = ['gemini-2.5-pro', 'gemini-pro-latest'];
        const flashModels = ['gemini-2.5-flash', 'gemini-flash-lite-latest', 'gemini-flash-latest'];

        const isPro = proModels.includes(selectedModel);
        const isFlash = flashModels.includes(selectedModel);
        const isThinkingBudgetSupported = isGoogleModel && (isPro || isFlash);
        // --- End Modification ---
    
        if (thinkingBudgetSection) {
            if (isThinkingBudgetSupported) {
                thinkingBudgetSection.style.display = 'block';

                let budget = null;
                if (currentPreset && currentPreset.id === 'universal') {
                     budget = userApiSettings.universalModelSettings?.thinkingBudget;
                } else if (currentPreset) {
                    budget = currentPreset.thinkingBudget;
                }

                const isEnabled = budget !== null && typeof budget !== 'undefined';
                
                thinkingBudgetToggle.checked = isEnabled;
                thinkingBudgetControls.classList.toggle('disabled', !isEnabled);
                
                // --- [MODIFIED] Use the new isPro flag for max value ---
                thinkingBudgetSlider.min = "0";
                thinkingBudgetSlider.max = isPro ? "32768" : "24576";
                thinkingBudgetSlider.step = "128";
                // --- End Modification ---
                
                const currentValue = isEnabled ? budget : 0;
                thinkingBudgetSlider.value = currentValue;
                thinkingBudgetValue.textContent = currentValue;

            } else {
                thinkingBudgetSection.style.display = 'none';
            }
        }
    };
    
    modelSelect.removeEventListener('change', updateGroundingVisibility);
    modelSelect.addEventListener('change', updateGroundingVisibility);
    modelSelect.removeEventListener('change', updateThinkingBudgetVisibility);
    modelSelect.addEventListener('change', updateThinkingBudgetVisibility);

    if (preset && preset.isUniversal) {
        const universalSettings = userApiSettings.universalModelSettings || { selectedModel: 'gemini-flash-latest', maxOutputTokens: 65536, temperature: 1, topP: 0.95, useGrounding: false, chatHistoryLimit: 20, autoCompactEnabled: true, thinkingBudget: null };

        titleEl.textContent = '범용 모델 (기본)';
        nameInput.value = preset.name;
        keyInput.value = '******************';
        statusEl.innerHTML = `✅ 기본 제공되는 Gemini 모델을 사용합니다.<br>별도의 API 키가 필요 없습니다.`;
        statusEl.className = 'status-success';
        
        const universalModels = ['gemini-flash-latest', 'gemini-flash-lite-latest', 'gemini-2.5-pro'];
        modelSelect.innerHTML = '';
        universalModels.forEach(modelId => {
            const option = document.createElement('option');
            option.value = modelId;
            option.textContent = modelId;
            modelSelect.appendChild(option);
        });
        modelSelect.value = universalSettings.selectedModel || 'gemini-flash-latest';
        modelSelect.removeAttribute('data-full-list');
        if (modelSearchInput) modelSearchInput.style.display = 'none';
        
        maxTokensInput.value = universalSettings.maxOutputTokens;
        historyLimitInput.value = universalSettings.chatHistoryLimit ?? 20;
        if (autoCompactToggle) autoCompactToggle.checked = universalSettings.autoCompactEnabled !== false;
        const temp = universalSettings.temperature ?? 1;
        const topP = universalSettings.topP ?? 0.95;
        tempSlider.value = temp;
        tempValue.textContent = parseFloat(temp).toFixed(2);
        topPSlider.value = topP;
        topPValue.textContent = parseFloat(topP).toFixed(2);
        
        [nameInput, keyInput].forEach(el => el.disabled = true);
        [modelSelect, maxTokensInput, historyLimitInput, tempSlider, topPSlider].forEach(el => el.disabled = false);
        if (autoCompactToggle) autoCompactToggle.disabled = false;

        deleteBtn.style.display = 'none';
        verifyBtn.style.display = 'none';
        
        updateGroundingVisibility();
        if (groundingToggle) {
            groundingToggle.checked = userApiSettings.universalModelSettings?.useGrounding || false;
        }
        updateThinkingBudgetVisibility();

        if (advancedTabBtn) advancedTabBtn.disabled = false;
        if (usageTabBtn) usageTabBtn.disabled = true;
        
        return;
    }

    // Restore UI for non-universal presets
    [nameInput, keyInput, maxTokensInput, historyLimitInput, tempSlider, topPSlider].forEach(el => el.disabled = false);
    if (autoCompactToggle) autoCompactToggle.disabled = false;
    [deleteBtn, verifyBtn].forEach(el => el.style.display = 'inline-block');
    if (advancedTabBtn) advancedTabBtn.disabled = false;
    if (usageTabBtn) usageTabBtn.disabled = false;

    if (isEditingNewPreset) {
        titleEl.textContent = '새 프리셋 추가';
        nameInput.value = '';
        keyInput.value = '';
        statusEl.textContent = 'API 키를 입력하고 검증하세요.';
        statusEl.className = '';
        modelSelect.innerHTML = '<option>키 검증 필요</option>';
        modelSelect.disabled = true;
        modelSelect.removeAttribute('data-full-list');
        if (modelSearchInput) modelSearchInput.style.display = 'none';
        maxTokensInput.value = '65536';
        historyLimitInput.value = '20';
        if (autoCompactToggle) autoCompactToggle.checked = true;
        tempSlider.value = 1;
        tempValue.textContent = '1.00';
        topPSlider.value = 0.95;
        topPValue.textContent = '0.95';
        deleteBtn.style.display = 'none';
    } else if (preset) {
        titleEl.textContent = '프리셋 편집';
        nameInput.value = preset.name || '';
        keyInput.value = preset.key || '';
        statusEl.textContent = preset.provider ? `✅ [${preset.provider}] 키가 검증되었습니다.` : '키 검증 필요';
        statusEl.className = preset.provider ? 'status-success' : '';
        
        const availableModels = preset.availableModels || [];
        modelSelect.dataset.fullList = JSON.stringify(availableModels);
        populateModelSelector(availableModels, preset.provider, preset.selectedModel, 'api-model-select');
        
        if (modelSearchInput) {
            if (availableModels.length > 10) {
                modelSearchInput.style.display = 'block';
                modelSearchInput.value = '';
            } else {
                modelSearchInput.style.display = 'none';
            }
        }

        maxTokensInput.value = preset.maxOutputTokens || '65536';
        historyLimitInput.value = preset.chatHistoryLimit ?? 20;
        if (autoCompactToggle) autoCompactToggle.checked = preset.autoCompactEnabled !== false;
        const temp = preset.temperature ?? 1;
        const topP = preset.topP ?? 0.95;
        tempSlider.value = temp;
        tempValue.textContent = parseFloat(temp).toFixed(2);
        topPSlider.value = topP;
        topPValue.textContent = parseFloat(topP).toFixed(2);
        deleteBtn.style.display = 'inline-block';
    }
    
    updateGroundingVisibility();
    if (groundingToggle) {
        groundingToggle.checked = preset?.useGrounding || false;
    }
    updateThinkingBudgetVisibility();
}

function renderTokenUsage(preset) {
    const tokenUsageDisplay = document.getElementById('token-usage-display-grid');
    const resetBtn = document.getElementById('reset-token-usage-btn');
    if (!tokenUsageDisplay || !resetBtn) return;

    if (!preset || preset.isUniversal || isEditingNewPreset) {
        tokenUsageDisplay.innerHTML = `<span>범용 모델은 사용량 추적을 지원하지 않습니다.</span>`;
        if (isEditingNewPreset) {
             tokenUsageDisplay.innerHTML = `<span>새 프리셋은 저장 후 사용량이 추적됩니다.</span>`;
        }
        resetBtn.style.display = 'none';
        return;
    }

    resetBtn.style.display = 'block';

    const usage = preset.tokenUsage || { prompt: 0, completion: 0, todayRequests: 0, totalRequests: 0, dailyModelUsage: {}, todayPromptTokens: 0, todayCompletionTokens: 0 };
    const { prompt = 0, completion = 0, todayRequests = 0, totalRequests = 0, dailyModelUsage = {}, todayPromptTokens = 0, todayCompletionTokens = 0 } = usage;
    const cumulativeTotalTokens = prompt + completion;
    const todayTotalTokens = todayPromptTokens + todayCompletionTokens;

    function getTimeUntilPSTMidnight() {
        const now = new Date();
        const nowInPST = new Date(now.toLocaleString("en-US", {timeZone: "America/Los_Angeles"}));
        const midnightInPST = new Date(nowInPST);
        midnightInPST.setDate(midnightInPST.getDate() + 1);
        midnightInPST.setHours(0, 0, 0, 0);

        let diff = midnightInPST.getTime() - nowInPST.getTime();

        const hours = Math.floor(diff / (1000 * 60 * 60));
        diff -= hours * (1000 * 60 * 60);
        const minutes = Math.floor(diff / (1000 * 60));
        diff -= minutes * (1000 * 60);
        const seconds = Math.floor(diff / 1000);

        return `${String(hours).padStart(2, '0')}시간 ${String(minutes).padStart(2, '0')}분 ${String(seconds).padStart(2, '0')}초`;
    }
    const timeUntilReset = getTimeUntilPSTMidnight();

    let modelUsageHtml = '';
    if (dailyModelUsage && typeof dailyModelUsage === 'object' && Object.keys(dailyModelUsage).length > 0) {
        modelUsageHtml += '<span class="usage-label usage-sub-header full-width">오늘 모델별 요청</span>';
        for (const [model, count] of Object.entries(dailyModelUsage)) {
            const truncatedModel = model.length > 20 ? `...${model.slice(-17)}` : model;
            modelUsageHtml += `
                <span class="usage-label sub-item" title="${model}">${truncatedModel}</span>
                <span class="usage-value">${count.toLocaleString()} 회</span>
            `;
        }
    }

    tokenUsageDisplay.innerHTML = `
        <span class="usage-label usage-sub-header full-width">오늘 사용량</span>
        <span class="usage-label">초기화까지 남은 시간:</span><span class="usage-value">${timeUntilReset}</span>
        <span class="usage-label">오늘 총 요청:</span><span class="usage-value">${todayRequests.toLocaleString()} 회</span>
        <span class="usage-label sub-item">오늘 입력 토큰:</span><span class="usage-value">${todayPromptTokens.toLocaleString()}</span>
        <span class="usage-label sub-item">오늘 출력 토큰:</span><span class="usage-value">${todayCompletionTokens.toLocaleString()}</span>
        <span class="usage-label sub-item">오늘 총 토큰:</span><span class="usage-value">${todayTotalTokens.toLocaleString()}</span>
        ${modelUsageHtml}
        <span class="usage-label usage-sub-header full-width">누적 사용량</span>
        <span class="usage-label">총 요청:</span><span class="usage-value">${totalRequests.toLocaleString()} 회</span>
        <span class="usage-label">입력 토큰:</span><span class="usage-value">${prompt.toLocaleString()}</span>
        <span class="usage-label">출력 토큰:</span><span class="usage-value">${completion.toLocaleString()}</span>
        <span class="usage-label">총 토큰:</span><span class="usage-value">${cumulativeTotalTokens.toLocaleString()}</span>
    `;
}
