/* --- Ailey & Bailey Canvas --- */
// File: 344_notes_job_ui.js
// Version: 2.0 (Dynamic Job UI)
// Description: Refactored the data extraction modal to dynamically change titles, messages, and button labels based on the project type (Narrative vs. Learning), improving clarity and user experience.

function _createChunkSizePopover(targetElement, onConfirm, defaultValue) {
    const popover = document.getElementById('chunk-size-popover');
    if (!popover) return;
    
    popover.innerHTML = `
        <label>묶음 크기 (턴 수)</label>
        <input type="number" value="${defaultValue}" min="1" max="100">
        <div class="popover-actions">
            <button class="popover-run-btn">실행</button>
        </div>
    `;

    const targetRect = targetElement.getBoundingClientRect();
    popover.style.display = 'flex';
    popover.style.top = `${targetRect.bottom + 5}px`;
    popover.style.left = `${targetRect.left}px`;
    
    highestZIndex += 2; // Ensure popover is above modal
    popover.style.zIndex = highestZIndex;

    const input = popover.querySelector('input');
    const runBtn = popover.querySelector('.popover-run-btn');

    const closePopover = (e) => {
        if (e && popover.contains(e.target)) return;
        popover.style.display = 'none';
        document.body.removeEventListener('click', closePopover, true);
    };

    runBtn.onclick = () => {
        const value = parseInt(input.value, 10);
        if (value > 0) {
            onConfirm(value);
            closePopover();
            const choiceModal = document.getElementById('choice-modal');
            if(choiceModal) choiceModal.style.display = 'none';
        }
    };
    
    setTimeout(() => document.body.addEventListener('click', closePopover, { once: true, capture: true }), 0);
}

function _showDataExtractionModal(title, message, buttons) {
    const choiceModal = document.getElementById('choice-modal');
    const modalTitle = document.getElementById('choice-modal-title');
    const modalMessage = document.getElementById('choice-modal-message');
    const modalActions = document.getElementById('choice-modal-actions');

    if (!choiceModal || !modalTitle || !modalMessage || !modalActions) return;

    highestZIndex++;
    choiceModal.style.zIndex = highestZIndex;

    modalTitle.textContent = title;
    modalMessage.textContent = message;
    modalActions.innerHTML = '';
    modalActions.className = 'custom-modal-actions choice-modal-buttons';

    buttons.forEach(buttonInfo => {
        let buttonElement;
        if (buttonInfo.isSplit) {
            buttonElement = document.createElement('div');
            buttonElement.className = 'split-button-container';
            buttonElement.id = buttonInfo.id;
            
            const mainButton = document.createElement('button');
            mainButton.className = 'modal-btn main-action';
            if (buttonInfo.class) mainButton.classList.add(buttonInfo.class);
            mainButton.innerHTML = buttonInfo.text + (buttonInfo.description ? `<span class="modal-btn-description">${buttonInfo.description}</span>` : '');
            
            mainButton.onclick = () => {
                if (buttonInfo.action) buttonInfo.action();
                choiceModal.style.display = 'none';
            };
            
            const moreButton = document.createElement('button');
            moreButton.className = 'modal-btn more-action';
            if (buttonInfo.class) moreButton.classList.add(buttonInfo.class);
            moreButton.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16"><path d="M7,10L12,15L17,10H7Z" /></svg>`;
            
            moreButton.onclick = (e) => {
                e.stopPropagation();
                if (buttonInfo.popoverAction) {
                    _createChunkSizePopover(e.currentTarget, buttonInfo.popoverAction, buttonInfo.defaultChunk);
                }
            };
            
            buttonElement.appendChild(mainButton);
            buttonElement.appendChild(moreButton);
        } else {
            buttonElement = document.createElement('button');
            buttonElement.id = buttonInfo.id;
            buttonElement.className = 'modal-btn';
            if (buttonInfo.class) buttonElement.classList.add(buttonInfo.class);
            buttonElement.innerHTML = buttonInfo.text + (buttonInfo.description ? `<span class="modal-btn-description">${buttonInfo.description}</span>` : '');
            
            buttonElement.onclick = () => {
                if (buttonInfo.action) buttonInfo.action();
                choiceModal.style.display = 'none';
            };
        }
        modalActions.appendChild(buttonElement);
    });

    choiceModal.style.display = 'flex';
}

async function requestRefinement(projectId) {
    if (activeRefinementJob || activeReportJob) {
        showModal("이미 다른 데이터 정제 또는 보고서 생성 작업이 진행 중입니다.", () => {});
        return;
    }

    const project = localNoteProjectsCache.find(p => p.id === projectId);
    if (!project) return;
    const hasRefinementState = project && project.refinementState && project.refinementState.lastProcessedNoteTimestamp;
    
    // [FIX] Check notes within the project to determine its type, not the project name itself.
    const allNotesInProject = localNotesCache.filter(n => n.projectId === projectId);
    const isLearningProject = allNotesInProject.some(note => note.title.startsWith('[학습]'));

    const SvgContinue = `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M8,5.14V19.14L19,12.14L8,5.14Z" /></svg>`;
    const SvgRestart = `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M13,3A9,9 0 0,0 4,12H1L4.89,15.89L8.78,12H6A7,7 0 0,1 13,5A7,7 0 0,1 20,12A7,7 0 0,1 13,19C11.07,19 9.32,18.21 8.06,16.94L6.64,18.36C8.27,20 10.5,21 13,21A9,9 0 0,0 22,12A9,9 0 0,0 13,3Z"/></svg>`;
    const SvgFull = `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M6.5,2C8.42,2 10,3.58 10,5.5C10,6.5 9.58,7.4 8.91,8.09L14,13.17L15.59,11.59L17,13L15.5,14.5L13.17,12.17L8.09,17.25C7.4,17.92 6.5,18.33 5.5,18.33C3.58,18.33 2,16.75 2,14.83C2,13.61 2.5,12.5 3.34,11.84L6.5,8.68V2M19.5,3.08L20.92,4.5L19.5,5.92L18.08,4.5L19.5,3.08M13.42,5.67L14.83,7.08L13.42,8.5L12,7.08L13.42,5.67M20,12V14.5L15.34,19.16C15.9,18.82 16.38,18.33 16.66,17.75L20,14.41V12M18.83,16.66C18.42,15.67 17.67,14.92 16.66,14.5L20.92,10.25L22.33,11.66L18.83,15.16V16.66Z" /></svg>`;
    const SvgLightweight = `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M7,2V13H10V22L17,10H13L17,2H7Z" /></svg>`;
    const SvgDownload = `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z" /></svg>`;
    const SvgReport = `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M3 5H9V11H3V5M5 7V9H7V7H5M11 7H21V9H11V7M11 15H21V17H11V15M5 15H7V17H5V15M3 13H9V19H3V13Z" /></svg>`;
    const SvgSave = `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M15,9H5V5H15M12,19A3,3 0 0,1 9,16A3,3 0 0,1 12,13A3,3 0 0,1 15,16A3,3 0 0,1 12,19M17,3H5C3.89,3 3,3.9 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V7L17,3Z" /></svg>`;

    // Dynamic UI Text based on project type
    const modalTitle = isLearningProject ? "학습 데이터 추출" : "서사 데이터 추출 방식 선택";
    const modalMessage = isLearningProject ? "어떤 방식으로 학습 데이터를 추출하시겠습니까?" : "어떤 방식으로 서사 데이터를 추출하시겠습니까?";
    const fullRefineText = isLearningProject ? "학습 내용 요약" : "전체 정제";
    const reportDescription = isLearningProject ? "학습 진행도, 성취도 등을<br>AI가 분석/요약합니다." : "등장인물, 관계도, 연대기 등<br>전체 서사를 AI가 분석/요약합니다.";

    // --- Build Buttons Programmatically ---

    const fullRefineButton = { 
        isSplit: true, 
        id: 'choice-full-refine', 
        text: `${SvgFull}<span>${fullRefineText}<br>(AI)</span>`, 
        class: 'confirm', 
        action: () => startRefinementProcess(projectId, 'full', false, isLearningProject ? 1 : 30), 
        popoverAction: (chunkSize) => startRefinementProcess(projectId, 'full', false, chunkSize), 
        defaultChunk: isLearningProject ? 1 : 30 
    };
    
    const reportButton = {
        isSplit: true, 
        id: 'choice-comprehensive-report', 
        text: `${SvgReport}<span>AI 종합 보고서</span>`, 
        description: reportDescription,
        class: 'secondary',
        action: () => startComprehensiveReportProcess(projectId, 30),
        popoverAction: (chunkSize) => startComprehensiveReportProcess(projectId, chunkSize),
        defaultChunk: 30
    };

    const downloadButton = { 
        id: 'choice-raw-download', 
        text: `${SvgDownload}<span>정제 없이<br>다운로드</span>`, 
        class: 'secondary', 
        action: () => handleRawDataDownload(projectId) 
    };

    const cancelButton = { 
        id: 'choice-refine-cancel', 
        text: '취소', 
        class: 'cancel', 
        action: () => {} 
    };

    let buttonsToShow = [];
    
    if (isLearningProject) {
        // Simple button set for Learning Projects
        buttonsToShow = [fullRefineButton, reportButton, downloadButton, cancelButton];
    } else { 
        // Complex button set for Narrative Projects
        if (hasRefinementState) {
            const notesForProject = localNotesCache.filter(n => n.projectId === projectId).sort((a, b) => (a.createdAt?.toMillis() || 0) - (b.createdAt?.toMillis() || 0));
            const lastTimestamp = project.refinementState.lastProcessedNoteTimestamp;
            const notesToProcess = notesForProject.filter(note => !lastTimestamp || (note.createdAt && note.createdAt > lastTimestamp));
            const newCountDesc = `(${notesToProcess.length}개)`;

            const continueFullButton = { isSplit: true, id: 'choice-continue-full', text: `${SvgContinue}<span>이어 정제 (전체)</span>`, description: newCountDesc, class: 'confirm', action: () => startRefinementProcess(projectId, 'full', false, 30), popoverAction: (chunkSize) => startRefinementProcess(projectId, 'full', false, chunkSize), defaultChunk: 30 };
            const continueLightButton = { isSplit: true, id: 'choice-continue-light', text: `${SvgLightweight}<span>이어 정제 (경량)</span>`, description: newCountDesc, class: 'secondary', action: () => startRefinementProcess(projectId, 'lightweight', false, 2), popoverAction: (chunkSize) => startRefinementProcess(projectId, 'lightweight', false, chunkSize), defaultChunk: 2 };
            const restartButton = { id: 'choice-restart-refine', text: `${SvgRestart}<span>처음부터 다시 정제</span>`, class: 'secondary', action: () => showModal('정말로 처음부터 다시 정제하시겠습니까? 기존 정제 기록이 삭제됩니다.', () => startRefinementProcess(projectId, 'full', true, 30)) };
            
            buttonsToShow.push(continueFullButton, continueLightButton, restartButton);
        } else {
            const lightweightRefineButton = { isSplit: true, id: 'choice-lightweight-refine', text: `${SvgLightweight}<span>경량화 정제<br>(AI)</span>`, class: 'secondary', action: () => startRefinementProcess(projectId, 'lightweight', false, 2), popoverAction: (chunkSize) => startRefinementProcess(projectId, 'lightweight', false, chunkSize), defaultChunk: 2 };
            buttonsToShow.push(fullRefineButton, lightweightRefineButton);
        }
        
        const saveForContinuationButton = {
            isSplit: true, id: 'choice-save-for-continuation', text: `${SvgSave}<span>이어하기용 저장</span>`, description: '시뮬레이션 상태를 보존하여<br>나중에 이어할 수 있습니다.', class: 'secondary',
            action: () => startRefinementProcess(projectId, 'continuation', false, 10),
            popoverAction: (chunkSize) => startRefinementProcess(projectId, 'continuation', false, chunkSize),
            defaultChunk: 10
        };
        
        buttonsToShow.push(saveForContinuationButton, reportButton, downloadButton, cancelButton);
    }

    _showDataExtractionModal(modalTitle, modalMessage, buttonsToShow);
}


function openManualRefinementModal(projectId) {
    const modal = document.getElementById('manual-refinement-modal-overlay');
    if (!modal) return;

    const listContainer = document.getElementById('manual-refinement-note-list');
    const saveBtn = document.getElementById('manual-refinement-save-btn');
    const cancelBtn = document.getElementById('manual-refinement-cancel-btn');

    let selectedNoteId = null;

    const renderList = () => {
        listContainer.innerHTML = '';
        const notesInProject = localNotesCache
            .filter(n => n.projectId === projectId && n.content && (n.content.includes('## [턴') || n.content.includes('## [📸 스냅샷:')))
            .sort((a, b) => (a.createdAt?.toMillis() || 0) - (b.createdAt?.toMillis() || 0));

        if (notesInProject.length === 0) {
            listContainer.innerHTML = '<p style="text-align: center; opacity: 0.7;">설정할 메모가 없습니다.</p>';
            return;
        }

        const fragment = document.createDocumentFragment();
        notesInProject.forEach(note => {
            const item = document.createElement('div');
            item.className = 'manual-refinement-note-item';
            item.dataset.noteId = note.id;
            if (note.id === selectedNoteId) {
                item.classList.add('selected');
            }

            const date = note.createdAt?.toDate()?.toLocaleString('ko-KR',{ dateStyle:'short', timeStyle:'short' }) || '날짜 없음';
            item.innerHTML = `
                <div class="title">${note.title || '무제 노트'}</div>
                <div class="date">${date}</div>
            `;
            fragment.appendChild(item);
        });
        listContainer.appendChild(fragment);
    };

    const close = () => {
        modal.style.display = 'none';
        listContainer.onclick = null;
        saveBtn.onclick = null;
        cancelBtn.onclick = null;
    };
    
    listContainer.onclick = (e) => {
        const item = e.target.closest('.manual-refinement-note-item');
        if (item) {
            selectedNoteId = item.dataset.noteId;
            saveBtn.disabled = false;
            renderList(); // Re-render to show selection
        }
    };

    saveBtn.onclick = () => {
        if (selectedNoteId) {
            setManualRefinementState(projectId, selectedNoteId);
            close();
        }
    };

    cancelBtn.onclick = close;
    
    highestZIndex++;
    modal.style.zIndex = highestZIndex;
    modal.style.display = 'flex';

    saveBtn.disabled = true;
    renderList();
}