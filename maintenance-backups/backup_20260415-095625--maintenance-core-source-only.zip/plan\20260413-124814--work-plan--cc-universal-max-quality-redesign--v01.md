# Work Plan

Plan Type: Work Plan
Workstream: Universal `.cc/.ccc` maximum-quality redesign
Version: v01
Status: Completed
Created: 2026-04-13 12:48:14 +09:00
Last Updated: 2026-04-13 12:59:45 +09:00
Related Plan:
- `plan/20260413-044449--work-plan--cc-exact-shell-lock-refinement--v01.md`
Supersedes: None

Approval Record

- The user explicitly lifted the previous size ceiling with: `5000자제한해제해볼게 너가 가능한 퀄리티 범용으로 낼수있도록 만들어봐`.
- The user then approved immediate execution with maximum reasoning via `/sub` using: `응 최대추론으로하고. 실시`.
- This approval applies to a fresh redesign loop focused on maximum practical universality rather than budget-constrained compactness.

Current Completion State

- The redesigned English module at `cc_universal_module_mm.md` has been rewritten and accepted.
- Two maximum-reasoning read-only workers completed final delta review and both returned `Pass`.
- The module now operates as a layered universal contract rather than an accumulation of narrow local fixes.
- The English artifact is complete for this run. The Korean translation file is still outside the completed critical path.

Completed So Far

- Extracted the original `.cc/.ccc` contract from the Ailey prompt.
- Built several increasingly refined universal modules.
- Removed obvious article-template leakage.
- Reintroduced exact `.cc` shell lock to stop outer-shell drift.
- Preserved `.ccc` as the freestyle path.
- Repeatedly validated against Singulari-Tea as a hostile host and against the original Ailey shell as the fidelity anchor.
- Confirmed that the remaining problem is not a single missing rule but overall universality quality under diverse hosts.
- Ran a fresh maximum-quality `/sub` audit with two high-reasoning read-only workers.
- Rewrote `cc_universal_module_mm.md` into a layered contract that explicitly separates trigger stripping, semantic freeze, host-unit preservation, exact `.cc` shell lock, conditional placeholders, `.ccc` runtime freedom, side-effect handling, and self-check.
- Re-ran final delta review on the rewritten module and received two passing verdicts.
- Accepted the rewritten English module as the current universal baseline for this workspace.

Remaining Work

1. Optional: sync `cc_universal_module_mm_ko.md` to the accepted English module.
2. Optional: add one last `.cc` micro-hardening sentence for hosts that normally emit post-artifact follow-up UI outside the artifact.

Current Blockers

- No blocking issue remains for the accepted English module in this run.
- Only non-blocking caveats remain around `.cc` post-artifact follow-up precedence for some Ailey-like hosts and judgment-heavy side-effect substitution in `.ccc`.

Next Step

- Report the accepted result to the user and, if requested, sync the Korean translation or add final micro-hardening.

Objective

The objective of this run is to produce the best practical universal `.cc/.ccc` prompt module we can, not merely the smallest one. The final module should preserve host-native semantics and output grammar where appropriate, hard-lock the `.cc` outer shell where required, keep `.ccc` as the only freestyle path, preserve strong placeholder authoring rules, and avoid drifting into either article-template priming or vague under-specified generalities. It should work as a real drop-in layer across very different host prompts instead of only passing narrow local tests.

Scope

This workstream includes prompt analysis, redesign, recursive refinement, subagent review, static checks, and edits to `cc_universal_module_mm.md`. It may lead to a later translation sync for `cc_universal_module_mm_ko.md`, but translation is not part of the current critical path. It does not require changing the Ailey source prompt, bundle files, or deployed runtime assets.

Primary Deliverables

- A redesigned `cc_universal_module_mm.md`
- New evidence under `subagent-runs/20260413-124814-cc-universal-max-quality/`
- An updated plan with score tracking
- A concise final report with real strengths, limits, and any unresolved tradeoffs

User Constraints

- Use `/sub`
- Use maximum reasoning
- Iterate recursively
- Prefer actual universality and quality over the old 5000-character limit
- Keep working until it comes out properly

Hidden Rules And Consistency Requirements

The hidden rule is that universality is not just about passing a checklist. A truly universal module must clearly separate three layers: immutable runtime-shell obligations, host-native semantic and structural obligations, and optional visual/default behavior that must never silently become mandatory. Another hidden rule is that examples of content structure inside the module easily become structure priming, so every such example must justify itself as a runtime necessity rather than a content habit. A third hidden rule is that placeholder guidance must stay strong without implying a document template. A fourth hidden rule is that `.cc` and `.ccc` are not just two formatting flavors; they have different authority boundaries and different allowable freedoms.

Technical Approach

The parent will run a broad read-only `/sub` audit. Worker 1 will focus on universality across host styles and identify where the current module still overfits to certain hosts or suppresses others. Worker 2 will focus on architecture, separating invariant runtime-shell rules from host-native rules and optional defaults, then propose a cleaner layered abstraction. The parent will then rewrite the module in one coherent pass rather than layering another micro-fix. After rewriting, the parent will measure, inspect, and send the result through a final delta review. If the delta review still finds material contradictions, the parent will iterate again inside this same run.

Why Delegation Is Justified

The user explicitly requested `/sub` with maximum reasoning. The failure mode now is global rather than local, so two independent high-reasoning perspectives are useful: one for real hostile-host behavior and one for architectural contract discipline. The writable surface remains a single prompt file, so the safest pattern is still read-only worker analysis plus parent-owned rewriting.

Validation Strategy

Validation will be broader than prior runs. The redesign should be tested against at least these host categories:

- narrative/stateful host similar to `Singulari-Tea Codex_v5_260312.txt`
- source-faithful instructional or analysis host similar to the Ailey source
- terse utility or console-like host with minimal prose tolerance
- structured documentary or report-style host

The final module should:

- preserve exact `.cc` shell lock
- preserve `.ccc` as the sole freestyle shell path
- preserve host-native inner structure instead of inventing a default article
- preserve strong image and visualization placeholder authoring
- remain zero-shot and MM-clean enough
- avoid hidden structure priming and drift between the shell and the host-defined content layer

Definition Of Done

This run is complete when the redesigned module has been reviewed by `/sub` workers under the broader universality bar, rewritten to address the resulting failure map, revalidated by final delta review, and accepted as a clearly better universal baseline than the current version, with any remaining limits honestly documented.

Result: completed. The current English module satisfies this definition for the scope of this run.

Risks

The main risk is designing a module so abstract that it becomes too weak to steer reliable output. A second risk is overcompensating in the other direction and rebuilding a hidden default template. A third risk is that preserving exact `.cc` shell lock may always slightly reduce flexibility for some hosts. A fourth risk is that broader universality may require more text, which can increase maintenance cost and ambiguity if not carefully structured.

Open Questions

- How much of the universal module should be layered explicitly into runtime-shell rules, host-native content rules, and optional-default rules?
- Should optional house defaults exist at all, or should the universal layer avoid them entirely?
- Should `.ccc` be more explicitly framed as a different authority tier rather than just a freestyle version of `.cc`?
- Should the module include a built-in validation directive for self-checking shell drift before output?

Acceptance Criteria

- The redesigned module is judged by `/sub` reviewers as materially stronger and more universal than the current one
- `.cc` exact shell lock remains intact
- `.ccc` remains the only freestyle shell path
- host-native content structure remains intact
- placeholder quality rules remain strong
- no major unresolved contradiction remains between shell fidelity and universality

Fallback And Repair Logic

If the first redesign still overfits a specific host type, the next pass will move one level more abstract while keeping shell literals intact. If the first redesign becomes too vague, the next pass will restore a few stronger control sentences only where they protect a proven failure path. If workers disagree, the parent will prefer the smallest complete layered model that explains the disagreement instead of patching symptoms.

Operational Notes

- All workers remain read-only
- The parent remains the only writer in the primary workspace
- Evidence for this run will live under `subagent-runs/20260413-124814-cc-universal-max-quality/`

Scoreboard

Current Score: 50
Score Source: provisional
Last Updated: 2026-04-13 12:48:14 +09:00
Score Rationale: The redesign run succeeded and the rewritten English module was accepted after two maximum-reasoning read-only workers both returned passing delta reviews. The provisional score remains capped at `50` only because the user has not yet provided an explicit score and the local scoring contract forbids a higher provisional value.
What Improved:
- The artificial 5000-character ceiling is no longer constraining design quality.
- The next redesign can optimize for coherence rather than compression.
- The acceptance bar is now properly global instead of local.
- The module now cleanly separates runtime-shell invariants from host-native grammar preservation.
- Final read-only review passed from both worker perspectives.
What Remains Unsatisfactory:
- The accepted English module still has a small residual ambiguity around `.cc` post-artifact follow-up precedence for some hosts.
- The Korean translation file has not yet been brought to parity with the accepted English version.
Actions To Raise Or Maintain The Score:
- Keep the accepted English module stable unless a concrete hostile-host failure appears.
- Sync the Korean translation if bilingual parity matters.
- Add one optional `.cc` precedence sentence only if a real host proves the current wording insufficient.

Score History

- 2026-04-13 12:48:14 +09:00 | score 50 | source provisional | New approved maximum-quality redesign run started after the user explicitly lifted the former 5000-character limit and requested a stronger universal module through `/sub`.
- 2026-04-13 12:59:45 +09:00 | score 50 | source provisional | Run completed successfully and the rewritten English universal module was accepted after final delta review from both maximum-reasoning workers. The value remains capped by the local provisional-score rule, not by lack of progress.
