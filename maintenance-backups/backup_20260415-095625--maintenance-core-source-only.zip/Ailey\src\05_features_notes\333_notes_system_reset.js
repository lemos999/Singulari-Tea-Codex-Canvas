
/*
--- Ailey & Bailey Canvas ---
File: 333_notes_system_reset.js
Version: 1.0 (File Splitting)
Description: Handles the system reset functionality.
*/

async function handleSystemReset() {
    const message = "정말로 이 캔버스의 모든 데이터를 영구적으로 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.";
    showModal(message, async () => {
        if (!db || !currentUser) { 
            showModal("초기화 실패: DB 연결을 확인해주세요.", () => {}); 
            return; 
        }
        const toastId = `system-reset-${Date.now()}`;
        showProgressToast("시스템 초기화 중...", toastId);
        
        try {
            // Phase 1: Explicitly delete all chat message subcollections
            if (chatSessionsCollectionRef) {
                const sessionsSnap = await chatSessionsCollectionRef.get();
                if (!sessionsSnap.empty) {
                    const deleteMessagesBatch = db.batch();
                    const readPromises = sessionsSnap.docs.map(sessionDoc => 
                        sessionDoc.ref.collection('messages').get().then(messagesSnap => {
                            messagesSnap.docs.forEach(msgDoc => deleteMessagesBatch.delete(msgDoc.ref));
                        })
                    );
                    await Promise.all(readPromises);
                    await deleteMessagesBatch.commit();
                }
            }

            // Phase 2: Delete all top-level documents and settings
            const collectionsToDelete = [
                notesCollectionRef, noteProjectsCollectionRef, chatSessionsCollectionRef,
                projectsCollectionRef, tagsCollectionRef, noteTemplatesCollectionRef,
                promptTemplatesCollectionRef, canvasImageHistoryCollectionRef
            ];
            const deleteDocsBatch = db.batch();
            const readPromises = collectionsToDelete.map(ref => ref ? ref.get() : Promise.resolve({ docs: [] }));
            const snapshots = await Promise.all(readPromises);
            
            snapshots.forEach(snapshot => {
                if(snapshot) {
                    snapshot.docs.forEach(doc => deleteDocsBatch.delete(doc.ref));
                }
            });

            // Delete the user settings document which contains API presets
            if (userSettingsRef) {
                deleteDocsBatch.delete(userSettingsRef);
            }

            await deleteDocsBatch.commit();
            
            localStorage.clear();
            hideProgressToast(toastId);
            showModal("✅ 모든 데이터가 성공적으로 삭제되었습니다. 페이지를 새로고침하여 시스템을 다시 시작합니다.", () => location.reload());
        } catch (error) { 
            console.error("❌ 시스템 초기화 실패:", error);
            hideProgressToast(toastId);
            showModal(`시스템 초기화 중 오류가 발생했습니다: ${error.message}`, () => {}); 
        }
    });
}
