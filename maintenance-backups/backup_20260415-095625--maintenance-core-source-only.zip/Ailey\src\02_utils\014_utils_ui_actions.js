﻿/* --- Ailey & Bailey Canvas --- */
// File: 014_utils_ui_actions.js
// Version: 1.3 (Snapshot Removal Cleanup)
// Description: Shared UI actions after retiring the legacy snapshot-recording workflow.

function updateClock() { 
    const clockElement = document.getElementById('real-time-clock'); 
    if (!clockElement) return; 
    const now = new Date(); 
    const options = { timeZone: 'Asia/Seoul', year: 'numeric', month: 'long', day: 'numeric', weekday: 'long', hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }; 
    clockElement.textContent = now.toLocaleString('ko-KR', options); 
}

function setupSystemInfoWidget() { 
    const canvasIdDisplay = document.getElementById('canvas-id-display'); 
    if (canvasIdDisplay) { 
        canvasIdDisplay.textContent = canvasId.substring(0, 8) + '...'; 
    } 
    const copyBtn = document.getElementById('copy-canvas-id'); 
    if (copyBtn) { 
        copyBtn.addEventListener('click', () => { 
            navigator.clipboard.writeText(canvasId).then(() => { 
                copyBtn.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z" /></svg>'; 
                setTimeout(() => { 
                    copyBtn.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z" /></svg>'; 
                }, 1500); 
            }); 
        }); 
    } 
}

function handleTextSelection(e) { 
    const selection = window.getSelection(); 
    const selectedText = selection.toString().trim(); 

    const isInsideChatMessages = e.target.closest('.chat-messages');
    const isDisallowed = e.target.closest('#selection-popover, #immersive-header, .project-context-menu, .session-context-menu') || (e.target.closest('.draggable-panel') && !isInsideChatMessages);
    if (isDisallowed) return;

    removeContextMenu(); 
    if (selectedText.length > 3) { 
        if (!selectionPopover || selection.rangeCount === 0) return;
        lastSelectedText = selectedText;
        const range = selection.getRangeAt(0); 
        const rect = range.getBoundingClientRect(); 
        const popover = selectionPopover; 
        const margin = 12;
        const gap = 10;

        popover.style.visibility = 'hidden';
        popover.style.display = 'flex';

        const popoverRect = popover.getBoundingClientRect();
        const preferredTop = rect.top - popoverRect.height - gap;
        const fallbackTop = rect.bottom + gap;
        const top = preferredTop >= margin
            ? preferredTop
            : Math.min(fallbackTop, window.innerHeight - popoverRect.height - margin);
        const centeredLeft = rect.left + (rect.width / 2) - (popoverRect.width / 2);
        const left = Math.max(margin, Math.min(centeredLeft, window.innerWidth - popoverRect.width - margin));

        popover.style.top = `${top}px`;
        popover.style.left = `${left}px`;
        popover.style.visibility = 'visible';
    } else if (!e.target.closest('#selection-popover')) { 
        if(selectionPopover) selectionPopover.style.display = 'none'; 
    } 
}

function handlePopoverAskAi() {
    if (!lastSelectedText || !chatInput) return;
    if (chatPanel && chatPanel.classList.contains('minimized')) {
        handlePanelMinimize(chatPanel);
    }
    togglePanel(chatPanel, true);
    const userQuery = `"${lastSelectedText}"\n\n???댁슜????????먯꽭???ㅻ챸?댁쨪??`;
    chatInput.value = userQuery;
    const selection = window.getSelection();
    const selectionSource = selection.anchorNode?.parentElement?.closest('#learning-content, .chat-messages');
    if (selectionSource && selectionSource.id === 'learning-content') {
        stagedHiddenContext = selectionSource.innerText || '';
        trace("UI", "PopoverAskAi", { context: "Staged FULL page" });
    } else {
        stagedHiddenContext = null;
        trace("UI", "PopoverAskAi", { context: "No context staged" });
    }
    autoResizeTextarea(chatInput);
    chatInput.focus();
    if (selectionPopover) selectionPopover.style.display = 'none';
}

async function handlePopoverAddNote() {
    if (!lastSelectedText) return;
    togglePanel(notesAppPanel, true);
    ensureNotePanelHeader();
    const newNoteId = await addNote(`> ${lastSelectedText}\n\n`);
    if (newNoteId) {
        openNoteEditor(newNoteId);
    }
    if (selectionPopover) {
        selectionPopover.style.display = 'none';
    }
}


function createCustomSelect(selectElement) {
    if (!selectElement) return;

    if (selectElement.nextElementSibling && selectElement.nextElementSibling.classList.contains('custom-select-container')) {
        return; 
    }

    const container = document.createElement('div');
    container.className = 'custom-select-container';

    const trigger = document.createElement('div');
    trigger.className = 'custom-select-trigger';

    const optionsContainer = document.createElement('div');
    optionsContainer.className = 'custom-select-options';

    const updateTriggerText = () => {
        trigger.textContent = selectElement.options[selectElement.selectedIndex].textContent;
    };

    Array.from(selectElement.options).forEach((option, index) => {
        const customOption = document.createElement('div');
        customOption.className = 'custom-select-option';
        customOption.textContent = option.textContent;
        customOption.dataset.value = option.value;

        if (option.selected) {
            customOption.classList.add('selected');
        }

        customOption.addEventListener('click', () => {
            selectElement.selectedIndex = index;
            selectElement.dispatchEvent(new Event('change'));
            updateTriggerText();
            container.classList.remove('open');
            optionsContainer.querySelectorAll('.custom-select-option').forEach(opt => opt.classList.remove('selected'));
            customOption.classList.add('selected');
        });

        optionsContainer.appendChild(customOption);
    });

    trigger.addEventListener('click', (e) => {
        e.stopPropagation();
        container.classList.toggle('open');
    });

    container.appendChild(trigger);
    container.appendChild(optionsContainer);
    selectElement.style.display = 'none';
    selectElement.after(container);
    updateTriggerText();

    document.addEventListener('click', (e) => {
        if (!container.contains(e.target)) {
            container.classList.remove('open');
        }
    });
}
