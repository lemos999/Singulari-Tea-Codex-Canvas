## Plan Type
Approved implementation plan, paused at architecture validation because a hard runtime blocker was discovered before writable product changes.

## Task
Add support for Codex / GPT OAuth alongside the existing API-key preset flow and expose it from chat settings, while preserving the current API-key path.

## User Intent
The user wants the app to support both of these connection styles:

- direct API-key presets, as the app supports today
- GPT / Codex OAuth-backed connection from the chat settings UI

The user explicitly asked that the work start only after a root local backup, and they want a rollback-safe approach.

## Understanding Report
The real goal is not merely adding a button labeled OAuth. The goal is to make chat settings support a second authentication mode that is actually usable in the current runtime. This means the result must work from the same browser-based HTML/runtime shell that already powers the app, must not break existing API-key presets, and must not ship a UI path that looks connected but cannot complete requests.

## Constraints
- The workspace requires plan-first before code changes.
- The app currently runs as browser/HTML runtime code, not a privileged desktop shell.
- Existing chat transport is browser `fetch`-based and provider-driven.
- Existing preset storage is local/browser persisted and key-oriented.
- A broken “OAuth connected” UI is worse than no feature because it would mislead the user into believing chat requests are supported.

## Root Backup
- Completed before analysis.
- Archive: `backup_20260415-002809--pre-openai-oauth-pass.zip`
- Verified entry count: `7358`

## Facts Collected
### Current local architecture
- Presets are stored in `userApiSettings.apiPresets` with `provider`, `key`, model settings, sampling, grounding, history, and auto-compact fields.
- Provider detection is currently key-pattern-based in `Ailey/src/03_core/115_core_api_settings_utils.js`.
- OpenAI API-key chat calls currently use browser `fetch` to `https://api.openai.com/v1/chat/completions` in `Ailey/src/04_features_chat/213_chat_api_service.js`.
- API preset verification for OpenAI currently uses browser `fetch` to `https://api.openai.com/v1/models` in `Ailey/src/03_core/114_core_api_settings_api_service.js`.

### Codex auth material found locally
- Local Codex auth file exists at `%USERPROFILE%\\.codex\\auth.json`.
- Top-level fields found: `auth_mode`, `OPENAI_API_KEY`, `tokens`, `last_refresh`
- Token fields found: `id_token`, `access_token`, `refresh_token`, `account_id`
- `OPENAI_API_KEY` is not present/populated in the local auth file on this machine.

### External behavior relevant to feasibility
- OpenAI API documentation still documents API-key authentication for the public API.
- OpenAI’s public Codex article indicates the ChatGPT-login/Codex path uses the ChatGPT backend Codex endpoint rather than the regular API-key endpoint.
- A live preflight check from `http://localhost:8080` to `https://chatgpt.com/backend-api/codex/responses` returned:
  - `HTTP/1.1 400 Bad Request`
  - `Disallowed CORS origin`
  - `vary: Origin`
  - `access-control-allow-headers: authorization,content-type`
  - `access-control-allow-credentials: true`

## Diagnosis
Direct Codex OAuth integration is not browser-safe in the current app architecture.

The blocker is not the presence of OAuth tokens. The blocker is that the browser runtime cannot directly call the ChatGPT Codex backend from this app’s origin because the backend rejects the origin at the CORS layer. That means:

- adding a Codex OAuth preset to the current browser app without a helper bridge would produce a misleading connection flow
- model verification would fail or require unsupported origin behavior
- actual chat sends would fail even if tokens were captured successfully

## Safe Conclusion
Do not patch the current chat settings with a fake-direct Codex OAuth mode in this pass.

That would ship a broken path.

## Safe Integration Options
### Option A: Local bridge / proxy companion
Add an explicit `openai_codex_oauth_bridge` provider that talks to a trusted local helper on `localhost`.

Responsibilities:
- browser UI manages connect/disconnect state only
- helper performs Codex OAuth flow, token refresh, and Codex backend requests
- browser talks only to the helper, not to `chatgpt.com/backend-api/*`

Pros:
- technically viable with current browser runtime
- rollback-safe because API-key mode remains untouched
- easiest way to preserve both API-key and OAuth side by side

Cons:
- requires a helper process or local service
- more moving parts to ship and support

### Option B: Hosted backend proxy
Add a hosted service to own OAuth, token refresh, model enumeration, and chat routing.

Pros:
- cleanest browser UX

Cons:
- requires backend hosting, secret handling, account/session design, abuse protection, and cost management

### Option C: Import-only auth artifact mode
Allow the user to import Codex auth artifacts or tokens in settings, but only for use with a companion bridge.

Pros:
- useful as part of Option A

Cons:
- still not enough by itself because the browser cannot directly call the backend endpoint

## Chosen Recommendation
Do not implement direct Codex OAuth inside the current browser-only settings flow.

The smallest complete design that can work is:
- keep current API-key provider unchanged
- design a separate OAuth provider family for a future local bridge
- only add product UI for OAuth when the bridge contract exists and is testable

## Approved Scope For This Investigation Pass
- backup the root
- inspect current provider/preset architecture
- inspect local Codex auth state structure without exposing secrets
- validate whether direct browser OAuth transport is feasible
- write the result down for maintenance and next-step implementation

## Out of Scope In This Pass
- shipping a broken direct OAuth preset
- reverse-engineering private ChatGPT traffic into production code without a safe transport path
- backend or local bridge implementation without separate approval

## Progress
- 2026-04-15 00:28 KST: User approved proceeding after backup.
- 2026-04-15 00:29 KST: Root backup archive created.
- 2026-04-15 00:31 KST: Current provider and preset code paths inspected.
- 2026-04-15 00:34 KST: Local Codex auth file shape verified without exposing tokens.
- 2026-04-15 00:35 KST: CORS preflight evidence confirmed direct browser path is blocked.
- 2026-04-15 00:39 KST: Plan updated with blocker and safe next-step options.

## Status
Completed as an architecture-validation and feasibility pass.

No product code was changed because the discovered path would not have produced a working feature in the current runtime.

## Next Safe Step
If the user wants OAuth support to truly land, open a new approved implementation pass for:

- a local Codex OAuth bridge contract
- settings UI integration for that bridge
- request/response compatibility mapping into the existing chat system
- failure states, reconnect flow, and rollback plan

## Scoreboard
### Current Score
40/100 (provisional, capped by workspace rule because the user has not scored this pass yet)

### Why This Score
- Positive:
  - root backup completed first as requested
  - hard blocker was found before shipping a broken UI
  - rollback risk avoided
- Negative:
  - user-requested OAuth settings integration is not yet implemented
  - a second approved pass is required for the bridge-based path

### Score History
- 2026-04-15 00:39 KST — 40/100 provisional — investigation complete, implementation deferred because direct browser path is blocked by CORS
