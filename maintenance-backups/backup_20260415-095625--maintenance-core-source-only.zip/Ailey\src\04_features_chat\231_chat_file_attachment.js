/* --- Ailey & Bailey Canvas --- */
// File: 231_chat_file_attachment.js
// Version: 2.0 (Multi Attachment Composer)
// Description: Handles chat composer attachments, including picker, paste, drop, preview chips, and removal.

const MAX_CHAT_ATTACHMENTS = 12;
const MAX_CHAT_FILE_BYTES = 12 * 1024 * 1024;
const CHAT_TEXT_EXTENSIONS = new Set([
    'txt', 'md', 'json', 'csv', 'tsv', 'js', 'ts', 'py', 'html', 'css', 'xml', 'yaml', 'yml'
]);

function normalizeChatMessageAttachments(message) {
    if (!message) return [];
    if (Array.isArray(message.attachments) && message.attachments.length > 0) {
        return message.attachments.filter(Boolean);
    }
    if (message.attachment) {
        return [message.attachment];
    }
    return [];
}

function syncLegacyAttachmentState() {
    attachedFile = stagedChatAttachments.length > 0 ? { ...stagedChatAttachments[0] } : null;
}

function getChatAttachmentKind(file) {
    const extension = (file.name.split('.').pop() || '').toLowerCase();
    if ((file.type || '').startsWith('image/')) return 'image';
    if (file.type === 'application/pdf' || extension === 'pdf') return 'pdf';
    if ((file.type || '').startsWith('text/') || CHAT_TEXT_EXTENSIONS.has(extension) || (file.type || '').includes('json') || (file.type || '').includes('javascript')) return 'text';
    return null;
}

function createAttachmentId(file) {
    return `att-${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${file.name.replace(/[^a-zA-Z0-9_.-]/g, '-')}`;
}

function formatFileSize(bytes) {
    if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let unit = 0;
    while (size >= 1024 && unit < units.length - 1) {
        size /= 1024;
        unit += 1;
    }
    return `${size.toFixed(size >= 10 || unit === 0 ? 0 : 1)} ${units[unit]}`;
}

function getAttachmentSummaryLabel(attachments) {
    if (!attachments || attachments.length === 0) {
        return '이미지, PDF, 텍스트 파일을 여러 개 붙여넣거나 끌어놓을 수 있습니다.';
    }
    const totalSize = attachments.reduce((sum, item) => sum + (item.size || 0), 0);
    return `첨부 ${attachments.length}개 준비됨 · ${formatFileSize(totalSize)}`;
}

function updateChatAttachmentHint() {
    if (!chatAttachmentHint) return;
    chatAttachmentHint.textContent = getAttachmentSummaryLabel(stagedChatAttachments);
}

function createAttachmentChipHtml(attachment, index) {
    const name = (attachment.name || '첨부 파일').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const size = formatFileSize(attachment.size || 0);
    const imagePreview = attachment.type === 'image'
        ? `<img src="${attachment.content}" alt="${name}" class="chat-attachment-pill-thumb">`
        : `<span class="chat-attachment-pill-icon">${attachment.type === 'pdf' ? 'PDF' : 'TXT'}</span>`;

    return `
        <div class="chat-attachment-pill" data-attachment-index="${index}">
            <div class="chat-attachment-pill-leading">${imagePreview}</div>
            <div class="chat-attachment-pill-body">
                <span class="chat-attachment-pill-name">${name}</span>
                <span class="chat-attachment-pill-meta">${size}</span>
            </div>
            <button type="button" class="chat-attachment-remove-btn" data-remove-attachment="${index}" title="첨부 제거" aria-label="첨부 제거">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z" /></svg>
            </button>
        </div>
    `;
}

function renderStagedChatAttachments() {
    if (!attachedFileDisplay) return;

    syncLegacyAttachmentState();
    updateChatAttachmentHint();

    if (!stagedChatAttachments.length) {
        attachedFileDisplay.style.display = 'none';
        attachedFileDisplay.innerHTML = '';
        return;
    }

    attachedFileDisplay.innerHTML = `
        <div class="chat-attachment-tray-header">
            <span class="chat-attachment-tray-title">첨부 파일</span>
            <button type="button" class="chat-attachment-clear-all-btn" id="chat-attachment-clear-all-btn">모두 제거</button>
        </div>
        <div class="chat-attachment-pill-grid">
            ${stagedChatAttachments.map((attachment, index) => createAttachmentChipHtml(attachment, index)).join('')}
        </div>
    `;
    attachedFileDisplay.style.display = 'flex';

    attachedFileDisplay.querySelectorAll('[data-remove-attachment]').forEach(button => {
        button.addEventListener('click', () => removeAttachment(Number(button.dataset.removeAttachment)));
    });

    attachedFileDisplay.querySelector('#chat-attachment-clear-all-btn')?.addEventListener('click', clearAllChatAttachments);
}

function setComposerDropState(isActive) {
    if (!chatForm) return;
    chatForm.classList.toggle('is-drag-over', !!isActive);
}

function clearChatFileInput() {
    if (chatFileInput) {
        chatFileInput.value = '';
    }
}

function clearAllChatAttachments() {
    stagedChatAttachments = [];
    clearChatFileInput();
    renderStagedChatAttachments();
}

function removeAttachment(index) {
    if (typeof index !== 'number' || Number.isNaN(index)) {
        clearAllChatAttachments();
        return;
    }
    stagedChatAttachments = stagedChatAttachments.filter((_, itemIndex) => itemIndex !== index);
    renderStagedChatAttachments();
}

function handleFileAttachClick() {
    chatFileInput?.click();
}

function readFileAsChatAttachment(file) {
    return new Promise((resolve, reject) => {
        const attachmentType = getChatAttachmentKind(file);
        if (!attachmentType) {
            return reject(new Error(`지원하지 않는 파일 형식입니다: ${file.name}`));
        }
        if (file.size > MAX_CHAT_FILE_BYTES) {
            return reject(new Error(`${file.name} 파일이 너무 큽니다. 파일당 최대 ${formatFileSize(MAX_CHAT_FILE_BYTES)}까지 허용합니다.`));
        }

        const reader = new FileReader();
        reader.onload = event => {
            resolve({
                id: createAttachmentId(file),
                name: file.name,
                content: event.target?.result || '',
                type: attachmentType,
                mimeType: file.type || '',
                size: file.size || 0,
                source: 'upload'
            });
        };
        reader.onerror = () => reject(new Error(`${file.name} 파일을 읽는 중 오류가 발생했습니다.`));

        if (attachmentType === 'image' || attachmentType === 'pdf') {
            reader.readAsDataURL(file);
        } else {
            reader.readAsText(file);
        }
    });
}

async function appendAttachmentsFromFileList(fileList) {
    const files = Array.from(fileList || []);
    if (!files.length) return;

    const availableSlots = Math.max(MAX_CHAT_ATTACHMENTS - stagedChatAttachments.length, 0);
    if (availableSlots <= 0) {
        showModal(`첨부는 최대 ${MAX_CHAT_ATTACHMENTS}개까지 가능합니다.`, () => {});
        clearChatFileInput();
        return;
    }

    const nextFiles = files.slice(0, availableSlots);
    const results = await Promise.allSettled(nextFiles.map(readFileAsChatAttachment));
    const successAttachments = results
        .filter(result => result.status === 'fulfilled')
        .map(result => result.value);
    const failures = results
        .filter(result => result.status === 'rejected')
        .map(result => result.reason?.message || '파일을 읽지 못했습니다.');

    if (successAttachments.length > 0) {
        stagedChatAttachments = [...stagedChatAttachments, ...successAttachments];
        renderStagedChatAttachments();
    }

    if (failures.length > 0) {
        showModal(failures.join('\n'), () => {});
    }

    clearChatFileInput();
}

function handleFileSelected(event) {
    appendAttachmentsFromFileList(event.target?.files);
}

function extractClipboardFiles(event) {
    const clipboard = event.clipboardData;
    if (!clipboard) return [];

    const directFiles = Array.from(clipboard.files || []);
    if (directFiles.length > 0) return directFiles;

    return Array.from(clipboard.items || [])
        .map(item => item.getAsFile())
        .filter(Boolean);
}

function handleChatComposerPaste(event) {
    const files = extractClipboardFiles(event);
    if (!files.length) return;
    event.preventDefault();
    appendAttachmentsFromFileList(files);
}

function isFileDragEvent(event) {
    const types = Array.from(event.dataTransfer?.types || []);
    return types.includes('Files');
}

function handleChatComposerDragEnter(event) {
    if (!isFileDragEvent(event)) return;
    event.preventDefault();
    setComposerDropState(true);
}

function handleChatComposerDragOver(event) {
    if (!isFileDragEvent(event)) return;
    event.preventDefault();
    if (event.dataTransfer) {
        event.dataTransfer.dropEffect = 'copy';
    }
    setComposerDropState(true);
}

function handleChatComposerDragLeave(event) {
    if (!chatForm) return;
    if (event.relatedTarget && chatForm.contains(event.relatedTarget)) return;
    setComposerDropState(false);
}

function handleChatComposerDrop(event) {
    if (!isFileDragEvent(event)) return;
    event.preventDefault();
    setComposerDropState(false);
    appendAttachmentsFromFileList(event.dataTransfer?.files);
}
