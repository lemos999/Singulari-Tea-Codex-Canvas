# Thin Action Bar Header Refactor Plan

- Created: 2026-04-12 22:59:59 +09:00
- Last Updated: 2026-04-12 23:21:24 +09:00
- Status: completed_pending_user_validation
- Plan Type: implementation
- Scope: immersive header only

## Objective

Replace the current immersive header with the approved `Thin Action Bar` direction.

The new header should:

- reduce visual obstruction over the reading surface
- remove quick query UI from the header
- remove clock/time display from the header
- remove the explicit header visibility toggle UI and its saved state behavior
- support narrow desktop widths and mobile widths without becoming tall or unreadable

## Approved Direction

- Keep only a minimal brand area plus essential action buttons.
- Preserve core actions:
  - snapshot
  - export
  - notes
  - chat
  - theme
- Make the header always visible but physically thinner and less dominant.
- Do not introduce a second large control row.
- Prefer small complete changes over a wider navigation-system rewrite.

## Files In Scope

- `Ailey/src/00_shell/000_shell_template.js`
- `Ailey/src/00_shell/005_shell_part6_main_assembler.js`
- `Ailey/src_css/001_base.css`
- `Ailey/src_css/009_widget_misc.css`
- `Ailey/src_css/010_widget_header_addons.css`
- `Ailey/src/03_core/120_core_main_initializer.js`

## Design Notes

- Remove the center quick-query region entirely.
- Remove the left system-info/time region entirely.
- Collapse the header to a centered, slim, rounded action bar with reduced padding and smaller buttons.
- On mobile:
  - hide non-essential supporting copy
  - tighten spacing
  - keep the actions single-row if possible

## Risks

- Existing runtime hooks for quick query and header visibility may assume elements exist.
- Export dropdown positioning must still work after header layout changes.
- Very small widths may still require tighter icon spacing to avoid wrap.

## Mitigation

- Keep null-safe runtime guards where existing code already supports missing DOM nodes.
- Remove saved header-visibility restore logic instead of only hiding the toggle visually.
- Validate with `node --check` and `node Ailey/bundler.js`.

## Execution Steps

1. Replace header markup with a minimal left brand and right actions layout.
2. Rebuild the immersive header CSS as a thin floating action bar.
3. Remove header visibility toggle markup and CSS.
4. Remove quick-query/time-driven initializer logic that is no longer relevant to the header.
5. Verify syntax and rebundle.

## Scoreboard

- Current Score: 92
- Score Source: provisional
- Last Updated: 2026-04-12 23:21:24 +09:00
- Rationale: the thin action bar header is implemented, bundled, and pushed to the hosted bundle repo, but the user has not manually validated the live reading surface yet
- What Improved: the header now uses a slim floating action bar, quick query/time/toggle UI were removed from the surface, runtime toggle restore logic was removed, and the hosted bundle is updated
- What Remains Unsatisfactory: the final visual judgment for narrow desktop and mobile still depends on user-side runtime validation
- Next Step: user validates the new thin header against real exported/live HTML pages

## Score History

- 2026-04-12 22:59:59 +09:00 | 50 | provisional | user approved the Thin Action Bar direction after backup
- 2026-04-12 23:21:24 +09:00 | 92 | provisional | thin action bar header refactor implemented, rebundled, and deployed to hosted bundle commit `8203934`
