# Image Overlay And Selection Toolbar Cleanup Report

- Created: 2026-04-13 01:00:00 +09:00
- Scope: refined image-generation surface removal, right-click add-menu removal, selection-toolbar redesign
- Hosted Bundle Commit: `9adde8d7cee5b7e7e8c85ec5f1a1b3b7994d0a16`

## Delivered

- Removed the active `정제 후 생성` user path from image generation flows.
- Removed the right-click add-menu behavior for image/visualization insertion in rendered content.
- Rebuilt the selection toolbar as a smaller floating action bar with:
  - above-selection preference
  - viewport clamping
  - lighter visual weight
  - dark/light theme support

## Key Changes

- `001_shell_part2_modals_common.js`
  - rebuilt selection-popover markup into compact icon-led actions
- `014_utils_ui_actions.js`
  - changed popover placement to fixed-position, above-first, clamped layout
- `006_widget_popovers_tooltips.css`
  - redesigned selection toolbar visuals for both themes
- `111_core_api_settings_data.js`
  - normalized legacy vision settings to `quick` or `off`
  - dropped `refineApi` from normalized runtime state
- `125_core_initializer_vision_ui.js`
  - removed refined button wiring
  - removed refined panel/settings controls at runtime
- `124_core_initializer_vision_handler.js`
  - normalized generation path to quick-mode behavior
- `013_utils_block_renderer.js`
  - suppressed refined placeholder control at runtime
  - disabled the right-click add-menu path
- `123_core_initializer_vision_logic.js`
  - simplified auto-image-generation to quick mode
  - suppressed refined overlay/failure buttons at runtime
- `025_vision_weaver_panel.css`
  - hid refined panel button and promoted quick button styling
- `027_image_gen_studio.css`
  - hid refined studio button and promoted quick action styling
- `028_image_placeholders.css`
  - hid refined image buttons in placeholder/overlay surfaces

## Verification

- `node --check` passed for all touched JS files
- `node Ailey/bundler.js` passed
- hosted bundle pushed to `origin/main`

## Residual Notes

- Some legacy refined-related strings still exist in old shell/template source blocks, but the active runtime surface and interaction path are removed or suppressed.
- User-facing validation is still needed for:
  - selection toolbar placement over real highlighted text
  - right-click behavior in exported/live HTML
  - image generation surfaces no longer showing refined actions
