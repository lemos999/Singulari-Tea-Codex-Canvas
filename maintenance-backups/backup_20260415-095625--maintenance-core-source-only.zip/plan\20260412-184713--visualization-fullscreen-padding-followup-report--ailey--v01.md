# Visualization Fullscreen Padding Follow-Up Report

- Created: 2026-04-12 18:47:13 +09:00
- Author: Codex
- Scope: live export scene visualization fullscreen enter/exit regression
- Status: deployed-awaiting-user-validation

## Trigger

User reported that in `C:\Users\Lemos\Downloads\기단의 성질과 변화 (1).html`, a scene-style visualization kept reasonable left/right padding before fullscreen, but after entering fullscreen once and exiting, the visualization visually stretched and lost that padding.

## Root Cause

Two behaviors combined into the regression:

1. `Ailey/src_css/004_widget_visualization_options.css`
   - live export scene blocks sized `.visualization-execution-wrapper` with viewport-based width logic:
   - `width: min(1180px, calc(100vw - 48px))`
   - this ignored the article/container padding envelope and recent fullscreen/resize state

2. `Ailey/src/02_utils/013_utils_block_renderer.js`
   - cinema mode forced `document.body.style.overflow = 'hidden'`
   - exit restored it with an empty string instead of restoring the prior inline value explicitly
   - this made the post-fullscreen resize path less deterministic than necessary

## Fix

### 1. Container-relative scene width restoration

Updated live export scene wrapper sizing so it follows the padded content container rather than the viewport:

- desktop: `calc(100% + 80px)` with `margin-left: -40px`
- medium width: `calc(100% + 48px)` with `margin-left: -24px`
- mobile: `100%`

This preserves the intended scene bleed without letting fullscreen/resize transitions snap the block to viewport width.

### 2. Safe cinema exit state restoration

Cinema mode now:

- stores the previous `document.body.style.overflow`
- restores that exact value on exit
- uses a shared `exitCinemaMode()` path for both button exit and `Escape`

This narrows state drift during fullscreen enter/exit and keeps layout restoration predictable.

## Files Changed

- `Ailey/src_css/004_widget_visualization_options.css`
- `Ailey/src/02_utils/013_utils_block_renderer.js`
- `Ailey/bundle/main.js`
- `Ailey/bundle/main.css`

## Verification

- `node --check Ailey/src/02_utils/013_utils_block_renderer.js`
- `node Ailey/bundler.js`

## Deployment

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `4184a49`
- commit message: `Fix fullscreen exit padding regression for scene visualizations`

## Remaining Step

User manual validation on exported/live HTML remains pending.
