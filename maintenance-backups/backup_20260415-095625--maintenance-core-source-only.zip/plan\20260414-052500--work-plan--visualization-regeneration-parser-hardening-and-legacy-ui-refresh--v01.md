Plan Type: Work Plan
Workstream: Visualization Regeneration Parser Hardening And Legacy UI Refresh
Version: v01
Status: Completed / Published
Created: 2026-04-14 05:25:00 +09:00
Last Updated: 2026-04-14 05:48:41 +09:00
Supersedes or Related Plan: Related to `plan/20260414-045500--work-plan--panorama-fullscreen-and-gemini-local-chat-fix--v01.md`
Current Completion State: Shared parser hardening, regeneration runtime fixes, legacy failure-surface refresh, bundle rebuild, validation, and publish are complete.
Completed So Far: Added resilient visualization fragment extraction for unlabeled fenced blocks and JSON-wrapped html payloads, forced visualization system jobs onto historyless programmatic sends, cleared visualization system sessions on both success and failure, refreshed modal and inline regeneration error surfaces, improved code-block labeling for visualization fragments in system chat, rebuilt the bundle, validated the regeneration paths, and copied the narrow bundle diff into the publish repository.
Remaining Work: None for the approved scope.
Current Blockers: None
Next Step: Monitor user retest feedback and reopen only if a new regeneration response shape still slips past the parser.

# User Understanding

The user is actively testing visualization regeneration. General prompt-template conversations using Ailey & Bailey Light respond correctly, but regeneration of visualization content fails with an old error path that says the AI did not return a valid HTML code block.

The user suspects the response may be chunked or cut mid-stream. The screenshots show that the Visualization Engine session can still display a code block-like response, but the visualization regeneration pipeline rejects it and falls back to an outdated failure UI. The user wants both the real cause fixed and the old failure UI refreshed so these surfaces match the renewed shell design language.

# Scope

In scope:

- inspect the visualization regeneration path separately from ordinary prompt-template chat
- identify whether the failure comes from chunking, stream assembly, parser strictness, or prompt-contract drift
- harden HTML extraction for regeneration and related visualization generation paths
- preserve safe rejection for truly invalid outputs while accepting valid HTML returned in slightly different fence formats
- redesign the regeneration failure modal and closely related legacy failure surfaces so they match the newer note/chat/settings language
- rebuild and validate the runtime behavior

Out of scope unless required by the above:

- redesigning every modal in the application indiscriminately
- changing the Data Visualizer template into a different product feature
- rewriting the full visualization engine architecture
- changing storage schema for sessions, presets, or notes

# Smallest Safe Assumptions

- The current failure is more likely parser strictness than a model incapability, because the screenshot shows a code block response in the Visualization Engine session.
- The code block shown as a generic “Code Block” rather than an explicitly typed HTML block is a strong signal that the model sometimes returns fenced code without the `html` language tag.
- The user wants regeneration to remain strict enough to reject prose or malformed junk, but not so strict that valid HTML fragments are discarded only because the fence label is missing.
- The modernized UI should reuse the renewed shell styling vocabulary rather than invent a fourth modal family.

# Objective

Deliver one bounded runtime update that makes visualization regeneration resilient to reasonable response-shape variation from the AI, while also refreshing the outdated regeneration-failure UI so parser or generation failures are communicated in the same modern management language as the renewed notes, chat, and settings surfaces.

# Design Intent

The parser should become more intelligent, not more permissive in an unsafe way. Prefer the best valid HTML fragment in this order:

1. an explicit `html` fenced block
2. another fenced block whose contents clearly look like injectable visualization HTML
3. a raw response body that clearly contains visualization HTML or script markup after markdown cleanup

The parser should stay centralized so generation, regeneration, batch generation, and adjacent code-fix flows do not drift into different extraction rules.

For UI, the redesign should focus on failure surfaces the user can hit during regeneration and nearby legacy modals, with emphasis on hierarchy, action clarity, calmer spacing, better destructive action styling, and consistency with the newer settings and notes refresh.

# Hidden Rules And Consistency Requirements

First, the regeneration parser must not silently accept arbitrary text just because it contains angle brackets. It should use content-shape heuristics that are specifically appropriate for visualization fragments.

Second, the same extraction rules should be reused across single generation, regeneration, and batch generation wherever possible. If one path is hardened and the others stay brittle, the problem will reappear under a different button.

Third, parser failure reporting should still preserve observability. If a response is rejected, the error should indicate whether the parser found no fenced block, found a block that did not look like visualization HTML, or found only incomplete markup.

Fourth, the updated failure modal should not regress existing confirm or cancel semantics. It should remain easy to dismiss and easy to understand, while visually matching the newer shell family.

# Work Sequence

## Phase 1: Confirm The Actual Failure Mode

Inspect the current regeneration response parsing and compare it against the Data Visualizer prompt contract. Confirm whether the actual issue is:

- unlabeled fenced code blocks
- non-`html` fenced blocks that still contain valid HTML
- raw fragment responses after markdown cleanup
- truncated or incomplete stream assembly

Leave this phase with a concrete parser-failure explanation.

## Phase 2: Implement Shared Visualization HTML Extraction

Create one reusable extractor for visualization HTML fragments and apply it to:

- single visualization generation
- visualization regeneration
- batch visualization generation
- adjacent code-fix flows if the same brittle extraction logic is duplicated there

The extractor should prioritize explicit `html` fences but gracefully accept other clearly valid fragment shapes.

## Phase 3: Refresh Legacy Failure UI

Modernize the regeneration-failure modal and the embedded visualization error presentation so they align with the renewed shell language:

- better spacing
- clearer title and body hierarchy
- stronger primary and destructive action distinction
- less dated flat gray button treatment
- more coherent error card styling

## Phase 4: Rebuild And Verify

Validate that:

- regeneration succeeds when the AI returns a generic fenced code block containing valid HTML
- truly invalid responses are still rejected
- the refreshed modal renders correctly in the failure path
- no new page errors appear

## Phase 5: Publish

If the fix is clean, rebuild the bundle, copy the narrow bundle diff into the publish repository, commit, push, and record the final commit hash.

# Validation Strategy

Use a focused browser or runtime reproduction to compare:

1. the Visualization Engine session response content
2. the string returned by the programmatic regeneration path
3. the parser result
4. the rendered visualization block or failure surface

Verification should explicitly check unlabeled fenced code blocks, labeled `html` blocks, and raw fragment fallback behavior.

# Definition Of Done

This task is done when:

- valid visualization HTML is no longer rejected just because the fence label is missing or variant
- regeneration succeeds for the reported failure shape
- the regeneration failure modal and related legacy error surfaces are visibly refreshed
- the bundle rebuild succeeds
- validation shows the new parser behavior and failure UI behavior clearly
- the result is published if no blocking regressions remain

# Rollback

Rollback remains straightforward. Revert the shared visualization extractor changes and the modal or error-surface styling changes, rebuild the bundle, and restore the previous published bundle.

# Scoreboard

Current Score: 50
Score Source: provisional
Last Updated: 2026-04-14 05:48:41 +09:00
Score Rationale: The approved scope is implemented, validated, and published. The result now accepts the response shapes that previously failed, refreshes the outdated failure surfaces, and preserves a narrow rollback surface.
What Improved: Visualization regeneration no longer depends on polluted system-session history, accepts unlabeled fenced fragments and JSON-wrapped html payloads, shows refreshed failure UI when the response is truly invalid, and labels system-chat visualization fragments more clearly.
What Remains Unsatisfactory: Live real-model retest with the exact user-side regeneration sample is still needed for final experiential confirmation, and existing non-blocking third-party console warnings remain outside this change set.
What Should Happen Next To Raise Or Maintain The Score: Let the user retest regeneration in the live flow; if they confirm the reported failure is gone, the score can move from provisional to user-confirmed.

## Score History

- 2026-04-14 05:25:00 +09:00 | Score: 45 | Source: provisional | Reason: New approved plan created for regeneration parser hardening and legacy UI refresh; implementation still pending.
- 2026-04-14 05:48:41 +09:00 | Score: 50 | Source: provisional | Reason: Parser hardening, legacy UI refresh, validation, and publish completed for the approved scope.
