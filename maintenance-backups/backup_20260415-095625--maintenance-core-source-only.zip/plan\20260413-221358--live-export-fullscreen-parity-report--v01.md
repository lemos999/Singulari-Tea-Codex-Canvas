Report Type: implementation-report
Workstream: Live export parity and fullscreen stabilization for canvas-rendered interactive exports
Version: v01
Status: Published
Created: 2026-04-13 23:08:03 +09:00
Related Plan: 20260413-221358--work-plan--live-export-fullscreen-parity--v01.md

# Outcome

The live-export parity and fullscreen stabilization work passed the harsh browser matrix and was published to the canonical bundle repository.

- Publish repo: `https://github.com/lemos999/Singulari-Tea-Codex-Canvas`
- Publish commit: `8189e36`
- Commit message: `Stabilize live export parity and fullscreen runtime`

# Landed Runtime Changes

- `Ailey/src/02_utils/018_utils_html_exporter.js`
  - Preserve the mounted `<main id="ai-content-placeholder">` root in live exports instead of exporting only the inner learning fragment.
  - Preserve artifact-authored head resources around the required baseline shell so Tailwind/Lucide-like dependencies survive local live export.
  - Copy iframe `srcdoc` payloads into the exported HTML before serialization.

- `Ailey/src/00_shell/005_shell_part6_main_assembler.js`
  - Add compatibility resource injection for Tailwind-driven or Lucide-driven legacy artifacts.
  - Bias legacy Tailwind-like artifacts toward free-layout mounting when no explicit layout attribute survives export.

- `Ailey/src/02_utils/013_utils_block_renderer.js`
  - Fix concurrent visualization script-loading races so later blocks wait for actual library readiness rather than only checking for a matching `<script src>`.
  - Strengthen cleanup for timers, observers, animation frames, and generated `_cleanup` hooks across rerender/fullscreen cycles.
  - Add safer cinema/fullscreen relayout sequencing after enter and exit.
  - Repair common generated D3 easing alias typos such as `d3.easeSineInOut` to the canonical `d3.easeSinInOut`.

- `Ailey/src_css/004_widget_visualization_options.css`
  - Remove export-only width overrides that made local live exports drift away from canvas sizing.

# Validation Evidence

Primary validation run:
- `visual-tests/20260413-221358-live-export-fullscreen-parity/validation-summary.json`
- `visual-tests/20260413-221358-live-export-fullscreen-parity/validation-report.json`

Result summary:
- Generated fresh live export: `file://` pass, `http://` pass
- `태양의 성계- 중력과 빛의 대서사시.html`: `file://` pass, `http://` pass
- `태양계- 생명의 요람과 우주의 신비.html`: `file://` pass, `http://` pass
- All six matrix entries report `fullscreenOk: true`
- All six matrix entries report `shellMounted: true`
- All six matrix entries report `pageErrorCount: 0`
- The fresh generated export preserves `hasMainRootMarkup`, `hasTailwindCdn`, `hasLucideCdn`, `hasDataCcLayout`, and `hasBundleMainJs`

# `/sub` Review Summary

- W1 export parity audit identified that live export was serializing only `#learning-content` and dropping required head resources.
- W2 fullscreen/lifecycle audit identified cinema-mode sizing and cleanup weaknesses.
- W3 validation audit confirmed the need for a file/http and enter/exit/re-enter matrix.
- Planck confirmed the critical loader race around DOM-presence being mistaken for script readiness.
- Dewey confirmed the repaired goal appears functionally satisfied and only low-risk confidence items remain.

# Remaining Watch Items

- `shellVisible: false` remains the observed state in the validation suite, which proves mount/bootstrap but not visibly open shell chrome.
- There is still small non-fatal console warning noise from third-party libraries or CDN usage.
- Free-layout inference for legacy artifacts remains heuristic when explicit layout attributes are absent.

# Decision

Acceptance: `pass`

The bounded repairs solved the user-facing parity/fullscreen problem closely enough to publish. Future work, if any, should be a separate confidence-hardening pass rather than a continuation of this repair loop.
