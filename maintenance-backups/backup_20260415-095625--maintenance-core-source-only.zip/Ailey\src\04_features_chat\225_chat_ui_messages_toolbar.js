/* --- Ailey & Bailey Canvas --- */
// File: 225_chat_ui_messages_toolbar.js
// Version: 3.0 (Inline Message Actions)
// Description: Renders stable bottom action rows for chat messages and routes click actions without hover toolbars.

function isMessageToolbarTouchMode() {
    if (document.body?.classList.contains('mobile-shell-mode')) return true;
    if (window.matchMedia) {
        try {
            return window.matchMedia('(pointer: coarse)').matches;
        } catch (_) {}
    }
    return window.innerWidth <= 820;
}

function dismissActiveMessageToolbar() {
    // Legacy no-op kept for compatibility with older action handlers.
}

function keepMessageToolbarVisible() {
    // Legacy no-op kept for compatibility with older initializer code paths.
}

function updateToolbarPosition() {
    // Legacy no-op kept for compatibility with older initializer code paths.
}

function removeToolbarWithDelay() {
    // Legacy no-op kept for compatibility with older initializer code paths.
}

function toggleMessageToolbar() {
    // Legacy no-op kept for compatibility with older initializer code paths.
}

function handleMessageToolbarDocumentPointerDown() {
    // Legacy no-op kept for compatibility with older initializer code paths.
}

function canRegenerateMessage(messageId) {
    if (!messageId || !currentSessionId) return false;

    const session = (currentSessionId === 'temporary-chat')
        ? temporarySession
        : localChatSessionsCache.find(s => s.id === currentSessionId);

    if (!session?.messages?.length) return false;

    const aiMessageIndex = session.messages.findIndex(m => getMessageId(m) === messageId);
    if (aiMessageIndex < 1 || aiMessageIndex !== session.messages.length - 1) return false;

    return session.messages[aiMessageIndex]?.role === 'ai'
        && session.messages[aiMessageIndex - 1]?.role === 'user';
}

function buildInlineMessageActionButton(messageId, action, title, svg, label) {
    return `
        <button
            class="message-inline-action-button"
            data-action="${action}"
            data-message-id="${messageId}"
            title="${title}"
            aria-label="${title}"
            type="button"
        >
            ${svg}
            <span class="message-inline-action-label">${label}</span>
        </button>
    `;
}

function buildInlineMessageActionsMarkup(messageId, options = {}) {
    if (!messageId) return '';

    const isUser = !!options.isUser;
    const copySvg = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z" /></svg>';
    const deleteSvg = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19M8,9H16V19H8V9M15.5,4L14.5,3H9.5L8.5,4H5V6H19V4H15.5Z" /></svg>';
    const regenerateSvg = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17.65,6.35C16.2,4.9 14.21,4 12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20C15.73,20 18.84,17.45 19.73,14H17.65C16.83,16.33 14.61,18 12,18A6,6 0 0,1 6,12A6,6 0 0,1 12,6C13.66,6 15.14,6.69 16.22,7.78L13,11H20V4L17.65,6.35Z" /></svg>';

    let html = `
        <div class="message-inline-actions ${isUser ? 'user-message-inline-actions' : 'ai-message-inline-actions'}" data-message-id="${messageId}">
            ${buildInlineMessageActionButton(messageId, 'copy', '메시지 복사', copySvg, '복사')}
            ${buildInlineMessageActionButton(messageId, 'delete', '메시지 삭제', deleteSvg, '삭제')}
    `;

    if (!isUser && canRegenerateMessage(messageId)) {
        html += buildInlineMessageActionButton(messageId, 'regenerate', '응답 다시 생성', regenerateSvg, '다시 생성');
    }

    html += '</div>';
    return html;
}

async function handleInlineMessageActionTrigger(actionButton) {
    if (!actionButton) return;

    const action = actionButton.dataset.action;
    const messageId = actionButton.dataset.messageId;
    const messageElement = actionButton
        .closest('.ai-response-container, .user-message-container')
        ?.querySelector(`.chat-message[data-message-id="${messageId}"]`);

    if (!action || !messageId || !messageElement) return;

    switch (action) {
        case 'copy':
            await handleMessageCopy(messageId);
            break;
        case 'delete':
            await handleMessageDelete(messageId, messageElement);
            break;
        case 'regenerate':
            await handleMessageRegenerate(messageId, messageElement);
            break;
    }
}
