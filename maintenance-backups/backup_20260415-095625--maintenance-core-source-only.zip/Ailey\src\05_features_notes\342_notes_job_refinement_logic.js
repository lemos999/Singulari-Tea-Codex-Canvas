/* --- Ailey & Bailey Canvas --- */
// File: src/05_features_notes/342_notes_job_refinement_logic.js
// Version: 8.0 (Incremental Learning Report)
// Description: Implemented an incremental analysis system for learning projects. The logic now checks for a cached `learning_state` and only processes notes that are new or have been updated since the last run, significantly improving efficiency.

async function _handleLearningProjectReport(projectId, noteIds = null) {
    const originalActivePromptId = activePromptId;
    const toastId = `learning-report-${Date.now()}`;
    showProgressToast('모듈형 학습 기록 생성 중...', toastId);
    trace("Report.Learning.Modular", "start", { projectId, noteCount: noteIds?.length || 'all' });

    let sessionId;
    try {
        const project = localNoteProjectsCache.find(p => p.id === projectId);
        if (!project) throw new Error('폴더를 찾을 수 없습니다.');
        
        const isSelectiveJob = !!noteIds;
        const existingLearningState = isSelectiveJob ? '' : (project.learning_state || '');

        const allNotesInProject = localNotesCache.filter(n => n.projectId === projectId && n.title.startsWith('[학습]'));

        updateProgressToast('노트 분류 및 분석 준비 중...', toastId);
        let curriculumNoteContent = '';
        const contentNotes = [];

        for (const note of allNotesInProject) {
            const content = await getNoteContent(note.id) || '';
            if (content.includes('<!-- CURRICULUM_DATA:')) {
                curriculumNoteContent = content;
            } else {
                contentNotes.push({ ...note, content });
            }
        }
        
        if (!curriculumNoteContent) {
            throw new Error("프로젝트에서 커리큘럼 맵 데이터를 찾을 수 없습니다. 학습 경로를 추론할 수 없습니다.");
        }

        let notesToProcess;
        if (isSelectiveJob) {
            notesToProcess = contentNotes.filter(n => noteIds.includes(n.id));
        } else {
            const lastTimestamp = project.refinementState?.lastProcessedNoteTimestamp;
            notesToProcess = contentNotes.filter(note => !lastTimestamp || (note.createdAt && note.createdAt > lastTimestamp));
        }
        
        if (notesToProcess.length === 0) {
            throw new Error(isSelectiveJob ? '선택한 노트 중 처리할 학습 노트가 없습니다.' : '새롭게 정제할 학습 노트가 없습니다.');
        }

        const analyzerTemplate = promptTemplatesCache.find(p => p.name === 'Learning Module Analyzer');
        if (!analyzerTemplate) throw new Error("Learning Module Analyzer 템플릿을 찾을 수 없습니다.");
        
        const sessionTitle = `⚙️ ${project.name} 데이터 정제`;
        sessionId = await findOrCreateSystemSession(sessionTitle);
        if (!sessionId) throw new Error("작업용 채팅 세션을 생성/탐색할 수 없습니다.");
        
        togglePanel(chatPanel, true);
        await selectSession(sessionId);
        
        notesToProcess.sort((a, b) => (a.createdAt?.toMillis() || 0) - (b.createdAt?.toMillis() || 0));

        updateProgressToast(`개별 모듈 분석 중... (0/${notesToProcess.length})`, toastId);
        const newMiniReports = [];
        let index = 0;
        for (const note of notesToProcess) {
            const contentForAI = `ORIGINAL_NOTE_TITLE: ${note.title}\n\n---\n\n[학습 완료 내용]\n${note.content}\n\n---\n\n[전체 커리큘럼 맵]\n${curriculumNoteContent}`;
            const report = await programmaticChatSend(sessionId, contentForAI, analyzerTemplate.promptText, true);
            newMiniReports.push(report);
            index++;
            updateProgressToast(`개별 모듈 분석 중... (${index}/${notesToProcess.length})`, toastId);
        }

        updateProgressToast('최종 기록 조립 및 저장 중...', toastId);
        const updatedState = [existingLearningState, ...newMiniReports].filter(Boolean).join('\n\n---\n\n');
        const finalDownloadableContent = [curriculumNoteContent, updatedState].filter(Boolean).join('\n\n---\n\n');

        if (!isSelectiveJob) {
            const lastProcessedNote = notesToProcess[notesToProcess.length - 1];
            if (lastProcessedNote && lastProcessedNote.createdAt) {
                const newTimestamp = lastProcessedNote.createdAt;
                const newRefinementState = {
                    ...(project.refinementState || {}),
                    lastProcessedNoteTimestamp: newTimestamp,
                    lastRefinedAt: firebase.firestore.FieldValue.serverTimestamp(),
                };
                
                await updateNoteProject(projectId, {
                    learning_state: updatedState,
                    refinementState: newRefinementState
                });
                trace("Refinement", "learning.state.saved", { projectId, newStateSize: updatedState.length });
            }
        }

        const finalAiMessage = { 
            role: 'ai', 
            content: `**[시스템]** 모듈형 학습 기록 생성이 완료되었습니다. (${notesToProcess.length}개 노트 처리됨)`,
            isLearningReport: true,
            reportMarkdown: finalDownloadableContent, 
            timestamp: firebase.firestore.FieldValue.serverTimestamp() 
        };

        const sessionDocRef = chatSessionsCollectionRef.doc(sessionId);
        await sessionDocRef.collection("messages").add(finalAiMessage);
        await sessionDocRef.update({ updatedAt: firebase.firestore.FieldValue.serverTimestamp() });
        
        hideProgressToast(toastId);
        showToastNotification("✅ 학습 기록 생성 완료", "채팅 패널에서 결과를 확인하고 다운로드하세요.", `learning-report-done-${Date.now()}`);

    } catch (error) {
        console.error("Modular learning report generation failed:", error);
        trace("Report.Learning.Modular", "error", { error: error.message }, {}, "ERROR");
        showModal(`학습 기록 생성 실패: ${error.message}`, () => {});
        if (sessionId) {
            const errorMsg = { role: 'ai', content: `**[시스템]** 오류로 인해 학습 기록 생성에 실패했습니다:\n${error.message}`, timestamp: firebase.firestore.FieldValue.serverTimestamp() };
            chatSessionsCollectionRef.doc(sessionId).collection("messages").add(errorMsg);
        }
    } finally {
        hideProgressToast(toastId);
        activePromptId = originalActivePromptId;
        updateChatHeaderModelSelector();
    }
}


async function startRefinementProcess(projectId, mode, forceRestart = false, chunkSizeInTurns = 2) {
    const originalActivePromptId = activePromptId;
    const toastId = `refinement-progress-${Date.now()}`;
    trace("Refinement", "request.start", { projectId, mode, forceRestart, chunkSizeInTurns });

    try {
        const project = localNoteProjectsCache.find(p => p.id === projectId);
        if (!project) throw new Error('폴더를 찾을 수 없습니다.');
        
        const allNotesInProjectForCheck = localNotesCache.filter(n => n.projectId === projectId);
        const isLearningProject = allNotesInProjectForCheck.some(note => note.title.startsWith('[학습]'));

        if (isLearningProject) {
            await _handleLearningProjectReport(projectId);
            return;
        }

        const notesForProject = allNotesInProjectForCheck.sort((a, b) => (a.createdAt?.toMillis() || 0) - (b.createdAt?.toMillis() || 0));

        if (notesForProject.length === 0) {
            showModal('정제할 메모가 폴더에 없습니다.', () => {});
            return;
        }

        const refinerTemplate = promptTemplatesCache.find(p => p.name === 'Narrative Data Refiner');
        if (!refinerTemplate) throw new Error(`"Narrative Data Refiner" 프롬프트 템플릿을 찾을 수 없습니다.`);
        
        let lastTimestamp = project.refinementState?.lastProcessedNoteTimestamp;
        let sessionId = project.refinementState?.targetSessionId;

        if (forceRestart) {
            await noteProjectsCollectionRef.doc(projectId).update({ 
                refinementState: firebase.firestore.FieldValue.delete(),
                learning_state: firebase.firestore.FieldValue.delete()
            });
            trace("Firestore", "refinement.resetState.success (from choice)", { projectId });
            
            const projectInCache = localNoteProjectsCache.find(p => p.id === projectId);
            if (projectInCache) {
                delete projectInCache.refinementState;
                delete projectInCache.learning_state;
            }

            sessionId = null;
            lastTimestamp = null;
        }
        
        let notesToProcess = notesForProject.filter(note => !lastTimestamp || (note.createdAt && note.createdAt > lastTimestamp));

        if (notesToProcess.length === 0) {
            showModal("정제할 새로운 메모리가 없습니다. 모든 메모리가 최신 상태입니다.", () => {});
            trace("Refinement", "request.noop", { reason: "No new notes" });
            return;
        }
        
        const contentPromises = notesToProcess.map(note => getNoteContent(note.id));
        const allContents = await Promise.all(contentPromises);
        
        const fullContent = allContents.join('\n\n---\n\n');
        const memoryBlocks = fullContent.split(/(?=## \[(?:턴|📸 스냅샷:))/).filter(chunk => chunk.trim() !== '');
        let finalMemoryBlocks = memoryBlocks;
        if (mode === 'continuation') {
            trace("Refinement", "mode.continuation.start", { totalTurns: memoryBlocks.length });
            if (memoryBlocks.length > 0) {
                const lastTurn = memoryBlocks.pop();
                const lightweightBlocks = memoryBlocks.map(turn => extractLightweightContent(turn));
                finalMemoryBlocks = [...lightweightBlocks, lastTurn];
            }
        }
        const turnChunks = [];
        for (let i = 0; i < finalMemoryBlocks.length; i += chunkSizeInTurns) {
            turnChunks.push(finalMemoryBlocks.slice(i, i + chunkSizeInTurns));
        }
        const contentChunks = turnChunks.map(chunk => chunk.join('\n\n'));

        if (contentChunks.length === 0) {
             showModal("처리할 데이터를 찾을 수 없습니다.", () => {});
             return;
        }

        if (!sessionId) {
            const sessionTitle = `⚙️ ${project.name} 데이터 정제`;
            const newSessionRef = await chatSessionsCollectionRef.add({ title: sessionTitle, createdAt: firebase.firestore.FieldValue.serverTimestamp(), updatedAt: firebase.firestore.FieldValue.serverTimestamp() });
            sessionId = newSessionRef.id;
        }

        togglePanel(chatPanel, true);
        await selectSession(sessionId);

        activeRefinementJob = {
            isSelective: false, refinementMode: mode, projectId: projectId, sessionId: sessionId,
            notesToProcess: notesToProcess,
            isLearningProject: false,
            turnChunks: contentChunks, 
            currentIndex: 0, retryCount: 0, processedMessageIds: new Set(), totalChunks: contentChunks.length,
            originalPromptId: originalActivePromptId, toastId: toastId, promptTemplateId: refinerTemplate.id, accumulatedResults: [],
        };
        
        showProgressToast(`데이터 정제 중... (0/${activeRefinementJob.totalChunks}개 완료)`, activeRefinementJob.toastId);
        
        setTimeout(() => { dispatchRefinementTask(0); }, 500);

    } catch (error) {
        console.error("Data refinement process failed:", error);
        trace("Refinement", "request.error", { error: error.message }, {}, "ERROR");
        showModal(`데이터 정제 프로세스 실패: ${error.message}`, () => {});
        if (activeRefinementJob) hideProgressToast(activeRefinementJob.toastId);
        activeRefinementJob = null;
        activePromptId = originalActivePromptId;
    }
}

async function startSelectiveRefinementProcess(projectId, noteIds, mode, chunkSizeInTurns = 2) {
    const originalActivePromptId = activePromptId;
    const toastId = `refinement-progress-${Date.now()}`;
    trace("Refinement", "request.start.selective", { projectId, count: noteIds.length, mode, chunkSizeInTurns });
    
    try {
        const project = localNoteProjectsCache.find(p => p.id === projectId);
        if (!project) throw new Error('폴더를 찾을 수 없습니다.');
        
        const allNotesInProjectForCheck = localNotesCache.filter(n => n.projectId === projectId);
        const isLearningProject = allNotesInProjectForCheck.some(note => note.title.startsWith('[학습]'));

        if (isLearningProject) {
            toggleSelectionMode(projectId);
            await _handleLearningProjectReport(projectId, noteIds);
            return;
        }

        const notesToProcess = localNotesCache.filter(n => noteIds.includes(n.id)).sort((a, b) => (a.createdAt?.toMillis() || 0) - (b.createdAt?.toMillis() || 0));

        if (notesToProcess.length === 0) {
            showModal('선택한 메모를 찾을 수 없습니다.', () => {});
            return;
        }
        
        const contentPromises = notesToProcess.map(note => getNoteContent(note.id));
        const allContents = await Promise.all(contentPromises);
        
        const fullContent = allContents.join('\n\n---\n\n');
        const memoryBlocks = fullContent.split(/(?=## \[(?:턴|📸 스냅샷:))/).filter(chunk => chunk.trim() !== '');
        const turnChunks = [];
        for (let i = 0; i < memoryBlocks.length; i += chunkSizeInTurns) {
            turnChunks.push(memoryBlocks.slice(i, i + chunkSizeInTurns));
        }
        const contentChunks = turnChunks.map(chunk => chunk.join('\n\n'));

        const refinerTemplate = promptTemplatesCache.find(p => p.name === 'Narrative Data Refiner');
        if (!refinerTemplate) throw new Error(`"Narrative Data Refiner" 프롬프트 템플릿을 찾을 수 없습니다.`);

        let sessionId = project.refinementState?.targetSessionId;
        if (!sessionId) {
            const sessionTitle = `⚙️ ${project.name} 데이터 정제`;
            const newSessionRef = await chatSessionsCollectionRef.add({ title: sessionTitle, createdAt: firebase.firestore.FieldValue.serverTimestamp(), updatedAt: firebase.firestore.FieldValue.serverTimestamp() });
            sessionId = newSessionRef.id;
        }
        
        togglePanel(chatPanel, true);
        await selectSession(sessionId);

        activeRefinementJob = {
            isSelective: true, refinementMode: mode, projectId: projectId, sessionId: sessionId,
            notesToProcess: notesToProcess,
            isLearningProject: false,
            turnChunks: contentChunks, 
            currentIndex: 0, retryCount: 0, processedMessageIds: new Set(), totalChunks: contentChunks.length,
            originalPromptId: originalActivePromptId, toastId: toastId, promptTemplateId: refinerTemplate.id, accumulatedResults: [],
        };
        
        showProgressToast(`데이터 정제 중... (0/${activeRefinementJob.totalChunks}개 완료)`, activeRefinementJob.toastId);
        
        toggleSelectionMode(projectId);
        
        setTimeout(() => { dispatchRefinementTask(0); }, 500);

    } catch (error) {
        console.error("Selective data refinement failed:", error);
        trace("Refinement", "request.selective.error", { error: error.message }, {}, "ERROR");
        showModal(`선택 항목 정제 실패: ${error.message}`, () => {});
        if (activeRefinementJob) hideProgressToast(activeRefinementJob.toastId);
        activeRefinementJob = null;
        activePromptId = originalActivePromptId;
        toggleSelectionMode(projectId);
    }
}

async function dispatchRefinementTask(index) {
    if (!activeRefinementJob || index >= activeRefinementJob.totalChunks) {
        return;
    }

    const { sessionId, turnChunks, totalChunks, toastId, promptTemplateId, refinementMode } = activeRefinementJob;

    try {
        updateProgressToast(`데이터 정제 중... (${index + 1}/${totalChunks} 처리중)`, toastId);

        const chunkToProcess = turnChunks[index];
        let noteContent = chunkToProcess; 

        if (refinementMode === 'lightweight' && !activeRefinementJob.isLearningProject) {
            noteContent = extractLightweightContent(chunkToProcess);
        }

        const refinerTemplate = promptTemplatesCache.find(p => p.id === promptTemplateId);
        if (!refinerTemplate || !refinerTemplate.promptText) {
            throw new Error("Data refiner template not found or is empty.");
        }
        
        const systemInstruction = refinerTemplate.promptText;
        const userContent = `--- 데이터 시작 ---\n${noteContent || '(내용 없음)'}\n--- 데이터 끝 ---`;

        await programmaticChatSend(sessionId, userContent, systemInstruction);

    } catch (error) {
        console.error(`Error dispatching refinement task for index ${index}:`, error);
        handleRefinementStep({
            content: `API 오류: programmaticChatSend failed - ${error.message}`,
            id: `dispatch-error-${Date.now()}`
        });
    }
}

async function handleRefinementStep(aiMessage) {
    if (!activeRefinementJob) return;

    if (aiMessage) {
        const msgId = getMessageId(aiMessage);
        if (activeRefinementJob.processedMessageIds.has(msgId)) {
            trace("Refinement", "step.ignore.duplicate", { msgId: msgId.substring(0, 10) });
            return;
        }
        activeRefinementJob.processedMessageIds.add(msgId);
        
        if (aiMessage.content && aiMessage.content.startsWith('**[시스템]**')) {
            trace("Refinement", "step.ignore.finalMessage", { sessionId: activeRefinementJob.sessionId });
            return;
        }

        const isError = aiMessage.content && aiMessage.content.includes("API 오류");

        if (isError) {
            activeRefinementJob.retryCount++;
            trace("Refinement", "step.failure", { retry: activeRefinementJob.retryCount, max: 3 });

            if (activeRefinementJob.retryCount >= 3) {
                hideProgressToast(activeRefinementJob.toastId);
                showModal(`데이터 정제 실패: 처리 중 3회 연속 오류가 발생하여 작업을 중단합니다.`, () => {});
                activePromptId = activeRefinementJob.originalPromptId;
                updateChatHeaderModelSelector();
                activeRefinementJob = null;
                return;
            }

            updateProgressToast(`API 오류 발생. 10초 후 재시도... (${activeRefinementJob.retryCount}/3)`, activeRefinementJob.toastId);
            setTimeout(() => {
                dispatchRefinementTask(activeRefinementJob.currentIndex);
            }, 10000);
            return;
        }

        activeRefinementJob.accumulatedResults.push(aiMessage.content || '');
        activeRefinementJob.retryCount = 0;
        activeRefinementJob.currentIndex++;
    }

    if (activeRefinementJob.currentIndex >= activeRefinementJob.totalChunks) {
        // [RACE-CONDITION-FIX] Copy the job state and nullify the global immediately.
        const jobToFinalize = { ...activeRefinementJob };
        const { projectId, notesToProcess, sessionId, originalPromptId, toastId, accumulatedResults, isSelective } = jobToFinalize;
        activeRefinementJob = null; // Nullify immediately
        
        try {
            const allResults = accumulatedResults;
            const finalCombinedContent = allResults.filter(s => s && s.trim()).join(',\n');
            
            const finalAiMessageContent = `**[시스템]** 모든 데이터 정제가 완료되어 하나의 최종 결과물로 종합했습니다.\n\n---\n\n${finalCombinedContent}`;
            const finalAiMessage = { role: 'ai', content: finalAiMessageContent, timestamp: firebase.firestore.FieldValue.serverTimestamp() };
    
            const sessionDocRef = chatSessionsCollectionRef.doc(sessionId);
            await sessionDocRef.collection("messages").add(finalAiMessage);
            await sessionDocRef.update({ updatedAt: firebase.firestore.FieldValue.serverTimestamp() });
            
            if (!isSelective) {
                const lastProcessedNote = notesToProcess[notesToProcess.length - 1];
                if (lastProcessedNote && lastProcessedNote.createdAt) {
                    const newRefinementState = {
                        lastProcessedNoteTimestamp: lastProcessedNote.createdAt,
                        lastRefinedAt: firebase.firestore.FieldValue.serverTimestamp(),
                        targetSessionId: sessionId
                    };
                    await noteProjectsCollectionRef.doc(projectId).set({ refinementState: newRefinementState }, { merge: true });
                    trace("Firestore", "refinement.saveState.success", { projectId });
                }
            } else {
                trace("Refinement", "job.complete.selective.skipStateUpdate", { projectId });
            }
        } catch(error) {
             console.error("Error during refinement finalization:", error);
             showModal(`데이터 정제 최종 단계 실패: ${error.message}`, () => {});
        } finally {
            hideProgressToast(toastId);
            activePromptId = originalPromptId;
            updateChatHeaderModelSelector();
        }
        return;
    }

    dispatchRefinementTask(activeRefinementJob.currentIndex);
}