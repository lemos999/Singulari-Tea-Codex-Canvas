/* --- Ailey & Bailey Canvas --- */
// File: 235_chat_drag_drop.js
// Version: 1.0 (Refactored from 230_chat_app.js)
// Description: Manages all drag-and-drop logic for sessions and projects in the sidebar.

let draggedSessionId = null;

function handleDragStart(e) {
    const sessionItem = e.target.closest('.session-item');
    if (sessionItem && !sessionItem.classList.contains('temporary')) {
        draggedSessionId = sessionItem.dataset.sessionId;
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', draggedSessionId);
        setTimeout(() => sessionItem.classList.add('is-dragging'), 0);
    }
}

function handleDragOver(e) {
    e.preventDefault();
    const dropTarget = e.target.closest('.session-item, .project-header');
    if (dropTarget) {
        const targetId = dropTarget.dataset.sessionId || dropTarget.closest('.project-container')?.dataset.projectId;
        if (targetId !== draggedSessionId) dropTarget.classList.add('drag-over');
    }
}

function handleDragLeave(e) {
    const dropTarget = e.target.closest('.session-item, .project-header');
    if (dropTarget) dropTarget.classList.remove('drag-over');
}

function handleDrop(e) {
    e.preventDefault();
    if (!draggedSessionId) return;
    const dropTarget = e.target.closest('.session-item, .project-header');
    document.querySelectorAll('.drag-over').forEach(el => el.classList.remove('drag-over'));
    if (dropTarget) {
        if (dropTarget.classList.contains('session-item')) {
            const targetSessionId = dropTarget.dataset.sessionId;
            if (draggedSessionId !== targetSessionId) createProjectFromSessions([draggedSessionId, targetSessionId]);
        } else if (dropTarget.classList.contains('project-header')) {
            const targetProjectId = dropTarget.closest('.project-container').dataset.projectId;
            moveSessionToProject(draggedSessionId, targetProjectId);
        }
    }
    const draggedElement = document.querySelector(`.session-item[data-session-id="${draggedSessionId}"]`);
    if (draggedElement) draggedElement.classList.remove('is-dragging');
    draggedSessionId = null;
}
