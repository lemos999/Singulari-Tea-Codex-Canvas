// src/04_features_chat/999_chat_esm_consumer.js
import { getFormattedDate } from '../02_utils/999_utils_esm_example.js';

console.log(`[ESM TEST SUCCESS] Today's date is: ${getFormattedDate()}`);
