---
title: CC Standard Mode Prompt Hardening Plan
slug: cc-standard-mode-prompt-hardening
created: 2026-04-13 02:19:00 +09:00
last_updated: 2026-04-13 02:28:32 +09:00
status: superseded
owner: Codex
requested_by: User
version: v01
---

# CC Standard Mode Prompt Hardening Plan

## Goal

Superseded. This plan originally targeted stronger authored visualization prompts inside placeholders. The active approved direction now requires direct visualization code for `.cc`, and that work is tracked in `plan/20260413-022832--work-plan--cc-direct-visualization-code-contract--v01.md`.

## Approved Scope

- Edit only `.cc`-specific prompt rules.
- Keep `.ccc` behavior unchanged.
- Keep the file at or below 52,000 characters after modification.
- Improve how `.cc` tells the model to author visualization prompts directly into the generated HTML.
- Prefer runtime-compatible prompt improvements over speculative unsupported markup.

## Backup

- Preflight backup: `backup_20260413-021541--cc-prompt-only-preflight.zip`

## Findings

- Current file length is `51,554`, so the available growth budget is small.
- The active `.cc` rules are concentrated in `[PATH A: STANDARD MODE (.cc)]`.
- The current visualization instruction is too weak: it only says to inject a generic placeholder with `data-prompt="..."`.
- Because runtime compatibility must be preserved, the safest upgrade is to make the prompt contract much more explicit while keeping the placeholder format stable.

## Plan

### Phase 0
- Keep scope locked to one file and one path: `.cc`.

### Phase 1
- Completed
- Tightened `.cc` visual injection rules so the model must:
  - write complete section-specific image prompts
  - write complete section-specific visualization prompts
  - avoid leaving generic `...` prompt shells
  - place visualization placeholders in conceptually dense sections only

### Phase 2
- Completed
- Added a direct-authoring rule so the generated HTML already contains authored visualization prompts at creation time instead of relying on vague later refinement.

### Phase 3
- Completed
- Compressed nearby `.cc` wording enough to keep the file under 52,000 characters.

### Phase 4
- Completed
- Verified final file length: `51,787`
- Verified the edited region stayed inside `[PATH A: STANDARD MODE (.cc)]`

## Success Criteria

- Only `.cc` instructions change.
- `.ccc` section remains untouched.
- The file stays at or below 52,000 characters.
- The `.cc` prompt now explicitly requires fully written visualization prompts inside placeholder markup.

## Scoreboard

- Current score: 48
- Score source: provisional
- Last updated: 2026-04-13 02:28:32 +09:00
- Score rationale: The original prompt-hardening task completed, but the user clarified that it solved the wrong layer. This plan is now superseded by a direct-code successor plan.
- What improved:
  - Scope narrowed to one file and one protocol path
  - Length constraint confirmed before editing
  - `.cc` now demands fully authored visualization prompts instead of vague placeholder shells
- What remains unsatisfactory:
  - The approved direction has changed, so this file is no longer the active delivery record
- What should happen next to raise or maintain the score:
  - Continue under the successor direct-code plan and replace placeholder instructions in `.cc`

## Score History

- 2026-04-13 02:19:00 +09:00 | score: 40 | source: provisional | rationale: approved one-file plan created, implementation pending
- 2026-04-13 02:19:00 +09:00 | score: 48 | source: provisional | rationale: `.cc`-only prompt hardening completed within the 52,000-character limit
- 2026-04-13 02:28:32 +09:00 | score: 48 | source: provisional | rationale: plan marked superseded because the approved direction changed from prompt authoring to direct visualization code
