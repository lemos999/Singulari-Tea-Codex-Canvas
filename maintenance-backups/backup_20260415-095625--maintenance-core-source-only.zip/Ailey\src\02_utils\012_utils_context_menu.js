/* --- Ailey & Bailey Canvas --- */
// File: 012_utils_context_menu.js
// Version: 2.4 (Viewport-Aware Submenu Positioning)
// Description: Keeps context menus and nested submenus inside the visible viewport so overflow actions remain clickable.

let currentOpenContextMenu = null;
const CONTEXT_MENU_MARGIN = 8;
const SUBMENU_GAP = 0;
const SUBMENU_CLOSE_DELAY_MS = 140;
const handleCloseEvents = () => removeContextMenu();

function clampContextMenuCoordinate(value, size, viewportSize) {
    return Math.max(CONTEXT_MENU_MARGIN, Math.min(value, viewportSize - size - CONTEXT_MENU_MARGIN));
}

function removeContextMenu() {
    if (currentOpenContextMenu) {
        document.removeEventListener('click', handleCloseEvents);
        document.removeEventListener('scroll', handleCloseEvents, true);
        currentOpenContextMenu.remove();
        currentOpenContextMenu = null;
    }
}

function positionSubmenu(parentButton, submenu) {
    if (!parentButton || !submenu) return;

    submenu.classList.remove('open-left', 'align-bottom');
    submenu.style.visibility = 'hidden';
    submenu.style.display = 'block';

    const parentRect = parentButton.getBoundingClientRect();
    const submenuRect = submenu.getBoundingClientRect();
    const shouldOpenLeft = parentRect.right + SUBMENU_GAP + submenuRect.width > window.innerWidth - CONTEXT_MENU_MARGIN;
    const shouldAlignBottom = parentRect.top + submenuRect.height > window.innerHeight - CONTEXT_MENU_MARGIN;

    if (shouldOpenLeft) {
        submenu.classList.add('open-left');
    }

    if (shouldAlignBottom) {
        submenu.classList.add('align-bottom');
    }

    submenu.style.maxHeight = `${Math.max(180, window.innerHeight - CONTEXT_MENU_MARGIN * 2)}px`;
    submenu.style.visibility = '';
    submenu.style.display = '';
}

function attachSubmenuBehavior(button, submenu) {
    let closeTimer = null;

    const clearCloseTimer = () => {
        if (!closeTimer) return;
        clearTimeout(closeTimer);
        closeTimer = null;
    };

    const openSubmenu = () => {
        clearCloseTimer();
        positionSubmenu(button, submenu);
        button.classList.add('submenu-visible');
    };

    const closeSubmenu = (event) => {
        if (event?.relatedTarget && button.contains(event.relatedTarget)) return;
        clearCloseTimer();
        closeTimer = setTimeout(() => {
            if (button.matches(':hover') || submenu.matches(':hover') || button.contains(document.activeElement)) {
                return;
            }
            button.classList.remove('submenu-visible');
        }, SUBMENU_CLOSE_DELAY_MS);
    };

    button.addEventListener('mouseenter', openSubmenu);
    submenu.addEventListener('mouseenter', openSubmenu);
    button.addEventListener('focusin', openSubmenu);
    button.addEventListener('mouseleave', closeSubmenu);
    submenu.addEventListener('mouseleave', closeSubmenu);
    button.addEventListener('focusout', closeSubmenu);
    submenu.addEventListener('focusin', openSubmenu);
    submenu.addEventListener('focusout', closeSubmenu);
}

function createContextMenu(items, event) {
    event.preventDefault();
    event.stopPropagation();
    removeContextMenu();

    const menu = document.createElement('div');
    menu.className = 'custom-context-menu';

    const createMenuItem = (item) => {
        if (item.separator) {
            const separator = document.createElement('div');
            separator.className = 'context-menu-separator';
            return separator;
        }

        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'context-menu-item';
        button.disabled = item.disabled || false;

        if (item.submenu) {
            button.classList.add('submenu-container');
            button.innerHTML = `<span>${item.label}</span><span class="submenu-arrow">&#9656;</span>`;

            const submenu = document.createElement('div');
            submenu.className = 'context-submenu';
            item.submenu.forEach((subItem) => submenu.appendChild(createMenuItem(subItem)));
            button.appendChild(submenu);
            attachSubmenuBehavior(button, submenu);
        } else {
            button.textContent = item.label;
            if (item.action) {
                button.addEventListener('click', (clickEvent) => {
                    clickEvent.stopPropagation();
                    item.action();
                    removeContextMenu();
                });
            }
        }

        return button;
    };

    items.forEach((item) => menu.appendChild(createMenuItem(item)));

    menu.style.visibility = 'hidden';

    highestZIndex++;
    menu.style.zIndex = highestZIndex;

    document.body.appendChild(menu);

    const menuWidth = menu.offsetWidth;
    const menuHeight = menu.offsetHeight;
    const left = clampContextMenuCoordinate(event.clientX, menuWidth, window.innerWidth);
    const top = clampContextMenuCoordinate(event.clientY, menuHeight, window.innerHeight);

    menu.style.left = `${left}px`;
    menu.style.top = `${top}px`;
    menu.style.visibility = 'visible';

    currentOpenContextMenu = menu;
    menu.addEventListener('click', (clickEvent) => clickEvent.stopPropagation());

    setTimeout(() => {
        document.addEventListener('click', handleCloseEvents, { once: true });
        document.addEventListener('scroll', handleCloseEvents, { once: true, capture: true });
    }, 0);
}
