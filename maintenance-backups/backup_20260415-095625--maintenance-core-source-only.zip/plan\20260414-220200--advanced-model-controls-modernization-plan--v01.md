# Advanced Model Controls Modernization Plan

- Timestamp: 2026-04-14 22:02 KST
- Scope: planning only, no behavior change in this document

## Why This Needs A Dedicated Pass

The current advanced model controls were layered over multiple generations of UI and provider support. They work, but the surface still carries legacy assumptions:

- temperature and top-p are exposed as raw sliders without clear provider-specific guidance
- grounding visibility is model-name driven and should become capability-driven
- thinking budget support is hardcoded to a small list of model ids
- history limit was previously raw message slicing, not a reliable context policy
- compact memory is now added, so the wording and grouping should reflect that new behavior

## Recommended Next Pass

1. Split controls into three groups:
   - Context: history window, auto compact, contextless behavior
   - Sampling: temperature, top-p, max output tokens
   - Retrieval / reasoning: grounding, thinking budget

2. Replace raw model-name checks with capability flags:
   - supportsGrounding
   - supportsThinkingBudget
   - supportsSamplingTuning

3. Improve wording and defaults:
   - explicitly show durable default values
   - explain when each control is ignored by the active provider/model
   - show a small “safe / balanced / experimental” band for sampling controls

4. Add guardrails:
   - validate range input before save
   - disable unsupported controls instead of silently hiding only some of them
   - persist per-preset control values with visible inheritance from universal defaults

5. Improve mobile layout:
   - shorter header copy
   - denser but readable cards
   - sticky save area
   - grouped toggles before long sliders

## Concrete Refactor Targets

- [Ailey/src/03_core/110_core_api_settings.js](/abs/path/c:/Users/Lemos/Desktop/새 폴더 (2)/Ailey/src/03_core/110_core_api_settings.js:1)
- [Ailey/src/03_core/111_core_api_settings_data.js](/abs/path/c:/Users/Lemos/Desktop/새 폴더 (2)/Ailey/src/03_core/111_core_api_settings_data.js:1)
- [Ailey/src/03_core/112_core_api_settings_ui_structure.js](/abs/path/c:/Users/Lemos/Desktop/새 폴더 (2)/Ailey/src/03_core/112_core_api_settings_ui_structure.js:1)
- [Ailey/src/03_core/114_core_api_settings_ui_refresh.js](/abs/path/c:/Users/Lemos/Desktop/새 폴더 (2)/Ailey/src/03_core/114_core_api_settings_ui_refresh.js:1)
- [Ailey/src/04_features_chat/213_chat_api_service.js](/abs/path/c:/Users/Lemos/Desktop/새 폴더 (2)/Ailey/src/04_features_chat/213_chat_api_service.js:1)

## Success Criteria

- control semantics match actual provider behavior
- unsupported features never appear active by mistake
- mobile advanced settings fit without oversized explanatory headers
- compact memory and raw history are explained together, not as separate legacy controls
