# Ailey Visualization Generation Stability Plan

- Artifact Type: feature-plan
- Created: 2026-04-12 14:54:25 +09:00
- Status: validated-complete
- Scope: stabilize visualization generation quality by enforcing single-item generation, redesigning the `Data Visualizer` system prompt, and adding runtime-side validation/hardening for generated visualization blocks
- Goal: make generated visualizations render reliably inside the provided container without blank canvases, API misuse, mis-sized scenes, or batch-order ambiguity
- Relationship to Prior Work: this plan is a follow-up to `20260412-095100--viz-rendering-fix-plan--ailey--v01.md`. The earlier plan stabilized the renderer and container behavior. This plan shifts focus upstream to generation quality, delivery structure, and prompt contract design.

## Scoreboard

- Current Score: 100
- Score Source: user
- Last Updated: 2026-04-12 15:56:33 +09:00
- Rationale: The renderer now scopes generated DOM lookup and style ownership to the active visualization block, which materially reduces blank-scene failures caused by cross-block DOM collisions. Remaining uncertainty is now mostly browser-side user regression testing across varied exported HTML files.
- What Improved: Visualization execution is now block-local by default, repeated generic IDs no longer misroute `document.getElementById(...)` lookups across sibling blocks, and scoped style ownership reduces replay and cross-block leakage.
- Validated Outcome: User validation is complete and authoritative. This plan is considered successful at `100/100`.
- Reopen Rule: Treat any future rendering issue as a new regression task unless it is clearly the same DOM-collision class already resolved here.
- Superseding Note: The active follow-up focus is now DOM collision recovery and multi-visualization export validation. Older pre-DOM-hardening risk notes below are retained as history, but the current manual validation target is `[공간의 재구성] 10가지 인터랙티브 시각화 실험실.html` plus similar multi-scene exports.
- What Remains Unsatisfactory: Some generated visualizations are blank due to invalid library API usage, the system still allows multi-item batch generation behavior that weakens mapping reliability, and scene-style outputs still need stronger “fit inside host box” guidance at generation time.
- Next Score Target: Ship single-item enforcement plus a stricter `Data Visualizer` output contract, then re-test the previously failing `알고리즘 시각화 실험실.html` cases.

### Immediate Progress Note

- Phase 0 completed locally: visualization generation is now operationally single-item.
- Phase 1 completed locally: the default `Data Visualizer` prompt was rewritten and bumped to version `24.0`.
- Verification completed locally: touched JavaScript files passed `node --check`, and `node bundler.js` completed successfully.
- Remaining from this plan: runtime validation/auto-repair, targeted regression tests, and hosted bundle deployment.
- Phase 2 is now complete locally: the renderer performs preflight repairs for known D3/p5 failure patterns and surfaces clearer diagnostics for dependency/runtime failures.
- Hosted bundle deployment is now complete: `Singulari-Tea-Codex-Canvas` `main` was updated to commit `6306977f7965e07b528af309abe3316a5899dfc6`.
- Remaining from this plan is now user-side manual validation against the previously failing exported HTML cases.
- DOM-scope repair follow-up is now complete locally: generated scripts execute against a block-local scoped `document`, `window.document` lookup patterns are auto-repaired, and per-block scoped style ownership reduces cross-block leakage during replay and re-render.
- The prompt contract has now been strengthened again to version `25.0`, explicitly banning global document lookup and generic repeated fragment IDs.
- Hosted bundle deployment was updated again for the DOM stability pass: `Singulari-Tea-Codex-Canvas` `main` is now at commit `acb1063b51e47faeadde608743854ed1a971c300`.
- Remaining from this plan is user-side manual validation focused on exported HTML pages where repeated IDs and global DOM lookup previously caused blank or misplaced scene canvases.
- User validation is now complete: the user awarded a `100` score after confirming the rendering behavior improved to the expected level.
- This plan should now be treated as a validated reference memo for future visualization stability work, not just an active work queue.

### Score History

- 2026-04-12 14:54:25 +09:00 | 35 | provisional | New upstream generation-stability plan opened after user testing showed that renderer containment alone is not enough.
- 2026-04-12 15:10:54 +09:00 | 42 | provisional | Phase 0 and Phase 1 completed locally: visualization generation is operationally single-item and the default prompt contract is now materially stricter.
- 2026-04-12 15:21:47 +09:00 | 48 | provisional | Phase 2 runtime hardening shipped, the bundle was rebuilt, and the hosted repository main branch was updated for user manual validation.
- 2026-04-12 15:41:36 +09:00 | 50 | provisional | DOM scope hardening shipped: generated scripts now resolve DOM nodes inside the active visualization block, scoped styles are re-owned per block, the prompt contract was tightened again, and the hosted bundle was redeployed.
- 2026-04-12 15:56:33 +09:00 | 100 | user | User validated the rendering result and explicitly awarded a perfect score after the DOM stability hardening pass.

---

## Working Understanding

The current problem is no longer mainly about the visualization host box. It is now about generation correctness and delivery reliability.

Observed examples from `알고리즘 시각화 실험실.html` show:

- D3 blocks can fail before first paint because the generated code mixes D3 selections and DOM APIs incorrectly.
- Some p5 blocks are structurally weak even when they do not hard-crash, because the generated code duplicates canvas ownership or produces poor first-frame feedback.
- Current batch visualization generation maps outputs back to placeholders by order only, which is fragile once more than one visualization is generated in a single model response.

This means we need to improve both:

- upstream generation constraints
- downstream validation and repair behavior

## Confirmed Findings

### 1. `batchGenerationSize: 1` already exists as the source-code default, but it is not truly enforced

Current state:

- `src/03_core/111_core_api_settings_data.js` defines `batchGenerationSize: 1`.
- `src/03_core/120_core_main_initializer.js` still honors whatever batch size is currently stored in user settings.
- `src/03_core/121_core_initializer_visualization.js` exposes a batch-size input in the visualization options modal and persists changed values.

Implication:

- The app defaults to `1`, but it does not guarantee single-item generation in practice.
- A previously saved setting above `1` can still reactivate the fragile batch path.

### 2. The current batch mapping is order-based, not identity-based

Current state:

- `handleBatchVisualizationGeneration(...)` sends multiple requests in one prompt.
- It asks the model to return multiple HTML code blocks in sequence.
- The runtime extracts them with a global regex and assigns them back to placeholders by position.

Implication:

- If the model omits one block, swaps order, or returns a malformed extra block, the mapping becomes unreliable.
- This risk grows as requested visualizations become more complex and heterogeneous.

### 3. The existing `Data Visualizer` prompt is too permissive for interactive-library correctness

Current state:

- `src/03_core/102_template_data_visualizer.js` includes basic sandbox rules.
- It bans full HTML, `window.onload`, and `window.innerWidth`.
- It does not give strong per-library usage patterns, a fit-to-container contract, or a mandatory self-check before final output.

Implication:

- The model can still produce visually plausible but runtime-invalid code.
- The prompt does not explicitly forbid API misuse patterns such as `d3.select(...).querySelector(...)`.
- The prompt does not force the model to guarantee that the first rendered frame already fits inside the host container.

### 4. Renderer-side validation currently catches too little

Current state:

- The renderer sanitizes some global DOM misuse and resizes after execution.
- External script failures are logged, but the loader resolves instead of failing hard.
- There is no preflight validation layer for known invalid generation patterns.

Implication:

- Invalid generated code often degrades into “blank surface + controls” rather than an actionable error or an automatic correction path.

### 5. DOM-global lookup and generic ID reuse can misroute scene renderers across sibling visualization blocks

Current state:

- Generated fragments frequently use generic IDs such as `three-canvas-holder`, `ui-overlay`, `container`, or `root`.
- Generated scripts often resolve those nodes with `document.getElementById(...)` or `document.querySelector(...)`.
- Exported live HTML can host many visualization fragments on the same page, so document-global lookup is not stable.

Implication:

- A later block can mount its canvas into an earlier block's holder even while its controls render in the correct section.
- This produces the observed “controls visible, scene blank here” failure mode for some Three.js blocks.
- Prompt-only guidance is not enough; the runtime must enforce block-local DOM lookup by default.

## Postmortem Memo

This section records why the previous visualization system rendered incorrectly and what changed to stabilize it.

### A. The old renderer assumed each generated visualization lived on an empty page

What was wrong:

- Generated fragments were injected directly into the shared page DOM.
- Many generated scripts used global patterns such as `document.getElementById(...)`, `document.querySelector(...)`, `window.document`, generic IDs, and global `<style>` selectors.
- That assumption is only safe when one widget owns the whole page. It is unsafe when many visualizations coexist in one exported HTML document.

Why it mis-rendered:

- Later blocks could accidentally select DOM nodes belonging to earlier blocks.
- A renderer could mount its canvas into the wrong holder while controls still appeared in the correct section.
- Global CSS could also style sibling visualizations unintentionally.

How it was solved:

- `013_utils_block_renderer.js` now creates a block-local scoped `document` proxy for generated code.
- DOM lookup now resolves inside the active `vizContainer` subtree by default.
- `window.document` and `globalThis.document` access patterns are downgraded to the scoped `document`.
- Generated `<style>` blocks are now scoped and tagged per visualization owner so replay and re-render no longer leak styles across siblings.

### B. The old system tolerated generic repeated IDs and selectors

What was wrong:

- Generated code frequently used IDs like `three-canvas-holder`, `ui-overlay`, `container`, and `root`.
- Those names were reused across multiple blocks in the same exported page.

Why it mis-rendered:

- HTML IDs must be unique at the document level.
- Once the same ID appeared multiple times, document-global lookup returned the first match, not the intended local node.
- This was a direct cause of the “black area here, actual canvas somewhere else” symptom.

How it was solved:

- Prompt contract `Data Visualizer` was tightened from `24.0` to `25.0`.
- The prompt now bans generic repeated fragment IDs and requires fragment-local selectors resolved from `vizContainer` or the fragment root.
- Runtime DOM scoping now protects the system even when a generated fragment still violates the ideal selector policy.

### C. The old prompt contract was too permissive for real runtime correctness

What was wrong:

- The original prompt mostly banned a few obvious globals, but it did not strongly specify:
  - library-safe DOM patterns
  - first-frame fit requirements
  - resize obligations
  - selector ownership rules
  - forbidden cross-API misuse patterns

Why it mis-rendered:

- The model could output code that looked plausible but was operationally invalid.
- Typical failures included:
  - `d3.select(...).querySelector(...)`
  - p5 duplicate canvas ownership
  - weak Three.js first-frame composition
  - DOM-global lookup inside multi-block pages

How it was solved:

- The prompt was rewritten as a contract instead of a suggestion.
- Library-specific safe patterns were added for D3, p5, Three.js, Chart.js, and similar libraries.
- The prompt now explicitly requires first-frame visibility inside the host box, resize behavior, fragment-local selectors, and single-fragment output.

### D. The old delivery path allowed fragile multi-item generation and order-only mapping

What was wrong:

- Visualization generation could still operate in batches larger than `1`.
- Returned code blocks were matched back to placeholders by order rather than strong identity.

Why it mis-rendered:

- If the model omitted, reordered, or malformed one visualization, the wrong HTML could be attached to the wrong placeholder.
- This made debugging much harder because a rendering failure could actually be a mapping failure.

How it was solved:

- Visualization generation was operationally clamped to `1` item at a time.
- Stored settings above `1` no longer reactivate the old fragile batch behavior.
- UI affordances suggesting larger visualization batches were disabled or neutralized.

### E. The old runtime did not fail loudly enough when generated code was invalid

What was wrong:

- External dependency failure handling was weak.
- Known invalid patterns were not intercepted early enough.
- Blank containers could remain on screen without a clear explanation.

Why it mis-rendered:

- Users saw “nothing renders” or “controls only” symptoms without a clear diagnostic.
- This made model-quality bugs look like random renderer instability.

How it was solved:

- Script loading now fails more explicitly.
- Preflight repair/validation now catches high-confidence patterns such as:
  - D3 selection/DOM mix-ups
  - p5 duplicate static canvas ownership
  - document-global lookup patterns
- When confidence is low, the renderer now prefers an actionable diagnostic state over silent blank output.

### F. The earlier rendering stack also had host-level CSS and layout collisions

What was wrong:

- Some earlier failures were not caused by the generated code alone.
- Host CSS used selectors that were too global, such as drawing-canvas styles affecting unrelated visualization containers.
- Initial scene layout could also run before the host box had settled to its real size.

Why it mis-rendered:

- Generated charts or scenes could inherit fullscreen or fixed styles that belonged to another subsystem.
- A scene could also render too early against a temporary size, causing clipping or nearly invisible first paint.

How it was solved:

- Drawing-canvas selectors were narrowed to drawing-specific wrappers instead of generic shared class names.
- Visualization sizing got additional layout-settle and resize passes.
- Scene-style blocks now benefit from stricter host-box sizing guidance in the prompt and the runtime.

### Net conclusion

The old system's biggest mistake was not one bug. It was a trust model problem.

- It trusted generated fragments to behave like well-scoped widgets even though they were being injected into one shared DOM.
- It trusted the model to produce stable selectors and runtime-safe code without enough contractual constraints.
- It trusted blank output to be self-explanatory instead of diagnostic.

The fix was therefore layered:

- stricter generation contract
- stricter delivery behavior
- stricter runtime scoping
- stricter failure surfacing
- narrower host CSS ownership

That layered approach is what finally moved the rendering behavior from fragile to user-validated.

## Hidden Constraints and Risks

- The app uses a direct-DOM injection model, not iframe sandboxing. Prompt instructions must therefore be explicit about DOM ownership and container scoping.
- Prompt templates are seeded into Firestore/local data through version-based sync. Prompt changes must bump the template version.
- Live exported HTML depends on the hosted bundle, so any generation/runtime fix that affects export behavior must still pass bundle and hosted deployment flow.
- We should preserve the ability to generate advanced interactive scenes, but not at the cost of frequent broken output. “Simpler but correct” is better than “ambitious but blank.”

## Files In Scope

| File | Responsibility |
|---|---|
| `src/03_core/111_core_api_settings_data.js` | default visualization settings and sanitization of stored settings |
| `src/03_core/120_core_main_initializer.js` | auto-generation batching behavior on load |
| `src/03_core/121_core_initializer_visualization.js` | visualization generation flow, modal UI, batch path, output mapping |
| `src/03_core/102_template_data_visualizer.js` | system prompt contract for visualization generation |
| `src/03_core/102_core_seeding.js` | version-based prompt template synchronization |
| `src/02_utils/013_utils_block_renderer.js` | runtime validation, common-pattern repair, and failure surfacing |
| `src/03_core/103_core_default_templates_assembler.js` | inclusion of the revised default template set |

## Design Direction

The smallest complete stabilization design is:

1. enforce single-item visualization generation operationally, not just by default
2. redesign the `Data Visualizer` prompt around explicit output contracts and per-library safe patterns
3. add lightweight runtime-side validation and correction for a small set of common bad patterns
4. surface actionable failures instead of silent blank canvases

This keeps the system flexible, but removes avoidable ambiguity at every layer.

## Prompt Redesign Principles

The revised `Data Visualizer` prompt should become a contract, not a loose description.

### Core Contract Additions

- Require exactly one visualization fragment per request.
- Require exactly one fenced `html` code block and no surrounding prose.
- Require one dedicated root wrapper inside `vizContainer`.
- Require all rendering to stay inside that wrapper and fit within `100% x 100%`.
- Require that the initial frame already shows the meaningful content without manual zoom or scroll.
- Require that any scene or canvas code respond to host resizing.

### Explicit Library-Safe Rules

For D3:

- Use either `const root = vizContainer.querySelector(...)` for DOM lookup, or `d3.select(root)` for D3 operations.
- Never call DOM methods on a D3 selection.
- Preferred pattern: `const root = vizContainer.querySelector('#x'); const svg = d3.select(root).append('svg');`

For p5:

- Use one dedicated holder element.
- If using `p.createCanvas(...)`, do not also rely on a pre-existing static `<canvas>` for the same drawing surface.
- Parent the renderer to the holder.
- Include resize handling via `window.addEventListener('resize', ...)` or `ResizeObserver`.

For Three.js:

- Append `renderer.domElement` to a dedicated holder.
- Size using holder dimensions, not global window size.
- Include `ResizeObserver` updates.
- Set camera and object scale so the full subject is legible on first paint.

For canvas/Chart/ECharts/Plotly:

- Use a dedicated holder/canvas.
- Keep controls visually separate from the chart drawing surface.
- Do not overflow outside the container.

### Mandatory Self-Check Before Final Output

The prompt should instruct the model to internally verify:

- no full HTML document tags
- no JSON wrapper
- no `window.onload`
- no `window.innerWidth` or `window.innerHeight`
- no `document.body` manipulation
- no DOM methods called on D3 selections
- no duplicate canvas ownership patterns for p5
- output fits the host box on first render

### Graceful Fallback Rule

If the requested interaction would likely be unstable in the current sandbox, the prompt should prefer:

- a simpler but correct 2D interactive visualization

instead of:

- a visually ambitious but fragile 3D or multi-library output

## Execution Plan

### Phase 0 - Single-Item Enforcement

Goal:

- make visualization generation effectively single-item by policy

Tasks:

- sanitize loaded `visualizationSettings.batchGenerationSize` so values above `1` are clamped back to `1`
- remove or disable UI affordances that suggest multi-item generation is supported
- make `handleSequentialGenerationOnLoad()` and manual generation paths treat visualization generation as one-at-a-time only
- keep image batching unchanged unless explicitly reopened later

Acceptance criteria:

- a saved value above `1` can no longer reactivate multi-item visualization generation
- the modal no longer encourages or persists multi-item visualization batch sizes

### Phase 1 - `Data Visualizer` Prompt Rewrite

Goal:

- improve first-pass generation correctness

Tasks:

- rewrite `TEMPLATE_DATA_VISUALIZER.promptText` as a stricter output contract
- add explicit per-library safe patterns and anti-pattern bans
- add container-fit and first-frame visibility rules
- add self-check rules
- bump template version so seeding updates persisted defaults reliably

Acceptance criteria:

- the prompt clearly prohibits the known D3 misuse pattern
- the prompt explicitly addresses p5 holder/canvas ownership
- the prompt explicitly addresses Three.js camera fit and resize behavior

### Phase 2 - Runtime Validation and Auto-Repair

Goal:

- catch and soften common model mistakes before or during execution

Tasks:

- add lightweight detection for known invalid patterns such as `d3.select(...).querySelector(...)`
- rewrite the most common safe-to-repair patterns automatically where confidence is high
- fail with a clear diagnostic block when confidence is low instead of silently showing a blank surface
- consider making external script load failures propagate more clearly to the user-facing error state

Acceptance criteria:

- the failing D3 blank cases produce either a successful repaired render or an explicit actionable error
- blank white/black containers without diagnostics become much rarer

### Phase 3 - Verification Matrix

Goal:

- prove the new generation contract actually improves outcomes

Verification set:

- `알고리즘 시각화 실험실.html`
- previously problematic exported astronomy HTML files
- one D3 graph case
- one D3 geometry case
- one p5 2D simulation case
- one Three.js scene case

Checks:

- first paint appears without blank surface
- content fits inside host box
- controls work
- replay/regenerate remains stable
- export/live mode still behaves consistently

### Phase 4 - Rebundle and Hosted Deployment

Goal:

- ship the stabilized generation/runtime path through the same hosted bundle workflow already used for live export

Tasks:

- run syntax checks
- run `node bundler.js`
- sync `bundle/` to the hosted bundle repository
- document deployment state and test results

## Non-Goals

- We are not redesigning the entire renderer architecture into iframe isolation in this plan.
- We are not trying to preserve multi-item visualization batching right now.
- We are not promising perfect auto-repair of arbitrary invalid generated code; only a small set of high-confidence fixes is in scope.

## First Recommended Slice

The first implementation slice should be:

1. Phase 0 single-item enforcement
2. Phase 1 prompt rewrite

Reason:

- This is the smallest upstream correction with the highest expected stability gain.
- It reduces ambiguity before we invest in renderer-side repair complexity.

## Success Definition

This plan is successful when all of the following are true:

- visualization generation behaves as single-item generation in practice
- the seeded `Data Visualizer` prompt is materially stricter and more deterministic
- common D3/p5/Three failure modes are reduced by contract before runtime
- exported live HTML renders meaningfully inside the host box without obvious clipping or blank first paint

## Current Status

- Planning completed
- Phase 0 completed locally
- Phase 1 completed locally
- Local syntax checks passed for touched JavaScript files
- Local `node bundler.js` run completed successfully
- Phase 2 runtime validation and auto-repair completed locally
- Hosted bundle deployment completed to `Singulari-Tea-Codex-Canvas` `main`
- Current hosted commit: `6306977f7965e07b528af309abe3316a5899dfc6`
- Manual browser validation by the user is now the next step for this plan
