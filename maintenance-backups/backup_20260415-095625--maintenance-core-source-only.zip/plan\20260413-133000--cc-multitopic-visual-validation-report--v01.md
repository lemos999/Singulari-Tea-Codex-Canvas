# Validation Report

Report Type: Validation Report
Scope: Universal `.cc` multi-topic rendered feel
Created: 2026-04-13 13:48:00 +09:00
Related Plan: `plan/20260413-133000--work-plan--cc-multitopic-visual-validation--v01.md`

Test Set

1. `대항해시대`
2. `블랙홀`
3. `TCP 3-way handshake`
4. `세포호흡`

Artifacts

Initial batch:

- [01-age-of-exploration.html](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000/01-age-of-exploration.html>)
- [02-black-hole.html](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000/02-black-hole.html>)
- [03-tcp-three-way-handshake.html](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000/03-tcp-three-way-handshake.html>)
- [04-cellular-respiration.html](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000/04-cellular-respiration.html>)

Initial screenshots:

- [01-age-of-exploration.png](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000/screens/01-age-of-exploration.png>)
- [02-black-hole.png](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000/screens/02-black-hole.png>)
- [03-tcp-three-way-handshake.png](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000/screens/03-tcp-three-way-handshake.png>)
- [04-cellular-respiration.png](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000/screens/04-cellular-respiration.png>)

Rerun batch:

- [01-age-of-exploration.html](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000-rerun/01-age-of-exploration.html>)
- [02-black-hole.html](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000-rerun/02-black-hole.html>)
- [03-tcp-three-way-handshake.html](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000-rerun/03-tcp-three-way-handshake.html>)
- [04-cellular-respiration.html](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000-rerun/04-cellular-respiration.html>)

Rerun screenshots:

- [01-age-of-exploration.png](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000-rerun/screens/01-age-of-exploration.png>)
- [02-black-hole.png](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000-rerun/screens/02-black-hole.png>)
- [03-tcp-three-way-handshake.png](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000-rerun/screens/03-tcp-three-way-handshake.png>)
- [04-cellular-respiration.png](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000-rerun/screens/04-cellular-respiration.png>)

Targeted process rerun:

- [03-tcp-three-way-handshake.html](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000-rerun2/03-tcp-three-way-handshake.html>)
- [04-cellular-respiration.html](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000-rerun2/04-cellular-respiration.html>)
- [03-tcp-three-way-handshake.png](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000-rerun2/screens/03-tcp-three-way-handshake.png>)
- [04-cellular-respiration.png](</c:/Users/Lemos/Desktop/새 폴더 (2)/visual-tests/20260413-133000-rerun2/screens/04-cellular-respiration.png>)

What Broke First

1. No visible `<h1>` anchor across the initial batch.
2. Pages felt like floating text blocks instead of confident subject renders.
3. Process-topic placeholders sometimes surfaced local settings overlays, visually hijacking the page.
4. Strong emphasis and structure in the initial batch still leaned too much toward generic explainer behavior.

What Changed

1. The module now allows one honest `<h1>` for named-topic minimal-host queries.
2. The module now explicitly prefers sparse `<strong>` usage in short direct answers.
3. Placeholder ambition is now tied more tightly to answer size.
4. For minimal-host process topics, placeholder use is now more conservative when runtime readiness is unknown.

Final Assessment

Rendered feel improved materially after the refinements. The h1 anchor made a visible difference immediately. For spatial and iconic topics, one placeholder remained acceptable. For process-heavy topics, removing the placeholder produced cleaner and more dependable screens in this local runtime.

Topic Scores

1. `대항해시대`: `95`
2. `블랙홀`: `93`
3. `TCP 3-way handshake`: `96`
4. `세포호흡`: `96`

Average

- Final self-audited visual average: `95.0`

Remaining Caveat

The local runtime still did not fully prove the image-placeholder path visually because the image surface remained in a loading state in this environment. The call shape is valid, but the visual confirmation is weaker than the text and heading checks.
