/* --- Ailey & Bailey Canvas --- */
// File: 215_chat_orchestrator.js
// Version: 10.2 (AI Fix Revert)
// Description: Implemented UI restoration for failed AI code fixes. If applying the AI's suggested code fails, the block now reverts to its original error state instead of getting stuck on a loading indicator.

async function _handleAiResponse(aiMessage, userMessage, sessionId, isTemporary) {
    // [MODIFIED] Intercept and handle code fix responses with a robust replacement strategy
    if (activeCodeFixJob && activeCodeFixJob.targetElementId) {
        trace("Orchestrator", "CodeFix.responseReceived", { target: activeCodeFixJob.targetElementId });
        const targetElement = document.getElementById(activeCodeFixJob.targetElementId);

        if (targetElement) {
            try {
                const extraction = typeof window.chooseBestVisualizationHtmlCandidate === 'function'
                    ? window.chooseBestVisualizationHtmlCandidate(aiMessage.content)
                    : null;
                const newHtmlContent = extraction?.htmlContent || '';
                if (!newHtmlContent) {
                    throw new Error("AI 응답에서 적용 가능한 시각화 HTML을 찾지 못했습니다.");
                }

                // Create a fresh visualization block data object. This works for both
                // fixing an existing visualization and generating one for a placeholder.
                const newBlockData = {
                    type: 'visualization',
                    htmlContent: newHtmlContent,
                };
                
                // [NEW STRATEGY] Create a brand new element using the canonical renderBlock function.
                if (typeof renderBlock === 'function') {
                    const newBlockElement = renderBlock(newBlockData);
                    if (newBlockElement) {
                        // Replace the old error-state element with the new, clean one.
                        targetElement.replaceWith(newBlockElement);
                        showToastNotification("✅ AI가 수정한 코드를 적용했습니다.", "", `code-fix-success-${Date.now()}`);

                        const systemSessionId = await findOrCreateSystemSession('[System] Visualization Engine');
                        if (systemSessionId && typeof clearSessionMessages === 'function') {
                            await clearSessionMessages(systemSessionId);
                        }
                    } else {
                        throw new Error("renderBlock did not return a valid element.");
                    }
                } else {
                     throw new Error("renderBlock function is not available.");
                }

            } catch (error) {
                console.error("Failed to apply AI code fix:", error);
                showModal(`AI 코드 적용 실패: ${error.message}`, () => {});
                if (targetElement && activeCodeFixJob.originalHTML && activeCodeFixJob.originalClassName) {
                    targetElement.className = activeCodeFixJob.originalClassName;
                    targetElement.innerHTML = activeCodeFixJob.originalHTML;
                }
            } finally {
                // Clear the job state regardless of success or failure
                activeCodeFixJob = null;
                trace("Orchestrator", "CodeFix.jobCleared");
            }
        } else {
            console.warn("Could not find target element for code fix:", activeCodeFixJob.targetElementId);
            activeCodeFixJob = null; // Clear stale job
        }
        return; // Stop further processing as this was a code-fix response.
    }


    const fullResponse = aiMessage.content;
    const fromQuickQuery = false; // This handler is not for quick query's temporary responses.

    if (isInteractiveRecallMode && isNarrativeArchiveFormat(fullResponse)) {
        trace("Orchestrator", "_handleAiResponse.isNarrative", { sessionId: sessionId.substring(0,5) });
        
        const turnMatch = fullResponse.match(/## \[\s?턴\s?(\d+)\s?\]/);
        const turnNumber = turnMatch ? parseInt(turnMatch[1], 10) : ++interactiveModeTurnCounter;
        
        const session = isTemporary ? { title: '임시 채팅' } : localChatSessionsCache.find(s => s.id === sessionId);
        const theme = session?.title || "Interactive Recall";
        
        const turnInfo = { theme, turn: turnNumber, snapshot: { userChoice: userMessage.content } };
        
        renderMarkdownAsScene(fullResponse, turnInfo);
        archiveMarkdownSnapshot(theme, turnNumber, fullResponse);

        const systemMessageContent = `[장면이 재구성되었습니다. (턴 ${turnNumber})]`;
        const systemMessage = { ...aiMessage, content: systemMessageContent };
        
        if (!isTemporary) {
            const batch = db.batch();
            const sessionDocRef = chatSessionsCollectionRef.doc(sessionId);
            const messageDocRef = sessionDocRef.collection("messages").doc();
            batch.set(messageDocRef, systemMessage);
            batch.update(sessionDocRef, { updatedAt: firebase.firestore.FieldValue.serverTimestamp() });
            await batch.commit();
        } else {
             temporarySession.messages.push({ ...systemMessage, timestamp: new Date() });
             renderFinalMessage({ ...systemMessage, timestamp: new Date() }, sessionId);
        }
        
    } else {
        trace("Orchestrator", "_handleAiResponse.isNormalChat", { sessionId: sessionId.substring(0,5) });
        // Normal AI response, save/render as usual.
        if (!isTemporary) {
            const batch = db.batch();
            const sessionDocRef = chatSessionsCollectionRef.doc(sessionId);
            const messageDocRef = sessionDocRef.collection("messages").doc();
            batch.set(messageDocRef, aiMessage);
            batch.update(sessionDocRef, { updatedAt: firebase.firestore.FieldValue.serverTimestamp() });
            await batch.commit();

            if (currentSessionId !== sessionId) {
                completedButUnseenResponses.add(sessionId);
                renderSidebarContent();
                const sessionData = localChatSessionsCache.find(s => s.id === sessionId);
                showToastNotification("새로운 답변이 도착했습니다.", sessionData?.title || "이전 대화", sessionId);
            }
            if (fromQuickQuery) {
                const sessionForToast = localChatSessionsCache.find(s => s.id === sessionId);
                const titleForToast = sessionForToast ? sessionForToast.title : "새 대화";
                showToastNotification("✅ 질문이 전송되었습니다.", `'${titleForToast}'에 저장됨`, sessionId);
            }

        } else {
             temporarySession.messages.push({ ...aiMessage, timestamp: new Date() });
             if (currentSessionId === 'temporary-chat') {
                renderFinalMessage({ ...aiMessage, timestamp: new Date() }, 'temporary-chat');
            } else if (fromQuickQuery) {
                showToastNotification("임시 답변 도착!", aiMessage.content.substring(0, 50) + "...", `temp-response-${Date.now()}`);
            }
        }
    }
}


function removeChatLoadingIndicators(sessionId) {
    if (!chatMessages || !sessionId) return;
    chatMessages.querySelector(`.ai-response-container[data-message-id="${sessionId}"]`)?.remove();
    chatMessages.querySelector(`.ai-response-container[data-streaming-session-id="${sessionId}"]`)?.remove();
}

function isAiResponseComplete(provider, responseMeta) {
    if (provider === 'google_paid' && typeof window._isGoogleResponseComplete === 'function') {
        return window._isGoogleResponseComplete(responseMeta);
    }
    return true;
}

function describeAiCompletionIssue(provider, responseMeta, responseText = '') {
    if (provider === 'google_paid' && typeof window._describeGoogleResponseIssue === 'function') {
        return window._describeGoogleResponseIssue(responseMeta, responseText);
    }
    return '';
}

function buildGoogleModelCandidates(primaryModel, responseHandlingOptions = null) {
    const fallbackModels = Array.isArray(responseHandlingOptions?.fallbackModels)
        ? responseHandlingOptions.fallbackModels
        : [];
    const candidates = [primaryModel, ...fallbackModels]
        .map((item) => String(item || '').trim())
        .filter(Boolean);
    return [...new Set(candidates)];
}

function shouldFallbackGoogleModel(error) {
    const message = String(error?.message || error || '').toLowerCase();
    if (!message) return false;
    return (
        message.includes('429')
        || message.includes('quota')
        || message.includes('rate limit')
        || message.includes('retry in')
        || message.includes('503')
        || message.includes('unavailable')
        || message.includes('overloaded')
        || message.includes('timeout')
        || message.includes('timed out')
        || message.includes('failed to fetch')
        || message.includes('networkerror')
    );
}

function resolveActiveChatRuntimeConfig() {
    const activePreset = userApiSettings.apiPresets.find((preset) => preset.id === userApiSettings.activePresetId);

    if (activePreset) {
        return {
            activePreset,
            provider: activePreset.provider,
            model: activePreset.selectedModel,
            key: activePreset.key,
            maxTokens: activePreset.maxOutputTokens,
            temperature: activePreset.temperature,
            topP: activePreset.topP,
            useGrounding: activePreset.useGrounding,
            thinkingBudget: activePreset.thinkingBudget,
            chatHistoryLimit: getEffectiveChatHistoryLimit(activePreset),
            autoCompactEnabled: getEffectiveAutoCompactEnabled(activePreset)
        };
    }

    const universalSettings = userApiSettings.universalModelSettings || {};
    return {
        activePreset: null,
        provider: 'universal',
        model: localStorage.getItem('selectedAiModel') || defaultModel,
        key: '',
        maxTokens: universalSettings.maxOutputTokens || 65536,
        temperature: universalSettings.temperature ?? 1,
        topP: universalSettings.topP ?? 0.95,
        useGrounding: universalSettings.useGrounding || false,
        thinkingBudget: null,
        chatHistoryLimit: getEffectiveChatHistoryLimit(null),
        autoCompactEnabled: getEffectiveAutoCompactEnabled(null)
    };
}


async function sendQueryToAI(userMessage, history, sessionId, isTemporary = false, fromQuickQuery = false, hiddenContext = null, systemInstructionOverride = null, responseHandlingOptions = null) {
    const inputToManage = fromQuickQuery ? quickQueryInput : chatInput;
    const buttonToManage = fromQuickQuery ? quickQuerySendBtn : chatSendBtn;
    const effectiveResponseHandling = responseHandlingOptions || {};

    if (inputToManage) inputToManage.disabled = true;
    if (buttonToManage) buttonToManage.disabled = true;
    if (!fromQuickQuery && chatInput) chatInput.placeholder = "생각중...";

    if (!isTemporary) {
        pendingResponses.add(sessionId);
        renderSidebarContent();
    }

    if (currentSessionId === sessionId) {
        renderNewMessages([{ role: 'ai', status: 'loading', id: sessionId }]);
    }

    const startTime = performance.now();
    try {
        const runtimeConfig = resolveActiveChatRuntimeConfig();
        const activePreset = runtimeConfig.activePreset;
        
        let systemInstruction = "You are Ailey. ...";
        if (systemInstructionOverride) {
            systemInstruction = systemInstructionOverride;
        } else if (activePromptId) {
            const template = promptTemplatesCache.find(t => t.id === activePromptId);
            if (template && template.promptText) systemInstruction = template.promptText;
        }
        
        let historyForPayload = stripTrailingCurrentUserMessage(history, userMessage);
        let mergedHiddenContext = hiddenContext;
        let compactionInfo = null;
        if (isContextlessMode) {
            if (historyForPayload && historyForPayload.length > 0) {
                historyForPayload = historyForPayload.slice(-1);
            }
            trace("API.Request", "ContextlessMode.active", { history_length: historyForPayload.length });
        } else {
            const compactedContext = await prepareHistoryForAutoCompact({
                sessionId,
                isTemporary,
                userMessage,
                baseHistory: historyForPayload,
                historyLimit: runtimeConfig.chatHistoryLimit,
                autoCompactEnabled: runtimeConfig.autoCompactEnabled,
                runtimeConfig
            });

            historyForPayload = compactedContext.historyForPayload;
            mergedHiddenContext = mergeCompactionMemoryIntoHiddenContext(hiddenContext, compactedContext.compactMemoryText);

            if (compactedContext.didCompact) {
                compactionInfo = {
                    compactedMessageCount: compactedContext.compactedMessageCount || 0,
                    compactedChunkCount: compactedContext.compactedChunkCount || 0,
                    threshold: compactedContext.threshold || runtimeConfig.chatHistoryLimit || 20,
                    compactedAt: Date.now()
                };

                if (typeof showToastNotification === 'function') {
                    const compactedCount = Number(compactionInfo.compactedMessageCount) || 0;
                    const compactedCopy = compactedCount > 0
                        ? `이전 대화 ${compactedCount}개를 메모리로 정리했습니다.`
                        : '이전 대화를 메모리로 정리했습니다.';
                    showToastNotification('대화 메모리를 압축했습니다.', compactedCopy, `chat-compact-${sessionId || 'temporary-chat'}-${compactionInfo.compactedAt}`);
                }
            }
        }

        // [CRITICAL FIX] Combine history with the current user message to form the complete payload.
        const finalHistoryForPayload = [...historyForPayload, userMessage];
        const payload = buildChatPayload(systemInstruction, finalHistoryForPayload, mergedHiddenContext, userMessage.attachment);

        let { provider, model, key, maxTokens, temperature, topP, useGrounding, thinkingBudget } = runtimeConfig;

        trace("API.Request", "sendQueryToAI.Pre-flight", { provider, model: model, thinkingBudget: thinkingBudget !== null ? thinkingBudget : 'auto', history: history.length, attachment: !!userMessage.attachment, context: !!hiddenContext, temp: isTemporary }, { sessionId: sessionId });

        if (provider === 'google_paid') {
            const generationConfig = {
                maxOutputTokens: Number(maxTokens) || 65536,
                temperature: temperature ?? 1,
                topP: topP ?? 0.95,
            };

            const config = {};

            if (useGrounding) {
                config.tools = [{googleSearch: {}}];
                trace("API.Request", "GroundingEnabled");
            }
            
            if (thinkingBudget !== null && thinkingBudget >= 0) {
                config.thinkingConfig = { thinkingBudget: thinkingBudget };
                trace("API.Request", "ThinkingBudgetEnabled", { budget: thinkingBudget });
            }

            if (Number.isFinite(Number(effectiveResponseHandling.apiRetryLimit))) {
                config._retryLimit = Math.max(0, Number(effectiveResponseHandling.apiRetryLimit));
            }

            const googleModelCandidates = buildGoogleModelCandidates(model, effectiveResponseHandling);
            let lastGoogleError = null;

            for (let candidateIndex = 0; candidateIndex < googleModelCandidates.length; candidateIndex += 1) {
                const activeModel = googleModelCandidates[candidateIndex];
                const hasMoreCandidates = candidateIndex < googleModelCandidates.length - 1;

                try {
                    const stream = await _fetchStreamFromApi(key, activeModel, payload, generationConfig, config);

            let aiMessageElement = null;
            let fullResponse = '';
            let groundingMetadata = null;
            let usageData = null;
            let responseMeta = null;
            
            const loadingElement = document.querySelector(`.ai-response-container[data-message-id="${sessionId}"]`);

            const debouncedRender = debounce((element, text) => {
                if (!element) return;
                const shouldFollow = typeof shouldAutoFollowChat === 'function'
                    ? shouldAutoFollowChat()
                    : true;
                renderStaticMarkdown(element, text);
                if (shouldFollow) {
                    autoScrollChat(true);
                }
            }, 150);
            
            let firstChunkReceived = false;
            for await (const chunk of stream) {
                if (chunk.candidates?.[0]?.groundingMetadata) {
                    groundingMetadata = chunk.candidates[0].groundingMetadata;
                }
                if (chunk.responseMeta) {
                    responseMeta = chunk.responseMeta;
                }
                
                if (chunk.usageMetadata) {
                    usageData = {
                        prompt: chunk.usageMetadata.promptTokenCount,
                        completion: chunk.usageMetadata.candidatesTokenCount
                    };
                }

                const chunkText = chunk.text;
                if (chunkText) {
                    if (!firstChunkReceived) {
                        firstChunkReceived = true;
                        // Do not render if it's an interactive recall turn; the handler will do it.
                        if (!isInteractiveRecallMode || !isNarrativeArchiveFormat(chunkText)) {
                            if (loadingElement) loadingElement.remove();
                            const tempContainer = createAiMessageContainer({ role: 'ai', content: '' }, -1, false);
                            tempContainer.dataset.streamingSessionId = sessionId; // Add identifier
                            if(chatMessages) chatMessages.appendChild(tempContainer);
                            aiMessageElement = tempContainer.querySelector('.chat-message.ai');
                        }
                    }
                    fullResponse += chunkText;
                    if (aiMessageElement) {
                        const span = document.createElement('span');
                        span.className = 'stream-chunk';
                        const processedChunk = renderKatexInString(chunkText);
                        span.innerHTML = marked.parseInline(processedChunk, { gfm: true, breaks: true, sanitize: false });
                        aiMessageElement.appendChild(span);

                        autoScrollChat();

                        debouncedRender(aiMessageElement, fullResponse);
                    }
                }
            }
            
            if (aiMessageElement) {
                const shouldFollow = typeof shouldAutoFollowChat === 'function'
                    ? shouldAutoFollowChat()
                    : true;
                renderStaticMarkdown(aiMessageElement, fullResponse);
                if (shouldFollow) {
                    autoScrollChat(true);
                }
            }

            const responseIsComplete = isAiResponseComplete(provider, responseMeta);
            const responseIssue = describeAiCompletionIssue(provider, responseMeta, fullResponse);

            if (effectiveResponseHandling.requireCompleteResponse && !responseIsComplete) {
                throw new Error(responseIssue || 'AI 응답이 완전하게 종료되지 않았습니다.');
            }
            
            if (activePreset) {
                const usage = activePreset.tokenUsage;
                const currentDateInPST = new Date().toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' });

                if (usage.lastRequestDate && usage.lastRequestDate !== currentDateInPST) {
                    trace("API.Usage", "Rollover.start", { lastDate: usage.lastRequestDate, newDate: currentDateInPST });
                    usage.totalRequests = (usage.totalRequests || 0) + (usage.todayRequests || 0);
                    usage.prompt = (usage.prompt || 0) + (usage.todayPromptTokens || 0);
                    usage.completion = (usage.completion || 0) + (usage.todayCompletionTokens || 0);

                    usage.todayRequests = 0;
                    usage.todayPromptTokens = 0;
                    usage.todayCompletionTokens = 0;
                    usage.dailyModelUsage = {};
                }

                usage.lastRequestDate = currentDateInPST;
                usage.todayRequests = (usage.todayRequests || 0) + 1;
                usage.dailyModelUsage[activeModel] = (usage.dailyModelUsage[activeModel] || 0) + 1;
                
                if (usageData) {
                    trace("API.Usage", "StreamUsageData.found", { ...usageData, model: activeModel });
                    usage.todayPromptTokens = (usage.todayPromptTokens || 0) + (usageData.prompt || 0);
                    usage.todayCompletionTokens = (usage.todayCompletionTokens || 0) + (usageData.completion || 0);
                } else {
                     trace("API.Usage", "StreamUsageData.notFound", { model: activeModel }, {}, "WARN");
                }
                
                saveUserSettingsToFirebase(true);
            }

            const endTime = performance.now();
            const duration = ((endTime - startTime) / 1000).toFixed(2);
            const aiMessage = { 
                role: 'ai', 
                content: fullResponse, 
                timestamp: firebase.firestore.FieldValue.serverTimestamp(), 
                duration: duration,
                model: activeModel,
                thinkingBudget: thinkingBudget,
                provider: provider,
                responseMeta: responseMeta,
                compactionInfo: compactionInfo,
                responseIssue: responseIsComplete ? null : (responseIssue || 'AI 응답이 완전하게 끝나지 않았습니다.')
            };
            
            if (groundingMetadata) {
                aiMessage.groundingMetadata = groundingMetadata;
                trace("API.Response", "GroundingMetadataReceived", { chunks: groundingMetadata.groundingChunks?.length || 0, model: activeModel });
            }
            
            await _handleAiResponse(aiMessage, userMessage, sessionId, isTemporary);
            if (effectiveResponseHandling.returnDetails) {
                return {
                    content: fullResponse,
                    responseMeta,
                    responseIssue: aiMessage.responseIssue,
                    isComplete: responseIsComplete,
                    model: activeModel
                };
            }
                    return fullResponse;
                } catch (googleError) {
                    lastGoogleError = googleError;
                    removeChatLoadingIndicators(sessionId);
                    const canFallback = hasMoreCandidates && shouldFallbackGoogleModel(googleError);

                    trace(
                        "API.Request",
                        canFallback ? "GoogleModelFallback" : "GoogleModelAttemptFailed",
                        {
                            provider,
                            attemptedModel: activeModel,
                            fallbackModel: canFallback ? googleModelCandidates[candidateIndex + 1] : null,
                            error: googleError.message
                        },
                        { sessionId: sessionId },
                        canFallback ? "WARN" : "ERROR"
                    );

                    if (canFallback) {
                        continue;
                    }

                    throw googleError;
                }
            }

            throw lastGoogleError || new Error('Google 모델 응답을 가져오지 못했습니다.');

        } else {
            // --- Non-Streaming Logic Path ---
            const { content: aiRes, usage: usageData, responseMeta = null } = await _fetchFromApi(provider, model, key, payload, maxTokens, temperature, topP, useGrounding, thinkingBudget);
            const responseIsComplete = isAiResponseComplete(provider, responseMeta);
            const responseIssue = describeAiCompletionIssue(provider, responseMeta, aiRes);

            if (effectiveResponseHandling.requireCompleteResponse && !responseIsComplete) {
                throw new Error(responseIssue || 'AI 응답이 완전하게 종료되지 않았습니다.');
            }
            
            if (activePreset && provider !== 'google_paid' && provider !== 'universal') {
                const usage = activePreset.tokenUsage;
                const currentDateInPST = new Date().toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' });

                if (usage.lastRequestDate && usage.lastRequestDate !== currentDateInPST) {
                    trace("API.Usage", "Rollover.start", { lastDate: usage.lastRequestDate, newDate: currentDateInPST });
                    usage.totalRequests = (usage.totalRequests || 0) + (usage.todayRequests || 0);
                    usage.prompt = (usage.prompt || 0) + (usage.todayPromptTokens || 0);
                    usage.completion = (usage.completion || 0) + (usage.todayCompletionTokens || 0);

                    usage.todayRequests = 0;
                    usage.todayPromptTokens = 0;
                    usage.todayCompletionTokens = 0;
                    usage.dailyModelUsage = {};
                }

                usage.lastRequestDate = currentDateInPST;
                usage.todayRequests = (usage.todayRequests || 0) + 1;
                usage.dailyModelUsage[model] = (usage.dailyModelUsage[model] || 0) + 1;
                
                if (usageData) {
                    usage.todayPromptTokens = (usage.todayPromptTokens || 0) + (usageData.prompt || 0);
                    usage.todayCompletionTokens = (usage.todayCompletionTokens || 0) + (usageData.completion || 0);
                }
                
                saveUserSettingsToFirebase(true);
            }
            
            const endTime = performance.now();
            const duration = ((endTime - startTime) / 1000).toFixed(2);
            const aiMessage = { 
                role: 'ai', 
                content: aiRes, 
                timestamp: firebase.firestore.FieldValue.serverTimestamp(), 
                duration: duration,
                model: model,
                thinkingBudget: thinkingBudget,
                provider: provider,
                responseMeta: responseMeta,
                compactionInfo: compactionInfo,
                responseIssue: responseIsComplete ? null : (responseIssue || 'AI 응답이 완전하게 끝나지 않았습니다.')
            };

            if (!isTemporary) {
                activeStreams[sessionId] = { startTime: Date.now(), content: aiMessage.content, duration: aiMessage.duration, isComplete: false, isRendering: false };
            }
            
            await _handleAiResponse(aiMessage, userMessage, sessionId, isTemporary);
            if (effectiveResponseHandling.returnDetails) {
                return {
                    content: aiRes,
                    responseMeta,
                    responseIssue: aiMessage.responseIssue,
                    isComplete: responseIsComplete
                };
            }
            return aiRes;
        }
    } catch (e) {
        console.error("Chat send error:", e);
        trace("API.Request", "sendQueryToAI.Error", { error: e.message }, { sessionId: sessionId }, "ERROR");
        removeChatLoadingIndicators(sessionId);
        const errorMessage = { role: 'ai', content: 'API 오류가 발생했습니다: ' + e.message, timestamp: new Date() };
        if (isTemporary) {
            temporarySession.messages.push(errorMessage);
            if (currentSessionId === 'temporary-chat') {
                 renderFinalMessage(errorMessage, 'temporary-chat');
            } else if (fromQuickQuery) {
                 showToastNotification("❌ 임시 질문 실패", e.message, `temp-error-${Date.now()}`);
            }
        } else if (chatSessionsCollectionRef && sessionId) {
           const errorForDb = { ...errorMessage, timestamp: firebase.firestore.FieldValue.serverTimestamp() };
           await chatSessionsCollectionRef.doc(sessionId).collection("messages").add(errorForDb);
        }
        throw e;
    } finally {
        if (inputToManage) {
            inputToManage.disabled = false;
            if (document.hasFocus()) {
                inputToManage.focus();
            }
        }
        if (buttonToManage) buttonToManage.disabled = false;
        if (!fromQuickQuery && chatInput) chatInput.placeholder = "Ailey & Bailey에게 질문하기...";

        if (!isTemporary) {
            pendingResponses.delete(sessionId);
            renderSidebarContent();
        }
    }
}

async function programmaticChatSend(sessionId, content, systemInstructionOverride = null, ignoreHistory = false) {
    const result = await programmaticChatSendDetailed(sessionId, content, systemInstructionOverride, ignoreHistory);
    return result.content;
}

async function programmaticChatSendDetailed(sessionId, content, systemInstructionOverride = null, ignoreHistory = false, responseHandlingOptions = null) {
    trace("API.Programmatic", "Request.start", { sessionId: sessionId.substring(0,5), contentLength: content.length, ignoreHistory });
    
    try {
        const userMessage = {
            role: 'user',
            content: content,
            timestamp: firebase.firestore.FieldValue.serverTimestamp()
        };

        await chatSessionsCollectionRef.doc(sessionId).collection("messages").add(userMessage);
        
        let historyForContext = [];
        if (!ignoreHistory) {
            const activePreset = userApiSettings.apiPresets.find(p => p.id === userApiSettings.activePresetId);
            let historyLimit = 20;
            if (activePreset) {
                historyLimit = activePreset.chatHistoryLimit ?? 20;
            } else {
                historyLimit = userApiSettings.universalModelSettings?.chatHistoryLimit ?? 20;
            }
            historyLimit = normalizeChatHistoryLimitValue(historyLimit, 20);
            historyForContext = historyLimit > 0
                ? (await fetchPastMessages(sessionId, null, historyLimit)).reverse()
                : [];

            const lastHistoryMessage = historyForContext[historyForContext.length - 1];
            if (
                lastHistoryMessage &&
                lastHistoryMessage.role === 'user' &&
                lastHistoryMessage.content === content
            ) {
                historyForContext = historyForContext.slice(0, -1);
                trace("API.Programmatic", "History.dedupedCurrentUserMessage", {
                    sessionId: sessionId.substring(0, 5),
                    historyLength: historyForContext.length
                });
            }
        }
        
        const aiResponse = await sendQueryToAI(userMessage, historyForContext, sessionId, false, false, null, systemInstructionOverride, responseHandlingOptions);
        const normalizedResponse = typeof aiResponse === 'string'
            ? { content: aiResponse, responseMeta: null, responseIssue: '', isComplete: true }
            : aiResponse;
        
        trace("API.Programmatic", "Request.success", {
            responseLength: normalizedResponse.content?.length || 0,
            finishReason: normalizedResponse.responseMeta?.finishReason || 'STOP',
            isComplete: normalizedResponse.isComplete !== false
        });
        return normalizedResponse;

    } catch (e) {
        console.error("Programmatic chat flow failed:", e.message);
        throw e;
    }
}

window.programmaticChatSendDetailed = programmaticChatSendDetailed;
