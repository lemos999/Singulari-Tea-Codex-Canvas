/* --- Ailey & Bailey Canvas --- */
// File: 346_notes_job_translation_logic.js
// Version: 6.1 (Learning Translator)
// Description: Updated the language selection modal to include the 'Learning Subtitle Translator' prompt template as an option, expanding the available translation methods.

async function startTranslationProcess(title, content, chunkSize, targetLanguage, promptId) {
    const toastId = `translation-prep-${Date.now()}`;
    showProgressToast('번역 준비 중...', toastId);
    trace("Translation", "start", { title, contentLength: content.length, chunkSize, targetLanguage });

    try {
        updateProgressToast('번역용 폴더 생성 중...', toastId);
        const newProjectRef = await noteProjectsCollectionRef.add({
            name: title,
            isTranslationProject: true, // Mark this as a translation project
            targetLanguage: targetLanguage, // Save the target language
            translationPromptId: promptId, // Store the selected prompt ID
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        const projectId = newProjectRef.id;

        // [MODIFIED] Use the intelligent splitter instead of a simple character-based split.
        const chunks = hybridHierarchicalSplit(content, chunkSize);

        updateProgressToast(`문서를 ${chunks.length}개로 분할 및 저장 중...`, toastId);
        const batch = db.batch();
        chunks.forEach((chunk, index) => {
            const noteRef = notesCollectionRef.doc();
            batch.set(noteRef, {
                title: `Part ${index + 1}`,
                content: chunk,
                projectId: projectId,
                isPinned: false,
                tags: [],
                createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            });
        });
        await batch.commit();

        hideProgressToast(toastId);
        showToastNotification("✅ 번역 준비 완료", `'${title}' 폴더에서 '번역 시작'을 눌러주세요.`, `translation-ready-${Date.now()}`);
        trace("Translation", "prep.success", { projectId, chunkCount: chunks.length });
        
        togglePanel(notesAppPanel, true);
        ensureNotePanelHeader();
        switchView('list');
        renderNoteList();

    } catch (error) {
        console.error("Failed to prepare translation:", error);
        trace("Translation", "prep.error", { error: error.message }, {}, "ERROR");
        hideProgressToast(toastId);
        showModal(`번역 준비에 실패했습니다: ${error.message}`, () => {});
    }
}

function _openLanguageSelectionModal(projectId, onConfirm) {
    const modal = document.getElementById('translation-language-modal-overlay');
    if (!modal) return;

    const project = localNoteProjectsCache.find(p => p.id === projectId);
    if (!project) return;

    const titleEl = document.getElementById('translation-language-modal-title-text');
    const selectRadio = document.getElementById('trans-lang-select-radio');
    const directRadio = document.getElementById('trans-lang-direct-radio');
    const langSelect = document.getElementById('translation-language-select');
    const directInput = document.getElementById('translation-language-direct-input');
    const promptSelect = document.getElementById('translation-prompt-select');
    const delayInput = document.getElementById('translation-delay-input');
    const confirmBtn = document.getElementById('translation-language-confirm-btn');
    const cancelBtn = document.getElementById('translation-language-cancel-btn');
    
    titleEl.textContent = project.name;
    delayInput.value = '10'; // Reset to default

    const defaultLang = project.targetLanguage || 'Korean';
    const isMajorLang = Array.from(langSelect.options).some(opt => opt.value === defaultLang);

    if (isMajorLang) {
        selectRadio.checked = true;
        langSelect.value = defaultLang;
    } else {
        directRadio.checked = true;
        directInput.value = defaultLang;
    }

    if (promptSelect) {
        promptSelect.innerHTML = '';
        const translationTemplates = promptTemplatesCache
            .filter(t => ["Document Translator", "Master Translator", "Learning Subtitle Translator"].includes(t.name))
            .sort((a,b) => a.name.localeCompare(b.name));
        translationTemplates.forEach(template => {
            const option = document.createElement('option');
            option.value = template.id;
            option.textContent = template.name;
            promptSelect.appendChild(option);
        });
        if (project.translationPromptId) {
            promptSelect.value = project.translationPromptId;
        } else {
            const masterTranslator = translationTemplates.find(t => t.name === "Master Translator");
            if (masterTranslator) {
                promptSelect.value = masterTranslator.id;
            }
        }
    }


    const handleLanguageOptionChange = () => {
        const isSelectChecked = selectRadio.checked;
        if (langSelect.nextElementSibling && langSelect.nextElementSibling.classList.contains('custom-select-container')) {
            langSelect.nextElementSibling.style.pointerEvents = isSelectChecked ? 'auto' : 'none';
            langSelect.nextElementSibling.style.opacity = isSelectChecked ? '1' : '0.5';
        } else {
            langSelect.disabled = !isSelectChecked;
        }
        directInput.disabled = !directRadio.checked;
    };

    handleLanguageOptionChange();
    
    selectRadio.addEventListener('change', handleLanguageOptionChange);
    directRadio.addEventListener('change', handleLanguageOptionChange);

    const close = () => {
        modal.style.display = 'none';
        selectRadio.removeEventListener('change', handleLanguageOptionChange);
        directRadio.removeEventListener('change', handleLanguageOptionChange);
        confirmBtn.onclick = null;
        cancelBtn.onclick = null;
        modal.onclick = null;
    };

    confirmBtn.onclick = () => {
        let targetLanguage = 'Korean';
        if (selectRadio.checked) {
            targetLanguage = langSelect.value;
        } else {
            targetLanguage = directInput.value.trim();
        }
        if (!targetLanguage) {
            showModal("번역할 언어를 선택하거나 입력해주세요.", () => {});
            return;
        }
        
        const selectedPromptId = promptSelect.value;
        const delay = parseInt(delayInput.value, 10) || 10;
        
        if (project.translationPromptId !== selectedPromptId) {
            noteProjectsCollectionRef.doc(projectId).update({ translationPromptId: selectedPromptId });
        }
        
        onConfirm(targetLanguage, delay, selectedPromptId);
        close();
    };

    cancelBtn.onclick = close;
    modal.onclick = (e) => { if (e.target === modal) close(); };

    highestZIndex++;
    modal.style.zIndex = highestZIndex;
    modal.style.display = 'flex';

    if (typeof createCustomSelect === 'function') {
        createCustomSelect(document.getElementById('translation-language-select'));
        createCustomSelect(promptSelect);
    }
}

async function _startTranslationJobWithLanguage(projectId, targetLanguage, delayInSeconds = 10, promptId) {
    if (activeTranslationJob) {
        showModal("이미 다른 번역 작업이 진행 중입니다.", () => {});
        return;
    }

    const originalActivePromptId = activePromptId;
    const originalIsContextlessMode = isContextlessMode;
    const toastId = `translation-progress-${Date.now()}`;
    trace("Translation", "request.start", { projectId, delay: delayInSeconds });

    try {
        isContextlessMode = true;
        if (contextToggleBtn) contextToggleBtn.classList.add('active');
        trace("Translation", "contextlessMode.enabled");

        const project = localNoteProjectsCache.find(p => p.id === projectId);
        if (!project) throw new Error('폴더를 찾을 수 없습니다.');
        
        trace("Translation", "request.language", { lang: targetLanguage });

        const notesToProcess = localNotesCache
            .filter(n => n.projectId === projectId)
            .sort((a, b) => (a.title.localeCompare(b.title, undefined, { numeric: true })));
        
        if (notesToProcess.length === 0) {
            throw new Error('번역할 메모가 폴더에 없습니다.');
        }

        const finalPromptId = promptId || project.translationPromptId;
        let translatorTemplate = promptTemplatesCache.find(p => p.id === finalPromptId);

        if (!translatorTemplate) {
            // Fallback if ID is invalid or not found.
            translatorTemplate = promptTemplatesCache.find(p => p.name === 'Master Translator') || promptTemplatesCache.find(p => p.name === 'Document Translator');
            if (!translatorTemplate) {
                throw new Error('번역 프롬프트 템플릿을 찾을 수 없습니다.');
            }
        }
        
        const finalSystemInstruction = translatorTemplate.promptText.replace('{{TARGET_LANGUAGE}}', targetLanguage);
        trace("Translation", "request.prompt", { finalInstruction: finalSystemInstruction });

        const sessionTitle = `번역: ${project.name}`;
        const sessionId = await findOrCreateSystemSession(sessionTitle);
        if (!sessionId) throw new Error("번역용 채팅 세션을 생성/탐색할 수 없습니다.");

        togglePanel(chatPanel, true);
        await selectSession(sessionId);

        activeTranslationJob = {
            projectId, sessionId, notesToProcess,
            currentIndex: 0,
            retryCount: 0,
            processedMessageIds: new Set(),
            totalChunks: notesToProcess.length,
            originalActivePromptId: originalActivePromptId,
            toastId,
            finalSystemInstruction,
            accumulatedResults: [],
            failedChunks: [],
            originalIsContextlessMode,
            delayInSeconds // [NEW] Store the delay
        };
        
        showProgressToast(`문서 번역 중... (0/${activeTranslationJob.totalChunks}개 완료)`, toastId);
        
        setTimeout(() => { dispatchTranslationTask(0); }, 500);

    } catch (error) {
        console.error("Document translation process failed:", error);
        trace("Translation", "request.error", { error: error.message }, {}, "ERROR");
        
        isContextlessMode = originalIsContextlessMode;
        if (contextToggleBtn) contextToggleBtn.classList.toggle('active', isContextlessMode);
        trace("Translation", "contextlessMode.restoredOnError");

        if (activeTranslationJob) hideProgressToast(activeTranslationJob.toastId);
        activeTranslationJob = null;
        activePromptId = originalActivePromptId;
        showModal(`문서 번역 프로세스 실패: ${error.message}`, () => {});
    }
}

async function requestTranslation(projectId) {
    trace("Translation", "request.initiated", { projectId });
    _openLanguageSelectionModal(projectId, (targetLanguage, delay, promptId) => {
        _startTranslationJobWithLanguage(projectId, targetLanguage, delay, promptId);
    });
}

async function dispatchTranslationTask(index) {
    if (!activeTranslationJob || index >= activeTranslationJob.totalChunks) {
        return;
    }

    const { sessionId, notesToProcess, totalChunks, toastId, finalSystemInstruction } = activeTranslationJob;

    try {
        updateProgressToast(`문서 번역 중... (${index + 1}/${totalChunks} 처리중)`, toastId);

        const noteToProcess = notesToProcess[index];
        const noteContent = await getNoteContent(noteToProcess.id);
        
        const systemInstruction = finalSystemInstruction;
        const userContent = noteContent || '(내용 없음)';

        await programmaticChatSend(sessionId, userContent, systemInstruction, true);

    } catch (error) {
        console.error(`Error dispatching translation task for index ${index}:`, error);
        handleTranslationStep({
            content: `API 오류: programmaticChatSend failed - ${error.message}`,
            id: `dispatch-trans-error-${Date.now()}`
        });
    }
}

async function handleTranslationStep(aiMessage) {
    if (!activeTranslationJob) return;

    let advanceToNextStep = false;

    if (aiMessage) {
        const msgId = getMessageId(aiMessage);
        if (activeTranslationJob.processedMessageIds.has(msgId)) {
            trace("Translation", "step.ignore.duplicate", { msgId: msgId.substring(0, 10) });
            return;
        }
        activeTranslationJob.processedMessageIds.add(msgId);
        
        if (aiMessage.content && aiMessage.content.startsWith('**[시스템]**')) {
            trace("Translation", "step.ignore.finalMessage", { sessionId: activeTranslationJob.sessionId });
            return;
        }

        const content = aiMessage.content || '';
        const isApiError = content.includes("API 오류");
        const isEmptyResponse = content.trim() === '';
        const isError = isApiError || isEmptyResponse;
        const errorReason = isApiError ? "API 오류" : (isEmptyResponse ? "빈 응답" : "성공");

        if (isError) {
            activeTranslationJob.retryCount++;
            trace("Translation", "step.failure", { reason: errorReason, retry: activeTranslationJob.retryCount, max: 3 });

            if (activeTranslationJob.retryCount >= 3) {
                trace("Translation", "step.finalFailure.skipChunk", { chunkIndex: activeTranslationJob.currentIndex, reason: errorReason });
                
                const failedNote = activeTranslationJob.notesToProcess[activeTranslationJob.currentIndex];
                const failedPartTitle = failedNote.title || `Part ${activeTranslationJob.currentIndex + 1}`;
                activeTranslationJob.failedChunks.push(failedPartTitle);

                activeTranslationJob.accumulatedResults.push(`\n\n--- [오류: '${failedPartTitle}' 부분은 번역에 실패했습니다. (API 문제 또는 안전 검열)] ---\n\n`);
                
                activeTranslationJob.retryCount = 0; 
                activeTranslationJob.currentIndex++;
                advanceToNextStep = true;
            } else {
                updateProgressToast(`${errorReason} 발생. 10초 후 재시도... (${activeTranslationJob.retryCount}/3)`, activeTranslationJob.toastId);
                setTimeout(() => {
                    dispatchTranslationTask(activeTranslationJob.currentIndex);
                }, 10000);
                return;
            }
        } else {
            activeTranslationJob.accumulatedResults.push(aiMessage.content || '');
            activeTranslationJob.retryCount = 0;
            activeTranslationJob.currentIndex++;
            advanceToNextStep = true;
        }
    } else {
        advanceToNextStep = true;
    }

    if (!advanceToNextStep) return;

    const { projectId, currentIndex, totalChunks, accumulatedResults, sessionId, originalActivePromptId, toastId, originalIsContextlessMode, delayInSeconds } = activeTranslationJob;

    if (currentIndex >= totalChunks) {
        hideProgressToast(toastId);
        trace("Translation", "job.complete", { sessionId, resultsCount: accumulatedResults.length, failedCount: activeTranslationJob.failedChunks.length });

        const finalCombinedContent = accumulatedResults.filter(s => s).join('\n\n');
        let finalAiMessageContent = `**[시스템]** 모든 문서 조각의 번역이 완료되어 하나의 최종 결과물로 종합했습니다.`;

        if (activeTranslationJob.failedChunks.length > 0) {
            finalAiMessageContent += `\n\n⚠️ **오류 보고:** 다음 부분들은 3회 재시도 후에도 번역에 실패했습니다:\n- ${activeTranslationJob.failedChunks.join('\n- ')}`;
        }
        
        finalAiMessageContent += `\n\n---\n\n${finalCombinedContent}`;
        
        const finalAiMessage = { role: 'ai', content: finalAiMessageContent, timestamp: firebase.firestore.FieldValue.serverTimestamp() };

        const sessionDocRef = chatSessionsCollectionRef.doc(sessionId);
        await sessionDocRef.collection("messages").add(finalAiMessage);
        await sessionDocRef.update({ updatedAt: firebase.firestore.FieldValue.serverTimestamp() });

        await noteProjectsCollectionRef.doc(projectId).update({
            isTranslationProject: false,
            lastTranslatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        trace("Translation", "job.complete.success", { projectId });

        activePromptId = originalActivePromptId;
        updateChatHeaderModelSelector();
        isContextlessMode = originalIsContextlessMode;
        if (contextToggleBtn) contextToggleBtn.classList.toggle('active', isContextlessMode);
        trace("Translation", "contextlessMode.restoredOnCompletion");

        activeTranslationJob = null;
        return;
    }

    // [MODIFIED] Apply delay before dispatching the next task.
    updateProgressToast(`다음 번역 대기 중... (${delayInSeconds}초)`, toastId);
    setTimeout(() => {
        dispatchTranslationTask(currentIndex);
    }, delayInSeconds * 1000);
}