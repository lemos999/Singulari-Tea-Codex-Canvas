Plan Type: Work Plan
Workstream: Chat Receive Pipeline Deep Review and Modernization
Version: v01
Status: Active
Created: 2026-04-14 06:06:58 +09:00
Last Updated: 2026-04-14 06:06:58 +09:00
Supersedes or Related Plan: Related to `plan/20260414-052500--work-plan--visualization-regeneration-parser-hardening-and-legacy-ui-refresh--v01.md`
Current Completion State: Planning approved, scan in progress, no new code changes made yet
Completed So Far: User concern captured; planning gate satisfied; new workstream opened; initial investigation targets identified from prior regeneration fixes
Remaining Work: Trace the full chat receive path; reproduce the truncation symptom with evidence; determine whether the failure is in model output, transport, completion-state handling, parser extraction, message persistence, or UI rendering; implement the smallest complete fix; modernize stale receive/failure UI surfaces implicated by the findings; verify across normal chat and visualization-engine flows; publish if stable
Current Blockers: Need concrete runtime evidence showing the exact stage where long HTML/code responses are lost or truncated
Next Step: Perform a read-first pipeline trace across API service, orchestrator, message storage, markdown/code rendering, and visualization-system glue, then reproduce the failing symptom with instrumentation

# Scoreboard

Current Score: 45
Score Source: provisional
Last Updated: 2026-04-14 06:06:58 +09:00
Score Rationale: The user is still observing a core runtime defect after earlier fixes, so confidence is limited until the full receive path is revalidated with evidence and the symptom is eliminated in the live UI.
What Improved: Prior regeneration parsing was hardened, system-session history pollution was reduced, and legacy regeneration error UI already received an initial refresh. Those changes narrowed the search space and reduced one class of failure.
What Remains Unsatisfactory: The user still sees code/HTML responses appear and then stop, which means the acceptance bar for reliable structured output is not met. The receive path likely still has a contract mismatch or UI-layer truncation behavior.
What Should Happen Next To Raise Or Maintain The Score: Identify the true failure boundary with concrete evidence, fix the boundary instead of layering additional heuristics, modernize the stale receive/error surfaces involved in the path, and prove the fix with reproducible validation on the same visualization-engine workflow the user is using.

## Score History

- 2026-04-14 06:06:58 +09:00 | score=45 | source=provisional | New plan opened for a deeper end-to-end receive-pipeline investigation after the user reported that responses still appear to arrive and then cut off in the system visualization chat flow.

# Objective

Stabilize the end-to-end chat receive pipeline so that structured outputs, especially long HTML fragments returned through the visualization-engine flow, arrive, assemble, persist, and render without appearing to cut off mid-response. The work must go beyond the earlier parser hardening pass and determine whether the remaining defect is caused by transport assumptions, completion-state handling, parser boundaries, history contamination, message summarization, markdown/code rendering, UI collapse behavior, or a hidden rule conflict between the general chat path and the visualization-system path. The result should also improve the user experience of any stale or visibly old receive/failure surfaces that are still part of the problematic path.

# Why This Work Exists

The user is still reproducing a failure where a system chat message shows only the beginning of an HTML fragment such as `<div id="orrery-d3-root" style="width:` and then seems to stop. That symptom can be misleading: it could mean the model truly stopped early, the runtime treated a partial response as complete, the parser extracted only a prefix, the store retained only part of the content, the renderer collapsed or clipped the block, or a rule conflict caused post-processing to throw away later content. A shallow fix risks making the system even harder to reason about. This work exists to replace guesswork with evidence, shrink the failure surface to a single bounded cause or a small set of compatible causes, and land a durable structural fix instead of another symptom patch.

# Scope

In scope:

- Deep review of the request/response receive path for chat and visualization-engine jobs
- Reproduction and instrumentation of the truncation symptom in the same environment the user is using
- Analysis of completion-state semantics for Gemini responses, including whether non-clean finishes are currently being mistaken for valid complete content
- Analysis of how structured content moves from API response to chunk assembly to message persistence to markdown/code-block presentation
- Analysis of whether UI components are clipping, collapsing, or summarizing long fragments in a way that looks like transport truncation
- Surgical fixes in the minimum set of modules needed to make the receive contract explicit and robust
- Refresh of legacy receive/failure UI components that are clearly part of the broken path and undermine clarity or trust during failures
- Verification against both standard Ailey & Bailey chat sends and `[System] Visualization Engine` sends
- Documentation in the active plan and a final report, plus GitHub publication if verification passes

Out of scope unless evidence proves it is required:

- A full rewrite of the entire chat application
- Broad model-routing redesign unrelated to the receive defect
- Speculative migration to a different provider SDK without evidence that the current provider interface is the root cause
- Cosmetic redesigns unrelated to the receive/failure path being investigated

# Confirmed Facts

- The workspace uses a mandatory plan-first flow and this plan is the approved living record for the task.
- Earlier work hardened visualization regeneration parsing and forced historyless sends for visualization generation flows.
- The user still observes a visible symptom where a visualization-system reply appears to cut off after the beginning of an HTML fragment.
- The same model family can produce usable answers in other template/chat contexts, so the defect is unlikely to be a universal provider outage.
- The runtime includes both a generic chat path and a visualization-engine/system-chat path, which may not share identical assumptions.

# Safe Assumptions

- The most likely failure is not raw network chunk loss. Browser-level chunk loss is possible but less likely than a logic mismatch around finish handling, response extraction, or rendering.
- The earlier parser hardening reduced some extraction failures, which means the remaining defect is probably deeper in the receive contract or in the UI presentation path.
- A reliable fix will probably require changes in both logic and UI, but the logical receive contract should drive the UI changes instead of the reverse.

# Unresolved Questions To Answer During Scan

- Does the provider return a finish reason that signals truncation, token exhaustion, safety stop, or incomplete generation while the runtime still treats the response as success?
- Is the visualization-engine path truly historyless from request construction through response handling, or do some system-session behaviors still inject stale context?
- Does the response contain the full HTML in raw transport data while the renderer shows only a shortened preview?
- Is the code-block component intentionally summarizing or clipping content without an obvious “expand/full content” affordance?
- Are markdown extraction rules or code-block normalization rules stripping everything after a colon, quote, or fenced-block boundary?
- Are message persistence or serialization limits clipping long system messages before the renderer sees them?
- Is there a hidden conflict between visualization-specific extraction logic and generic chat content rendering?

# Technical Approach

Use a layered scan-to-fix approach. First prove where the content stops being whole. Only then change behavior. The preferred fix order is:

1. establish raw provider response truth
2. establish receive-pipeline truth after chunk assembly
3. establish stored-message truth
4. establish rendered-message truth
5. repair the first layer where the content diverges from the prior layer
6. tighten completion/error semantics so partial content is never silently treated as success
7. modernize the stale receive/failure UI that currently hides or poorly explains the problem

This keeps the design minimal and rollback-safe. If the raw provider response is already incomplete, the fix belongs near completion handling, prompt sizing, or provider request policy. If the raw response is complete but the stored or rendered version is not, the fix belongs in extraction, storage, or UI presentation.

# Phased Work Sequence

## Phase 1: Scan The Receive Contract

Review the modules that define how requests are sent, how provider responses are normalized, how chunks are assembled, how system visualization messages are represented, how code/HTML blocks are extracted, and how chat messages are rendered. Build a written map of the actual receive path for both normal chat and visualization-engine jobs. Identify every boundary where content can be lost, shortened, misclassified, or hidden.

Success for this phase means having a bounded list of concrete loss points instead of a broad suspicion that “something in chat is old.”

## Phase 2: Reproduce With Evidence

Create or reuse a targeted validation script that reproduces the failing visualization-engine send. Capture the following at minimum:

- raw provider response text length
- finish reason or equivalent completion metadata
- post-normalization text length
- stored message content length
- rendered DOM text length or preview state
- whether the message includes hidden full content behind a collapsed UI

If needed, add temporary instrumentation in a reversible and secret-safe way. Do not log API keys or other secrets. Prefer structured debug signals that can be removed once the cause is fixed.

Success for this phase means being able to point to the first exact stage where content diverges from the earlier stage.

## Phase 3: Repair The Smallest True Boundary

Implement the minimum complete fix based on evidence. Possible categories include:

- completion-state hardening if truncated provider responses are being accepted as full responses
- receive aggregation hardening if chunk or synthetic-stream assembly drops suffix content
- parser normalization hardening if valid HTML/code is being shortened during extraction
- message persistence hardening if the store clips or rewrites long code blocks
- renderer redesign if the UI is only showing a preview and misleading the user into thinking the response ended

The fix should make the contract explicit: either a response is complete and shown faithfully, or it is incomplete and surfaced as such with a modern failure or recovery state. Avoid silent degradation.

Success for this phase means the first failing boundary is repaired and the logic no longer depends on ambiguous heuristics.

## Phase 4: Modernize Legacy Receive And Failure Surfaces

Refresh the stale UI elements directly involved in the receive path. This may include:

- old system-message code cards
- clipped HTML/code previews without clear expansion behavior
- outdated failure modals or banners
- vague “invalid code block” language that does not distinguish provider truncation from extraction failure

The redesign should match the newer note/chat visual language already introduced elsewhere in the product. It should also make the state of a long structured response more legible: whether the content is complete, partially shown, expandable, invalid, or failed due to provider-side limits.

Success for this phase means the user can clearly tell what happened without relying on guesswork or inspecting devtools.

## Phase 5: Verify, Review, And Publish

Run targeted validations covering:

- normal text chat in the same model preset
- visualization-engine generation
- visualization-engine regeneration
- long HTML/code responses
- incomplete-response handling
- old regression cases already fixed in the previous workstream

Then perform a read-only review pass focused on correctness, simplicity, rollback safety, and hidden regressions. If stable, copy the built bundle to the publish repo and push to GitHub. If not stable, enter a bounded fix loop and keep the scope contained to the approved workstream.

# Hidden Rules And Consistency Requirements

- A partial provider response must never be silently labeled as a normal successful structured output.
- Historyless visualization jobs must remain historyless end-to-end, not just at one entry point.
- The system chat path and normal chat path can differ where needed, but their receive semantics must not contradict each other in invisible ways.
- Long code or HTML outputs must have a faithful representation. If the UI uses preview mode, that must be explicit and reversible through an obvious interaction.
- Failure language must distinguish between provider truncation, extraction failure, invalid content shape, and render-time failure.
- Any instrumentation added for debugging must be removable, secret-safe, and not become a permanent noisy log channel.
- The fix should not regress existing live export, fullscreen, archive, or placeholder behavior that depends on structured HTML responses.

# Risks

## Risk: Fixing Only The Renderer Masks A Deeper Provider Or Orchestrator Problem

If the UI merely starts showing more text but the raw response is genuinely incomplete, the user will still get broken visualizations. Mitigation: always validate the earliest boundary first.

## Risk: Tightening Completion Rules Breaks Previously Accepted Marginal Outputs

If the runtime starts rejecting more incomplete responses, it may surface more explicit failures. Mitigation: pair stricter acceptance with clearer recovery UI and only reject when the contract truly cannot succeed.

## Risk: Debug Instrumentation Pollutes Runtime State

Instrumentation that changes timing or stores excessive data could create new behavior. Mitigation: keep debug surfaces minimal, deterministic, and removable; prefer test-only scripts where possible.

## Risk: Shared Chat Components Affect More Than Visualization Jobs

Renderer or orchestrator changes may impact standard chat or other system agents. Mitigation: verify across ordinary chat, visualization engine, and known working prompt-template paths.

# Validation Strategy

Validation must prove not only that a happy-path response works, but that the receive contract is observable and stable. The verification bundle should include:

- a reproducible scenario matching the user’s failing HTML visualization message
- captured evidence for raw response length and finish metadata
- proof of whether the stored message equals the raw normalized message
- DOM-level proof that the rendered content is either fully shown or explicitly previewed
- proof that incomplete outputs produce a modern, explanatory failure state rather than a misleading partial success
- regression checks for previous fixes around historyless regeneration and resilient HTML extraction

Screenshots should be captured for the old symptom and the repaired state when possible. Validation outputs should live under `visual-tests/` with time-sortable folders and concise summaries.

# Definition Of Done

The work is done when all of the following are true:

- the first actual truncation or misrepresentation boundary has been identified with evidence
- the bounded root cause has been fixed in the smallest complete way
- long visualization HTML/code responses no longer appear to arbitrarily stop unless the provider truly ended early
- if the provider truly ends early, the runtime surfaces that as an explicit incomplete-response failure instead of a fake success
- legacy receive/failure UI involved in this path has been refreshed to the current design language
- regression validations pass across both standard chat and visualization-engine flows
- the active plan file and final report accurately record what changed, what was verified, and any remaining non-blocking caveats
- the publish repo is updated and pushed only if the validations support release

# Expected Deliverables

- Updated source code in the smallest necessary receive/orchestrator/render/UI modules
- Updated bundle artifacts for release if validation passes
- One or more validation scripts or repro helpers under `visual-tests/`
- Validation outputs with evidence
- An updated plan file reflecting progress and score state
- A concise final report and GitHub commit if published

# Initial Investigation Targets

Priority modules to inspect first:

- `Ailey/src/04_features_chat/213_chat_api_service.js`
- `Ailey/src/04_features_chat/215_chat_orchestrator.js`
- `Ailey/src/04_features_chat/223_chat_ui_messages_content.js`
- visualization-system entry points and glue under `Ailey/src/03_core/`
- markdown/code-block rendering CSS under `Ailey/src_css/`
- any storage layer that serializes or truncates chat messages

Priority evidence to gather first:

- whether `gemini-2.5-flash` responses include finish metadata indicating truncation
- whether the visualization-engine message is stored in full but previewed in the UI
- whether any normalization function strips trailing content after a generic HTML label or fenced block

# Progress Log

- 2026-04-14 06:06:58 +09:00 | Plan created and activated for deep receive-pipeline analysis after the user reported that responses still appear to arrive and then cut off in the visualization-engine chat flow.

