---
title: Chat Surface Refactor Plan
slug: chat-surface-refactor
created: 2026-04-13 01:34:04 +09:00
last_updated: 2026-04-13 02:01:29 +09:00
status: deployed-awaiting-user-validation
owner: Codex
requested_by: User
version: v01
---

# Chat Surface Refactor Plan

## Goal

Refactor the legacy chat surface into a cleaner, more coherent composer and session UI that behaves much closer to a modern ChatGPT-style workspace. The main target is end-to-end consistency across message composition, attachments, session/project flow, provider payload generation, and user-facing copy.

## User-Approved Scope

- Create a root backup before changes.
- Restore the previous `이전 대화 참조` chain-style icon.
- Clean up the legacy chat shell and remove visibly broken or low-quality text.
- Replace single-file attachment handling with a true multi-attachment composer.
- Support paste, file picker, drag-and-drop, and multiple files in one send flow.
- Support common image, PDF, and text/code file inputs.
- Keep project/session workflows coherent while modernizing the composer.
- Rebundle, document, and ship the updated hosted bundle.

## Backup

- Preflight backup: `backup_20260413-013146--chat-refactor-preflight.zip`

## Execution Record

### Phase 0
- Completed
- Root backup created.
- Approved plan record created.

### Phase 1
- Completed
- Chat shell markup rewritten for cleaner Korean copy and a modern composer structure.
- `이전 대화 참조` toggle restored to a chain-style icon surface.
- Settings surface labels cleaned.

### Phase 2
- Completed
- Multi-attachment staging model introduced through `stagedChatAttachments`.
- File picker expanded to support multiple files.
- Paste, drag-enter, drag-over, drag-leave, and drop behaviors wired into the composer.
- Attachment tray, per-item remove, and clear-all interactions added.

### Phase 3
- Completed
- User message model upgraded to carry multiple attachments.
- Payload builder updated to emit:
  - Gemini inline image/pdf parts
  - OpenAI-compatible text/image_url content arrays
  - Anthropic-compatible image blocks
- User message rendering upgraded for multi-image previews and non-image chips.
- Session switching and new-chat flows now clear staged attachments safely.

### Phase 4
- Completed
- Chat sidebar, session/project labels, modal copy, and date-group copy cleaned.
- Main initializer updated to render and maintain the new composer.
- Bundle rebuilt successfully.

### Phase 5
- Completed
- Plan artifact rewritten to remove mojibake and reflect actual delivery state.
- Final report prepared.

### Phase 6
- Completed
- Hosted bundle deployed to `Singulari-Tea-Codex-Canvas` `main`.
- Deployment commit: `036f4ed9b5b9cfe701c7cbe6cb2d9415117f6a60`
- External deployment repository verified clean after push.

## Files Changed

- `Ailey/src/00_shell/003_shell_part4_panel_notes_chat.js`
- `Ailey/src/00_shell/005_shell_part6_main_assembler.js`
- `Ailey/src/01_state/001_state_globalVars.js`
- `Ailey/src/02_utils/011_utils_helpers.js`
- `Ailey/src/03_core/120_core_main_initializer.js`
- `Ailey/src/04_features_chat/200_chat_data.js`
- `Ailey/src/04_features_chat/210_chat_ui_actions.js`
- `Ailey/src/04_features_chat/212_chat_payload_builder.js`
- `Ailey/src/04_features_chat/213_chat_api_service.js`
- `Ailey/src/04_features_chat/221_chat_ui_sidebar.js`
- `Ailey/src/04_features_chat/224_chat_ui_messages_element_factory.js`
- `Ailey/src/04_features_chat/227_chat_ui_modals.js`
- `Ailey/src/04_features_chat/231_chat_file_attachment.js`
- `Ailey/src/04_features_chat/233_chat_sidebar_actions.js`
- `Ailey/src/04_features_chat/234_chat_session_manager.js`
- `Ailey/src_css/020_chat_panel_base.css`
- `Ailey/src_css/021_chat_sidebar.css`
- `Ailey/src_css/022_chat_messages.css`
- `Ailey/src_css/023_chat_input.css`
- `Ailey/src_css/024_chat_controls_modals.css`

## Verification

- `node --check Ailey/src/00_shell/003_shell_part4_panel_notes_chat.js`
- `node --check Ailey/src/04_features_chat/231_chat_file_attachment.js`
- `node --check Ailey/src/04_features_chat/210_chat_ui_actions.js`
- `node --check Ailey/src/04_features_chat/212_chat_payload_builder.js`
- `node --check Ailey/src/04_features_chat/224_chat_ui_messages_element_factory.js`
- `node --check Ailey/src/04_features_chat/221_chat_ui_sidebar.js`
- `node --check Ailey/src/04_features_chat/227_chat_ui_modals.js`
- `node --check Ailey/src/04_features_chat/233_chat_sidebar_actions.js`
- `node --check Ailey/src/04_features_chat/234_chat_session_manager.js`
- `node --check Ailey/src/04_features_chat/200_chat_data.js`
- `node --check Ailey/src/04_features_chat/213_chat_api_service.js`
- `node --check Ailey/src/03_core/120_core_main_initializer.js`
- `node --check Ailey/src/01_state/001_state_globalVars.js`
- `node --check Ailey/src/02_utils/011_utils_helpers.js`
- `node Ailey/bundler.js`

## Success Criteria

- A user can stage multiple files at once from picker, paste, or drop.
- Image, PDF, and text/code attachments are visible before send.
- The composer can send attachment-only messages without requiring typed text.
- Message rendering shows attachment previews in a stable, readable way.
- Provider payload generation remains coherent for Gemini, OpenAI-compatible providers, and Anthropic.
- The chat surface reads as one cohesive system rather than a mix of old and new fragments.

## Known Follow-Ups

- Legacy `refined` / image-generation cleanup code still exists elsewhere in the repo and was intentionally kept out of this chat-only refactor slice.
- Browser runtime validation is still pending user manual testing.

## Next Step

- Ask the user to manually validate:
  - chain icon behavior
  - multi-file paste/drop/picker flow
  - image and PDF sending behavior
  - project/session flow

## Scoreboard

- Current score: 48
- Score source: provisional
- Last updated: 2026-04-13 02:01:29 +09:00
- Score rationale: The implementation breadth is strong, the bundle builds cleanly, and the hosted bundle is deployed, but the user has not yet manually validated the new chat surface in the browser.
- What improved:
  - Modern multi-attachment composer
  - Cleaner Korean UI copy
  - Chain icon restored for context toggle
  - Better provider payload coverage for attachments
- What remains unsatisfactory:
  - No user runtime score yet
  - Legacy non-chat cleanup remains outside this slice
- What should happen next to raise or maintain the score:
  - User validates real browser behavior

## Score History

- 2026-04-13 01:34:04 +09:00 | score: 40 | source: provisional | rationale: approved plan created, implementation not started
- 2026-04-13 01:57:13 +09:00 | score: 48 | source: provisional | rationale: implementation and bundling complete, awaiting browser validation
- 2026-04-13 02:01:29 +09:00 | score: 48 | source: provisional | rationale: hosted bundle deployed successfully; waiting for browser validation
