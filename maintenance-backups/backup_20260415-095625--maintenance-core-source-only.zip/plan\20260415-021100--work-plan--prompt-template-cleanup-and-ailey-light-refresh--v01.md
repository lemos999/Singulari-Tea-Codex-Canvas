Plan Type: work-plan
Workstream: Prompt Template Cleanup and Ailey Light Refresh
Version: v01
Status: Completed
Created: 2026-04-15 02:11 KST
Last Updated: 2026-04-15 02:22 KST
Supersedes or Related Plan: Related to the current stable prompt-template system and the latest startup optimization pass. This plan does not supersede a prior template-cleanup plan because no prior approved cleanup plan exists for this exact scope.
Current Completion State: Backup, inventory, implementation, rebuild, validation, and publication completed
Completed So Far: A full root backup has been created, the prompt-template source inventory has been scanned, runtime code-path usage has been traced, the requested replacement markdown source has been identified, the safe deletion boundary has been narrowed to only defaults that are not referenced by current runtime behavior, the unreferenced `Dynamic Narrative Scene Generator` default has been removed from source and the default inventory, the `Ailey & Bailey(Light)` template has been refreshed from the approved markdown source through an ASCII-safe base64 decode path, the bundle has been rebuilt, validation confirms that the refreshed Ailey prompt exactly matches the markdown source while the required templates remain present and no runtime errors appear, and the updated bundle has been published to the GitHub Pages repo as commit `1c8fe9c`.
Remaining Work: No further implementation work is required for this pass.
Current Blockers: None
Next Step: User confirmation in the real runtime and, if desired later, a separate follow-up pass to review whether any user-stored orphaned non-default templates should be cleaned up manually.

# Scoreboard

Current Score: 50
Score Source: provisional
Last Updated: 2026-04-15 02:11 KST
Score Rationale: The user approved a cleanup pass and explicitly asked for aggressive removal of templates that can disappear, but no user-visible result has been delivered yet in this pass. The current score therefore stays conservative until cleanup, replacement, rebuild, and validation all succeed.
What Improved: The safe preservation set is now clearer than at the start of the task. The inventory shows which templates are hard-required by runtime features and which ones can be safely removed from defaults.
What Remains Unsatisfactory: The prompt-template set still includes at least one obsolete default, and the Ailey & Bailey Light default content has not yet been replaced with the approved markdown source.
What Should Happen Next To Raise Or Maintain The Score: Implement only the validated cleanup, preserve all referenced templates, replace the Ailey & Bailey Light content without introducing mojibake, verify the resulting seeded default set and runtime references, and publish only after that passes.

## Score History

- 2026-04-15 02:11 KST | 50 | provisional | New workstream opened after approval. Inventory is complete, but the user-facing outcome is not yet delivered.

# Objective

Streamline the built-in prompt-template defaults so that obviously unused defaults are removed, while preserving every template that current runtime features still depend on, and replace the default `Ailey & Bailey(Light)` template body with the exact content from the approved markdown source file:

- `Ailey & Bailey X대화형_260323.md`

The deeper objective is not cosmetic decluttering alone. The real goal is to keep the prompt-template system coherent and maintainable, reduce stale defaults that confuse future maintenance, and refresh the core Ailey & Bailey Light persona template from a single approved source artifact without repeating the past encoding mistakes that produced broken Korean text.

# User-Confirmed Preservation Rules

The user explicitly approved removal only for templates that can disappear and explicitly named templates that must not be removed.

These preservation rules are authoritative for this plan:

- `Ailey & Bailey(Light)` must stay
- the visualization template must stay
- `Code Corrector` must stay

The code scan also shows additional defaults that still support existing product surfaces and therefore must remain even though the user did not name each one individually. Removing any of these would silently break features the user still uses or may rely on later.

# Inventory Summary

The runtime scan identified the following meaningful template groups.

## Core chat persona

- `Ailey & Bailey(Light)`

This is the general chat persona template and must remain.

## Visualization and image generation

- `Data Visualizer`
- `Image Prompt Generator`

These are required by the visualization and image-generation pipelines. Runtime code looks them up by exact template name, and generation will fail if they disappear.

## Code manipulation

- `Code Corrector`

This is required by the code-correction action flow and must remain.

## Learning and notes workflows

- `Narrative Data Refiner`
- `Learning Module Analyzer`
- `Comprehensive Chronicler`

These still have direct references in the notes refinement and report-generation logic. Even where source comments call an older path “deprecated” or “obsolete,” the present runtime still uses the template name in non-learning report flows. Therefore they cannot be removed in this pass.

## Translation workflows

- `Document Translator`
- `Master Translator`
- `Learning Subtitle Translator`

These are still used by the notes translation flow and translator selection logic. They must remain.

## Candidate for removal

- `Dynamic Narrative Scene Generator`

Current source inventory shows this default template file exists and is seeded into defaults, but no current runtime code looks it up by name or relies on it for a visible feature path. This is the strongest candidate for safe removal in the current pass.

# Safe Deletion Boundary

The cleanup must stop at the smallest complete set that is truly safe.

Included in scope:

- remove the unreferenced `Dynamic Narrative Scene Generator` default from the seeded default inventory
- delete its standalone source file if it is not referenced elsewhere
- preserve all other seeded defaults
- refresh only the `Ailey & Bailey(Light)` default content

Explicitly out of scope:

- removing templates that still back notes, translation, visualization, or code-correction flows
- renaming templates
- changing prompt-template runtime data structures
- changing prompt-template UI
- migrating or deleting user-created templates
- changing how defaults are versioned in Firestore beyond what current seeding already does

# Why Only One Template Is Being Removed

The user asked to remove templates that are safe to lose, not to maximize deletion count at the cost of hidden breakage. The scan shows that many defaults which might look “old” or “specialized” are still wired into current runtime behavior.

Examples:

- `Data Visualizer` is used repeatedly by the visualization initializer
- `Code Corrector` is required by the code-correction block flow
- `Document Translator`, `Master Translator`, and `Learning Subtitle Translator` are all used by the translation workflow
- `Narrative Data Refiner`, `Learning Module Analyzer`, and `Comprehensive Chronicler` all still participate in notes and reporting logic

That means aggressive deletion would create subtle feature failures. The smallest correct cleanup is therefore to remove only the template whose default is actually unreferenced today.

# Replacement Strategy for Ailey & Bailey Light

The user wants the current default Ailey & Bailey Light prompt replaced with the contents of:

- `Ailey & Bailey X대화형_260323.md`

The crucial constraint is byte safety. This repository already proved vulnerable to text corruption when localized content was rewritten too broadly in source files. The replacement therefore must avoid inserting large Korean text blocks directly into JS through a fragile path.

The safest design is:

1. read the markdown source as bytes
2. encode those bytes into an ASCII-safe representation
3. store that ASCII-safe representation in the default template source
4. decode it at runtime into the exact UTF-8 prompt text

This design keeps the source edit largely ASCII-only, which sharply lowers the risk of mojibake during patching. It also keeps the template content tightly coupled to the approved markdown source while making the transformation explicit and auditable.

# Smallest Safe Assumption

The smallest safe assumption is that the markdown file is the new source of truth for the default `Ailey & Bailey(Light)` prompt and that only the built-in default template needs to be refreshed. This plan assumes the user does not need historic stored copies of that default template to be forcibly rewritten beyond the existing seeding/version behavior already present in the application.

If stored defaults in local or Firestore state are versioned correctly, the existing seeding logic should update them when the default version changes. This pass should therefore focus on the built-in default source and the seeded-default inventory rather than trying to mutate every existing stored note or prompt-template document directly.

# Technical Approach

## Part 1: Remove the unreferenced default template

The cleanup should remove `TEMPLATE_DYNAMIC_NARRATIVE_SCENE_GENERATOR` from the `DEFAULT_PROMPT_TEMPLATES` array and delete the corresponding template source file if it is not referenced elsewhere. Since the seeding logic compares current JS defaults against existing stored defaults and removes orphaned default templates, this should also cause the obsolete default to be deleted from Firestore-backed defaults on the next seed pass.

## Part 2: Refresh Ailey & Bailey Light from the approved markdown

The current `102_template_ailey_bailey_light.js` file should be updated so its `promptText` resolves from an ASCII-safe encoded payload derived from the markdown file. The implementation should remain simple:

- a tiny local helper can decode a base64 UTF-8 payload
- the `promptText` field uses that decoder
- the payload is generated directly from `Ailey & Bailey X대화형_260323.md`

This approach avoids introducing a separate runtime fetch path, avoids new network dependencies, and avoids broad non-ASCII patching in the JS file itself.

# Hidden Rules and Maintenance Concerns

Several hidden constraints matter here even though the user did not state each one explicitly.

## Hidden rule: cleanup must not silently break expert workflows

Some templates are not visible in the main chat header every day but still drive specific features such as report generation, code correction, translation, visualization, and image prompting. These count as active product surfaces. Removing them because they “look old” would violate the real intent of safe cleanup.

## Hidden rule: source comments are not the same as live behavior

Some files contain comments describing older deprecations or transitions. Those comments cannot be trusted alone. The live code still references certain template names explicitly. The runtime references win over comments when deciding removal safety.

## Hidden rule: encoding safety is part of correctness

In this workspace, readable Korean output is not just presentation quality; it is part of functional correctness. Any edit path that risks text corruption must be rejected even if the logical content replacement is otherwise right.

## Hidden rule: user defaults and seeded defaults are different surfaces

This plan is about built-in defaults that seed into persistent storage. It is not about deleting arbitrary user-created templates from stored data. The cleanup must therefore stay bounded to the default template source and the default seeding inventory.

# Risks

## Risk: removing a template that has a hidden runtime dependency

If a supposedly unused default is actually referenced dynamically or indirectly, removal could break a feature later.

Mitigation:

- rely on exact-name code scan before removal
- remove only the strongest unused candidate
- keep the change list small

## Risk: markdown replacement introduces mojibake

This is the most important risk in the workstream.

Mitigation:

- avoid pasting large Korean blocks directly into the JS source
- use an ASCII-safe encoded payload
- validate the resulting prompt text in the built bundle or source-level decode path

## Risk: seeding does not update the stored default cleanly

If the version is not bumped or if stored defaults are not recognized as default templates, users may not receive the updated default automatically.

Mitigation:

- inspect and update the Ailey template version field when replacing content
- rely on existing seeding logic, which already handles version-aware updates and orphaned default cleanup

## Risk: cleanup is technically correct but too broad

Even a correct cleanup could become harder to rollback if too many files move at once.

Mitigation:

- keep the scope to one removal candidate and one content refresh
- avoid unrelated template cleanup

# Validation Plan

Validation must prove both safety and intent.

Required checks:

1. the default template inventory no longer includes `Dynamic Narrative Scene Generator`
2. the preserved templates still exist in the default inventory:
   - `Ailey & Bailey(Light)`
   - `Data Visualizer`
   - `Code Corrector`
3. the refreshed `Ailey & Bailey(Light)` template source decodes to the exact approved markdown content
4. the bundle rebuild succeeds
5. there are no new page or console errors in a focused harness or runtime check

Recommended additional checks:

- confirm the seeded default list still contains the learning/report/translation templates that code paths require
- confirm the replacement content contains readable Korean and not broken glyphs

# Definition of Done

This work is done only when all of the following are true:

- the root backup exists
- only genuinely unused default templates were removed
- `Ailey & Bailey(Light)` remains present
- visualization and code-correction templates remain present
- the Ailey & Bailey Light content matches the approved markdown source semantically and byte-safely
- the bundle rebuild succeeds
- validation confirms the new default inventory and replacement content
- the published bundle is updated on GitHub

# Rollback Strategy

Rollback should be simple and bounded.

If anything goes wrong, restore:

- the removed template source file
- the default template assembler
- the Ailey & Bailey Light template file
- the rebuilt bundle

Because this pass is intentionally limited to prompt-template defaults and one template-content refresh, rollback remains straightforward and does not require touching unrelated notes, chat, or startup systems.

# Review Standard

Before publishing, the change should answer “yes” to all of these:

- Did we remove only templates that are truly unused?
- Did we keep Ailey & Bailey Light, the visualization template, and Code Corrector?
- Did we avoid broad non-ASCII source rewriting?
- Is the Ailey template content replacement traceable back to the approved markdown source?
- Is the resulting source easier, not harder, to maintain?

If any answer is “no,” the change should be narrowed further before shipping.
