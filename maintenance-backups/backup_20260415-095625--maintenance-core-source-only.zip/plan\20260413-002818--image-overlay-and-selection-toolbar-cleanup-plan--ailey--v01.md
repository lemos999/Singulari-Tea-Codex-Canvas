# Image Overlay And Selection Toolbar Cleanup Plan

- Created: 2026-04-13 00:28:18 +09:00
- Last Updated: 2026-04-13 01:00:00 +09:00
- Status: implemented-awaiting-user-validation
- Owner: Codex
- Scope: Ailey image overlay controls, right-click add menu, text-selection action toolbar

## Objective

Remove low-value or broken interaction surfaces that now hurt clarity:

1. Remove `정제 후 생성` from image overlays, image placeholders, image studio, and related settings/debug surfaces.
2. Remove the right-click add menu entries for image and visualization insertion.
3. Redesign the text-selection toolbar so it avoids covering selected text, looks lighter and cleaner, and adapts to both dark and light modes.

## Why

- `정제 후 생성` is visually broken in some surfaces, is no longer trusted by the user, and duplicates other generation paths.
- The right-click add hover/menu creates accidental UI noise and is no longer desired.
- The current text-selection popover is too heavy, can cover the selected range, and does not match the newer UI language.

## Boundaries

- Do not change core image generation itself beyond removing the refined-entry surface.
- Keep `빠른 생성`, `옵션`, `설정`, `다운로드` flows intact where still relevant.
- Keep text-selection actions functionally equivalent:
  - ask AI about selected text
  - add selected text to note

## Planned Changes

### Phase 0. Surface Inventory Lock

- Remove `정제 후 생성` from:
  - image placeholder controls
  - generated image overlay controls
  - image generation studio buttons
  - vision/debug panel controls
  - any related styles and disabled-state handlers
- Remove right-click add-menu invocation for image/visualization insertion.

### Phase 1. Selection Toolbar Redesign

- Replace the chunky button row with a compact floating action bar.
- Prefer positioning above the selected range.
- If there is not enough space above, place it below with a tighter offset.
- Clamp horizontally so it stays in viewport.
- Use lighter visual weight and smaller icon-led buttons.
- Support both dark and light themes.

### Phase 2. Cleanup And Guardrails

- Remove dead CSS selectors and stale handlers tied to refined mode or removed menus.
- Keep IDs and event wiring narrow and explicit.
- Preserve keyboard safety and no-selection guard behavior.

### Phase 3. Verification And Delivery

- Run `node --check` on touched JS files.
- Run `node Ailey/bundler.js`.
- Update hosted bundle repo.
- Write follow-up report.

## File Targets

- `Ailey/src/03_core/123_core_initializer_vision_logic.js`
- `Ailey/src/03_core/124_core_initializer_vision_handler.js`
- `Ailey/src/03_core/125_core_initializer_vision_ui.js`
- `Ailey/src/02_utils/013_utils_block_renderer.js`
- `Ailey/src/02_utils/014_utils_ui_actions.js`
- `Ailey/src/00_shell/001_shell_part2_modals_common.js`
- `Ailey/src/00_shell/002_shell_part3_f.js`
- `Ailey/src/00_shell/004_shell_part5_panel_vision_debugger.js`
- `Ailey/src_css/006_widget_popovers_tooltips.css`
- `Ailey/src_css/025_vision_weaver_panel.css`
- `Ailey/src_css/027_image_gen_studio.css`
- `Ailey/src_css/028_image_placeholders.css`

## Success Criteria

- No visible `정제 후 생성` entry remains in image UI surfaces.
- Right-click add hover/menu no longer appears.
- Text-selection toolbar no longer obscures the selected text in the common case.
- New toolbar feels visually aligned with current light/dark surfaces.
- Bundle rebuild and hosted deployment succeed.

## Notes

- Safe assumption: removing refined-entry surfaces is acceptable even if some legacy handler code remains temporarily unused during the same patch, but dead entry points should be removed where practical in this pass.
- Runtime result: refined-entry surfaces are removed or runtime-suppressed, the right-click add menu no longer opens, and the selection toolbar now renders as a compact theme-aware floating bar that prefers appearing above the selected range.
- Hosted bundle deployed: `9adde8d7cee5b7e7e8c85ec5f1a1b3b7994d0a16`
