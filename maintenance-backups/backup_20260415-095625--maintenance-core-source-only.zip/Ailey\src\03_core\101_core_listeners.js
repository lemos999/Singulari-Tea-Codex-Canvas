/* --- Ailey & Bailey Canvas --- */
// File: 101_core_listeners.js
// Version: 1.0 (Refactored)
// Description: Centralized module for managing all Firestore real-time listeners.

// Listener for prompt templates
function listenToPromptTemplates() {
    return new Promise((resolve) => {
        if (!promptTemplatesCollectionRef) return resolve();
        if (unsubscribeFromPromptTemplates) unsubscribeFromPromptTemplates();
        unsubscribeFromPromptTemplates = promptTemplatesCollectionRef.onSnapshot(snapshot => {
            promptTemplatesCache = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            if (promptManagerModalOverlay?.style.display === 'flex') {
                renderPromptManager();
            }
            renderQuickPromptSelect();
            resolve();
        }, error => { console.error("Prompt Templates listener error:", error); resolve(); });
    });
}

function listenToNotes() { 
    return new Promise(resolve => { 
        if (!notesCollectionRef) return resolve(); 
        if (unsubscribeFromNotes) unsubscribeFromNotes();
        
        let query = notesCollectionRef.orderBy("updatedAt", "desc");

        unsubscribeFromNotes = query.onSnapshot(s => { 
            localNotesCache = s.docs.map(d => ({ id: d.id, ...d.data() })); 
            if (localNotesCache.length > 0) {
                lastVisibleNoteTimestamp = localNotesCache[localNotesCache.length - 1].updatedAt;
            }
            // This is for UI pagination, archiver will query directly.
            hasMoreNotes = true; 
            if (document.getElementById('notes-app-panel')?.style.display === 'flex') {
                renderNoteList();
            }
            resolve(); 
        }, e => { console.error("노트 수신 오류:", e); resolve(); }); 
    }); 
}

function listenToNoteProjects() {
    return new Promise((resolve) => {
        if (!noteProjectsCollectionRef) return resolve();
        if (unsubscribeFromNoteProjects) unsubscribeFromNoteProjects();
        unsubscribeFromNoteProjects = noteProjectsCollectionRef.onSnapshot(snapshot => {
            const oldCache = [...localNoteProjectsCache];
            localNoteProjectsCache = snapshot.docs.map(doc => ({
                id: doc.id,
                isExpanded: oldCache.find(p => p.id === doc.id)?.isExpanded ?? false, ...doc.data()
            }));
            if (document.getElementById('notes-app-panel')?.style.display === 'flex') renderNoteList();
            if (newlyCreatedNoteProjectId) {
                const newProjectElement = document.querySelector(`.note-project-container[data-project-id="${newlyCreatedNoteProjectId}"]`);
                if (newProjectElement) { startNoteProjectRename(newlyCreatedNoteProjectId); newlyCreatedNoteProjectId = null; }
            }
            resolve();
        }, error => { console.error("Note Project listener error:", error); resolve(); });
    });
}

function listenToTags() {
    return new Promise((resolve) => {
        if (!tagsCollectionRef) return resolve();
        if (unsubscribeFromTags) unsubscribeFromTags();
        unsubscribeFromTags = tagsCollectionRef.onSnapshot(snapshot => {
            localTagsCache = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            resolve();
        }, error => { console.error("Tags listener error:", error); resolve(); });
    });
}

function listenToNoteTemplates() {
    return new Promise((resolve) => {
        if (!noteTemplatesCollectionRef) return resolve();
        if (unsubscribeFromNoteTemplates) unsubscribeFromNoteTemplates();
        unsubscribeFromNoteTemplates = noteTemplatesCollectionRef.onSnapshot(snapshot => {
            noteTemplatesCache = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            resolve();
        }, error => { console.error("Note Templates listener error:", error); resolve(); });
    });
}

function listenToProjects() {
    return new Promise((resolve) => {
        if (!projectsCollectionRef) return resolve();
        if (unsubscribeFromProjects) unsubscribeFromProjects();
        unsubscribeFromProjects = projectsCollectionRef.onSnapshot(snapshot => {
            const oldCache = [...localProjectsCache];
            localProjectsCache = snapshot.docs.map(doc => ({
                id: doc.id,
                isExpanded: oldCache.find(p => p.id === doc.id)?.isExpanded ?? false, ...doc.data()
            }));
            renderSidebarContent();
            if (newlyCreatedProjectId) {
                const newProjectElement = document.querySelector(`.project-container[data-project-id="${newlyCreatedProjectId}"]`);
                if (newProjectElement) { startProjectRename(newlyCreatedProjectId); newlyCreatedProjectId = null; }
            }
            resolve();
        }, error => { console.error("Project listener error:", error); resolve(); });
    });
}

function listenToChatSessions() {
    return new Promise((resolve) => {
        if (!chatSessionsCollectionRef) return resolve();
        if (unsubscribeFromChatSessions) unsubscribeFromChatSessions();

        const query = chatSessionsCollectionRef.orderBy("updatedAt", "desc");

        unsubscribeFromChatSessions = query.onSnapshot(snapshot => {
            const changes = snapshot.docChanges();
            let shouldRerenderSidebar = false;

            changes.forEach(change => {
                const data = { id: change.doc.id, ...change.doc.data() };
                const index = localChatSessionsCache.findIndex(s => s.id === change.doc.id);

                if (change.type === "added") {
                    if (index === -1) {
                        localChatSessionsCache.push(data);
                        shouldRerenderSidebar = true;
                    }
                } else if (change.type === "modified") {
                    if (index !== -1) {
                        // [FIX] Prevent stale data propagation on metadata updates.
                        // Get a reference to the potentially loaded messages array from the old cache object.
                        const existingMessages = localChatSessionsCache[index].messages;
                        
                        // Create the new session object from scratch using the fresh data from Firestore.
                        const newSessionData = { id: change.doc.id, ...data };
                        
                        // If there was a 'messages' array (because the session was active), re-attach it.
                        if (existingMessages) {
                            newSessionData.messages = existingMessages;
                        }
                        
                        // Replace the entire object in the cache to prevent stale properties from surviving.
                        localChatSessionsCache[index] = newSessionData;
                        shouldRerenderSidebar = true;
                    }
                } else if (change.type === "removed") {
                    if (index !== -1) {
                        localChatSessionsCache.splice(index, 1);
                        shouldRerenderSidebar = true;
                    }
                }
            });

            if (shouldRerenderSidebar) {
                 localChatSessionsCache.sort((a, b) => (b.updatedAt?.toMillis() || 0) - (a.updatedAt?.toMillis() || 0));
                 renderSidebarContent();
            }

            resolve();
        }, error => { console.error("Chat session listener error:", error); resolve(); });
    });
}

async function initializeListeners() {
    await Promise.all([
        listenToNotes(),
        listenToNoteProjects(),
        listenToTags(),
        listenToNoteTemplates(),
        listenToChatSessions(),
        listenToProjects(),
        listenToPromptTemplates()
    ]);
}
