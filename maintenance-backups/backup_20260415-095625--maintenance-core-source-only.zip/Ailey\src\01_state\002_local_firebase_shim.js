/* --- Ailey & Bailey Canvas --- */
// File: 002_local_firebase_shim.js
// Version: 1.0 (Local Mode Bootstrap)
// Description: Provides a Firestore-like local persistence shim for non-Canvas execution.

const LOCAL_FIREBASE_DB_NAME = 'AileyLocalFirebaseShim';
const LOCAL_FIREBASE_DB_VERSION = 1;
const LOCAL_FIREBASE_DOC_STORE = 'documents';
const LOCAL_FIREBASE_COLLECTION_INDEX = 'collectionPath';

function isLocalPlainObject(value) {
    if (!value || typeof value !== 'object') return false;
    return Object.getPrototypeOf(value) === Object.prototype;
}

function createLocalId() {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
        return crypto.randomUUID();
    }
    return `local-${Date.now()}-${Math.random().toString(16).slice(2, 10)}`;
}

function cloneLocalValue(value) {
    if (value instanceof LocalTimestamp) {
        return LocalTimestamp.fromMillis(value.toMillis());
    }
    if (value instanceof Date) {
        return new Date(value.getTime());
    }
    if (Array.isArray(value)) {
        return value.map(cloneLocalValue);
    }
    if (isLocalPlainObject(value)) {
        const clone = {};
        Object.keys(value).forEach(key => {
            clone[key] = cloneLocalValue(value[key]);
        });
        return clone;
    }
    return value;
}

function serializeLocalValue(value) {
    if (value instanceof LocalTimestamp) {
        return { __localType: 'timestamp', ms: value.toMillis() };
    }
    if (value instanceof Date) {
        return { __localType: 'date', iso: value.toISOString() };
    }
    if (Array.isArray(value)) {
        return value.map(serializeLocalValue);
    }
    if (isLocalPlainObject(value)) {
        const serialized = {};
        Object.keys(value).forEach(key => {
            serialized[key] = serializeLocalValue(value[key]);
        });
        return serialized;
    }
    return value;
}

function reviveLocalValue(value) {
    if (!value || typeof value !== 'object') {
        return value;
    }
    if (Array.isArray(value)) {
        return value.map(reviveLocalValue);
    }
    if (value.__localType === 'timestamp') {
        return LocalTimestamp.fromMillis(value.ms);
    }
    if (value.__localType === 'date') {
        return new Date(value.iso);
    }
    const revived = {};
    Object.keys(value).forEach(key => {
        revived[key] = reviveLocalValue(value[key]);
    });
    return revived;
}

function stableLocalStringify(value) {
    if (value instanceof LocalTimestamp) {
        return `timestamp:${value.toMillis()}`;
    }
    if (value instanceof Date) {
        return `date:${value.toISOString()}`;
    }
    if (Array.isArray(value)) {
        return `[${value.map(stableLocalStringify).join(',')}]`;
    }
    if (isLocalPlainObject(value)) {
        return `{${Object.keys(value).sort().map(key => `${key}:${stableLocalStringify(value[key])}`).join(',')}}`;
    }
    return JSON.stringify(value);
}

function normalizeComparableValue(value) {
    if (value instanceof LocalTimestamp) {
        return value.toMillis();
    }
    if (value instanceof Date) {
        return value.getTime();
    }
    if (value && typeof value.toMillis === 'function') {
        return value.toMillis();
    }
    return value;
}

function getLocalFieldValueKind(value) {
    if (!value || typeof value !== 'object') return null;
    if (value.__localFieldValue) return value.__localFieldValue;
    if (value._methodName === 'FieldValue.serverTimestamp') return 'serverTimestamp';
    if (value._methodName === 'FieldValue.delete') return 'delete';
    if (value._methodName === 'FieldValue.arrayUnion') return 'arrayUnion';
    if (value._methodName === 'FieldValue.arrayRemove') return 'arrayRemove';
    return null;
}

function coerceLocalSpecialValue(value) {
    const kind = getLocalFieldValueKind(value);
    if (kind === 'serverTimestamp') return LocalFirebaseShim.FieldValue.serverTimestamp();
    if (kind === 'delete') return LocalFirebaseShim.FieldValue.delete();
    if (kind === 'arrayUnion') return LocalFirebaseShim.FieldValue.arrayUnion(...(value._elements || value.elements || value.items || []));
    if (kind === 'arrayRemove') return LocalFirebaseShim.FieldValue.arrayRemove(...(value._elements || value.elements || value.items || []));
    if (value instanceof LocalTimestamp) return value;
    if (value && typeof value.toDate === 'function' && typeof value.seconds === 'number') {
        return LocalTimestamp.fromDate(value.toDate());
    }
    return value;
}

function getLocalValueAtPath(target, fieldPath) {
    const segments = String(fieldPath).split('.');
    let cursor = target;
    for (const segment of segments) {
        if (!cursor || typeof cursor !== 'object') return undefined;
        cursor = cursor[segment];
    }
    return cursor;
}

function setLocalValueAtPath(target, fieldPath, value) {
    const segments = String(fieldPath).split('.');
    let cursor = target;
    while (segments.length > 1) {
        const segment = segments.shift();
        if (!isLocalPlainObject(cursor[segment])) {
            cursor[segment] = {};
        }
        cursor = cursor[segment];
    }
    cursor[segments[0]] = value;
}

function deleteLocalValueAtPath(target, fieldPath) {
    const segments = String(fieldPath).split('.');
    let cursor = target;
    while (segments.length > 1) {
        const segment = segments.shift();
        if (!cursor || typeof cursor !== 'object') return;
        cursor = cursor[segment];
    }
    if (cursor && typeof cursor === 'object') {
        delete cursor[segments[0]];
    }
}

function resolveLocalStoredValue(value) {
    const normalized = coerceLocalSpecialValue(value);
    const kind = getLocalFieldValueKind(normalized);
    if (kind === 'serverTimestamp') {
        return LocalTimestamp.now();
    }
    if (kind) {
        return normalized;
    }
    if (Array.isArray(normalized)) {
        return normalized.map(resolveLocalStoredValue);
    }
    if (isLocalPlainObject(normalized)) {
        const resolved = {};
        Object.keys(normalized).forEach(key => {
            resolved[key] = resolveLocalStoredValue(normalized[key]);
        });
        return resolved;
    }
    if (normalized instanceof Date) {
        return new Date(normalized.getTime());
    }
    if (normalized instanceof LocalTimestamp) {
        return LocalTimestamp.fromMillis(normalized.toMillis());
    }
    return normalized;
}

class LocalTimestamp {
    constructor(milliseconds) {
        this._milliseconds = Number(milliseconds);
        this.seconds = Math.floor(this._milliseconds / 1000);
        this.nanoseconds = (this._milliseconds % 1000) * 1000000;
    }

    static now() {
        return new LocalTimestamp(Date.now());
    }

    static fromDate(date) {
        return new LocalTimestamp(date.getTime());
    }

    static fromMillis(milliseconds) {
        return new LocalTimestamp(milliseconds);
    }

    toDate() {
        return new Date(this._milliseconds);
    }

    toMillis() {
        return this._milliseconds;
    }

    valueOf() {
        return this._milliseconds;
    }

    toJSON() {
        return { __localType: 'timestamp', ms: this._milliseconds };
    }
}

class LocalMemoryAdapter {
    constructor() {
        this.records = new Map();
    }

    async initialize() {}

    async getDocument(path) {
        return this.records.has(path) ? cloneLocalValue(this.records.get(path)) : null;
    }

    async putDocument(record) {
        this.records.set(record.path, cloneLocalValue(record));
    }

    async deleteDocument(path) {
        this.records.delete(path);
    }

    async getCollection(collectionPath) {
        return Array.from(this.records.values())
            .filter(record => record.collectionPath === collectionPath)
            .map(record => cloneLocalValue(record));
    }
}

class LocalIndexedDbAdapter {
    constructor() {
        this.db = null;
    }

    async initialize() {
        if (this.db || typeof indexedDB === 'undefined') return;
        this.db = await new Promise((resolve, reject) => {
            const request = indexedDB.open(LOCAL_FIREBASE_DB_NAME, LOCAL_FIREBASE_DB_VERSION);
            request.onupgradeneeded = event => {
                const dbInstance = event.target.result;
                if (!dbInstance.objectStoreNames.contains(LOCAL_FIREBASE_DOC_STORE)) {
                    const store = dbInstance.createObjectStore(LOCAL_FIREBASE_DOC_STORE, { keyPath: 'path' });
                    store.createIndex(LOCAL_FIREBASE_COLLECTION_INDEX, LOCAL_FIREBASE_COLLECTION_INDEX, { unique: false });
                }
            };
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error || new Error('IndexedDB open failed.'));
        });
    }

    async getDocument(path) {
        return this._runStore('readonly', store => store.get(path));
    }

    async putDocument(record) {
        return this._runStore('readwrite', store => store.put(record));
    }

    async deleteDocument(path) {
        return this._runStore('readwrite', store => store.delete(path));
    }

    async getCollection(collectionPath) {
        await this.initialize();
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(LOCAL_FIREBASE_DOC_STORE, 'readonly');
            const store = transaction.objectStore(LOCAL_FIREBASE_DOC_STORE);
            const index = store.index(LOCAL_FIREBASE_COLLECTION_INDEX);
            const request = index.getAll(IDBKeyRange.only(collectionPath));
            request.onsuccess = () => resolve(request.result || []);
            request.onerror = () => reject(request.error || new Error('IndexedDB collection read failed.'));
        });
    }

    async _runStore(mode, operation) {
        await this.initialize();
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(LOCAL_FIREBASE_DOC_STORE, mode);
            const store = transaction.objectStore(LOCAL_FIREBASE_DOC_STORE);
            const request = operation(store);
            request.onsuccess = () => resolve(request.result ?? null);
            request.onerror = () => reject(request.error || new Error('IndexedDB operation failed.'));
        });
    }
}

class LocalDocSnapshot {
    constructor(ref, exists, data) {
        this.ref = ref;
        this.id = ref.id;
        this.exists = exists;
        this._data = exists ? cloneLocalValue(data) : undefined;
        this.metadata = { fromCache: false, hasPendingWrites: false };
    }

    data() {
        return this.exists ? cloneLocalValue(this._data) : undefined;
    }
}

class LocalQuerySnapshot {
    constructor(docs, changes) {
        this.docs = docs;
        this._changes = changes || docs.map(doc => ({ type: 'added', doc }));
        this.empty = docs.length === 0;
        this.size = docs.length;
        this.metadata = { fromCache: false, hasPendingWrites: false };
    }

    forEach(callback) {
        this.docs.forEach(callback);
    }

    docChanges() {
        return this._changes.slice();
    }
}

class LocalWriteBatch {
    constructor(shim) {
        this.shim = shim;
        this.operations = [];
    }

    set(docRef, data, options) {
        this.operations.push({ type: 'set', ref: docRef, data, options: options || {} });
        return this;
    }

    update(docRef, data) {
        this.operations.push({ type: 'update', ref: docRef, data });
        return this;
    }

    delete(docRef) {
        this.operations.push({ type: 'delete', ref: docRef });
        return this;
    }

    async commit() {
        for (const operation of this.operations) {
            if (operation.type === 'update') {
                const existing = await this.shim._readRawDocument(operation.ref.path);
                if (!existing) {
                    throw new Error(`Document does not exist: ${operation.ref.path}`);
                }
            }
        }
        for (const operation of this.operations) {
            if (operation.type === 'set') {
                await this.shim._writeDocument(operation.ref.path, operation.data, { merge: !!operation.options.merge, suppressNotify: true });
            } else if (operation.type === 'update') {
                await this.shim._updateDocument(operation.ref.path, operation.data, { suppressNotify: true });
            } else if (operation.type === 'delete') {
                await this.shim._deleteDocument(operation.ref.path, { suppressNotify: true });
            }
        }
        await this.shim._flushListeners();
    }
}

class LocalQuery {
    constructor(shim, collectionPath, constraints) {
        this.shim = shim;
        this.path = collectionPath;
        this.constraints = constraints || {
            filters: [],
            orderBys: [],
            limitValue: null,
            startAfterValue: undefined
        };
    }

    where(field, operator, value) {
        return this._cloneWith({
            filters: [...this.constraints.filters, { field, operator, value }]
        });
    }

    orderBy(field, direction = 'asc') {
        return this._cloneWith({
            orderBys: [...this.constraints.orderBys, { field, direction: direction || 'asc' }]
        });
    }

    limit(limitValue) {
        return this._cloneWith({ limitValue: Number(limitValue) });
    }

    startAfter(value) {
        return this._cloneWith({ startAfterValue: value });
    }

    async get() {
        const docs = await this.shim._runQuery(this.path, this.constraints);
        return new LocalQuerySnapshot(docs);
    }

    onSnapshot(callback, errorCallback) {
        return this.shim._registerQueryListener(this.path, this.constraints, callback, errorCallback);
    }

    _cloneWith(overrides) {
        return new LocalQuery(this.shim, this.path, {
            filters: overrides.filters || this.constraints.filters.slice(),
            orderBys: overrides.orderBys || this.constraints.orderBys.slice(),
            limitValue: Object.prototype.hasOwnProperty.call(overrides, 'limitValue') ? overrides.limitValue : this.constraints.limitValue,
            startAfterValue: Object.prototype.hasOwnProperty.call(overrides, 'startAfterValue') ? overrides.startAfterValue : this.constraints.startAfterValue
        });
    }
}

class LocalCollectionRef extends LocalQuery {
    constructor(shim, collectionPath) {
        super(shim, collectionPath);
    }

    doc(id) {
        return new LocalDocRef(this.shim, `${this.path}/${id || createLocalId()}`);
    }

    async add(data) {
        const docRef = this.doc();
        await docRef.set(data);
        return docRef;
    }
}

class LocalDocRef {
    constructor(shim, documentPath) {
        this.shim = shim;
        this.path = documentPath;
        const segments = documentPath.split('/');
        this.id = segments[segments.length - 1];
    }

    async get() {
        const record = await this.shim._readRawDocument(this.path);
        if (!record) {
            return new LocalDocSnapshot(this, false);
        }
        return new LocalDocSnapshot(this, true, reviveLocalValue(record.data));
    }

    async set(data, options) {
        await this.shim._writeDocument(this.path, data, { merge: !!options?.merge });
    }

    async update(data) {
        await this.shim._updateDocument(this.path, data);
    }

    async delete() {
        await this.shim._deleteDocument(this.path);
    }

    collection(collectionPath) {
        return new LocalCollectionRef(this.shim, `${this.path}/${collectionPath}`);
    }

    onSnapshot(callback, errorCallback) {
        return this.shim._registerDocumentListener(this.path, callback, errorCallback);
    }
}

class LocalFirebaseShim {
    constructor() {
        this.adapter = typeof indexedDB === 'undefined' ? new LocalMemoryAdapter() : new LocalIndexedDbAdapter();
        this.listeners = new Map();
        this.listenerSequence = 0;
    }

    static get FieldValue() {
        return {
            serverTimestamp: () => ({ __localFieldValue: 'serverTimestamp' }),
            delete: () => ({ __localFieldValue: 'delete' }),
            arrayUnion: (...items) => ({ __localFieldValue: 'arrayUnion', items }),
            arrayRemove: (...items) => ({ __localFieldValue: 'arrayRemove', items })
        };
    }

    static get Timestamp() {
        return LocalTimestamp;
    }

    static installFirebaseCompat() {
        if (typeof firebase === 'undefined' || !firebase.firestore) return;
        firebase.firestore.FieldValue = LocalFirebaseShim.FieldValue;
        firebase.firestore.Timestamp = LocalTimestamp;
    }

    async initialize() {
        await this.adapter.initialize();
    }

    collection(collectionPath) {
        return new LocalCollectionRef(this, collectionPath);
    }

    batch() {
        return new LocalWriteBatch(this);
    }

    async _readRawDocument(documentPath) {
        return this.adapter.getDocument(documentPath);
    }

    async _writeDocument(documentPath, payload, options) {
        const rawRecord = await this._readRawDocument(documentPath);
        const baseData = rawRecord ? reviveLocalValue(rawRecord.data) : {};
        const nextData = options?.merge ? cloneLocalValue(baseData) : {};
        Object.keys(payload || {}).forEach(fieldPath => {
            this._applyFieldMutation(nextData, fieldPath, payload[fieldPath]);
        });
        await this.adapter.putDocument(this._createRecord(documentPath, nextData));
        if (!options?.suppressNotify) {
            await this._flushListeners();
        }
    }

    async _updateDocument(documentPath, payload, options) {
        const rawRecord = await this._readRawDocument(documentPath);
        if (!rawRecord) {
            throw new Error(`Document does not exist: ${documentPath}`);
        }
        const nextData = reviveLocalValue(rawRecord.data);
        Object.keys(payload || {}).forEach(fieldPath => {
            this._applyFieldMutation(nextData, fieldPath, payload[fieldPath]);
        });
        await this.adapter.putDocument(this._createRecord(documentPath, nextData));
        if (!options?.suppressNotify) {
            await this._flushListeners();
        }
    }

    async _deleteDocument(documentPath, options) {
        await this.adapter.deleteDocument(documentPath);
        if (!options?.suppressNotify) {
            await this._flushListeners();
        }
    }

    _createRecord(documentPath, data) {
        const segments = documentPath.split('/');
        return {
            path: documentPath,
            collectionPath: segments.slice(0, -1).join('/'),
            docId: segments[segments.length - 1],
            data: serializeLocalValue(data)
        };
    }

    _applyFieldMutation(target, fieldPath, rawValue) {
        const normalizedValue = coerceLocalSpecialValue(rawValue);
        const kind = getLocalFieldValueKind(normalizedValue);

        if (kind === 'delete') {
            deleteLocalValueAtPath(target, fieldPath);
            return;
        }

        if (kind === 'arrayUnion' || kind === 'arrayRemove') {
            const existingValue = getLocalValueAtPath(target, fieldPath);
            const currentArray = Array.isArray(existingValue) ? existingValue.slice() : [];
            const items = (normalizedValue.items || []).map(item => resolveLocalStoredValue(item));
            const nextArray = kind === 'arrayUnion'
                ? this._applyArrayUnion(currentArray, items)
                : this._applyArrayRemove(currentArray, items);
            setLocalValueAtPath(target, fieldPath, nextArray);
            return;
        }

        setLocalValueAtPath(target, fieldPath, resolveLocalStoredValue(normalizedValue));
    }

    _applyArrayUnion(existingArray, items) {
        const nextArray = existingArray.slice();
        items.forEach(item => {
            const hasMatch = nextArray.some(existing => stableLocalStringify(existing) === stableLocalStringify(item));
            if (!hasMatch) {
                nextArray.push(item);
            }
        });
        return nextArray;
    }

    _applyArrayRemove(existingArray, items) {
        const removalKeys = new Set(items.map(item => stableLocalStringify(item)));
        return existingArray.filter(item => !removalKeys.has(stableLocalStringify(item)));
    }

    async _runQuery(collectionPath, constraints) {
        const records = await this.adapter.getCollection(collectionPath);
        let entries = records.map(record => ({
            id: record.docId,
            path: record.path,
            data: reviveLocalValue(record.data)
        }));

        for (const filter of constraints.filters || []) {
            entries = entries.filter(entry => this._matchesFilter(entry.data, filter));
        }

        if ((constraints.orderBys || []).length > 0) {
            entries.sort((left, right) => this._compareEntries(left.data, right.data, constraints.orderBys));
        }

        if (constraints.startAfterValue !== undefined) {
            entries = this._applyStartAfter(entries, constraints);
        }

        if (typeof constraints.limitValue === 'number' && constraints.limitValue >= 0) {
            entries = entries.slice(0, constraints.limitValue);
        }

        return entries.map(entry => new LocalDocSnapshot(new LocalDocRef(this, entry.path), true, entry.data));
    }

    _matchesFilter(data, filter) {
        const left = normalizeComparableValue(getLocalValueAtPath(data, filter.field));
        const right = normalizeComparableValue(coerceLocalSpecialValue(filter.value));
        switch (filter.operator) {
            case '==': return stableLocalStringify(left) === stableLocalStringify(right);
            case '!=': return stableLocalStringify(left) !== stableLocalStringify(right);
            case '>': return left > right;
            case '>=': return left >= right;
            case '<': return left < right;
            case '<=': return left <= right;
            default: throw new Error(`Unsupported query operator: ${filter.operator}`);
        }
    }

    _compareEntries(leftData, rightData, orderBys) {
        for (const orderBy of orderBys) {
            const leftValue = normalizeComparableValue(getLocalValueAtPath(leftData, orderBy.field));
            const rightValue = normalizeComparableValue(getLocalValueAtPath(rightData, orderBy.field));
            if (leftValue === rightValue) continue;
            if (leftValue === undefined) return orderBy.direction === 'desc' ? 1 : -1;
            if (rightValue === undefined) return orderBy.direction === 'desc' ? -1 : 1;
            if (leftValue > rightValue) return orderBy.direction === 'desc' ? -1 : 1;
            if (leftValue < rightValue) return orderBy.direction === 'desc' ? 1 : -1;
        }
        return 0;
    }

    _applyStartAfter(entries, constraints) {
        const orderBy = (constraints.orderBys || [])[0];
        const cursorValue = constraints.startAfterValue instanceof LocalDocSnapshot
            ? getLocalValueAtPath(constraints.startAfterValue.data(), orderBy?.field)
            : constraints.startAfterValue;
        const normalizedCursor = normalizeComparableValue(coerceLocalSpecialValue(cursorValue));

        if (!orderBy) {
            return entries.filter(entry => entry.id !== cursorValue?.id);
        }

        return entries.filter(entry => {
            const value = normalizeComparableValue(getLocalValueAtPath(entry.data, orderBy.field));
            return orderBy.direction === 'desc' ? value < normalizedCursor : value > normalizedCursor;
        });
    }

    _registerQueryListener(collectionPath, constraints, callback, errorCallback) {
        return this._registerListener({
            type: 'query',
            collectionPath,
            constraints,
            callback,
            errorCallback
        });
    }

    _registerDocumentListener(documentPath, callback, errorCallback) {
        return this._registerListener({
            type: 'document',
            documentPath,
            callback,
            errorCallback
        });
    }

    _registerListener(listener) {
        const listenerId = `listener-${++this.listenerSequence}`;
        this.listeners.set(listenerId, { ...listener, previousDocs: null, previousDocSnapshot: null });
        this._dispatchListener(listenerId).catch(error => {
            if (typeof listener.errorCallback === 'function') {
                listener.errorCallback(error);
            }
        });
        return () => this.listeners.delete(listenerId);
    }

    async _flushListeners() {
        const listenerIds = Array.from(this.listeners.keys());
        for (const listenerId of listenerIds) {
            await this._dispatchListener(listenerId);
        }
    }

    async _dispatchListener(listenerId) {
        const listener = this.listeners.get(listenerId);
        if (!listener) return;

        try {
            if (listener.type === 'document') {
                const rawRecord = await this._readRawDocument(listener.documentPath);
                const snapshot = rawRecord
                    ? new LocalDocSnapshot(new LocalDocRef(this, listener.documentPath), true, reviveLocalValue(rawRecord.data))
                    : new LocalDocSnapshot(new LocalDocRef(this, listener.documentPath), false);
                const hasChanged = !listener.previousDocSnapshot
                    || stableLocalStringify(listener.previousDocSnapshot.data()) !== stableLocalStringify(snapshot.data())
                    || listener.previousDocSnapshot.exists !== snapshot.exists;
                if (hasChanged) {
                    listener.callback(snapshot);
                    listener.previousDocSnapshot = snapshot;
                }
                return;
            }

            const docs = await this._runQuery(listener.collectionPath, listener.constraints);
            const changes = this._buildDocChanges(listener.previousDocs, docs);
            if (!listener.previousDocs || changes.length > 0) {
                listener.callback(new LocalQuerySnapshot(docs, changes));
                listener.previousDocs = docs;
            }
        } catch (error) {
            if (typeof listener.errorCallback === 'function') {
                listener.errorCallback(error);
                return;
            }
            throw error;
        }
    }

    _buildDocChanges(previousDocs, nextDocs) {
        if (!previousDocs) {
            return nextDocs.map(doc => ({ type: 'added', doc }));
        }

        const previousMap = new Map(previousDocs.map(doc => [doc.id, doc]));
        const nextMap = new Map(nextDocs.map(doc => [doc.id, doc]));
        const changes = [];

        nextDocs.forEach(doc => {
            const previousDoc = previousMap.get(doc.id);
            if (!previousDoc) {
                changes.push({ type: 'added', doc });
                return;
            }
            if (stableLocalStringify(previousDoc.data()) !== stableLocalStringify(doc.data())) {
                changes.push({ type: 'modified', doc });
            }
        });

        previousDocs.forEach(doc => {
            if (!nextMap.has(doc.id)) {
                changes.push({ type: 'removed', doc });
            }
        });

        return changes;
    }
}

if (typeof globalThis !== 'undefined') {
    globalThis.LocalFirebaseShim = LocalFirebaseShim;
    globalThis.LocalTimestamp = LocalTimestamp;
}

if (
    typeof globalThis !== 'undefined' &&
    typeof firebase !== 'undefined' &&
    firebase.firestore &&
    typeof __firebase_config === 'undefined'
) {
    LocalFirebaseShim.installFirebaseCompat();
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { LocalFirebaseShim, LocalTimestamp };
}
