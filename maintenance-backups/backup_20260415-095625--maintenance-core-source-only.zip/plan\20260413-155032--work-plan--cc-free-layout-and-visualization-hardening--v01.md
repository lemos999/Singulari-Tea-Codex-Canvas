Plan Type: Work Plan
Workstream: Universal `.cc` module freedom update and active visualization hardening
Version: v01
Status: Completed
Created: 2026-04-13 15:50:32 +09:00
Last Updated: 2026-04-13 16:05:30 +09:00
Supersedes or Related Plan: Related `plan/20260413-145000--work-plan--cc-single-trigger-unification--v01.md`; Related `plan/20260413-160500--cc-single-trigger-unification-report--v01.md`
Current Completion State: Complete. The active English prompt was rewritten, `.ccc` references were removed, freer `.cc` mounted-layout guidance was added, active visual-support rules were strengthened, `/sub` implementation and validation completed, and parent verification captured runtime-oriented evidence.
Completed So Far: Re-read the active prompt module, re-read the workspace plan-first contract, re-read the `/sub` orchestration workflow, inspected the current runtime composition code, confirmed that the runtime preserves a persistent core shell with header/chat/notes support while allowing freer mounted-content layout, wrote the approved `/sub` run kit, launched an implementer and a validator worker, landed the prompt rewrite in `cc_universal_module_mm.md`, removed remaining `.ccc` contract language, added freer mounted-layout guidance using `data-shell-layout=\"free\"` and `data-cc-layout=\"free\"`, strengthened active visual-support language, created a runtime free-layout visual fixture, and captured file-based screenshot evidence.
Remaining Work: No required implementation work remains in this plan. Optional future work would focus on parity updates for translation files or deeper automated browser instrumentation if the environment later exposes a reliable headless DOM-inspection path.
Current Blockers: No active blocker. The only remaining caveat is that localhost-driven headless browser validation was unreliable in this environment, so final runtime evidence used a `file://` fixture path instead.
Next Step: Report the completed prompt rewrite, `/sub` findings, and runtime evidence to the user.

# Scoreboard

Current Score: 50 / 100
Score Source: provisional
Last Updated: 2026-04-13 15:50:32 +09:00
Score Rationale: The work is complete and the result is materially stronger, but the local score must remain at or below the provisional cap because the user has not provided an explicit score yet.
What Improved:
1. The user gave explicit approval for the new coding direction.
2. The scope is now sharper than before: remove `.ccc` traces, reflect freer `.cc` composition, preserve always-on header/chat/notes support, and use visual materials more aggressively.
3. The runtime-side composition work already done earlier gives a real technical basis for the prompt rewrite rather than speculation.
What Remains Unsatisfactory:
1. The Korean translation file still reflects the older dual-mode worldview and was intentionally left untouched in this pass.
2. Headless localhost browser validation was unreliable in this environment, so the strongest runtime proof came from `file://` fixture rendering rather than a clean networked DOM dump.
Actions To Raise Or Maintain The Score:
1. Preserve the single-trigger `.cc` contract in future edits.
2. Keep the persistent runtime shell wording aligned with actual runtime behavior.
3. Maintain the stronger active visual-support default without drifting into reckless multi-placeholder overuse.
4. Update translated or mirrored module variants only if the user asks for parity.

Score History:
1. 2026-04-13 15:50:32 +09:00 | score 50 | source provisional | New approved workstream opened for `.ccc` removal, freer `.cc` composition guidance, and stronger active visual-support rules after the user explicitly approved proceeding.
2. 2026-04-13 16:05:30 +09:00 | score 50 | source provisional | Prompt rewrite completed, `/sub` validation passed with hard constraints, and runtime-oriented free-layout fixture evidence was captured. The score remains capped only because no explicit user score has been provided.

# Objective

Revise the active English universal canvas module so it fully reflects the current unified `.cc` product direction. The revised file should no longer contain public-contract language for `.ccc`, should stop describing legacy normalization behavior as part of the active surface contract, should describe `.cc` as a single composable canvas trigger that can support stronger layout freedom inside the persistent runtime shell, and should increase the expected use of visual support materials such as image and visualization placeholders.

This is not merely a copy-edit. The goal is to align three things that currently sit slightly out of sync:

1. the prompt contract,
2. the runtime behavior,
3. the user’s intended product philosophy.

The user’s philosophy is now clear. `.cc` should be the one thing they need to teach, remember, and distribute. The runtime should always preserve the top header, chat, and notes surfaces, but the content area should have more freedom than the older prompt implied. Visual materials should not be treated as fragile decorations to be avoided by default. They should be used actively and deliberately whenever they genuinely help the page communicate.

# Confirmed Facts

The active file is `cc_universal_module_mm.md`.

The user explicitly requested that because `.ccc` has been integrated, the `.ccc` language should be removed.

The user explicitly requested that `.cc` now be reflected as something that can be used more freely.

The user explicitly clarified that the runtime should still always support the top header, chat, and note surfaces.

The earlier runtime refactor established a persistent core shell and a freer content mount path. The runtime code now detects free-layout intent through a content attribute pattern and mounts the content without forcing the older centered wrapper in those cases.

The same runtime still exposes `renderAppShell(...)` as the compatibility entry point used by the canonical external shell.

The current prompt file still contains these stale elements:

1. wording about legacy `.ccc` normalization,
2. wording that implies all `.cc` freedom exists only as conservative interior styling under one narrow canonical content shape,
3. wording that does not yet describe the newer freer content-layout possibility inside the runtime shell,
4. visual-support guidance that is active but still slightly more cautious than the user now wants.

# Working Assumptions

The smallest safe assumption is that the user does not want to reintroduce a second public trigger in any form. Therefore the new prompt should not preserve `.ccc` as a compatibility instruction, alias, fallback, or documented public synonym in the active file. If backward compatibility is still needed elsewhere, that is a different file or a host-side concern, not part of this active user-facing module contract.

The safest assumption is that the prompt should still preserve the canonical external bootstrap shell exactly enough to remain compatible with the deployed runtime, because that shell continues to be the delivery envelope expected by the GitHub-hosted bundle. However, the prompt no longer needs to imply that the mounted content itself must always look like the older narrow wrapper-based layout.

The safest assumption about freedom is therefore not “replace the shell freely,” but “allow the mounted content payload to declare freer layout intent and richer composition while the runtime still keeps the always-on shell surfaces.” This matches the current runtime more closely than either of the older extremes.

The safest assumption about header, chat, and notes is that these are runtime-owned persistent surfaces, not authorable content units. The prompt should therefore preserve them as part of the runtime environment and avoid language that would suggest suppressing or replacing them in ordinary `.cc` output.

The safest assumption about visual support is that the user wants a stronger default expectation, not reckless overuse. The prompt should therefore intensify the expectation for authored visual support while still preserving a runtime-aware downgrade path that favors readability over broken dominance.

# Design Intent

The revised module should define `.cc` as a single-trigger, host-faithful, runtime-compatible, visually assertive canvas contract with these four layers:

1. Activation layer
`.cc` is the only public trigger. No `.ccc` branch, no normalization prose, and no second-mode explanation should remain in the active English module.

2. Semantic layer
The frozen host answer still owns facts, order, pacing, omission states, UI presence, and closing position. The canvas layer remains a transport and rendering layer rather than a second author.

3. Runtime layer
The result still targets the canonical runtime bootstrap, but the mounted content is now allowed to use a freer layout contract inside the persistent runtime shell when the answer benefits from it. The runtime-owned top header, chat, notes, and shared shell surfaces remain available and should not be conceptually discarded by the prompt.

4. Visual-support layer
The prompt should actively encourage at least one deliberate visual support surface for most suitable explanatory pages, and should be more willing than before to use a second support surface when the subject truly warrants it and the reading spine remains strong.

# Planned Prompt Changes

The rewrite should make a focused set of changes and no more.

## 1. Trigger contract cleanup

The opening paragraph should be rewritten so it simply states that `.cc` is the public trigger. It should remove the sentence about legacy `.ccc` normalization entirely. The trigger text should still say that the control token is stripped before host semantic parsing and that no trigger means normal plain-text host behavior.

This change matters because even mentioning legacy normalization in the active file continues to preserve `.ccc` as a living public concept. The user’s new requirement is stricter than simple unification. They want the active module to stop teaching `.ccc` at all.

## 2. Shell and runtime contract realignment

The current shell section should stop implying that all freedom exists only as conservative content styling inside a single fixed centered composition shape. The outer bootstrap shell remains canonical, but the content-mount rules should explicitly acknowledge the persistent runtime shell.

The new wording should establish that:

1. the canonical `.cc` bootstrap remains exact,
2. the runtime may mount the content into a persistent core shell that keeps header, chat, notes, and other shared surfaces alive,
3. the generated content should therefore focus on the payload inside `#ai-content-placeholder`,
4. and the payload may declare a freer layout intent when the answer needs a more expansive presentation.

To stay aligned with the runtime already present in the workspace, the prompt should authorize a layout signal such as `data-shell-layout="free"` or `data-cc-layout="free"` on the mounted content root when a host-light explanation, scene page, route explanation, or other visual-first subject benefits from freer composition.

This should not become a vague promise of anything-goes HTML takeover. The prompt should make clear that free-layout freedom exists inside the content mount and under the persistent core shell, not as permission to remove the runtime-owned header/chat/notes environment or to switch to an unrelated external standalone page system.

## 3. Content-shape freedom clarification

The current module already has strong explanatory fallback rules, but it still leans toward a relatively house-style article surface. The rewrite should keep the value of honest headings, chips, summaries, and sections while clarifying that host-light `.cc` artifacts may choose more varied composition patterns.

Examples of composition patterns the prompt should now allow, when justified by the subject:

1. article-like flow,
2. split visual-and-explainer hero,
3. route or chronology narrative,
4. concept map sectioning,
5. gallery-like sectional groupings,
6. dashboard-style grouped surfaces,
7. wide explanatory banded layouts,
8. immersive scene-led openings.

The important constraint is that this freedom remains subject-driven and host-faithful. The prompt should not collapse into “make it pretty however you want.” It should explain that the page may be bold, asymmetrical, and wide, but only insofar as that structure helps preserve and illuminate the frozen host answer.

## 4. Active visualization hardening

The existing visual-support section is already decent, but this pass should make it more assertive in both wording and decision logic.

The revised prompt should explicitly say that suitable `.cc` explanations normally deserve visual support, and that omission of a support surface should be an exception that needs a concrete justification such as readability harm, runtime instability that cannot be safely degraded, or strong host instructions against additional support.

It should also clarify preferred strategies by subject shape:

1. spatial or place-heavy subjects should usually get at least one image or map-like support,
2. route or chronology-heavy subjects should usually get at least one journey, sequence, or era-defining support surface,
3. system, protocol, and process-heavy subjects should usually get at least one structured or diagram-like support surface,
4. comparative subjects should strongly consider one contrast-focused support surface,
5. iconic-scene subjects should strongly consider one authored scene image.

The downgrade logic should remain but become “reduce fragility before reducing ambition.” That means:

1. choose safer placement before removing support,
2. choose a richer image placeholder before abandoning the visual idea,
3. preserve at least one meaningful support unit whenever possible,
4. allow a second unit only when it clearly helps more than it harms.

## 5. Self-check refresh

The self-check at the end should be updated so it no longer mentions `.ccc` normalization. Instead it should verify:

1. `.cc` is the only public trigger,
2. the trigger token remained out-of-band,
3. the frozen host answer remained the only semantic source,
4. the canonical runtime bootstrap remained compatible,
5. freer layout signals were used only when justified,
6. runtime-owned persistent shell surfaces were not conceptually erased,
7. host-defined unit order remained intact,
8. no invented sections appeared outside the fallback allowance,
9. terminal and omission states were preserved,
10. and visual support was actively used whenever the subject clearly warranted it unless a concrete downgrade reason existed.

# `/sub` Execution Strategy

This run should use supervised internal delegation because the user explicitly asked for `/sub` and explicitly asked for a harsh maximum-reasoning test.

The team should stay small and serial because the writable surface is effectively one file and the acceptance story is easier when the edit is produced once and then challenged by a separate read-only validator.

Planned execution shape:

1. One implementation-oriented worker proposes the rewritten prompt contract for `cc_universal_module_mm.md`.
2. One read-only validation worker audits the revised prompt against the runtime reality and the user’s intent, and proposes harsh test cases plus failure checks.
3. The parent lands the accepted edits into the primary workspace.
4. The parent runs local verification, including content inspection and runtime-oriented fixture checks.

This is a serial run overall with a late validation stage, so the execution mode should be reported as `serial`.

# Validation Strategy

Validation must be much stronger than a simple text diff because the user explicitly asked for something like “test it hard.”

The validation should include all of the following:

## A. Contract audit

Read the revised file and confirm that:

1. no active `.ccc` command or normalization language remains,
2. the opening section now cleanly presents `.cc` as the only public trigger,
3. the freer composition model is clearly described,
4. the always-on runtime shell surfaces are not contradicted,
5. the visual-support rules are more assertive than before.

## B. Runtime-alignment audit

Cross-check the revised prompt text against the actual runtime composition code. The prompt must not promise a full standalone-shell freedom that the runtime no longer wants, and it must not deny the freer content-layout path that the runtime now supports.

The validator should specifically challenge these possible failure modes:

1. prompt says freedom but still locks content into the old narrow wrapper concept,
2. prompt says freedom in a way that implies it may remove the persistent shell,
3. prompt allows attributes or layout signals the runtime does not actually read,
4. prompt overstates visualization support without keeping a downgrade path.

## C. Harsh subject-based test matrix

The validation should test hypothetical output guidance against multiple subject types. At minimum:

1. a historical route topic,
2. an astronomy or cosmic structure topic,
3. a protocol or networking topic,
4. a biological process topic,
5. an architectural or place-heavy topic,
6. a comparative analysis topic.

The test should ask whether the new prompt would actively steer the artifact toward:

1. stronger but still host-faithful structure,
2. free-layout use when appropriate,
3. at least one deliberate visual support surface,
4. restrained fallback behavior when runtime risk appears.

## D. Free-layout compatibility fixture check

Because the runtime now supports a freer mounted-content path, the parent should also verify that a representative fixture using the sanctioned layout signal still mounts correctly under the current bundle and does not suppress the top header/chat/notes shell.

This check does not prove the prompt generates perfect output on its own, but it does prove that the new prompt contract is describing something the runtime can genuinely accept.

# Risks

The biggest risk is semantic overshoot. In trying to make `.cc` feel freer, the prompt could accidentally imply that the content generator is allowed to discard runtime-owned shell surfaces or swap in a totally different bootstrap. That would contradict the user’s insistence that top header, chat, and notes remain always supported.

The second risk is under-correction. If the text only removes `.ccc` references without meaningfully changing the freedom guidance, the user’s core complaint will remain unsolved.

The third risk is over-aggressive visualization wording. If the prompt pushes `visualization-placeholder` too hard in every case without respecting runtime instability, the artifact may once again create blocked or awkward pages.

The fourth risk is prompt bloat. This file is already dense. The rewrite must improve clarity, not only add new paragraphs.

# Definition Of Done

This work is done when all of the following are true:

1. `cc_universal_module_mm.md` no longer contains public `.ccc` or legacy-normalization language.
2. The prompt clearly states that `.cc` is the single public trigger.
3. The prompt reflects the current model of a persistent runtime shell with always-on header, chat, and notes support.
4. The prompt explicitly allows freer mounted-content composition, including a sanctioned free-layout signal, without promising shell replacement.
5. The prompt uses stronger active-visualization language than before.
6. A `/sub` validation pass challenges the rewrite and produces evidence on disk.
7. Parent verification confirms the final file is internally consistent and aligned with the current runtime.

# Implementation Notes

The change should stay surgical. The only required user-facing prompt file change is `cc_universal_module_mm.md`. Test artifacts, plan artifacts, and `/sub` evidence files are allowed as supporting changes. The Korean translation file should not be edited in this pass unless the user later asks for parity.

The rewrite should favor replacement and tightening over sprawling additive duplication. If a paragraph can be rewritten to carry the new truth more clearly than appending an exception clause, rewriting is preferred.

The final summary to the user should provide:

1. what changed in the prompt contract,
2. how the freer `.cc` model is now framed,
3. how visual-support rules were strengthened,
4. what `/sub` validation did,
5. and any remaining caveat that still belongs to runtime rather than prompt text.
