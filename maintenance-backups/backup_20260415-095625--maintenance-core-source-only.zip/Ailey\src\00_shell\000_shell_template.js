/* --- Ailey & Bailey Canvas --- */
// File: 000_shell_template.js
// Version: 9.4
// Description: Upper-right dock with GitHub, support, live export, notes, chat, and theme actions.

const SHELL_PART_1 = `
    <header id="immersive-header" aria-label="빠른 도구">
        <div class="fixed-tool-container controls-disabled">
            <div class="loader-text">로딩 중...</div>
            <a class="tool-button external-tool-button" id="github-profile-link" href="https://github.com/lemos999" target="_blank" rel="noopener noreferrer" title="GitHub 열기" aria-label="GitHub 열기">
                <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor" aria-hidden="true"><path d="M12,2A10,10 0 0,0 2,12C2,16.42 4.87,20.17 8.84,21.5C9.34,21.58 9.5,21.27 9.5,21V19.31C6.73,19.91 6.14,17.97 6.14,17.97C5.68,16.81 5.03,16.5 5.03,16.5C4.12,15.88 5.1,15.89 5.1,15.89C6.1,15.96 6.63,16.92 6.63,16.92C7.53,18.45 8.97,18 9.54,17.76C9.63,17.11 9.89,16.67 10.18,16.42C7.97,16.17 5.65,15.31 5.65,11.5C5.65,10.39 6.04,9.5 6.69,8.79C6.59,8.54 6.24,7.5 6.79,6.15C6.79,6.15 7.63,5.88 9.5,7.15C10.29,6.93 11.15,6.82 12,6.82C12.85,6.82 13.71,6.93 14.5,7.15C16.36,5.88 17.2,6.15 17.2,6.15C17.76,7.5 17.41,8.54 17.31,8.79C17.96,9.5 18.35,10.39 18.35,11.5C18.35,15.32 16.02,16.16 13.81,16.41C14.17,16.72 14.5,17.33 14.5,18.27V21C14.5,21.27 14.66,21.59 15.17,21.5C19.14,20.17 22,16.42 22,12A10,10 0 0,0 12,2Z"></path></svg>
            </a>
            <a class="tool-button external-tool-button" id="support-link" href="https://ctee.kr/place/fewweekslater" target="_blank" rel="noopener noreferrer" title="후원 링크 열기" aria-label="후원 링크 열기">
                <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor" aria-hidden="true"><path d="M2,21H20V19H2V21M18,8H20A2,2 0 0,1 22,10V13A2,2 0 0,1 20,15H18V16A3,3 0 0,1 15,19H7A3,3 0 0,1 4,16V6H18V8M18,13H20V10H18V13M6,2H16V4H6V2Z"></path></svg>
            </a>
            <button class="tool-button" id="export-main-content-btn" type="button" title="라이브 HTML로 내보내기" aria-label="라이브 HTML로 내보내기">
                <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z"></path></svg>
            </button>
            <div class="tool-button" id="notes-app-toggle-btn" title="노트 열기 또는 닫기" aria-label="노트 열기 또는 닫기">
                <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M17,4V10L15,8L13,10V4H6A2,2 0 0,0 4,6V18A2,2 0 0,0 6,20H18A2,2 0 0,0 20,18V6A2,2 0 0,0 18,4H17Z" /></svg>
            </div>
            <div class="tool-button" id="chat-toggle-btn" title="채팅 열기 또는 닫기" aria-label="채팅 열기 또는 닫기">
                <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M18,14V11H16V14H13V16H16V19H18V16H21V14M12,2C6.5,2 2,6.5 2,12C2,17.5 6.5,22 12,22C13.2,22 14.4,21.8 15.5,21.3C15.9,21.9 16.5,22.4 17.2,22.7L19,23.5V21.1C20.2,20.1 21.1,18.8 21.7,17.3C21.9,16.5 22,15.8 22,15C22,8.4 17.6,2 12,2Z" /></svg>
            </div>
            <div class="tool-button" id="theme-toggle" title="테마 전환" aria-label="테마 전환">
                <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M12,18V22H10V18H12M12,2V6H10V2H12M22,12H18V10H22V12M6,12H2V10H6V12M16.95,7.05L19.78,4.22L18.36,2.81L15.54,5.64L16.95,7.05M8.46,15.54L5.64,18.36L4.22,16.95L7.05,14.12L8.46,15.54M18.36,21.19L19.78,19.78L16.95,16.95L15.54,18.36L18.36,21.19M7.05,8.46L4.22,5.64L5.64,4.22L8.46,7.05L7.05,8.46M12,7A5,5 0 0,0 7,12A5,5 0 0,0 12,17A5,5 0 0,0 17,12A5,5 0 0,0 12,7Z" /></svg>
            </div>
        </div>
    </header>
`;
