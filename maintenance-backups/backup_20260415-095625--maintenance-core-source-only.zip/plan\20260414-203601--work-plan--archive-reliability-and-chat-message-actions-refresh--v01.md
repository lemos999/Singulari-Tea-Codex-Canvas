Plan Type: work-plan
Workstream: Archive Reliability and Chat Message Actions Refresh
Version: v01
Status: Completed
Created: 2026-04-14 20:36:01 +09:00
Last Updated: 2026-04-14 21:19:40 +09:00
Supersedes or Related Plan: Related to prior notes/archive stabilization passes and recent mobile/runtime UI refinements; no direct superseded active plan for this workstream.
Current Completion State: Implementation, verification, review, and publish completed. The rebuilt bundle is on the publish repository and the workstream is closed unless the user asks for follow-up refinement or rollback.
Completed So Far: Confirmed user intent and mobile requirements, reproduced the archive divergence with the two real download fixtures, proved that the failing rainstorm export truncated during HTML-to-Markdown conversion rather than during later persistence, patched the generic converter so text-heavy div/span structures and tables survive even in visualization-heavy live-export HTML, moved HTML-source note writes to serialized replace semantics for safer persistence, redesigned the chat message action surface into an anchored action pill, added clipboard-first copy with graceful fallback, fixed delete/regenerate sequencing for both temporary and persisted sessions, hardened desktop hover-to-toolbar behavior so moving onto the action surface no longer hides it mid-click, rebuilt the runtime bundle, validated archive and action behavior through a dedicated browser harness, and published the verified bundle to the GitHub Pages repository.
Remaining Work: None inside the approved scope.
Current Blockers: None.
Next Step: Wait for user acceptance or follow-up requests, with rollback still small because the change surface stayed bounded.

# Scoreboard

- Current Score: 50
- Score Source: provisional
- Last Updated: 2026-04-14 21:19:40 +09:00
- Score Rationale: The implementation and verification are complete and locally green, but the user has not supplied a new explicit score for this workstream, so the provisional score remains capped. The evidence quality is now much stronger than at planning time.
- What Improved: The archive converter now preserves the later sections that were previously lost in the rainstorm export, HTML-source archiving uses serialized note replacement, message actions are refreshed for desktop/canvas/mobile, copy prefers direct clipboard writes, and delete/regenerate are verified for both temporary and persisted session paths.
- What Remains Unsatisfactory: No local blocker remains. The only outstanding state change is publish completion and the user’s own acceptance score.
- Actions To Raise Or Maintain Score: Publish the verified bundle cleanly, report the validation artifacts clearly, and keep rollback simple by limiting the change surface to the archiver and chat message-action files.
- Score History:
  - 2026-04-14 20:36:01 +09:00 | score=50 | source=provisional | Initial approved plan state for the archive reliability plus message-action refresh workstream.
  - 2026-04-14 20:39:19 +09:00 | score=50 | source=provisional | Scope refined to require mobile-ready message actions as part of the same workstream; score unchanged because implementation and verification have not started yet.
  - 2026-04-14 21:14:30 +09:00 | score=50 | source=provisional | Implementation and verification complete with green local evidence; score remains capped until the user supplies a new explicit rating.
  - 2026-04-14 21:19:40 +09:00 | score=50 | source=provisional | Publish completed cleanly after green verification; score remains capped because no new explicit user score has been given for this workstream.

# Objective

Deliver one bounded reliability pass that makes note archiving succeed across both lightweight and visualization-heavy exported HTML documents, while also refreshing the chat message action surface so copy, delete, and regenerate are easier to use and behave correctly in local runtime, canvas-mounted runtime, and mobile layouts. The goal is not to redesign the entire note system or the entire chat renderer. The goal is to fix the real reliability boundary: a user should be able to archive exported HTML into notes without losing large sections or stopping mid-document, and a user should be able to act on messages without fighting clipping, z-index, modal friction, mobile awkwardness, or broken action behavior.

This plan deliberately treats archive reliability and chat message actions as two related but separate surfaces. They are related because both live inside the same runtime shell and both have visible quality debt from earlier iterations. They must still be solved independently enough that a regression in one does not hide the source of the other. The implementation should avoid decorative cleanup, avoid speculative abstraction, and keep rollback easy.

# Confirmed Facts

The user has supplied two concrete archive fixtures. The file `C:\Users\Lemos\Downloads\폭풍우 기상 시스템 (The Rainstorm) (4).html` is the failing or partially archived case. The file `C:\Users\Lemos\Downloads\[태양의 자녀들] 태양계 행성의 분류와 기원.html` is the successful comparison case. The failing file is much larger and includes hydrated visualization block data rather than only lightweight placeholder structures. That difference matters because the current archive converter appears to have been evolved incrementally across multiple export generations.

The current archive conversion surface appears to center on `Ailey/src/03_core/130_core_archiver.js`, especially `handleHtmlSourceArchiving(...)` and `convertHtmlToMarkdown(...)`. Existing logic already tries to find exported content inside `template#exported-content`, `#ai-content-placeholder`, `main`, or `body`. It also has a mixed strategy that uses both host-structure-specific extraction and a more generic traversal fallback. This is a clue that current behavior may already be inconsistent between different export shapes.

The current chat message action surface appears to center on `Ailey/src/04_features_chat/225_chat_ui_messages_toolbar.js`, with copy/delete/regenerate behaviors in `Ailey/src/04_features_chat/211_chat_actions.js` and old toolbar visuals in `Ailey/src_css/009_message_toolbar.css`. The copy flow currently depends on a legacy copy modal instead of preferring direct clipboard use where possible. The toolbar itself is positioned as a side-floating absolute element with low z-index assumptions that do not match newer canvas and overlay contexts.

Mobile support is now part of the accepted direction for the message-action workstream. That means any solution that depends solely on hover or assumes generous desktop pointer precision is insufficient even if it looks correct on a laptop. The chosen design must preserve mouse friendliness while also remaining discoverable and usable on touch screens.

# Smallest Safe Assumptions

The safest working assumption for the archive bug is that the failing HTML is not fundamentally unsupported, but that the current conversion path either skips or aborts after encountering one of the following: large embedded block data, hydrated visualization containers, deeply nested live-export content surfaces, or one of the generic traversal filters. This assumption is safer than assuming note storage limits, because the comparison file succeeds and the user describes a partial archive rather than a complete crash.

The safest working assumption for message actions is that the core semantic operations already exist, but the interaction model and layering contract are too old for the current shell. This means the preferred repair is likely a UI and behavior hardening pass rather than a full rewrite of how messages are stored or streamed.

The safest working assumption for mobile is that the same semantic actions should remain available, but their presentation cannot depend on hover-only reveal. The smallest safe design will likely reuse the same action handlers while giving the mobile shell a more explicit affordance.

# Scope

In scope:

- reproducing the archive truncation behavior locally using the two provided HTML fixtures
- improving the archive extraction path so it preserves content consistently across lightweight and visualization-heavy exported HTML
- preserving existing successful archive behavior for already-working export formats
- refreshing the chat message action toolbar for local runtime, canvas runtime, and mobile
- making copy easy and direct where clipboard APIs are available
- ensuring delete and regenerate continue to work correctly after the UI refresh
- making the refreshed action surface usable when hover is not available
- adding focused verification artifacts for both archive conversion and message-action behavior

Out of scope for this pass unless the findings make it unavoidable:

- rewriting the full note data model
- changing the narrative archiving contract unless archive correctness demands it
- redesigning the entire chat message card system
- changing model provider behavior, streaming transport, or unrelated message rendering
- adding new message actions beyond copy, delete, and regenerate
- sweeping refactors of unrelated archive helpers or shell chrome

# Hidden Rules And Consistency Requirements

The result must feel complete, which means more than “the code runs.” Archive reliability has hidden rules. If a document exports through different shells but still represents the same visible learning content, archiving should not behave differently only because one version serialized a visualization block and another left a placeholder. The user’s intent is “archive the content,” not “archive only the simple formats.” That means extraction must focus on canonical content roots and robust content-unit handling, not fragile assumptions about one export generation.

Similarly, the message action surface has hidden UX rules. On canvas, a floating action strip that ends up under adjacent layers is effectively broken even if the click handlers technically exist. Copy that opens a modal when direct clipboard copy is possible adds friction and makes the feature feel older than the surrounding runtime. Delete and regenerate must remain easy to discover, but also must not unexpectedly vanish behind clipped ancestors or overlap in ways that make the action unsafe. The user explicitly asked for easy copying, correct z-index, and reliable action behavior, so the refresh must improve both the visuals and the execution path.

Mobile adds another hidden rule: the message actions cannot depend entirely on hover reveal. If the actions are technically present but require an interaction pattern that touch users cannot reliably perform, the feature is still functionally broken. The mobile presentation should therefore be explicit enough to discover and use, but not so heavy that every message turns into a cluttered action dashboard.

Because the user warned that rollback may be needed if the patch is not right, rollback safety is a first-class constraint. That means archive extraction changes should be staged so the old and new paths can be compared or at least reasoned about clearly. Message action changes should preserve existing action IDs and call sites when possible, so a rollback is small if needed.

# Risks

The first major risk is overfitting the archive fix to the provided failing file. If the implementation becomes a one-off special case for the rainstorm export, it may fix one document while silently regressing others. The right design should instead identify a more general rule, such as a canonical content-root extraction sequence or a block-aware traversal that ignores runtime scaffolding but preserves meaningful units.

The second major risk is changing message copy behavior in a way that fails under canvas security boundaries or mobile interaction constraints. Clipboard APIs may be blocked depending on user gesture timing or environment. The design should therefore prefer direct clipboard copy in local runtime when available and fall back gracefully to a surfaced copy experience instead of assuming one path always works.

The third major risk is destabilizing delete or regenerate behavior by redesigning the toolbar without respecting how current message IDs, temporary sessions, and Firestore-backed sessions work. The UI refresh should be layered on top of existing semantics first, then only adjust the action handlers where the current behavior is clearly inadequate.

The fourth major risk is that a hover-first design may still feel broken or undiscoverable on touch devices. The mobile portion of this workstream should therefore treat touch affordance as a first-class part of the action-surface refresh rather than as a later afterthought.

The fifth major risk is touching too many files and blurring cause and effect. This pass should avoid unrelated UI cleanup or generalized note refactors. The safest design is a narrow, fixture-driven archive fix plus a focused toolbar/action refresh.

# Recommended Technical Approach

Use a fixture-driven repair strategy for the archive workstream. The core idea is to stop guessing from HTML strings in the abstract and instead run the actual converter against the working and failing files, then inspect exactly what output is produced, where it diverges, and what structural branches are responsible. Once the failure mode is proven, patch the extraction path at the smallest stable boundary. A likely strong candidate is to normalize how exported content roots are detected and then convert from a pruned, meaningful DOM subtree rather than from the full raw document or from mixed legacy selectors that can drift.

Use a layered affordance refresh for message actions. Keep the semantic operations identified by message ID, but move the UI toward a more modern anchored action surface with strong z-index, stable hit targets, predictable appearance, and a touch-safe mobile presentation. The toolbar should be easy to use when hovering with a mouse, remain accessible within the canvas shell, and stay discoverable on mobile without relying on hover that touch devices do not provide. Copy should prefer direct clipboard write when the platform and permission context allow it. If direct write fails, the user should still get a clear fallback that is easier than the current modal-only flow.

# Phase Sequence

## Phase 1: Reproduce And Measure Archive Divergence

Build a narrow local harness that imports or invokes the current archive conversion path using the two user-provided HTML files as fixtures. The output should record at least converted content length, presence of known section titles, count of major blocks or headings, and whether the converter appears to stop after visualization-heavy regions. The purpose of this phase is not fancy test infrastructure. The purpose is evidence. By the end of this phase there should be a clear statement like “the converter stops after hydrated visualization blocks,” or “the converter chooses the wrong content root,” or “the output is complete and truncation happens later during note save.”

This phase should also check whether the failure happens before persistence or during persistence. If `convertHtmlToMarkdown(...)` already returns incomplete output, the fix belongs in extraction/conversion. If the output is complete and the note content later ends up partial, the bug is likely in note update or serialization boundaries. The design should not assume one or the other until the output is measured.

## Phase 2: Patch Archive Conversion At The Smallest Stable Boundary

Once the failure point is known, adjust the conversion path so archive behavior is shaped around meaningful exported content units rather than raw page scaffolding. A likely healthy direction is to introduce a robust content-root normalization step that prefers exported template payload content when available, strips runtime-only wrapper elements, and preserves the actual visible learning content, including section text surrounding visualization blocks. If hydrated visualization blocks are present, the converter should treat them as content-adjacent units rather than as a signal to abandon later siblings.

If the generic walker is where the content is lost, refine it so it can step over visualization or runtime-heavy blocks without terminating the rest of the walk. If the root selection is wrong, standardize it. If persistence is the problem, then fix note update or serialization with the least invasive change that keeps existing notes compatible.

The archive patch must preserve already-working cases. The solar-system fixture should continue to archive correctly, and simpler note or lesson pages should not lose formatting or headings because of the new logic.

## Phase 3: Refresh Message Actions Without Changing Their Semantics More Than Necessary

Redesign the message action UI so it no longer behaves like an older floating side widget. The refreshed version should have a stronger anchored presentation, stronger z-index, cleaner spacing, and a mobile-safe presentation so it reads as part of the message card rather than a detached legacy overlay. The new UI should remain discoverable but not obscure message content.

For copy, prefer a direct clipboard path when running locally or when the environment grants clipboard access from a user gesture. If that succeeds, provide fast visual confirmation rather than opening a heavy modal. If direct clipboard access is blocked, fall back to a copy-friendly surfaced state that still works inside the canvas shell, keeping the selected content reachable and not hidden behind overlay stacking issues. On mobile, the affordance should be easy to trigger without requiring hover.

For delete, preserve current semantics about whether a message belongs to a temporary in-memory session or a persisted Firestore-backed session. The visible affordance should make deletion feel intentional but not cumbersome. The action should remain correct when invoked from refreshed toolbar placement.

For regenerate, preserve the model that the AI response is regenerated from the preceding user message and relevant prior session history. The visible affordance should be easy to trigger, but the action path must still protect the existing history semantics and not accidentally regenerate the wrong answer. The action should also degrade safely if the surrounding context is missing.

## Phase 4: Verify, Review, And Publish

Verification must prove user-visible outcomes, not just that functions return values. For archive reliability, the plan needs fixture-based proof that both supplied files archive fully enough to preserve the expected later sections or visible learning units. For chat actions, the plan needs a runtime check that copy succeeds directly where possible, that the refreshed toolbar is visually on top in canvas-like layering, that the mobile presentation remains usable without hover, and that delete/regenerate still do the right thing.

The review pass should then inspect only the changed files and ask the high-value questions: did the archive fix overfit one fixture, did the message action refresh introduce interaction regressions, and is rollback still small and obvious? Only after those answers are satisfactory should the bundle be rebuilt and the publish repo updated.

# Validation Strategy

Archive validation should include deterministic fixture checks. At minimum, the converter should be run against both provided HTML files and the resulting archive output should be checked for expected later-document anchors. For the rainstorm file, the validation should explicitly look for text the user indicated exists after the truncation point. For the successful solar-system file, the validation should confirm that the known good behavior stays good. If useful, add one smaller repo-local exported HTML sample to reduce the chance of overfitting the two download fixtures.

Message action validation should include runtime proof, ideally through a focused browser harness or at least a deterministic shell validation script. It should confirm that the toolbar appears above surrounding content, that copy can write to clipboard under local runtime, that fallback still works under restricted contexts, that delete removes the right message, that regenerate reuses the proper prior user prompt, and that the mobile presentation exposes the same actions without hover-only dependence. The validation should also confirm there are no new page-level errors from the refreshed toolbar behavior.

Manual checks may still be warranted for canvas-specific z-index and interaction feel, but the primary proof should be scripted enough to make rollback decisions easy and evidence-driven.

# Definition Of Done

This workstream is done when all of the following are true:

- the failing rainstorm HTML fixture archives without cutting off mid-document
- the successful solar-system fixture still archives correctly after the patch
- the archive path works regardless of whether the exported HTML still uses placeholders or already contains hydrated visualization block data
- the refreshed message action UI is visually usable and not trapped behind neighboring layers in canvas contexts
- copy is easier than before and writes directly to clipboard in local runtime when allowed
- delete and regenerate still work correctly from the refreshed action surface
- the same action surface remains usable on mobile without depending on hover
- focused verification artifacts exist on disk and show clean results
- the final review finds no material regression or avoidable scope drift

# Open Questions To Resolve During Scan

The first open question is whether the archive failure occurs strictly inside the HTML-to-markdown conversion or after conversion during note persistence. This must be settled early because it determines whether the patch belongs in extraction logic or in notes data handling.

The second open question is whether direct clipboard write is always allowed in the local runtime shell, or whether a small fallback confirmation state is still needed for some cases. This can be answered empirically during verification rather than through speculation.

The third open question is what the cleanest mobile affordance should be for message actions. The user has now made mobile correctness explicit, so the design must not stay hover-only, but it should still preserve the cleanest minimal surface rather than adding a bulky second UI if a compact touch-safe pattern works.

# Rollback Plan

Keep the patch narrow enough that rollback remains straightforward. Archive reliability changes should concentrate in the archiver and, only if proven necessary, the notes data layer. Message action changes should concentrate in the message toolbar/action files and their CSS. If verification fails, revert this bounded change set rather than mixing in unrelated runtime cleanups. Publish should happen only after the new validation artifacts exist and are green, so rollback is a clean choice instead of a guess.

# Progress Log

- 2026-04-14 20:36:01 +09:00: Approved workstream opened. Initial scan identified likely archive and message-action touch points. No writable implementation yet.
- 2026-04-14 20:39:19 +09:00: User added an explicit mobile requirement for the message-action refresh. Active plan updated in place before implementation.
- 2026-04-14 20:52:00 +09:00: Archive reproduction confirmed that the failing rainstorm export truncated inside `convertHtmlToMarkdown(...)` while the solar export remained intact.
- 2026-04-14 20:58:00 +09:00: Archiver patched to walk text nodes and simple generic containers, ignore runtime-only visualization scaffolding more carefully, serialize HTML-source note writes, and preserve table/card text beyond visualization-heavy sections.
- 2026-04-14 21:05:00 +09:00: Chat message action surface rebuilt as an anchored toolbar with clipboard-first copy, bounded regenerate eligibility, wrapper-safe delete behavior, and touch/mobile persistence.
- 2026-04-14 21:09:57 +09:00: Dedicated validation harness passed for the rainstorm and solar archive fixtures plus desktop/mobile/persisted message-action paths.
- 2026-04-14 21:14:30 +09:00: Review completed and active plan marked publish-ready.
- 2026-04-14 21:19:40 +09:00: Verified bundle published to `lemos999/Singulari-Tea-Codex-Canvas` on commit `7451029`.
