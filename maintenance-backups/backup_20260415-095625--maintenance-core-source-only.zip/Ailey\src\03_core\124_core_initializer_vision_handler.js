/* --- Ailey & Bailey Canvas --- */
// File: 124_core_initializer_vision_handler.js
// Version: 1.6 (Parallel Auto-Gen Support)
// Description: Modified handleGeneration to support parallel auto-generation by introducing an `isAuto` flag. This flag bypasses the global generation lock and suppresses global UI updates (side panel, buttons) to allow batch processing.

async function handleGeneration(mode, options = {}) {
    const { contextContainerId = 'learning-content', targetElement = null, isAuto = false } = options;
    const normalizedMode = 'quick';

    if (!isAuto && isImageGenerating) {
        showToastNotification("??? ?? ?? ????.", "?? ??? ?? ? ?? ??? ???.", `image-gen-busy-${Date.now()}`);
        return;
    }

    // Only disable global buttons if manually triggered. Auto-gen runs in background.
    const buttonsToDisable = !isAuto ? document.querySelectorAll(
        '#quick-generate-btn, .placeholder-action-btn, .overlay-control-btn[data-action="quick"], .overlay-control-btn[data-action="options"], .overlay-control-btn[data-action="settings"], .overlay-control-btn[data-action="download"]'
    ) : [];

    try {
        if (!isAuto) isImageGenerating = true;
        buttonsToDisable.forEach(btn => { if (btn) btn.disabled = true; });

        let rawContext = '';
        if (targetElement && targetElement.dataset.prompt) {
            rawContext = targetElement.dataset.prompt;
            trace("VisionWeaver", "ContextFromPrompt", { source: "data-prompt", length: rawContext.length });
        } else {
            rawContext = extractContextFromDOM(contextContainerId);
        }
        
        if (!rawContext) {
            const panelStatus = document.getElementById('image-panel-status');
            if (panelStatus && !isAuto) panelStatus.textContent = '오류: 현재 장면에서 추출할 텍스트가 없습니다.';
            if (!isAuto) showModal('오류: 현재 장면에서 추출할 텍스트가 없습니다.', () => {});
            return;
        }

        const contextSource = document.getElementById(contextContainerId);
        const imageTarget = targetElement || (contextSource ? contextSource.querySelector('.type-generated-image') : document.getElementById('generated-image-container'));
        
        const panelImageDisplayArea = document.getElementById('image-display-area');
        const panelImageStatus = document.getElementById('image-panel-status');
        
        const loaderHTML = `
            <div class="media-loading-state">
                <div class="loading-animation" aria-hidden="true">
                    <div class="dot"></div>
                    <div class="dot"></div>
                    <div class="dot"></div>
                </div>
            </div>
        `;
        
        if (imageTarget) {
            imageTarget.classList.add('type-generated-image-loading');
            imageTarget.innerHTML = loaderHTML;
        }
        // Do not update side panel display area for auto-gen to prevent thrashing
        if (!isAuto && contextContainerId === 'learning-content' && panelImageDisplayArea) {
            panelImageDisplayArea.innerHTML = loaderHTML;
        }

        const updateStatusText = (text) => {
            if (isAuto || !panelImageStatus) return;

            const normalizedText = String(text || '').trim();
            const shouldHideProgressText = /참조 이미지.*불러|프롬프트.*정제|이미지.*생성 중|생성 완료|재시도합니다/i.test(normalizedText);
            panelImageStatus.textContent = shouldHideProgressText ? '' : normalizedText;
        };
        
        const settings = userApiSettings.visionWeaverSettings;
        let finalPrompt = rawContext;

        if (normalizedMode === 'quick' && settings.rememberOptions && settings.rememberedOptions) {
            const rememberedPrompts = Object.values(settings.rememberedOptions).flat().filter(Boolean);
            if (rememberedPrompts.length > 0) {
                finalPrompt = `${rememberedPrompts.join(', ')}, ${finalPrompt}`;
                trace("VisionWeaver", "generate.quick.remembered", { count: rememberedPrompts.length });
            }
        }
        
        if (settings.disableTextOutput) {
            finalPrompt = `absolutely no text, no letters, no characters, no speech bubbles. visual-only output. ${finalPrompt}`;
            trace("VisionWeaver", "generate.disableText", { active: true });
        }

        const activePresetNum = settings.activePreset;
        let referenceImages = [];

        if (activePresetNum && activePresetNum !== 'none' && settings.presets[activePresetNum]) {
            updateStatusText('프리셋 참조 이미지 불러오는 중...');
            const preset = settings.presets[activePresetNum];
            const urlsToFetch = [preset.main, preset.face, preset.clothing].filter(Boolean);
            
            if (urlsToFetch.length > 0) {
                try {
                    const base64Promises = urlsToFetch.map(url => fetchImageAsBase64(url));
                    referenceImages = await Promise.all(base64Promises);
                    
                    const promptAdditions = [];
                    if (preset.main) promptAdditions.push("Use the first image for the overall mood, pose, and composition.");
                    if (preset.face) promptAdditions.push("Use the second image for the detailed facial features.");
                    if (preset.clothing) promptAdditions.push("Use the third image for the clothing style and texture.");
                    finalPrompt += `\n\n**Character Reference Instructions:**\n${promptAdditions.join(' ')}`;
                } catch (e) {
                    updateStatusText('오류: 참조 이미지 로드 실패.');
                }
            }
        }

        for (let attempt = 1; attempt <= 3; attempt++) {
            try {
                let imageDataUrl;
                if (normalizedMode === 'refined') {
                    updateStatusText('');
                    const refinedPrompt = await refineContextViaChatbot(finalPrompt);
                    updateStatusText('');
                    imageDataUrl = await generateImage(refinedPrompt, referenceImages);
                } else {
                    updateStatusText('');
                    const englishPrompt = `Cinematic, photorealistic, high-quality image. Scene: ${finalPrompt}`;
                    imageDataUrl = await generateImage(englishPrompt, referenceImages);
                }
                updateStatusText("생성 완료!");
                
                if (imageTarget) {
                    insertImageIntoDOM(imageDataUrl, imageTarget, contextContainerId);
                }
                // Only update side panel for manual triggers
                if (!isAuto && contextContainerId === 'learning-content' && panelImageDisplayArea) {
                    insertImageIntoDOM(imageDataUrl, panelImageDisplayArea, contextContainerId);
                }

                if (contextContainerId === 'learning-content') {
                    logImageGenerationHistory(canvasId);
                }
                return; 
            } catch (error) {
                console.error(`Generation attempt ${attempt} failed:`, error);
                if (attempt < 3) {
                    updateStatusText(`오류 발생. 5초 후 자동으로 재시도합니다... (${attempt}/3)`);
                    await new Promise(resolve => setTimeout(resolve, 5000));
                } else {
                    const errorMessage = '오류: 이미지 생성 최종 실패.';
                    updateStatusText(errorMessage);
                    _renderGenerationFailure(imageTarget, true);
                    if (!isAuto && contextContainerId === 'learning-content') {
                        _renderGenerationFailure(panelImageDisplayArea, false);
                    }
                }
            }
        }
    } finally {
        if (!isAuto) isImageGenerating = false;
        buttonsToDisable.forEach(btn => { if (btn) btn.disabled = false; });
    }
}
