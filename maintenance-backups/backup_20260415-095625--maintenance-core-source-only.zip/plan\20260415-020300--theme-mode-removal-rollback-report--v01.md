# Rollback Report - Theme Mode Removal - v01

- Status: completed
- Date: 2026-04-15 02:03 KST

## Summary

The theme-removal pass was rolled back. The visible theme toggle and saved-theme restore path were restored in source, and the published runtime bundle was rolled back to the last known-good pre-removal bundle state.

## What Was Restored

- `Ailey/src/00_shell/000_shell_template.js`
- `Ailey/src/01_state/001_state_globalVars.js`
- `Ailey/src/00_shell/005_shell_part6_main_assembler.js`
- `Ailey/src/03_core/120_core_main_initializer.js`

These were restored from `backup_20260415-002809--pre-openai-oauth-pass.zip`, which was confirmed to predate the theme-removal edits.

## Why The First Rollback Attempt Was Not Trusted

The later backup `backup_20260415-025411--pre-theme-mode-removal.zip` was already contaminated by partial theme-removal edits. Using it had restored inconsistent files and left missing theme controls.

## Important Finding

A fresh local rebundle was attempted after source restoration, but the rebuilt `Ailey/bundle/main.js` still showed widespread mojibake in many user-facing Korean strings. That indicates a broader encoding contamination remains in the local source set and should be diagnosed separately.

To avoid publishing another broken bundle, the final rollback did **not** use the fresh rebuilt output.

## Final Publish Strategy

Instead of publishing the newly rebuilt bundle, the runtime bundle was restored from the last known-good pre-removal publish commit:

- pre-removal publish commit: `1c8fe9c`
- rollback publish commit: `cdb548b`

Files restored from that known-good publish state:

- `Singulari-Tea-Codex-Canvas-pr/bundle/main.js`
- `Singulari-Tea-Codex-Canvas-pr/bundle/main.css`
- local mirrors:
  - `Ailey/bundle/main.js`
  - `Ailey/bundle/main.css`

## Verification Notes

- Source verification:
  - `theme-toggle` restored in `000_shell_template.js`
  - `themeToggle` binding restored in `001_state_globalVars.js`
  - saved theme restore logic restored in `005_shell_part6_main_assembler.js`
  - theme toggle click handler restored in `120_core_main_initializer.js`
- Publish verification:
  - GitHub publish repo reverted from `7ed1817` to rollback commit `cdb548b`

## Follow-Up

Do not re-apply theme-removal changes until the broader encoding issue in the local rebuild path is investigated and fixed.
