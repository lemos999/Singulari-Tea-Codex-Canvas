## Task

`정적 HTML로 내보내기`를 제거하고 export 버튼이 바로 `라이브 HTML로 내보내기`를 실행하도록 다시 패치하되, 지난 실패 원인이었던 bundler ESM 오판정을 먼저 고친다.

## Why the last pass failed

- `Ailey/bundler.js`가 파일 내용에 `import ` 또는 `export ` 문자열이 포함되기만 해도 ESM으로 분류했다.
- `src/00_shell/000_shell_template.js`는 실제 ESM이 아니지만 주석/설명 문자열 때문에 ESM으로 잘못 분류될 수 있었다.
- 그러면 `SHELL_PART_1` 정의가 shell assembler보다 뒤로 밀리면서 bootstrap이 깨진다.

## Goals

- `src/00_shell/**`는 번들러에서 항상 regular source로 처리한다.
- ESM 판정은 문자열 포함이 아니라 더 좁은 문법 패턴으로 제한한다.
- export dropdown/static export를 제거한다.
- export main button 클릭 시 바로 `window.exportAsLiveHtml({ title })` 호출로 연결한다.
- 로드 검증과 export 동작 검증이 모두 통과할 때만 publish한다.

## Scope

- `Ailey/bundler.js`
- `Ailey/src/00_shell/000_shell_template.js`
- `Ailey/src/03_core/120_core_main_initializer.js`
- `Ailey/src_css/010_widget_header_addons.css`
- `Ailey/bundle/main.js`
- `Ailey/bundle/main.css`

## Validation

- bundler output에서 `src/00_shell/000_shell_template.js`가 `Regular`로 분류된다.
- lightweight harness에서 shell bootstrap이 정상이고 `chat-panel`, `notes-app-panel`이 생성된다.
- export dropdown/static/live 하위 버튼이 더 이상 DOM에 없다.
- export button 클릭이 바로 `window.exportAsLiveHtml({ title })`로 연결된다.
- page error / console error가 없다.

## Rollback note

- 실패 시 직전 정상 배포 상태(`9a4e967`) 기준으로 즉시 되돌린다.
