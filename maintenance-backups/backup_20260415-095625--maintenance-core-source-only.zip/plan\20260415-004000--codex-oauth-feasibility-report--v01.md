## Summary
The app cannot safely support direct Codex / GPT OAuth chat requests from the current browser runtime because the ChatGPT Codex backend rejects the app origin at the CORS layer.

## What Was Verified
- Existing provider architecture is browser `fetch` based.
- OpenAI API-key mode remains valid and unaffected.
- Local Codex auth state exists on this machine as `%USERPROFILE%\\.codex\\auth.json`.
- Direct preflight to `https://chatgpt.com/backend-api/codex/responses` from a browser-style origin was rejected with `Disallowed CORS origin`.

## Practical Meaning
Adding a direct “GPT OAuth” option to chat settings right now would create a misleading feature:

- the UI could appear connected
- but actual chat requests would fail from this app runtime

## Why No Patch Was Shipped
The user explicitly asked for a proper result and rollback safety. Shipping a direct OAuth mode in the current architecture would violate that requirement because it would be broken by design.

## Recommended Path
Use a local bridge or hosted backend proxy for Codex OAuth.

Smallest safe direction:
- keep API-key presets as they are
- add a future bridge-backed OAuth provider separately
- only wire the settings UI once the bridge contract exists

## Backup
- `backup_20260415-002809--pre-openai-oauth-pass.zip`

## References Used
- OpenAI API auth docs: `https://platform.openai.com/docs/api-reference/authentication?api-mode=responses`
- OpenAI Codex article indicating ChatGPT login path uses the ChatGPT Codex backend: `https://openai.com/bs-BA/index/unrolling-the-codex-agent-loop/`
- Local runtime CORS probe against `https://chatgpt.com/backend-api/codex/responses`
