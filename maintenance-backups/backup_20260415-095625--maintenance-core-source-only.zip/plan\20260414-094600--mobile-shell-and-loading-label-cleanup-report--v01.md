Report Type: Implementation Report
Workstream: Mobile Shell and Loading Label Cleanup
Version: v01
Status: Completed
Created: 2026-04-14 09:46:00 +09:00
Related Plan: `plan/20260414-090500--work-plan--mobile-shell-and-loading-label-cleanup--v01.md`
Publish Commit: `5eca8e0`
Publish Repo: `lemos999/Singulari-Tea-Codex-Canvas`

# Summary

This pass finished the approved pre-mobile-shell workstream. The runtime now enters a touch-first single-panel shell mode on smaller viewports, mobile drawers and recall navigation behave predictably, slow local initialization no longer leaves the shell visually present but inert, and visible image or batch generation loading copy was removed from the active runtime surfaces that were in scope. The rebuilt bundle was validated on both mobile and desktop, then published.

# What Changed

## 1. Mobile shell behavior

- Added explicit mobile viewport handling and primary-panel arbitration in `Ailey/src/02_utils/013_utils_panel_manager.js`.
- Mobile mode now:
  - uses `900px` as the shell breakpoint
  - syncs `visualViewport` measurements into CSS variables
  - collapses the shell to one visible main panel at a time
  - disables desktop drag, resize, and maximize semantics
  - treats chat sidebar and recall turn list as mobile drawers

Key references:

- `Ailey/src/02_utils/013_utils_panel_manager.js:7`
- `Ailey/src/02_utils/013_utils_panel_manager.js:29`
- `Ailey/src/02_utils/013_utils_panel_manager.js:57`
- `Ailey/src/02_utils/013_utils_panel_manager.js:293`
- `Ailey/src/02_utils/013_utils_panel_manager.js:312`
- `Ailey/src/02_utils/013_utils_panel_manager.js:326`

## 2. Early shell binding before slow Firebase init

- Added a dedicated shell-binding guard so controls are wired before the runtime awaits Firebase.
- This prevents the local/mobile failure mode where the panel is visible but buttons and toggles are temporarily dead.

Key references:

- `Ailey/src/01_state/001_state_globalVars.js:93`
- `Ailey/src/00_shell/005_shell_part6_main_assembler.js:85`
- `Ailey/src/03_core/120_core_main_initializer.js:176`
- `Ailey/src/03_core/120_core_main_initializer.js:201`

## 3. Mobile CSS layout pass

- Panels now use full-viewport mobile geometry instead of desktop free-floating behavior.
- Chat sidebar, composer, settings popover, notes shell, and recall viewer each received mobile-safe sizing and spacing.

Key references:

- `Ailey/src_css/004_panels.css:43`
- `Ailey/src_css/020_chat_panel_base.css:155`
- `Ailey/src_css/021_chat_sidebar.css:421`
- `Ailey/src_css/023_chat_input.css:305`
- `Ailey/src_css/024_chat_controls_modals.css:467`
- `Ailey/src_css/015_notes_panel_base.css:90`
- `Ailey/src_css/018_notes_recall_viewer.css:170`

## 4. Silent loaders and loading-label cleanup

- Visualization placeholders now use the dot-based loader without injecting `"묶음 생성 중"` style copy.
- The pending visualization overlay uses a silent indicator instead of a legacy preparation sentence.
- Image-generation progress surfaces keep explicit failures but suppress cosmetic progress text.
- Empty image status containers collapse completely so blank space is not left behind.

Key references:

- `Ailey/src/03_core/121_core_initializer_visualization.js:1246`
- `Ailey/src/03_core/121_core_initializer_visualization.js:1290`
- `Ailey/src/03_core/121_core_initializer_visualization.js:1531`
- `Ailey/src/03_core/121_core_initializer_visualization.js:1702`
- `Ailey/src/03_core/124_core_initializer_vision_handler.js:64`
- `Ailey/src/03_core/124_core_initializer_vision_handler.js:116`
- `Ailey/src_css/025_vision_weaver_panel.css:87`

# Validation

Validation artifact:

- `visual-tests/mobile-shell-validation-2026-04-14T00-39-52-832Z/validation.json`
- `visual-tests/mobile-shell-validation-2026-04-14T00-39-52-832Z/validation-summary.txt`

Observed results:

- `mobileMode=true`
- `mobileChatFitsViewport=true`
- `mobileSidebarOpened=true`
- `mobileSettingsPopoverFits=true`
- `mobileSinglePanelMode=true`
- `mobileRecallOpened=true`
- `mobileRecallClosedByOutsideTap=true`
- `desktopStillDesktop=true`
- `desktopSidebarCollapsed=true`
- `desktopDidNotUseMobileDrawer=true`
- `imageBusyToastNeutralized=true`
- `batchLoaderTextDetached=true`
- `pendingOverlayTextAbsent=true`
- `pageErrorCount=0`
- `traceErrorCount=0`

# Publish

Published files:

- `bundle/main.js`
- `bundle/main.css`

Publish details:

- repo: `lemos999/Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `5eca8e0`

# Maintenance Notes

- Future mobile work should build on this single-panel shell mode instead of reviving desktop-like concurrent floating panels on narrow screens.
- The initialization-order fix is important for local file runs and slow startup paths; later refactors should preserve the rule that shell controls bind before network-dependent startup steps.
- The loading cleanup intentionally preserves explicit failure text. Only cosmetic progress copy was removed.
