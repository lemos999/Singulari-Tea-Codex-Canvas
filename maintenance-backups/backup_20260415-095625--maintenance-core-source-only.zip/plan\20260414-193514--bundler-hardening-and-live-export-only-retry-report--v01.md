## Summary

`정적 HTML로 내보내기`를 제거하고 export 버튼을 즉시 `라이브 HTML로 내보내기`로 연결했다. 이번에는 먼저 bundler의 ESM 오판정을 고쳐 shell bootstrap 안정성을 확보한 뒤 export UI를 단순화했다.

## Root cause from previous failed pass

- `Ailey/bundler.js`가 파일 내용에 `import ` 또는 `export ` 문자열이 포함되면 실제 문법 여부와 관계없이 ESM으로 분류했다.
- `src/00_shell/000_shell_template.js` 같은 shell 조립 파일이 잘못 ESM으로 분류되면 `SHELL_PART_1` 정의가 assembler보다 뒤로 밀릴 수 있다.
- 그 결과 bootstrap 시점에 `SHELL_PART_1 is not defined`가 발생해 shell 전체가 로드되지 않을 수 있었다.

## What changed

- `Ailey/bundler.js`
  - `src/00_shell/**`는 항상 regular source로 처리
  - ESM 판정은 단순 문자열 검색 대신 좁은 문법 패턴으로 제한

- `Ailey/src/00_shell/000_shell_template.js`
  - export dropdown 제거
  - `#export-main-content-btn` 단일 버튼으로 유지

- `Ailey/src/03_core/120_core_main_initializer.js`
  - export dropdown close logic 제거
  - static/live 하위 버튼 분기 제거
  - export main button 클릭 시 바로 `window.exportAsLiveHtml({ title })`

- `Ailey/src_css/010_widget_header_addons.css`
  - export wrapper 스타일 제거
  - button reset 추가 (`background`, `padding`, `appearance`)

## Validation

- bundler log:
  - `visual-tests/latest-bundler-output.log`
- browser validation:
  - `visual-tests/validate_live_export_only_retry.mjs`
  - `visual-tests/live-export-only-retry-2026-04-14T10-34-38-635Z/validation.json`
  - `visual-tests/live-export-only-retry-2026-04-14T10-34-38-635Z/validation-summary.txt`
  - `visual-tests/live-export-only-retry-2026-04-14T10-34-38-635Z/01-shell-bootstrap.png`

## Validation highlights

- `shellTemplateHasExportDropdown=false`
- `shellTemplateHasStaticExport=false`
- `initializerUsesDirectLiveExport=true`
- `bundlerMarksShellTemplateRegular=true`
- `bundlerMarksInitializerRegular=true`
- `hasChatPanel=true`
- `hasNotesPanel=true`
- `hasExportButton=true`
- `hasExportDropdown=false`
- `exportCallCount=1`
- `pageErrorCount=0`
- `consoleErrorCount=0`

## Publish

- bundle synced to `Singulari-Tea-Codex-Canvas-pr/bundle`
- safe to publish
