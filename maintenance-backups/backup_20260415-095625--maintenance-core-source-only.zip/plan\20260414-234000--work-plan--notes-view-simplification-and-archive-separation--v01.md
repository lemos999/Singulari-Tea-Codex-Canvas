Plan Type: Work Plan
Workstream: Notes View Simplification and Archive/Memo Separation
Version: v01
Status: Completed
Created: 2026-04-14 23:40 KST
Last Updated: 2026-04-14 23:59 KST
Supersedes or Related Plan: Related to prior Notes renewal passes, but no earlier plan in this exact scope.
Current Completion State: Backup complete, scan complete, implementation complete, validation complete, publish complete.
Completed So Far: Root local backup created; recall-view shell, recall-view renderer, notes list renderer, and related CSS/state surfaces scanned; legacy mode split and mixed archive/memo rendering identified; recall legacy toggles removed from the live Notes experience; recall rendering simplified to the canonical path; archive and memo list presentation separated; bundle rebuilt; desktop and mobile validation passed; publish bundle updated and pushed.
Remaining Work: None in this approved scope.
Current Blockers: None.
Next Step: Await user verification or follow-up Notes refinement requests.

# Scoreboard

- Current Score: 50
- Score Source: provisional
- Last Updated: 2026-04-14 23:59 KST
- Score Rationale: The requested Notes cleanup is implemented, validated, and published, but the user has not yet given a task-specific score for this pass. The score remains conservatively provisional under workspace rules.
- What Improved:
  - The request has been narrowed to a clear bounded Notes workstream.
  - A rollback-safe root backup now exists before any new writable change.
  - The real legacy surfaces were identified instead of assuming the UI buttons were the whole problem.
  - Recall now uses one canonical viewer path instead of legacy compatibility/editor toggles.
  - Archive-like notes and ordinary memos are separated in the Notes list and within mixed projects.
  - Desktop and mobile validation passed without page or console errors.
- What Remains Unsatisfactory:
  - `호환 보기` and `에디터 보기` still exist in the runtime.
  - Recall rendering still depends on mode flags and divergent rendering branches.
  - Archive-like notes and ordinary memos are still rendered under the same mixed list surface.
- What Should Happen Next To Raise Or Maintain The Score:
  - Remove the old recall mode split without breaking single-note recall or project recall.
  - Separate archive and memo presentation so users can scan them independently.
  - Verify both desktop and mobile Notes behavior and only then publish.

## Score History

- 2026-04-14 23:40 KST | 50 | provisional | Initial approved-plan score after backup and scan. No implementation evidence yet.
- 2026-04-14 23:59 KST | 50 | provisional | Implementation, validation, and publish completed. Score remains capped by workspace rule until the user gives an explicit rating for this pass.

# Objective

Simplify the Notes experience so it behaves like one coherent modern surface instead of carrying forward multiple legacy compatibility modes and mixed content groupings. The finished Notes workspace should no longer expose `호환 보기` or `에디터 보기` in the recall screen, should no longer depend on those old toggle states for user-visible behavior, and should present archived material separately from ordinary memos in the main Notes list. The goal is not to add new functionality. The goal is to remove stale behavior branches, reduce user confusion, and make the Notes UI easier to maintain.

# User-Visible Intent

The user wants three things at once:

1. Remove legacy recall viewing surfaces that feel like leftovers from an older build.
2. Make the Notes list stop mixing archive-style items and memo-style items in a way that obscures what each item is.
3. Do the cleanup in a principled, internally consistent way rather than merely hiding buttons.

The work therefore has to reach below the shell markup. If only the buttons are hidden, the state flags, re-render branches, and CSS contracts remain in the runtime and continue to increase fragility. That would not satisfy the request for a real cleanup.

# Confirmed Findings From The Scan

## 1. The recall screen still exposes two legacy viewing modes

The recall screen shell in `Ailey/src/00_shell/003_shell_part4_panel_notes_chat.js` still defines:

- `#recall-compatibility-toggle`
- `#recall-editor-toggle`

These are not cosmetic leftovers alone. They are wired into state and runtime logic.

## 2. The old recall modes still exist as independent runtime branches

`Ailey/src/05_features_notes/315_notes_recall_viewer.js` still maintains:

- `isRecallCompatibilityMode`
- `isRecallEditorMode`
- `_handleCompatibilityToggle()`
- `_handleEditorToggle()`
- `_rerenderCurrentRecallView()`

and `renderTurn(...)` still contains three divergent paths for learning notes:

- editor mode using Toast UI editor
- compatibility mode using Markdown/Marked rendering
- canonical block rendering mode

That means the current Notes recall experience is not one design. It is a mode switcher with three rendering paths. This is exactly the kind of legacy structure that tends to break over time and is expensive to reason about.

## 3. The Notes list is mixing archive and memo concerns

`Ailey/src/05_features_notes/320_notes_ui.js` renders:

- pinned notes
- project containers
- unassigned notes under `일반 메모`

Inside project containers, all note kinds are placed together in the same `notesInProject` loop. The renderer labels items with `LEARNING`, `RECALL`, `VISUAL`, or `NOTE`, but those labels are only descriptive. They do not restructure the list. As a result:

- archive-like notes are visually mixed with ordinary notes inside the same project group
- project summaries refer to archive semantics while item bodies still look like one undifferentiated list
- the user has to infer structure item by item instead of seeing archive vs memo at the section level

## 4. The shell and CSS still carry explicit compatibility/editor affordances

`Ailey/src_css/019_notes_job_ui.css` contains dedicated styling for:

- `#recall-compatibility-toggle`
- `#recall-editor-toggle`
- active states and hover states for both

`Ailey/src_css/017_notes_editor_view.css` still styles the classic note editor view, which must remain for ordinary note editing, but the recall-side editor mode appears to be a legacy branch rather than a needed primary surface.

`Ailey/src_css/018_notes_recall_viewer.css` assumes a more modern recall layout already, which means the recall compatibility/editor split is even more clearly legacy state carried inside a newer shell.

# Design Intent

This cleanup should produce a smaller and more explicit model:

- one canonical recall viewer path
- one dedicated editor path for editing notes in the editor view
- a notes list with separate presentation zones for archive material and memo material

That means the modern recall experience becomes the only recall experience. Editing remains available by entering the note editor in the contexts where editing is allowed, not by toggling the recall screen into a second embedded editor. This keeps responsibilities clear:

- editor view edits
- recall view recalls
- notes list classifies and groups content clearly

# Smallest Safe Assumptions

The following assumptions are the smallest safe ones consistent with the scan:

1. The user wants the recall screen to remain fully functional, but only in the modern structured rendering mode.
2. Removing `호환 보기` and `에디터 보기` means removing both the buttons and the runtime branches behind them, unless a branch is still required for a non-legacy path.
3. Archive-vs-memo separation should happen at the list layout level, not merely by changing the text labels on cards.
4. Ordinary note editing must still work through the main editor view, because the user did not ask to remove editing itself.
5. Existing archive and recall entry points such as project-level recall buttons must keep working.

# Scope

## In Scope

- Remove recall compatibility toggle UI.
- Remove recall editor toggle UI.
- Remove legacy recall mode state and mode-switch event wiring where no longer needed.
- Collapse recall rendering to the canonical structured recall path for supported recall content.
- Preserve ordinary note editing through the existing editor view.
- Rework the main Notes list so archive material and memo material are shown in separate sections or sub-containers with clearer grouping.
- Adjust CSS so the new structure is visually coherent on desktop and mobile.
- Rebuild the bundle and run focused validation.
- Publish to GitHub only if validation passes.

## Out Of Scope

- Large-scale archival data migration.
- Changes to note storage schema unless absolutely required by the requested behavior.
- New archive features, new filters, or new note types.
- Changing the high-level archive backup system beyond what the new Notes presentation requires.
- Refactoring unrelated chat, visualization, or model settings surfaces.

# Implementation Plan

## Phase 1: Remove Recall Legacy Modes Cleanly

Update the Notes shell so the recall header no longer contains compatibility-mode or embedded-editor-mode controls. The recall header should focus on:

- returning to the list
- toggling the recall sidebar
- showing the title
- searching within recall content

Then remove the old runtime state surfaces that exist only to support those modes. The target result is that recall rendering no longer depends on `isRecallCompatibilityMode` or `isRecallEditorMode` as user-switchable states.

Specific intent for this phase:

- stop binding recall toggle button references in global state
- remove compatibility/editor toggle button markup from the shell
- remove event listeners and active-state synchronization for those controls
- simplify `_rerenderCurrentRecallView()` or remove it if its only purpose is to re-render after mode switches
- simplify `renderTurn(...)` so it renders recall content using the canonical modern path only

The desired outcome is less branching, less state, and less opportunity for divergence between three recall renderers.

## Phase 2: Preserve The Right Editing Path

The classic editor view should remain available for ordinary notes through `openNoteEditor(...)`. The cleanup must not accidentally remove note editing from the product. The right mental model after the cleanup should be:

- normal memo note -> editor view
- recallable archive-like note -> recall view

If a note is recallable, it should open into recall as it does now. If a note is a normal editable note, it should still open the editor. The change is that recall itself will no longer pretend to be a secondary editor or markdown-compatibility viewer.

## Phase 3: Separate Archive And Memo Presentation In The Notes List

Redesign `renderNoteList()` and related helpers so the list reflects content roles rather than mixing everything into project containers and a generic memo bucket.

The expected grouping should follow these principles:

- archived material should live under an archive-oriented section
- ordinary memos should live under a memo-oriented section
- project containers should display their archive content and memo content separately when both exist
- a project containing only one category should not show an empty second category
- unassigned ordinary memos should remain easy to scan as memos

This does not require inventing new storage types. The existing note-kind heuristics can be improved and turned into list-structure decisions instead of mere badge labels.

Implementation should likely introduce small helper predicates such as:

- whether a note is archive-like
- whether a note is ordinary memo-like

Then use those predicates consistently in:

- project descriptor text
- project section composition
- top-level unassigned note sections

The main outcome is that a user can immediately tell what is archive content and what is memo content.

## Phase 4: Tighten The Notes UI Contract

Once archive-vs-memo sections exist, the CSS should reinforce that structure. The design should stay close to the current Notes workspace rather than reinventing it. The smallest complete visual cleanup is:

- clearer section headers for archive and memo groupings
- subcontainers inside a project when both archive and memo content are present
- spacing rules that prevent mixed lists from visually collapsing together
- no lingering styles for removed recall toggle controls

This phase should also verify that the mobile Notes shell still behaves properly after the new grouping and header simplification.

## Phase 5: Verification And Publish

Rebuild the bundle after the source changes. Then run a focused Notes validation that proves:

- the removed buttons are gone
- recall still opens and renders content
- ordinary note editing still opens the editor
- archive and memo content are separated in the list
- desktop and mobile Notes layouts stay usable
- no new page or console errors appear

Only after those checks pass should the bundle be copied into the publish repo and pushed to GitHub.

# Hidden Rules And Consistency Requirements

These details matter even if the visible request sounded simple:

1. Removing a view toggle is not complete unless the state and rendering branches that supported it are also removed or neutralized.
2. The recall viewer should not silently become less capable for archive reading. The canonical path must still render the supported archive content types.
3. The main editor must remain the only clear editing surface for notes.
4. Archive/memo separation must be data-consistent across top-level items and project-contained items. It is not acceptable for unassigned notes to be separated while project notes remain mixed.
5. Search behavior must remain coherent. If the Notes search matches archive and memo items, both should still appear, but under the right separated sections.
6. Selection-mode behavior must keep working. If memo or archive cards can be selected for backup in project contexts, the grouping change must not break checkbox handling or selection action bars.
7. Project-level recall buttons must still operate if a project contains recallable content.
8. The cleanup must stay rollback-safe: no schema migration, no irreversible transformation of stored note data.

# Risk Review

## Main Technical Risks

### Risk 1: Recall regression

If the compatibility/editor branches were covering edge cases that the canonical renderer does not handle, removing them could make certain old notes render poorly or not at all.

Mitigation:

- keep the canonical renderer path centered on the current structured block rendering that already powers the modern recall view
- validate with a recallable learning note and a recallable narrative/project note
- preserve narrative rendering logic untouched unless required

### Risk 2: Search and selection regressions in Notes list

Changing the grouping logic can accidentally break:

- filtered project inclusion
- selection mode
- checkbox visibility
- note click routing

Mitigation:

- keep item creation helpers stable where possible
- change grouping and container composition, not the note-card identity model
- explicitly test selection inside the new grouped project structure

### Risk 3: CSS drift after removing old controls

Removed buttons may leave awkward gaps or wrapping behavior in the recall header.

Mitigation:

- simplify recall-header layout after control removal
- test both desktop and mobile recall header states

## Rollback Strategy

The work is intentionally scoped to Notes-related files and CSS. If a regression appears, rollback can be performed by reverting only this Notes cleanup pass or by restoring from the root backup created before implementation.

# Validation Plan

The verification must prove observable behavior, not just compile success.

## Required Checks

1. Root backup exists and is readable.
2. Bundle builds successfully.
3. Notes panel loads without page errors.
4. Recall header no longer contains `호환 보기`.
5. Recall header no longer contains `에디터 보기`.
6. Opening a normal memo still opens the note editor.
7. Opening a recallable note still opens the recall viewer.
8. A project with archive-like content shows archive material in an archive grouping.
9. Memo-only content is shown under memo grouping and not mixed into archive sections.
10. Mobile viewport still shows a usable Notes shell and list.
11. No new console errors occur during Notes interactions.

## Evidence To Capture

- validation summary text/json
- one or more screenshots of the revised Notes list
- one screenshot of the revised recall header
- optional screenshot showing editor opening for a normal memo

# Definition Of Done

This work is done when all of the following are true:

- the recall screen no longer exposes compatibility or embedded editor toggles
- the runtime no longer depends on those old mode branches as user-facing behavior
- Notes list presentation clearly separates archive content from memo content
- ordinary memo editing still works
- recall still works
- validation is clean
- updated bundle is published to GitHub

# Recommended Technical Approach

Use the smallest complete design:

- preserve the existing Notes workspace shell and styling language
- remove only the legacy surfaces actually tied to the user request
- introduce minimal helper predicates for archive-vs-memo grouping
- keep note item and project container helpers cohesive rather than inventing a new abstraction layer

The right implementation shape is a narrow structural cleanup, not a new Notes architecture.

# Immediate Execution Order

1. Remove recall toggle markup and global bindings.
2. Remove or simplify the recall mode state and renderer branching.
3. Add archive-vs-memo classification helpers in Notes list rendering.
4. Restructure project and top-level list composition around those helpers.
5. Remove obsolete CSS for the deleted controls and adjust layout spacing.
6. Rebuild bundle.
7. Run focused Notes validation.
8. Publish only after clean results.

# Progress Log

- 2026-04-14 23:40 KST | Approved plan file created after backup and scan. Implementation has not started yet.
- 2026-04-14 23:49 KST | Notes list was rerouted through the separated archive/memo renderer and recall runtime state stopped binding legacy compatibility/editor toggle events.
- 2026-04-14 23:58 KST | Focused desktop/mobile Notes validation passed with recall toggles absent and archive/memo sections present.
- 2026-04-14 23:59 KST | Bundle published to GitHub as commit `b489daf`.
