/*
--- Ailey & Bailey Canvas ---
File: 331_notes_backup_exporter.js
Version: 1.1 (Local Auto Backup Mirror)
Description: Handles JSON backup export for notes and chat data, including local automatic backup mirroring.
*/

const LOCAL_AUTO_BACKUP_MIRROR_KEY = 'ailey_local_auto_backup_v1';
const LOCAL_AUTO_BACKUP_INTERVAL_MS = 30 * 60 * 1000;
let localAutoBackupIntervalId = null;
let localAutoBackupInitialized = false;

function isLocalBackupRuntime() {
    return (window.__AILEY_RUNTIME_MODE__ === 'local') || (typeof __firebase_config === 'undefined');
}

window.getLocalBackupStatus = function() {
    const isLocalRuntime = isLocalBackupRuntime();
    const rawBackup = localStorage.getItem(LOCAL_AUTO_BACKUP_MIRROR_KEY);

    if (!rawBackup) {
        return {
            isLocalRuntime,
            hasMirror: false,
            backupDate: null,
            backupSource: null,
            noteCount: 0,
            noteProjectCount: 0,
            chatCount: 0
        };
    }

    try {
        const payload = JSON.parse(rawBackup);
        return {
            isLocalRuntime,
            hasMirror: true,
            backupDate: payload.backupDate || null,
            backupSource: payload.backupSource || null,
            noteCount: Array.isArray(payload.notes) ? payload.notes.length : 0,
            noteProjectCount: Array.isArray(payload.noteProjects) ? payload.noteProjects.length : 0,
            chatCount: Array.isArray(payload.chatSessions) ? payload.chatSessions.length : 0
        };
    } catch (error) {
        console.error("Failed to parse local backup status payload:", error);
        return {
            isLocalRuntime,
            hasMirror: false,
            backupDate: null,
            backupSource: null,
            noteCount: 0,
            noteProjectCount: 0,
            chatCount: 0,
            parseError: error.message
        };
    }
};

function cloneSerializableSettings(value) {
    return JSON.parse(JSON.stringify(value || {}));
}

function serializeTimestampFields(item) {
    const nextItem = { ...item };
    if (nextItem.createdAt?.toDate) nextItem.createdAt = nextItem.createdAt.toDate().toISOString();
    if (nextItem.updatedAt?.toDate) nextItem.updatedAt = nextItem.updatedAt.toDate().toISOString();
    if (nextItem.generatedAt?.toDate) nextItem.generatedAt = nextItem.generatedAt.toDate().toISOString();
    if (Array.isArray(nextItem.messages)) {
        nextItem.messages = nextItem.messages.map(message => {
            const nextMessage = { ...message };
            if (nextMessage.timestamp?.toDate) {
                nextMessage.timestamp = nextMessage.timestamp.toDate().toISOString();
            }
            return nextMessage;
        });
    }
    return nextItem;
}

function createBackupPayload(dataToExport, options = {}) {
    return {
        backupVersion: '5.1',
        backupDate: new Date().toISOString(),
        runtimeMode: window.__AILEY_RUNTIME_MODE__ || 'unknown',
        backupSource: options.backupSource || 'manual-export',
        userApiSettings: cloneSerializableSettings(userApiSettings),
        notes: (dataToExport.notes || []).map(serializeTimestampFields),
        noteProjects: (dataToExport.noteProjects || []).map(serializeTimestampFields),
        chatSessions: (dataToExport.chatSessions || []).map(serializeTimestampFields),
        projects: (dataToExport.projects || []).map(serializeTimestampFields)
    };
}

function downloadBackupPayload(payload, baseFilename) {
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${baseFilename}-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
}

async function collectFullBackupData(onProgress) {
    const notesSnap = await notesCollectionRef.get();
    const noteProjectsSnap = await noteProjectsCollectionRef.get();
    const projectsSnap = await projectsCollectionRef.get();
    const sessionsSnap = await chatSessionsCollectionRef.get();

    const notes = notesSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    const noteProjects = noteProjectsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    const projects = projectsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    const chatSessions = [];

    if (typeof onProgress === 'function') {
        onProgress({ sessions: sessionsSnap.size });
    }

    for (const doc of sessionsSnap.docs) {
        const sessionData = { id: doc.id, ...doc.data() };
        const messagesSnap = await chatSessionsCollectionRef.doc(doc.id).collection('messages').orderBy('timestamp').get();
        sessionData.messages = messagesSnap.docs.map(messageDoc => ({ id: messageDoc.id, ...messageDoc.data() }));
        chatSessions.push(sessionData);
    }

    return { notes, noteProjects, chatSessions, projects };
}

async function mirrorLocalBackupToStorage(reason = 'interval') {
    if (!isLocalBackupRuntime()) return null;

    const dataToExport = await collectFullBackupData();
    const payload = createBackupPayload(dataToExport, { backupSource: `local-mirror:${reason}` });
    try {
        localStorage.setItem(LOCAL_AUTO_BACKUP_MIRROR_KEY, JSON.stringify(payload));
    } catch (error) {
        trace("Backup", "localMirror.save.error", { reason, error: error.message }, {}, "ERROR");
        throw error;
    }
    trace("Backup", "localMirror.saved", {
        reason,
        notes: payload.notes.length,
        chatSessions: payload.chatSessions.length
    });
    return payload;
}

window.initializeLocalBackupAutomation = function() {
    if (!isLocalBackupRuntime() || localAutoBackupInitialized) return;
    localAutoBackupInitialized = true;

    mirrorLocalBackupToStorage('startup').catch(error => {
        console.error("Initial local auto backup mirror failed:", error);
        trace("Backup", "localMirror.startup.error", { error: error.message }, {}, "ERROR");
    });

    localAutoBackupIntervalId = setInterval(() => {
        mirrorLocalBackupToStorage('interval').catch(error => {
            console.error("Interval local auto backup mirror failed:", error);
            trace("Backup", "localMirror.interval.error", { error: error.message }, {}, "ERROR");
        });
    }, LOCAL_AUTO_BACKUP_INTERVAL_MS);

    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') {
            mirrorLocalBackupToStorage('visibility-hidden').catch(() => {});
        }
    });

    window.addEventListener('pagehide', () => {
        mirrorLocalBackupToStorage('pagehide').catch(() => {});
    });
};

window.exportLatestLocalAutoBackup = function() {
    const rawBackup = localStorage.getItem(LOCAL_AUTO_BACKUP_MIRROR_KEY);
    if (!rawBackup) {
        showModal("No local automatic backup snapshot is available yet.", () => {});
        return;
    }

    try {
        downloadBackupPayload(JSON.parse(rawBackup), 'ailey-local-auto-backup');
    } catch (error) {
        console.error("Failed to export latest local auto backup:", error);
        showModal(`Local automatic backup export failed: ${error.message}`, () => {});
    }
};

window.exportAllData = async function() {
    const toastId = `export-all-${Date.now()}`;
    showProgressToast('Collecting full backup data...', toastId);
    trace("Backup", "exportAll.start");

    try {
        const dataToExport = await collectFullBackupData(progress => {
            updateProgressToast(`Collecting ${progress.sessions} chat sessions and their messages...`, toastId);
        });
        const payload = createBackupPayload(dataToExport);

        downloadBackupPayload(payload, 'ailey-canvas-full-backup');

        if (isLocalBackupRuntime()) {
            try {
                localStorage.setItem(LOCAL_AUTO_BACKUP_MIRROR_KEY, JSON.stringify(payload));
            } catch (error) {
                console.warn("Failed to refresh local backup mirror during manual export.", error);
            }
        }

        trace("Backup", "exportAll.success", {
            notes: payload.notes.length,
            projects: payload.projects.length
        });
    } catch (error) {
        console.error("Full data export failed:", error);
        trace("Backup", "exportAll.error", { error: error.message }, {}, "ERROR");
        showModal(`Full data export failed: ${error.message}`, () => {});
    } finally {
        hideProgressToast(toastId);
    }
};

window.exportNoteProject = async function(projectId) {
    if (!projectId) return;
    const toastId = `export-note-project-${Date.now()}`;
    showProgressToast('Collecting note project backup...', toastId);
    trace("Backup", "exportNoteProject.start", { projectId });

    try {
        const projectDoc = await noteProjectsCollectionRef.doc(projectId).get();
        if (!projectDoc.exists) throw new Error("Note project not found.");

        const notesSnap = await notesCollectionRef.where("projectId", "==", projectId).get();
        const payload = createBackupPayload({
            notes: notesSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })),
            noteProjects: [{ id: projectDoc.id, ...projectDoc.data() }]
        });

        downloadBackupPayload(payload, `note-project-${projectDoc.data().name || projectId}-backup`);
    } catch (error) {
        console.error("Note project export failed:", error);
        showModal(`Note project backup failed: ${error.message}`, () => {});
    } finally {
        hideProgressToast(toastId);
    }
};

window.exportChatProject = async function(projectId) {
    if (!projectId) return;
    const toastId = `export-chat-project-${Date.now()}`;
    showProgressToast('Collecting chat project backup...', toastId);
    trace("Backup", "exportChatProject.start", { projectId });

    try {
        const projectDoc = await projectsCollectionRef.doc(projectId).get();
        if (!projectDoc.exists) throw new Error("Chat project not found.");

        const sessionsSnap = await chatSessionsCollectionRef.where("projectId", "==", projectId).get();
        const chatSessions = [];
        for (const doc of sessionsSnap.docs) {
            const sessionData = { id: doc.id, ...doc.data() };
            const messagesSnap = await chatSessionsCollectionRef.doc(doc.id).collection('messages').orderBy('timestamp').get();
            sessionData.messages = messagesSnap.docs.map(messageDoc => ({ id: messageDoc.id, ...messageDoc.data() }));
            chatSessions.push(sessionData);
        }

        const payload = createBackupPayload({
            chatSessions,
            projects: [{ id: projectDoc.id, ...projectDoc.data() }]
        });

        downloadBackupPayload(payload, `chat-project-${projectDoc.data().name || projectId}-backup`);
    } catch (error) {
        console.error("Chat project export failed:", error);
        showModal(`Chat project backup failed: ${error.message}`, () => {});
    } finally {
        hideProgressToast(toastId);
    }
};

window.exportSelectedNotes = async function(noteIds) {
    if (!noteIds || noteIds.length === 0) return;
    const toastId = `export-selected-notes-${Date.now()}`;
    showProgressToast(`Collecting ${noteIds.length} selected notes...`, toastId);
    trace("Backup", "exportSelectedNotes.start", { count: noteIds.length });

    try {
        const noteDocs = await Promise.all(noteIds.map(id => notesCollectionRef.doc(id).get()));
        const notesData = noteDocs.map(doc => ({ id: doc.id, ...doc.data() }));
        const projectIds = new Set(notesData.map(note => note.projectId).filter(Boolean));

        let projectData = [];
        if (projectIds.size > 0) {
            const projectDocs = await Promise.all(
                Array.from(projectIds).map(projectId => noteProjectsCollectionRef.doc(projectId).get())
            );
            projectData = projectDocs.map(doc => ({ id: doc.id, ...doc.data() }));
        }

        const payload = createBackupPayload({
            notes: notesData,
            noteProjects: projectData
        });

        downloadBackupPayload(payload, 'selected-notes-backup');
    } catch (error) {
        console.error("Selected notes export failed:", error);
        showModal(`Selected notes backup failed: ${error.message}`, () => {});
    } finally {
        hideProgressToast(toastId);
    }
};
