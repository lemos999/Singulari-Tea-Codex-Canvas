Report Type: Workstream Report
Workstream: Blind `/sub` validation of `.cc` head-level CDN freedom
Version: v01
Status: Completed
Created: 2026-04-13 21:42:00 +09:00
Related Plan: `plan/20260413-205909--work-plan--cc-cdn-blind-sub-test--v01.md`

## Outcome

Initial blind-batch verdict: soft-fail.

Final workstream verdict: pass after bounded repair.

The original blind batch proved that the prompt can now generate genuinely freer `.cc` artifacts across multiple subject families. The route page became a route atlas, the smelt page became a specimen-like field guide, the comparison page became a contrast board, and the TLS page became a protocol console with authored and Mermaid-backed support. The contract no longer collapses everything into the same article shell.

The blocker was real: the two technical artifacts configured Tailwind CDN with `tailwind.config = ...` before the CDN script existed, which caused an early `ReferenceError`. That meant the prompt's new head-level CDN freedom was not yet safely operational under blind generation.

## Repair

I hardened the prompt in three places:

1. Added a guard-safe CDN bootstrap rule that explicitly forbids brittle pre-load global dereferences and gives the safe `window.tailwind = window.tailwind || {}; window.tailwind.config = {...};` pattern.
2. Strengthened the free-layout declaration rule so a true free-layout artifact must carry `data-cc-layout="free"`.
3. Extended the final self-check so early enhancer bootstrap failures are explicit contract violations.

## Verification

Original blind batch evidence:
- `visual-tests/20260413-205909-cc-cdn-blind-sub-test/validation-report.json`
- original screenshots in the same directory

Late audits:
- `subagent-runs/20260413-205909-cc-cdn-blind-sub-test/results/A1-read-only-audit.md`
- `subagent-runs/20260413-205909-cc-cdn-blind-sub-test/results/A2-shell-safety-audit.md`

Repair evidence:
- `subagent-runs/20260413-205909-cc-cdn-blind-sub-test/results/parent-repair-note.md`
- `visual-tests/20260413-205909-cc-cdn-blind-sub-test-r1-safe-bootstrap/validation-report.json`
- `visual-tests/20260413-205909-cc-cdn-blind-sub-test-r1-safe-bootstrap/r2-check/validation-report.json`

The repaired technical rerun removed the original Tailwind pageerror on both affected artifacts. Shell selectors remained mounted before and after repair. The remaining panel-visibility difference on the technical pair now looks like runtime display-state behavior rather than prompt-driven early failure, so it stays as a watch item rather than a blocker.

## Strongest And Weakest

Strongest artifact: `01-portuguese-sea-route-to-india.html`
- Best proof of true `.cc` freedom. It is spatial, subject-native, and visibly not an article fallback.

Weakest artifact: `03-supervised-vs-unsupervised.html`
- Still a good free-layout page, but it was the least adventurous composition family and one of the two pages hit by the original brittle Tailwind bootstrap bug.
