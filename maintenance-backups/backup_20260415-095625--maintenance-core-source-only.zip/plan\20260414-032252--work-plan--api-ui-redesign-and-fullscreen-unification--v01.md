Plan Type: Work Plan
Workstream: API UI Redesign And Fullscreen Unification
Version: v01
Status: Completed
Created: 2026-04-14 03:22:52 +09:00
Last Updated: 2026-04-14 04:57:00 +09:00
Supersedes or Related Plan: Related to `plan/20260414-021241--work-plan--chat-unification-live-visual-persistence--v01.md`
Current Completion State: Completed and published
Completed So Far: Fullscreen runtime behavior was unified around a body-level cinema host, API preset and prompt-template surfaces were redesigned to match the renewed shell language, the bundle was rebuilt, focused browser validation passed on both reported solar-system exports in `file` and `http` modes, and the verified bundle was published to GitHub as commit `3cb7568`.
Remaining Work: None for this approved scope beyond any future follow-up refinements the user may request.
Current Blockers: No blocking defects remain inside the approved scope. The only residual console warning in the failing solar page comes from that page's own Tailwind CDN usage and did not affect runtime behavior.
Next Step: Use the refreshed bundle as the new baseline and handle any follow-up polish or new regression reports separately.

# User Understanding

The user wants two connected but distinct runtime improvements.

The first improvement is a full redesign of API preset management and every closely connected UI surface so the experience no longer looks like an older leftover toolset beside the newly refreshed notes and chat shells. The redesign must include the preset selector that appears in the chat shell, the API preset management modal, the template-management modal and its list or editor surfaces, and any controls that are part of the same selection, activation, save, delete, or close flows. The target is a unified visual language, clearer hierarchy, more intuitive affordances, and better consistency with the renewed notes and chat design direction.

The second improvement is a functional fix for inconsistent visualization fullscreen behavior. The user has supplied a concrete contrast case. In one export, fullscreen works correctly. In another export, pressing the same fullscreen control does not produce a proper fullscreen or cinema-mode experience and instead leaves the visualization looking enlarged or rearranged inside the page context. The user wants analysis, correction, validation on the actual reported artifacts, and then GitHub publication.

The request is not just cosmetic. The fullscreen problem is a behavioral bug and the UI redesign spans multiple related surfaces that likely share runtime state, modal composition logic, and CSS tokens. The result must keep current functionality working while improving clarity and consistency.

# Scope

In scope:

- inspect the reported working and failing HTML exports and compare how the runtime mounts and expands visualization placeholders
- trace the visualization fullscreen, expand, and cinema-mode logic in runtime code and styles
- fix the inconsistent fullscreen path so equivalent supported visualizations behave consistently across the reported exports
- redesign API preset selection UI in the shell
- redesign the API settings modal and its tabs, list, form, and footer actions
- redesign the template-management modal and related list or editor surfaces so they match the renewed design language
- preserve existing settings, activation, save, delete, and selection flows unless a change is required for clarity or correctness
- rebuild the bundle, validate on the reported artifacts, and publish only the bundle changes needed for the verified fix

Out of scope unless required by the above:

- changing the meaning of stored API preset data
- changing template semantics or model prompt behavior beyond UI presentation and selection flow clarity
- rewriting unrelated shell surfaces
- changing export file format contracts unless a fullscreen fix strictly requires a compatibility-safe adjustment

# Smallest Safe Assumptions

- The fullscreen inconsistency is likely caused by runtime classification or layout-sync conditions rather than by content quality itself.
- The two reported solar-system exports are representative enough to diagnose the bug without needing a broad blind-batch first pass.
- The current API preset and template-management logic is functionally serviceable, so the main work should stay at the UI shell, modal structure, and styling layers rather than changing persistence semantics.
- The user wants the redesigned UI to feel visibly more modern and aligned with notes/chat, but not to the point of breaking established affordances or removing critical management actions.

# Why This Needs A New Plan

This request materially changes direction from the previous live-export media-control pass. That earlier plan focused on translation-surface removal, chat-shell unification, live visual persistence, and hover media controls. The current request introduces a new design workstream around API preset and template management while also reopening fullscreen behavior with a more specific cross-artifact bug report. Because this is a new approved direction with its own validation criteria and GitHub delivery target, it should be tracked under its own plan record rather than silently folded into the previous one.

# Objective

Deliver one verified runtime bundle update that makes API preset management and template-management UI surfaces feel consistent with the renewed notes and chat shells, while also making supported visualization fullscreen behavior consistent across the reported working and failing export pages. The end result should preserve existing functionality, improve readability and interaction clarity, avoid introducing new page errors, and be stable enough to publish to GitHub after direct validation.

# Design Intent

The redesign side should not become a decorative reskin with inconsistent subcomponents. It should move the preset and template surfaces toward the same family as the refreshed notes and chat panels: calmer shell framing, more deliberate spacing, clearer sectioning, stronger action emphasis, and less dated form/control presentation. The functional side should avoid hacks tied only to one solar-system example. The fullscreen fix should identify the real invariant for when a visualization is allowed to enter cinema mode or fullscreen and apply that invariant consistently across supported visualization content.

# Hidden Rules And Consistency Requirements

Several hidden requirements matter even if the user did not spell them out line by line.

First, the redesigned preset and template UI must remain understandable when local mode, Firebase-backed mode, or export mode changes which actions are possible. A prettier modal that becomes ambiguous about whether a preset is active, editable, saved, or merely selected would still feel wrong.

Second, fullscreen and cinema-mode behavior must remain safe for embedded content. A fix that forces fullscreen for surfaces that cannot resize safely, or that breaks overlay controls, would only replace one inconsistency with another.

Third, the API preset modal and template modal are management tools. They should expose hierarchy clearly: list or navigation on one side, focused editor state on the other, strong primary action placement, quiet destructive action, and obvious active-selection feedback. This clarity matters more than adding new ornaments.

Fourth, the redesign must respect persistence and rollback safety. Stored preset IDs, template IDs, and active-selection semantics should not change unless absolutely necessary. This should remain a UI-layer redesign with behavioral fixes, not an accidental data migration.

Fifth, the fullscreen fix must work for both live canvas runtime and local export-opened runtime whenever those pages are supported by the current bootstrap. It should not only work in the development path.

# Work Sequence

## Phase 1: Scan The Runtime And Compare The Reported Artifacts

Read the two reported solar-system exports and compare their visualization placeholder structure, mounted runtime DOM, and any data attributes that could influence fullscreen behavior. Inspect the runtime code that handles visualization controls, cinema mode, resize sync, wrapper classification, and fullscreen or expand actions. Confirm whether the difference comes from content shape, renderer strategy, mounted DOM structure, missing class application, or CSS constraints.

Leave this phase with a concrete explanation of why one page enters a correct fullscreen-like state and the other does not.

## Phase 2: Map Every Preset And Template UI Surface

Trace the full UI chain for API preset and template management. Identify:

- the shell-level preset selector
- the manage-settings button and modal entry path
- the preset list panel
- the preset editor tabs and footer actions
- the template list and template editor modal or drawer
- any styling files that still carry the older design language

This phase should also identify which UI surfaces are shared with other panels so the redesign can stay cohesive and not accidentally override unrelated modals.

## Phase 3: Redesign The API Preset And Template UI Shells

Refactor markup and CSS only as much as needed to produce a more coherent management experience.

The shell-level preset selector should read as part of the renewed workspace language rather than a legacy settings box. The settings modal should have stronger list-editor separation, clearer active-state styling, calmer but more deliberate spacing, and stronger primary-action emphasis. The template list and editor should similarly receive a cleaner layout, clearer selected state, better text hierarchy, and improved button semantics.

This redesign should preserve all current actions that still matter, including save, activate, delete, close, and tab navigation, while making those actions easier to understand at a glance.

## Phase 4: Fix Fullscreen Behavior At The Runtime Level

Implement the smallest complete fullscreen fix based on the cause found in Phase 1.

Possible safe correction directions include:

- unifying the condition that enables cinema mode for supported visualizations
- ensuring the visualization content container receives the same cinema-mode class path across both reported pages
- correcting resize and layout sync timing so one page does not stay constrained by its embedded wrapper
- adjusting wrapper CSS or mounted control behavior so expand no longer behaves like a mere in-page enlargement when fullscreen is expected

The chosen fix should be rooted in the actual runtime invariant, not page-specific branching.

## Phase 5: Verify On The Reported Pages And Related UI Flows

Run browser-based checks against:

- the reported working solar-system export
- the reported failing solar-system export
- the redesigned API preset selector and modal
- the template-management UI

Validation should confirm:

- equivalent supported visualizations now enter the same correct fullscreen or cinema behavior
- hover controls and action affordances still appear correctly
- no new page errors appear
- API preset selection still works
- preset modal open, edit, save, activate, and delete flows still behave
- template list and editor still behave

If the fullscreen fix reveals a bounded follow-up issue, perform one focused repair loop before publish.

## Phase 6: Rebuild, Review, And Publish

Rebuild the bundle, copy only the verified bundle files into the publish repository, confirm the changed file set is intentionally narrow, commit with a message that reflects the redesign and fullscreen fix, push to GitHub, and record the validation evidence and commit hash in the active plan.

# Technical Approach

The safest approach is to separate runtime behavior fixes from visual redesign while still landing them in one validated bundle release.

For fullscreen behavior, prefer fixing the existing expand or cinema path instead of inventing a second fullscreen system. There is already runtime machinery around `expand`, `cinema-mode`, control overlays, and layout-sync work. That existing path should be made consistent rather than bypassed.

For the UI redesign, prefer local CSS and minimal DOM refinement in the relevant shell and modal files rather than broad global token changes. The notes and chat redesign already created a newer design language. Reuse its shell ideas and proportions where possible instead of introducing a third style family.

For persistence and settings, keep the current preset data structures and template data structures stable. Change presentation, interaction order, and emphasis before changing semantics.

# Risks

The biggest risk is treating the fullscreen issue as a simple CSS problem when it may actually be a mismatch between visualization profile, wrapper structure, and layout-sync timing. If the fix only changes CSS, one content type may still fail under resize or re-entry.

Another risk is redesigning preset and template UIs so aggressively that selection or save semantics become less obvious, especially when modals have tabs, disabled states, or preset activation rules that differ by provider or environment.

There is also a risk that the two goals could bleed into one another if global modal styling is changed too broadly. The redesign should stay targeted enough that it improves the intended settings and template surfaces without causing unrelated modals to drift.

Finally, export-opened runtime behavior can differ from canvas runtime because of hydration timing and environment guards. Verification needs to cover the real reported files, not only the development shell.

# Failure Cases To Actively Check

- fullscreen button only enlarges the visualization inside the page instead of escaping the embedded reading layout
- fullscreen entry works once but exit leaves the visualization broken or clipped
- fullscreen works for one renderer family but not another
- shell-level preset selector becomes visually updated but loses active-state clarity
- modal redesign causes hidden or disabled tabs to look broken rather than intentionally inactive
- save, activate, or delete actions lose distinction after the redesign
- template editor text fields become harder to scan or are truncated by layout changes
- local export or live export paths regress while fixing canvas runtime fullscreen

# Validation Strategy

Use direct runtime evidence rather than only static review.

For fullscreen:

1. Load the known-good solar-system export and record its current fullscreen behavior.
2. Load the known-bad solar-system export and reproduce the bad expand behavior.
3. Apply the fix and confirm both now enter the same intended fullscreen or cinema state.
4. Confirm exit from fullscreen or cinema returns to a stable embedded state.
5. Confirm no page errors or critical console errors are introduced.

For API preset and template UI:

1. Open the shell-level preset selector and confirm the redesigned closed state is legible and aligned with the renewed shell.
2. Open the API settings modal and confirm list, editor, tabs, and footer actions read clearly.
3. Confirm preset activation and save actions still work.
4. Open the template-management UI and confirm list selection, editing, and save or delete actions still work.
5. Confirm the redesign remains coherent in both dark and light mode if both are supported.

# Definition Of Done

This task is done when all of the following are true:

- the reported fullscreen inconsistency has a confirmed root cause and a verified fix
- the two reported solar-system exports now behave consistently for supported visualization fullscreen
- API preset management UI is visibly redesigned and more intuitive
- connected template-management UI is also redesigned into the same family
- existing preset and template functionality remains intact
- bundle rebuild succeeds
- verification on the reported pages and UI flows succeeds without page errors
- only the intended bundle files are published to GitHub
- the final response can point to a clean validation artifact and a GitHub commit hash

# Review Standards

Before publishing, perform a quiet review against these questions:

- Did the fullscreen fix solve the real inconsistency or only mask it in one example?
- Does the redesigned preset and template UI actually improve clarity, or just change colors?
- Are save, activate, and delete actions still unmistakable?
- Did any modal or shell surface unrelated to preset or template management drift accidentally?
- Can the bundle be rolled back safely by reverting the two published bundle files?

# Rollback

Rollback should remain straightforward. The work is intended to stay bundle-scoped, so reverting the source edits and rebuilding the bundle should restore the previous behavior. No data migration is planned, and no persisted schema change should be introduced.

# Scoreboard

Current Score: 93
Score Source: verified
Last Updated: 2026-04-14 04:57:00 +09:00
Score Rationale: The approved scope was implemented, rebuilt, validated on the user-reported artifacts and connected UI flows, and the verified bundle was published with a narrow two-file diff.
What Improved: The inconsistent fullscreen path now uses a portal-style cinema host instead of staying trapped by page-local layout contexts, and the settings/API/template surfaces now present a much more coherent management workspace.
What Remains Unsatisfactory: The failing solar page still emits the expected third-party Tailwind production warning because the page itself includes the CDN script, but no runtime or fullscreen regression remained after the fix.
What Should Happen Next To Raise Or Maintain The Score: Keep future work narrowly scoped, preserve the validated cinema-host invariant, and reuse the new settings/template visual language across adjacent management surfaces when needed.

## Score History

- 2026-04-14 04:57:00 +09:00 | Score: 93 | Source: verified | Reason: Fullscreen unification and settings/template UI refresh were implemented, validated, and published as bundle commit `3cb7568`.
- 2026-04-14 03:22:52 +09:00 | Score: 45 | Source: provisional | Reason: New approved plan created for fullscreen unification and API/template UI redesign, with implementation still pending.
