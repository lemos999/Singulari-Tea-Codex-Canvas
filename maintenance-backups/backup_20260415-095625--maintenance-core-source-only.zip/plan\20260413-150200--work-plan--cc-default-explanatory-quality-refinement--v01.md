Plan Type: Work Plan
Workstream: Universal `.cc/.ccc` module blind validation and explanatory-quality refinement
Version: v01
Status: In Progress
Created: 2026-04-13 15:02:00 +09:00
Last Updated: 2026-04-13 15:45:00 +09:00
Supersedes or Related Plan: Related `plan/20260413-131000--work-plan--cc-universal-blind-render-test--v01.md`; related `plan/20260413-133000--work-plan--cc-multitopic-visual-validation--v01.md`
Current Completion State: Blind-render refinement and verification complete; awaiting user review
Completed So Far: Re-established the current failure claim from the latest user feedback; re-read the active universal module; reviewed the prior multi-topic visual validation report; defined a stricter acceptance rubric; rewrote the English universal module with a stronger host-light explanatory fallback; built a reusable local blind-batch harness; generated and screenshot multiple rerun batches; confirmed that unresolved placeholder paths damaged generic page quality; tightened the module again so generic `.cc` explanations prioritize reading quality over unstable auxiliary surfaces; produced a final rerun batch with a self-audited average above the 95 target
Remaining Work: User review of the final module and final rerun artifacts; optional follow-up if the user wants the Korean module synchronized or wants a dedicated placeholder-only validation pass
Current Blockers: No implementation blocker; only the known runtime caveat that generic placeholder paths can still produce empty or modal-dominated surfaces in this environment
Next Step: Present the final rerun artifacts, explain the score, and let the user decide whether to accept this version or push one more refinement pass

# Scoreboard

Current Score: 50 / 100
Score Source: provisional
Last Updated: 2026-04-13 15:45:00 +09:00
Score Rationale: The final self-audited rerun batch now clears the technical quality target, but the score must remain capped at 50 because the user has not yet provided an explicit satisfaction score and the local policy does not allow a higher provisional value. Internally, the rerun artifacts now look materially stronger: large headers, keyword chips, honest section hierarchy, moderate `<strong>` emphasis, and no modal-blocked reading spine in the final scored batch.
What Improved: The module now has a stronger host-light explanatory fallback, cleaner English source text, clearer styled-surface guidance, stronger heading honesty, better emphasis discipline, and a more reality-aware placeholder rule that protects reading quality. A reusable blind-batch harness and fresh screenshots now back up the claims.
What Remains Unsatisfactory: The placeholder runtime itself is still not proven stable for generic explanations in this environment. The module solves that by omitting or demoting unstable placeholder usage rather than by making the placeholder path itself reliable.
Actions To Raise Or Maintain Score:
1. Re-test from scratch instead of trusting prior optimistic scoring.
2. Separate scoring into at least two axes: host-fidelity protection and default explanatory rendering quality.
3. Raise the explanatory fallback from “minimal direct answer” toward “strong but disciplined explanatory canvas” without regressing into hard-wired foreign scaffolds for strong hosts.
4. Demand actual visible hierarchy in blind outputs, not just semantic correctness in the prompt text.
5. Re-score only from concrete artifacts: HTML, screenshots, and a visible-structure audit.

Score History:
1. 2026-04-13 15:02:00 +09:00 | 38 | provisional | New plan opened after the user rejected the prior optimistic evaluation and clarified that the module still fails the desired strong explanatory presentation standard.
2. 2026-04-13 15:45:00 +09:00 | 50 | provisional | Final rerun batch cleared the internal 95+ quality target, but the provisional score remains capped by local policy pending explicit user evaluation.

# Objective

Bring the universal `.cc/.ccc` module to a state where blind-rendered `.cc` outputs for generic explanation requests can satisfy two requirements at the same time without cheating on either one.

The first requirement is structural fidelity. When the host is rich, opinionated, stateful, or contract-heavy, the module must continue to preserve host-native grammar, unit order, omission logic, and shell discipline. This is the protection that earlier iterations added after failures involving foreign scaffolds, shell drift, and accidental re-authoring.

The second requirement is default explanatory quality. When the host is light and the request is simply “explain X” or “what is X,” the output cannot collapse into a weak block of plain paragraphs with an honest but visually underpowered heading. It should feel like an intentional explanatory canvas: strong top anchor, visible internal hierarchy when justified, disciplined but noticeable emphasis, and selective visual support that improves understanding rather than merely checking a placeholder box.

The purpose of this plan is to re-open the problem from the user’s actual acceptance standard rather than from the narrower technical success standard that previous iterations drifted toward. The working assumption is that the current module is not yet acceptable because it still optimizes too heavily for non-interference and too weakly for confident explanatory presentation.

# Confirmed Facts

The user explicitly stated that the current outputs do not meaningfully exhibit the stronger header treatment, the visible emphasized structure, or the styled explanatory feel shown in the reference screenshots. This is now authoritative acceptance feedback.

The active module currently contains strong instructions about preserving host-defined units, avoiding invented foreign structures, enforcing the exact `.cc` shell, using a minimal direct-answer fallback, and keeping placeholder use conservative when runtime reliability is uncertain.

The prior multi-topic validation report recorded acceptable scores under a rubric that the user has now effectively rejected as too lenient. That earlier run is still useful as evidence, but its conclusion is no longer sufficient for acceptance.

The active shell contract for `.cc` remains immutable and must not be loosened. The improvement work should happen inside the semantic guidance for host-light explanatory fallbacks, visible hierarchy rules, emphasis discipline, and placeholder strategy rather than by relaxing the outer-shell lock.

# Working Assumptions

The safest assumption is that the user still wants the strong host-preservation behavior for rich hosts and does not want a universal module that reverts to always imposing keyword panels, lesson scaffolds, or symmetrical chapters everywhere. The requested improvement is therefore not “make everything look like Ailey,” but “make host-light explanatory `.cc` outputs look intentionally designed and informative instead of bare.”

The safest assumption for evaluation is that actual rendered feel matters more than declarative prompt correctness. Therefore screenshots and visible HTML structure should outweigh theoretical prompt quality during scoring.

The safest assumption for scoring is that strong explanatory visual treatment should be allowed only in the minimal-host fallback or other cases where the host truly provides no stronger grammar of its own. That means the new instructions should add a disciplined default explanatory presentation branch rather than replacing the host-native model globally.

# Problem Restatement

The universal module currently performs three jobs: trigger handling, semantic freezing of the host-native answer, and HTML transmutation. Its strongest behaviors now live in the preservation and safety layers. The weak spot is that the minimal-host fallback is too timid. It avoids templating so aggressively that it also avoids making strong presentational commitments. The result is a page that may be correct, stable, and formally compliant yet still feel visually weak and under-structured compared with the desired explanatory standard.

This weakness is especially visible for generic educational or encyclopedic prompts where there is no rich host grammar to inherit. In those cases, the module should not merely avoid harm. It should produce a readable, visually anchored, pedagogically clear explanatory page while still remaining faithful to the query and avoiding an obviously canned symmetrical template.

The task is therefore to redesign the minimal-host explanatory branch so that it becomes stronger without becoming rigid, more visible without becoming over-authored, and more helpful without collapsing back into hard-wired foreign course scaffolds.

# Acceptance Standard

The revised acceptance standard must be more demanding than the previous one. The module will only be considered successful for this cycle if blind `.cc` renders for representative host-light topics visibly satisfy the following conditions.

1. The page has a credible top anchor. A named-topic explanation should not feel title-less, floating, or accidental. The top heading should be visually confident and honest rather than decorative nonsense.

2. The page shows real internal hierarchy when the answer naturally contains distinct subtopics. That hierarchy should be expressed through actual headings, not through paragraphs front-loaded with `<strong>` labels masquerading as sections.

3. `<strong>` usage should be sparse enough to avoid textbook-highlighter noise but present enough to give the page semantic scanning power. A visually rich explanation should not feel completely flat and unaccented.

4. The page should feel intentionally explanatory rather than merely converted. In practice that means there should often be a subtitle or short orienting line, meaningful section breaks when warranted, and visible structure proportional to the topic.

5. Placeholder use must remain conditional and topic-appropriate. Spatial, chronological, and process-heavy subjects may justify one strong placeholder. Short direct answers should not become placeholder-heavy. Unstable runtime surfaces should not dominate the page.

6. The module must continue to protect host-native structure in rich-host scenarios. A fix that makes generic explanations pretty but causes stateful or contract-rich hosts to drift would not be accepted.

7. The overall blind-test average must reach at least 95 under the stricter rubric used in this cycle, or else the remaining failure must be clearly outside prompt control and documented as such.

# Test Strategy

This cycle will use fresh blind `.cc` rendering rather than argument-by-prompt or self-reassurance from the module text. The renderer should be treated as a black box that only receives the universal module and a prompt. The evaluation should then inspect what actually appears.

The topic set should include at least four representative generic explanation topics from meaningfully different semantic shapes:

1. A historical-spatial topic such as the Age of Exploration or maritime expansion.
2. A physics or astronomy topic such as black holes.
3. A process or systems topic such as TCP three-way handshake.
4. A biological process topic such as cellular respiration or air-mass thermodynamic evolution.

If time allows, add one conceptual-social or abstract theory topic to ensure the explanatory fallback does not only work for concrete or map-friendly topics.

Each test should capture:

1. The produced HTML artifact.
2. A screenshot of the rendered result.
3. A short audit note about visible heading structure, emphasis density, placeholder behavior, and overall feel.

The tests should be run in batches so that improvements can be measured against the previous batch rather than judged in isolation.

# Scoring Rubric

The stricter scoring rubric for each topic should be explicit.

1. Top Anchor and Title Confidence: 0 to 20
The page should open with a clear, visible, topic-faithful heading. It should not feel missing, timid, misleading, or over-decorated.

2. Internal Hierarchy and Section Honesty: 0 to 20
Real subtopics should use real heading levels. Flat pages lose points. Fake bolded pseudo-headings lose points.

3. Emphasis Discipline and Scanability: 0 to 15
Important terms should be visible, but the page should not look like a study guide painted with a highlighter.

4. Explanatory Presentation Strength: 0 to 20
The page should feel like a deliberate explanatory artifact rather than raw converted paragraphs. This includes effective orientation, segmentation, and visible structure proportional to the topic.

5. Placeholder Judgment: 0 to 10
When placeholders appear, they should be topic-appropriate and helpful. When omitted, the page should still feel complete. Placeholder use that causes visual breakage loses points.

6. Shell Fidelity and Runtime Discipline: 0 to 10
The `.cc` shell must remain exact. No outer-shell drift, no rogue styling systems, no alternate bootstrap flow.

7. Host-Neutral Generalization Quality: 0 to 5
The output should work as a good generic explanation without obviously leaking a narrow house template.

Average the topic scores, then compare the average against the 95 threshold.

# Planned Changes To The Module

The plan is not to throw away the host-native philosophy. Instead, the change should introduce a stronger default explanatory presentation branch under clearly bounded conditions.

That branch should activate only when the frozen host answer is genuinely minimal and the host does not already define a stronger grammar. It should be framed as a faithful explanatory presentation fallback, not as a universal section template.

The change should likely include the following behavioral upgrades.

1. Permit a disciplined orientation block for minimal explanatory hosts. This may include one strong `<h1>` and, when justified by the answer shape, one short subtitle or orienting sentence near the top. The subtitle must be faithful, not decorative fluff.

2. Permit a small number of explicit sections for minimal explanatory hosts when the answer naturally divides into distinct explanatory units. These sections should not be symmetrical by default and should not be forced into a universal five-part scaffold.

3. Strengthen the rule for visible heading honesty. If the answer introduces a visible subtopic, it should generally become `<h2>` or `<h3>` rather than a bold lead-in paragraph.

4. Upgrade emphasis guidance from purely defensive to balanced. The current sparse-emphasis instruction may be too conservative. The revised guidance should allow enough `<strong>` to make definitions, actors, forces, periods, and consequence pivots visible.

5. Introduce a “default explanatory richness” clause that encourages the page to feel intentional even when the host is simple. This should explicitly mention scanability, visible segmentation, and subject-appropriate rhetorical anchors.

6. Keep placeholder use tied to answer size and topic need, but allow one strategically chosen placeholder to carry more presentational weight for the right topics.

# Risks

The biggest risk is regression on host-native preservation. A richer default explanatory fallback could quietly become an excuse to reintroduce foreign structure everywhere, especially for hosts that are sparse but still intentionally plain. This would undermine much of the prior progress.

The second risk is over-correction into a house article template. If the module starts always emitting title, subtitle, keyword panel, and three neat sections, it will become visually stronger but no longer truly universal.

The third risk is false confidence from pleasant screenshots. A design can look better in one or two topics while still failing across others or still cheating on host semantics.

The fourth risk is runtime noise from placeholders. A prompt may be well-authored but still trigger unstable runtime surfaces. The scoring must separate prompt quality from environment instability while still penalizing avoidable reliance on fragile surfaces.

# Validation Plan

Validation will happen in three loops if needed.

Loop 1: Establish the true current baseline with a fresh blind batch and the stricter rubric.

Loop 2: Apply the first refinement pass focused on stronger explanatory fallback, then rerun all failing or borderline topics and compare.

Loop 3: Apply a second refinement pass focused on any remaining gap, especially if the first pass improves hierarchy but still leaves emphasis or orientation too weak.

If the average reaches at least 95 and the remaining defects are minor or runtime-caused, stop. If the average is below 95, continue one more focused refinement pass if the failure still appears prompt-controllable. If the remaining gap is clearly caused by runtime behavior outside prompt control, stop and document that explicitly.

# Definition Of Done

The work is done when all of the following are true.

1. A new plan-governed test cycle has been completed and documented.
2. Fresh blind `.cc` artifacts exist for representative topics.
3. The rendered outputs have been inspected for visible hierarchy, emphasis, placeholder behavior, and overall explanatory feel.
4. The module text has been updated to address real observed failures rather than speculative ones.
5. The final average score under the stricter rubric is at least 95, or the remaining shortfall is explicitly documented as not reasonably controllable by prompt changes.
6. The final report clearly distinguishes what improved, what still risks regression, and why the resulting module should now better match the user’s desired visual standard.

# Operational Sequence

Phase 1: Baseline Audit
Run the fresh blind renders with the current module. Capture HTML and screenshots. Score them using the stricter rubric. Write down concrete visible failure modes rather than vague impressions.

Phase 2: Prompt Refactor
Edit the universal module to introduce a stronger explanatory presentation branch for minimal hosts while preserving the strong host-native protections. Keep the outer `.cc` shell untouched.

Phase 3: Re-Render
Run the same topic set again. Capture new artifacts. Compare directly against the baseline. Re-score.

Phase 4: Focused Repair
If the score remains under 95, isolate the exact reasons. Repair only the prompt instructions responsible for those failures rather than broadening the entire module again.

Phase 5: Final Verification and Reporting
Confirm the final artifacts, update this plan, append score history, and produce a concise user-facing summary with direct file paths.

# Notes On Rollback Safety

This work changes a single prompt module and creates new test artifacts. Rollback is low risk because behavior can be reverted by restoring the module file and ignoring the new validation artifacts. The main non-obvious rollback risk is conceptual rather than technical: once the module gains a stronger explanatory fallback, future changes may drift it further into a house template. That should be guarded against in the wording of the new branch and explicitly monitored in later tests.

# Notes On Evidence Discipline

The plan intentionally privileges evidence from actual rendered outputs over claims made from reading the prompt text. Earlier over-confidence came partly from reading the prompt as if declarative intent guaranteed visible effect. This cycle corrects that by requiring concrete proof in artifacts and screenshots.

# Update Policy For This Plan

After each material step, update this file with:

1. what was run,
2. what changed,
3. which topics failed or passed,
4. the new current completion state,
5. the new next step,
6. whether the score rationale changed,
7. and whether a new score-history entry is required.

No claims of success should be made in chat unless the artifacts actually support them.
