# Ailey Visualization Generation Phase 0-1 Report

- Artifact Type: implementation-report
- Created: 2026-04-12 15:10:54 +09:00
- Scope: Phase 0 single-item visualization enforcement and Phase 1 `Data Visualizer` prompt rewrite from `20260412-145425--visualization-generation-stability-plan--ailey--v01.md`
- Status: completed-locally

## Summary

Phase 0 and Phase 1 were completed locally.

The visualization pipeline now treats generation as single-item in practice, not just by default value. The default `Data Visualizer` template was also rewritten from a permissive sandbox note into a stricter generation contract focused on container fit, first-frame legibility, and library-safe implementation patterns.

## Implemented Changes

### 1. Stored visualization settings are now normalized back to single-item mode

- File: `Ailey/src/03_core/111_core_api_settings_data.js`
- Added `normalizeVisualizationSettings(...)`
- Loaded and saved `visualizationSettings` are now sanitized so `batchGenerationSize` remains `1`

Impact:

- Previously saved values above `1` can no longer silently reactivate multi-item visualization generation

### 2. On-load auto-generation now processes visualization placeholders one at a time

- File: `Ailey/src/03_core/120_core_main_initializer.js`
- Visualization auto-generation loop now iterates placeholder-by-placeholder
- Visualization batch size in that path is hard-fixed to `1`

Impact:

- The app no longer uses a multi-item visualization batch path during automatic generation on page load

### 3. Manual visualization generation now enforces single-item mode in practice

- File: `Ailey/src/03_core/121_core_initializer_visualization.js`
- Added `ENFORCED_VISUALIZATION_BATCH_SIZE = 1`
- Disabled the batch-size input in the modal
- Runtime now rewrites the batch label and help text to explain the stability mode clearly
- Manual generation path now uses the enforced single-item value

Impact:

- The modal no longer behaves like multi-item visualization generation is supported
- Persisted settings are corrected back to the enforced value

### 4. Batch-size input markup and styling were hardened

- Files:
  - `Ailey/src/00_shell/002_shell_part3_c.js`
  - `Ailey/src_css/004_widget_visualization_options.css`
- Input now carries `max="1"` and `disabled`
- Disabled visual treatment was added

Impact:

- Even before JS event handling, the UI now points toward single-item behavior

### 5. The default visualization system prompt was rewritten and version-bumped

- File: `Ailey/src/03_core/102_template_data_visualizer.js`
- Version bumped from `23.1` to `24.0`
- Prompt now requires:
  - exactly one visualization per request
  - exactly one fenced `html` block
  - one dedicated root wrapper inside `vizContainer`
  - container-fit sizing and visible first paint
  - simpler fallbacks when ambitious scenes would likely be fragile
  - explicit D3, p5, Three.js, and chart-library safe patterns
  - explicit bans on known bad patterns such as `d3.select(...).querySelector(...)`
  - a final internal self-check before output

Impact:

- The upstream generation contract is now much more aligned with the renderer's actual runtime constraints

## Verification

### Syntax Checks

- Passed:
  - `node --check Ailey/src/03_core/111_core_api_settings_data.js`
  - `node --check Ailey/src/03_core/120_core_main_initializer.js`
  - `node --check Ailey/src/03_core/121_core_initializer_visualization.js`
  - `node --check Ailey/src/03_core/102_template_data_visualizer.js`
  - `node --check Ailey/src/00_shell/002_shell_part3_c.js`

### Bundle Verification

- Passed:
  - `node bundler.js`
- Confirmed:
  - local `Ailey/bundle/main.js` now contains `TEMPLATE_DATA_VISUALIZER.version:"24.0"`
  - local bundle includes the new prompt rule banning `d3.select(...).querySelector(...)`

### Known Expected Non-Issue

- `node --check` is not applicable to CSS files, so `Ailey/src_css/004_widget_visualization_options.css` was not validated through that command

## Remaining Work

### Phase 2

- add runtime validation and high-confidence auto-repair for common invalid generated patterns
- improve failure surfacing so broken outputs do not degrade into blank surfaces without explanation

### Phase 3

- re-test previously failing exported HTML examples, especially the D3-heavy cases from `알고리즘 시각화 실험실.html`

### Phase 4

- if local runtime results improve, rebundle again if needed and deploy the hosted bundle

## Conclusion

This iteration improves the system at the generation-contract layer and removes the most obvious source of mapping ambiguity by operationally forcing single-item visualization generation.

The next meaningful risk now sits at runtime validation rather than batch structure or prompt looseness.
