/* --- Ailey & Bailey Canvas --- */
// File: 222_chat_ui_messages_utils.js
// Version: 2.2 (Respect Manual Scroll Position)
// Description: Keeps auto-follow near the bottom, but stops forcing the viewport down when the user has intentionally scrolled upward.

const CHAT_AUTOFOLLOW_THRESHOLD = 72;

function isChatNearBottom(threshold = CHAT_AUTOFOLLOW_THRESHOLD) {
    if (!chatMessages) return true;
    const remaining = chatMessages.scrollHeight - chatMessages.clientHeight - chatMessages.scrollTop;
    return remaining <= threshold;
}

function setChatAutoFollow(enabled) {
    currentSessionState.autoFollow = !!enabled;
    currentSessionState.isUserNearBottom = !!enabled;
}

function shouldAutoFollowChat(force = false) {
    if (force) return true;
    return currentSessionState?.autoFollow !== false;
}

function autoScrollChat(force = false) {
    if (!chatMessages || !shouldAutoFollowChat(force)) return;

    requestAnimationFrame(() => {
        if (!chatMessages) return;
        if (!force && !shouldAutoFollowChat(false)) return;
        chatMessages.scrollTop = chatMessages.scrollHeight;
        if (force) {
            setChatAutoFollow(true);
        }
    });
}

let isChatScrollListenerBound = false;

const maybeLoadMoreOnChatScroll = debounce(async (scrollTop, targetSessionId) => {
    if (!targetSessionId || targetSessionId === 'temporary-chat') return;
    if (scrollTop >= 100 || currentSessionState.isLoadingMore || !currentSessionState.hasMoreMessages) return;

    const oldestMessageTimestamp = currentSessionState.oldestMessageTimestamp;
    currentSessionState.isLoadingMore = true;
    trace("UI", "handleChatScroll.loadMore.start", {}, { oldest: oldestMessageTimestamp });

    try {
        const pastMessages = await fetchPastMessages(targetSessionId, oldestMessageTimestamp);
        if (currentSessionId !== targetSessionId) return;

        if (pastMessages.length > 0) {
            const olderMessages = pastMessages.slice().reverse();
            const sessionInCache = localChatSessionsCache.find(s => s.id === targetSessionId);
            if (sessionInCache) {
                if (!sessionInCache.messages) sessionInCache.messages = [];
                sessionInCache.messages.unshift(...olderMessages);
            }
            prependMessages(olderMessages);
            currentSessionState.oldestMessageTimestamp = pastMessages[pastMessages.length - 1].timestamp;
            if (pastMessages.length < MESSAGES_PER_PAGE) {
                currentSessionState.hasMoreMessages = false;
            }
        } else {
            currentSessionState.hasMoreMessages = false;
            trace("UI", "handleChatScroll.loadMore.end", { message: "No more messages" });
        }
    } catch (error) {
        console.error("Failed to load older chat messages:", error);
        trace("UI", "handleChatScroll.loadMore.error", { error: error.message }, {}, "ERROR");
    } finally {
        currentSessionState.isLoadingMore = false;
    }
}, 200);

function setupChatScrollListener() {
    if (!chatMessages || isChatScrollListenerBound) return;
    chatMessages.addEventListener('scroll', handleChatScroll);
    isChatScrollListenerBound = true;
}

function teardownChatScrollListener() {
    if (chatMessages) {
        chatMessages.removeEventListener('scroll', handleChatScroll);
    }
    isChatScrollListenerBound = false;
}

function handleChatScroll(e) {
    const { scrollTop } = e.target;
    const nearBottom = isChatNearBottom();
    setChatAutoFollow(nearBottom);

    if (!currentSessionId || currentSessionId === 'temporary-chat') return;
    maybeLoadMoreOnChatScroll(scrollTop, currentSessionId);
}

function getMessageId(msg) {
    if (msg.id) return msg.id;
    if (msg.timestamp instanceof Date) return msg.timestamp.getTime().toString();
    if (msg.timestamp?.toDate) return msg.timestamp.toDate().getTime().toString();
    return `msg-${Math.random()}`;
}
