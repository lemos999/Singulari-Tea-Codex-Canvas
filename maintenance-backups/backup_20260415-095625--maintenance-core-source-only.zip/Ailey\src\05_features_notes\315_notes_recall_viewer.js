
/* --- Ailey & Bailey Canvas --- */
// File: 315_notes_recall_viewer.js
// Version: 10.3 (Title Extraction & Content Priority)
// Description: Updated `_renderRecallView` to extract the main title from the content (lines starting with `# `) instead of relying solely on the note's metadata title. Also added support for `## ` (H2) parsing in `_parseLearningNoteToContentBlocks`.

let _debouncedFilter; // to hold debounced search function
let tocObserver = null; // To hold the IntersectionObserver instance

function _scrollToSection(index) {
    const sectionElement = document.getElementById(`recall-section-${index}`);
    if (sectionElement) {
        sectionElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    // Update active class
    document.querySelectorAll('.recall-turn-item').forEach(item => item.classList.remove('active'));
    const activeItem = document.querySelector(`.recall-turn-item[data-block-index="${index}"]`);
    if (activeItem) {
        activeItem.classList.add('active');
    }
}
 
function _filterRecallTurns() {
    if (!recallSearchInput || !recallTurnListContainer) return;
    const term = recallSearchInput.value.toLowerCase();
    const turnItems = recallTurnListContainer.querySelectorAll('.recall-turn-item');

    turnItems.forEach(item => {
        const turnIndex = parseInt(item.dataset.turnIndex, 10);
        const turnData = activeRecallTurns[turnIndex];

        if (turnData) {
            // Handle both string (narrative) and object (learning note) types
            const turnContent = (typeof turnData === 'string') ? turnData : (turnData.content || '');
            if (turnContent.toLowerCase().includes(term)) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        }
    });
}

// [NEW] Helper to re-render current view with new mode settings
function _rerenderCurrentRecallView() {
    if (!activeRecallTurns || activeRecallTurns.length === 0) return;

    const firstItem = activeRecallTurns[0];
    // Detection for the new single-note wrapper object { content: string, blocks: array }
    const isSingleNoteWrapper = (typeof firstItem === 'object' && firstItem.blocks && firstItem.content);

    if (isSingleNoteWrapper) {
        // Single Learning Note Mode: The whole content corresponds to this one wrapper
        renderTurn(firstItem, true);
    } else {
        // Project Mode (Narrative or Learning Project)
        const activeTurnItem = document.querySelector('#recall-turn-list-container .recall-turn-item.active');
        let targetIndex = 0;
        
        if (activeTurnItem && activeTurnItem.dataset.turnIndex !== undefined) {
            const idx = parseInt(activeTurnItem.dataset.turnIndex, 10);
            if (!isNaN(idx)) targetIndex = idx;
        }
        
        if (activeRecallTurns[targetIndex]) {
             const isLearningNote = (recallNoteTitle.textContent || '').includes('[학습]');
             renderTurn(activeRecallTurns[targetIndex], isLearningNote);
        }
    }
}

function _renderRecallView(title, memoryBlocksOrNotes, isLearningProject = false) {
    if (tocObserver) {
        tocObserver.disconnect();
        tocObserver = null;
    }
    
    if (!memoryBlocksOrNotes || memoryBlocksOrNotes.length === 0) {
        console.error("Cannot render recall view: No memory blocks provided.");
        if(recallContentContainer) recallContentContainer.innerHTML = '<p>회상할 기록을 찾을 수 없습니다.</p>';
        showToastNotification("회상할 기록이 없습니다.", "이 폴더에는 턴 또는 스냅샷 데이터가 포함된 메모가 없습니다.", `recall-empty-${Date.now()}`);
        return;
    }
    
    trace("RecallViewer", "render", { title: title, blockCount: memoryBlocksOrNotes.length, isLearningProject });

    switchView('recall');
    // Initial set, might be overwritten by content parsing below
    if(recallNoteTitle) recallNoteTitle.textContent = title;

    // Setup search
    if (recallSearchInput) {
        recallSearchInput.value = '';
        if (!_debouncedFilter) {
            _debouncedFilter = debounce(_filterRecallTurns, 300);
        }
        recallSearchInput.removeEventListener('input', _debouncedFilter); // remove old listener
        recallSearchInput.addEventListener('input', _debouncedFilter);
    }

    if (!recallTurnListContainer) return;
    
    recallTurnListContainer.innerHTML = ''; // Clear previous list
    const fragment = document.createDocumentFragment();
    const isSingleLearningNote = title.startsWith('[학습]') && !isLearningProject;

    if (isLearningProject) {
        const notes = memoryBlocksOrNotes;
        activeRecallTurns = notes; // Store the array of note objects

        notes.forEach((note, index) => {
            const turnItem = document.createElement('div');
            turnItem.className = 'recall-turn-item';
            turnItem.textContent = note.title.replace('[학습]', '').trim();
            turnItem.dataset.turnIndex = index;
            turnItem.addEventListener('click', () => {
                renderTurn(note, true); // Pass the note object and isLearningNote flag
                document.querySelectorAll('.recall-turn-item').forEach(item => item.classList.remove('active'));
                turnItem.classList.add('active');
            });
            fragment.appendChild(turnItem);
        });
        
        recallTurnListContainer.appendChild(fragment);
        if (notes.length > 0) {
            renderTurn(notes[0], true);
        }
    } else if (isSingleLearningNote) {
        // [MODIFIED] Unify parsing logic for TOC and content rendering.
        const fullContent = memoryBlocksOrNotes[0] || '';
        let noteTitle = title.replace('[학습]', '').trim(); // Default to note title
        const contentLines = fullContent.split('\n');
        
        let contentStartIndex = 0;
        while(contentStartIndex < contentLines.length && contentLines[contentStartIndex].trim() === '') { contentStartIndex++; }
        
        // [NEW] Extract H1 from content if present. This prioritizes the actual content title over the note title.
        if (contentStartIndex < contentLines.length && contentLines[contentStartIndex].trim().startsWith('# ')) {
            noteTitle = contentLines[contentStartIndex].trim().replace(/^#\s+/, '');
            contentStartIndex++;
        }
        
        // [CRITICAL FIX] Update the UI header with the extracted content title
        if(recallNoteTitle) recallNoteTitle.textContent = noteTitle;

        let noteSubtitle = '';
        if (contentStartIndex < contentLines.length && contentLines[contentStartIndex].trim().startsWith('*') && contentLines[contentStartIndex].trim().endsWith('*')) {
            noteSubtitle = contentLines[contentStartIndex].trim().slice(1, -1);
            contentStartIndex++;
        }
        
        const contentToParse = contentLines.slice(contentStartIndex).join('\n');
        const parsedBlocks = _parseLearningNoteToContentBlocks(contentToParse);
        
        const finalContentBlocks = [
            { type: 'main-header', title: noteTitle, subtitle: noteSubtitle },
            ...parsedBlocks
        ];

        // [FIX] Wrap in object to preserve both content and block structure for toggle logic
        activeRecallTurns = [{
            content: fullContent,
            blocks: finalContentBlocks,
            title: noteTitle
        }]; 
        
        renderTurn(activeRecallTurns[0], true); // Render the wrapper object

        // Build TOC from the parsed structure
        finalContentBlocks.forEach((block, index) => {
            if (block.type === 'heading' || block.type === 'curriculum-map') {
                const headingText = (block.type === 'heading' ? block.text : block.title).trim();
                const turnItem = document.createElement('div');
                turnItem.className = 'recall-turn-item';
                turnItem.textContent = headingText || `Section ${index + 1}`;
                turnItem.dataset.blockIndex = index; // Use the block's actual index
                turnItem.addEventListener('click', () => {
                    _scrollToSection(index);
                });
                fragment.appendChild(turnItem);
            }
        });
        
        recallTurnListContainer.appendChild(fragment);

        // Setup IntersectionObserver for scroll spying the TOC
        setTimeout(() => {
            const contentArea = document.getElementById('recall-content-area');
            if (!contentArea) return;
    
            let lastActiveTocIndex = null;
    
            const observerCallback = (entries) => {
                const intersectingEntries = entries.filter(e => e.isIntersecting);
                if (intersectingEntries.length > 0) {
                    const topEntry = intersectingEntries.reduce((prev, current) => {
                        return (prev.boundingClientRect.top < current.boundingClientRect.top) ? prev : current;
                    });
                    const currentIndex = parseInt(topEntry.target.id.split('-')[2], 10);
                    let targetHeadingIndex = -1;
                    // Use activeRecallTurns[0].blocks for single note view
                    const blocks = activeRecallTurns[0].blocks;
                    if (blocks) {
                        for (let i = currentIndex; i >= 0; i--) {
                            if (blocks[i] && (blocks[i].type === 'heading' || blocks[i].type === 'curriculum-map')) {
                                targetHeadingIndex = i;
                                break;
                            }
                        }
                    }

                    if (targetHeadingIndex !== -1 && lastActiveTocIndex !== targetHeadingIndex.toString()) {
                        lastActiveTocIndex = targetHeadingIndex.toString();
                        document.querySelectorAll('#recall-turn-list-container .recall-turn-item').forEach(item => item.classList.remove('active'));
                        const activeItem = document.querySelector(`#recall-turn-list-container .recall-turn-item[data-block-index="${targetHeadingIndex}"]`);
                        if (activeItem) {
                            activeItem.classList.add('active');
                            activeItem.scrollIntoView({ block: 'nearest', inline: 'start' });
                        }
                    }
                }
            };
    
            tocObserver = new IntersectionObserver(observerCallback, {
                root: contentArea, 
                rootMargin: '0px 0px -85% 0px', 
                threshold: 0
            });
    
            const sections = contentArea.querySelectorAll('[id^="recall-section-"]');
            sections.forEach(section => tocObserver.observe(section));
    
        }, 100);

    } else {
        // --- Existing logic for narrative notes ---
        const memoryBlocks = memoryBlocksOrNotes;
        activeRecallTurns = memoryBlocks;
        memoryBlocks.forEach((chunk, index) => {
            const turnMatch = chunk.match(/## \[\s?턴\s?(\d+)\s?\]/);
            const snapshotMatch = chunk.match(/## \[📸 스냅샷: (.*?)\]/);
            
            const turnItem = document.createElement('div');
            turnItem.className = 'recall-turn-item';

            if (turnMatch) {
                const turnNumber = turnMatch[1];
                const mainTitleMatch = chunk.match(/### @mainTitle: (.*)/);
                const mainTitle = mainTitleMatch ? mainTitleMatch[1].trim() : null;

                if (mainTitle) {
                    turnItem.textContent = `턴 ${turnNumber}: ${mainTitle}`;
                } else {
                    turnItem.textContent = `턴 ${turnNumber}`;
                }
            } else if (snapshotMatch) {
                const snapshotTitle = snapshotMatch[1].trim();
                turnItem.textContent = `📸 ${snapshotTitle}`;
            } else {
                 turnItem.textContent = `기록 #${index + 1}`;
            }
            
            turnItem.dataset.turnIndex = index;
            turnItem.addEventListener('click', () => {
                renderTurn(chunk, false); // Pass flag
                document.querySelectorAll('.recall-turn-item').forEach(item => item.classList.remove('active'));
                turnItem.classList.add('active');
            });
            fragment.appendChild(turnItem);
        });
        recallTurnListContainer.appendChild(fragment);
        if (memoryBlocks.length > 0) {
            renderTurn(memoryBlocks[0], false);
        }
    }

    if (!recallTurnListContainer.dataset.contextMenuBound) {
        recallTurnListContainer.addEventListener('contextmenu', (event) => {
            const turnItem = event.target.closest('.recall-turn-item');
            if (turnItem) {
                event.preventDefault();
                const turnIndex = parseInt(turnItem.dataset.turnIndex, 10);
                const isLearningNoteContext = (recallNoteTitle.textContent || '').includes('[학습]');
                
                const menuItems = [
                    {
                        label: '이 턴을 메인 화면에서 재구성',
                        action: () => {
                            let contentToRender;
                            if (isLearningProject) {
                                // For a learning project, activeRecallTurns is an array of note objects
                                contentToRender = activeRecallTurns[turnIndex]?.content || '';
                            } else if (isSingleLearningNote) {
                                // For a single learning note, use the wrapper's content
                                contentToRender = activeRecallTurns[0].content || '';
                            } else {
                                // For narrative notes, activeRecallTurns is an array of markdown strings
                                contentToRender = activeRecallTurns[turnIndex];
                            }
                            
                            if (contentToRender && typeof renderMarkdownAsScene === 'function') {
                                isInteractiveRecallMode = true;
                                trace("UI.Action", "InteractiveRecallTriggeredFromRecallViewer", { type: isLearningNoteContext ? 'learning' : 'narrative' });
                                renderMarkdownAsScene(contentToRender);
                                togglePanel(notesAppPanel, false);
                            }
                        }
                    }
                ];
                
                createContextMenu(menuItems, event);
            }
        });
        recallTurnListContainer.dataset.contextMenuBound = 'true';
    }
    
    const firstTurnItem = recallTurnListContainer.querySelector('.recall-turn-item');
    if (firstTurnItem) firstTurnItem.classList.add('active');
}

// Public function for single notes
function initializeSingleNoteRecallViewer(note) {
    if (!note || !note.content) {
        console.error("Cannot initialize recall viewer: Invalid note data.");
        return;
    }
    // We pass an array with a single item for consistency with the render function logic
    const memoryBlocks = [note.content]; 
    // Passing true for isLearningProject is WRONG here if we want to trigger single note logic.
    // But wait, logic checks title. If title has [학습], it triggers isSingleLearningNote inside.
    _renderRecallView(note.title, memoryBlocks, false);
}

// Public function for projects
async function initializeProjectRecallViewer(projectId) {
    const project = localNoteProjectsCache.find(p => p.id === projectId);
    if (!project) {
        console.error("Cannot initialize recall viewer: Project not found.");
        return;
    }
    
    const notesInProject = localNotesCache
        .filter(n => n.projectId === projectId && n.content && (n.content.includes('## [턴') || n.content.includes('## [📸 스냅샷:')))
        .sort((a, b) => (a.createdAt?.toMillis() || 0) - (b.createdAt?.toMillis() || 0));

    if (notesInProject.length === 0) {
        showToastNotification("회상할 기록이 없습니다.", "이 폴더에는 턴 또는 스냅샷 데이터가 포함된 메모가 없습니다.", `recall-empty-${Date.now()}`);
        return;
    }
    
    const contentPromises = notesInProject.map(note => getNoteContent(note.id));
    const allContents = await Promise.all(contentPromises);
    
    const fullContent = allContents.join('\n\n');
    const memoryBlocks = fullContent.split(/(?=## \[(?:턴|📸 스냅샷:))/).filter(chunk => chunk.trim() !== '');

    _renderRecallView(`[전체 회상] ${project.name}`, memoryBlocks, false);
}

async function initializeLearningProjectRecallViewer(projectId) {
    const project = localNoteProjectsCache.find(p => p.id === projectId);
    if (!project) {
        console.error("Cannot initialize recall viewer: Project not found.");
        return;
    }

    const notesInProject = localNotesCache
        .filter(n => n.projectId === projectId && n.title.startsWith('[학습]'))
        .sort((a, b) => a.title.localeCompare(b.title, 'ko', { numeric: true }));

    if (notesInProject.length === 0) {
        showToastNotification("회상할 학습 노트가 없습니다.", "이 폴더에는 '[학습]'으로 시작하는 메모가 없습니다.", `recall-empty-learning-${Date.now()}`);
        return;
    }
    
    _renderRecallView(`[학습 전체 회상] ${project.name}`, notesInProject, true);
}


function _parseLearningNoteToContentBlocks(markdown) {
    if (!markdown) return [];

    const blocks = [];
    
    // Check for special embedded curriculum data first for perfect reconstruction.
    const curriculumMatch = markdown.match(/<!-- CURRICULUM_DATA:([\s\S]*?) -->/);
    if (curriculumMatch && curriculumMatch[1]) {
        try {
            const curriculumData = JSON.parse(curriculumMatch[1]);
            if (curriculumData.type === 'curriculum-map') {
                blocks.push(curriculumData);
                // If we find this, we assume it's the only content and return immediately.
                return blocks;
            }
        } catch (e) {
            console.error("Failed to parse archived curriculum data from comment:", e);
            // Fall through to generic parsing if JSON is corrupt.
        }
    }

    const lines = markdown.split('\n');
    let currentParagraphLines = [];

    const pushParagraph = () => {
        if (currentParagraphLines.length > 0) {
            blocks.push({ type: 'paragraph', content: currentParagraphLines.join('\n').trim() });
            currentParagraphLines = [];
        }
    };

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const trimmedLine = line.trim();

        if (trimmedLine === '') {
            pushParagraph();
            continue;
        }

        if (trimmedLine.startsWith('**키워드:**')) {
            pushParagraph();
            const keywords = trimmedLine.substring('**키워드:**'.length).split(',').map(kw => kw.trim()).filter(Boolean);
            blocks.push({ type: 'keywords', keywords });
        } else if (trimmedLine.startsWith('## ')) {
            pushParagraph();
            // [MODIFIED] Support H2 headings in note body
            blocks.push({ type: 'heading', level: 2, text: trimmedLine.substring(3) });
            blocks.push({ type: 'generated-image-placeholder' });
            blocks.push({ type: 'visualization-placeholder' });
        } else if (trimmedLine.startsWith('### ')) {
            pushParagraph();
            // [MODIFIED] Use Level 3 for '###' headings to match standard H3 styling (underline) instead of H2 styling (bar).
            blocks.push({ type: 'heading', level: 3, text: trimmedLine.substring(4) });
            blocks.push({ type: 'generated-image-placeholder' });
            blocks.push({ type: 'visualization-placeholder' });
        } else if (trimmedLine === '---') {
            pushParagraph();
            blocks.push({ type: 'horizontal-rule' });
        } else if (trimmedLine.startsWith('> ')) {
            pushParagraph();
            let bqLines = [trimmedLine.substring(2)];
            while (i + 1 < lines.length && lines[i + 1].trim().startsWith('> ')) {
                i++;
                bqLines.push(lines[i].trim().substring(2));
            }
            blocks.push({ type: 'blockquote', content: bqLines.join('\n') });
        } else if (trimmedLine.startsWith('**') && trimmedLine.endsWith('**') && !trimmedLine.includes('키워드')) {
             pushParagraph();
             let summaryTitle = trimmedLine;
             let summaryContent = [];
             while(i + 1 < lines.length && lines[i + 1].trim() !== '' && !lines[i + 1].trim().match(/^(###\s|---|>|`|\*\*키워드:\*\*)/)) {
                 i++;
                 summaryContent.push(lines[i]);
             }
             blocks.push({ type: 'summary', title: summaryTitle, content: summaryContent.join('\n') });
        } else if (trimmedLine.match(/^\d+\.\s/)) { // Ordered list
            pushParagraph();
            let listItems = [trimmedLine.replace(/^\d+\.\s/, '')];
            while(i + 1 < lines.length && lines[i+1].trim().match(/^\d+\.\s/)) {
                i++;
                listItems.push(lines[i].trim().replace(/^\d+\.\s/, ''));
            }
            blocks.push({ type: 'ordered-list', items: listItems });
        } else if (trimmedLine.match(/^-\s/)) { // Unordered list
            pushParagraph();
            let listItems = [trimmedLine.replace(/-\s/, '')];
            while(i + 1 < lines.length && lines[i+1].trim().match(/^-\s/)) {
                i++;
                listItems.push(lines[i].trim().replace(/-\s/, ''));
            }
            blocks.push({ type: 'unordered-list', items: listItems });
        }
        else {
            currentParagraphLines.push(line);
        }
    }

    pushParagraph();

    return blocks;
}


function renderTurn(turnData, isLearningNote = false) {
    const contentArea = document.getElementById('recall-content-area');
    if (!contentArea) return;

    // Pass the noteId to the content area for the pin button to use
    if (isLearningNote && typeof turnData === 'object' && turnData.id) {
        contentArea.dataset.noteId = turnData.id;
    } else {
        delete contentArea.dataset.noteId;
    }

    contentArea.innerHTML = '';
    
    // [MODIFIED] Robust Type Detection for the new Wrapper structure
    const isSingleNoteWrapper = typeof turnData === 'object' && turnData.blocks && turnData.content;
    
    const isNoteObject = isLearningNote && typeof turnData === 'object' && turnData !== null && !Array.isArray(turnData) && !isSingleNoteWrapper;
    const isParsedBlockArray = isLearningNote && Array.isArray(turnData);

    if (isLearningNote) {
        let contentBlocks;
        if (isSingleNoteWrapper) {
            contentBlocks = turnData.blocks;
        } else if (isParsedBlockArray) {
            contentBlocks = turnData;
        } else {
            contentBlocks = _parseLearningNoteToContentBlocks(turnData.content || '');
        }
        
        contentBlocks.forEach((block, index) => {
            const blockElement = renderBlock(block);
            if (blockElement) {
                // Assign ID using the block's actual index
                blockElement.id = `recall-section-${index}`;
                contentArea.appendChild(blockElement);
            }
        });
    } else { // Narrative note
        const contentBlocks = parseTurnMarkdownToContentBlocks(turnData);
        contentBlocks.forEach((block, index) => {
            try {
                const blockElement = renderBlock(block, index);
                if (blockElement) {
                    contentArea.appendChild(blockElement);
                }
            } catch (error) {
                console.error("Block Rendering Error in Recall Viewer:", error, "Problematic Block:", block);
            }
        });
    }

    initializeDynamicContentListeners(contentArea);
}

function parseTurnMarkdownToContentBlocks(turnMarkdown) {
    const contentBlocks = [];

    const vizComments = [];
    const cleanMarkdown = turnMarkdown.replace(/<!-- VIZ_DATA:([\s\S]*?) -->/g, (match, vizDataJson) => {
        vizComments.push(vizDataJson);
        return '';
    });

    const mainTitleMatch = cleanMarkdown.match(/### @mainTitle: (.*)/);
    const mainSubtitleMatch = cleanMarkdown.match(/### @mainSubtitle: (.*)/);
    const turnMatch = cleanMarkdown.match(/## \[\s?턴\s?(\d+)\s?\]/);
    const snapshotMatch = cleanMarkdown.match(/## \[📸 스냅샷: (.*?)\]/);
    
    let headerTitle = "기록";
    if (mainTitleMatch && mainTitleMatch[1]) {
        headerTitle = mainTitleMatch[1].trim();
    } else if (snapshotMatch && snapshotMatch[1]) {
        headerTitle = snapshotMatch[1].trim();
    } else if (turnMatch && turnMatch[1]) {
        headerTitle = `턴 ${turnMatch[1]}`;
    }

    const headerBlock = {
        type: 'main-header',
        title: headerTitle
    };

    if (snapshotMatch && snapshotMatch[1]) {
        if (mainTitleMatch && mainTitleMatch[1]) {
            headerBlock.subtitle = `📸 스냅샷: ${snapshotMatch[1].trim()}`;
        }
    }
    else if (mainSubtitleMatch && mainSubtitleMatch[1]) {
        headerBlock.subtitle = mainSubtitleMatch[1].trim();
    }
    
    contentBlocks.push(headerBlock);

    const headingMatch = cleanMarkdown.match(/### @heading: (.*)/);
    let headingText = '**현재 상황**'; // Default fallback
    if (headingMatch && headingMatch[1]) {
        headingText = headingMatch[1].trim();
    }
    
    contentBlocks.push({
        type: 'heading',
        level: 2,
        text: headingText
    });

    // User Choice
    const userChoiceMatch = cleanMarkdown.match(/### 사용자 선택\s*\n> ([\s\S]*?)(?=\n\n---|\n###|$)/);
    if (userChoiceMatch && userChoiceMatch[1].trim()) {
        contentBlocks.push({
            type: 'blockquote',
            content: `**사용자 선택:** ${userChoiceMatch[1].trim()}`
        });
    }

    // Narrative
    const narrativeMatch = cleanMarkdown.match(/### 생성된 서사\s*\n([\s\S]*?)(?=\n\n---|\n###|$)/);
    if (narrativeMatch && narrativeMatch[1].trim()) {
        contentBlocks.push({ type: 'paragraph', content: narrativeMatch[1].trim() });
        contentBlocks.push({ type: 'generated-image-placeholder' });
        contentBlocks.push({ type: 'visualization-placeholder' });
    }

    contentBlocks.push({ type: 'horizontal-rule' });

    // [MODIFIED] Add map block before status dashboard
    const mapDataMatch = cleanMarkdown.match(/<!-- MAP_DATA:([\s\S]*?) -->/);
    if (mapDataMatch && mapDataMatch[1]) {
        try {
            const mapData = JSON.parse(mapDataMatch[1]);
            contentBlocks.push({
                type: 'interactive_map',
                locationName: mapData.locationName,
                latitude: mapData.latitude,
                longitude: mapData.longitude
            });
        } catch (e) {
            console.error("Failed to parse map data from markdown", e);
        }
    }

    // Status Dashboard & Scan Table
    const dashboardBlock = { type: 'status_dashboard', modules: [] };
    const statusMatch = cleanMarkdown.match(/### 상태 정보\s*\n([\s\S]*?)(?=\n\n---|\n###|$)/);
    if (statusMatch && statusMatch[1].trim()) {
        const statusContent = statusMatch[1].trim();
        const moduleParts = statusContent.split(/\s*\*\*(.*?)\*\*\s*\n/);
        
        for (let i = 1; i < moduleParts.length; i += 2) {
            const title = moduleParts[i];
            const itemsText = moduleParts[i + 1];
            if (!title || !itemsText) continue;

            const module = { title: title, items: [] };
            
            if (title.includes('상태')) module.icon = '❤️';
            if (title.includes('신체')) module.icon = '🧘';
            if (title.includes('환경')) module.icon = '🌍';
            if (title.includes('정보')) module.icon = '👤';
            if (title.includes('시간')) module.icon = '🕰️';
            if (title.includes('감각')) module.icon = '👁️';
            if (title.includes('사건')) module.icon = '📜';

            const itemLines = itemsText.trim().split('\n');
            itemLines.forEach(line => {
                const itemMatch = line.match(/- \*\*(.*?):\*\* (.*)/);
                if (itemMatch) {
                    const term = itemMatch[1].trim();
                    const def = itemMatch[2].trim();
                    // [FIX] Detect event progress item and populate event metadata
                    if (term === '진행도') {
                        module.event_name = title;
                        module.progress_percent = def.replace('%', '');
                        // We don't push to items so it renders as a progress bar in `renderBlock`
                    } else {
                        module.items.push({ term: term, definition: def });
                    }
                }
            });
            dashboardBlock.modules.push(module);
        }
    }
    
    const scanMatch = cleanMarkdown.match(/### 주변 탐색\s*\n([\s\S]*?)(?=\n\n---|\n###|$)/);
    if (scanMatch && scanMatch[1].trim()) {
        dashboardBlock.modules.push({
            title: "주변 탐색",
            icon: "🔍",
            scan_table_markdown: scanMatch[1].trim()
        });
    }

    if (dashboardBlock.modules.length > 0) {
        contentBlocks.push(dashboardBlock);
    }
    
    contentBlocks.push({ type: 'horizontal-rule' });

    // Append the parsed visualization blocks
    vizComments.forEach(vizDataJson => {
        try {
            const vizData = JSON.parse(vizDataJson);
            if (vizData.type === 'visualization') {
                contentBlocks.push(vizData);
            }
        } catch (e) {
            console.error("Failed to parse archived VIZ_DATA from comment:", e);
        }
    });

    // Presented Choices
    const choicesMatch = cleanMarkdown.match(/### 제시된 선택지\s*\n([\s\S]*?)$/);
    if (choicesMatch && choicesMatch[1].trim()) {
        const choiceItems = choicesMatch[1].trim().split('\n').map(line => {
            return line.replace(/^\d+\.\s*/, '').trim();
        });
        contentBlocks.push({
            type: 'ordered-list',
            items: choiceItems
        });
    }

    return contentBlocks;
}

async function renderMarkdownAsScene(markdown) {
    const placeholder = document.getElementById('ai-content-placeholder');
    if (!placeholder) return;

    // --- 1. FADE OUT ---
    placeholder.style.animation = 'content-fade-out 0.3s ease-out forwards';
    await new Promise(resolve => setTimeout(resolve, 300)); // Wait for animation

    // --- 2. RENDER NEW CONTENT (HIDDEN) ---
    placeholder.innerHTML = ''; 
    placeholder.style.animation = ''; // Reset animation property
    
    const wrapper = document.createElement('div');
    wrapper.className = 'wrapper';

    const container = document.createElement('div');
    container.className = 'container';
    container.id = 'learning-content';
    
    // Hide container initially for staggered animation
    container.style.visibility = 'hidden';

    // [MODIFIED] Intelligent parsing based on content
    let contentBlocks;
    if (markdown.includes('## [턴') || markdown.includes('## [📸 스냅샷:')) {
        // It's a narrative/chronicle note
        contentBlocks = parseTurnMarkdownToContentBlocks(markdown);
    } else {
        // It's a learning note
        const noteTitle = document.getElementById('recall-note-title')?.textContent || '학습 자료';
        // Attempt to extract H1 from content first for better title accuracy
        let displayTitle = noteTitle.replace('[학습]', '').trim();
        const lines = markdown.split('\n');
        let idx = 0;
        while(idx < lines.length && lines[idx].trim() === '') idx++;
        if (idx < lines.length && lines[idx].trim().startsWith('# ')) {
            displayTitle = lines[idx].trim().replace(/^#\s+/, '');
            // We don't remove the H1 line from markdown here because _parseLearningNoteToContentBlocks will handle it (now simply skipping it or processing it as paragraph if unrecognized, but we want a header block).
            // Actually, since we manually create a header block below, we might want to strip the H1 line from the body to avoid duplication if _parse supports it.
            // However, _parseLearningNoteToContentBlocks currently doesn't support H1 ('# '), so it would become a paragraph.
            // To fix duplication, let's remove the H1 line from the body passed to parser.
            lines.splice(idx, 1); // Remove H1 line
            markdown = lines.join('\n');
        }

        const parsedBody = _parseLearningNoteToContentBlocks(markdown);
        contentBlocks = [
            { type: 'main-header', title: displayTitle },
            ...parsedBody
        ];
    }
    
    contentBlocks.forEach((block, index) => {
        try {
            const blockElement = renderBlock(block, index);
            if (blockElement) {
                // Hide each block initially
                blockElement.style.opacity = 0;
                container.appendChild(blockElement);
            }
        } catch (error) {
            console.error("Block Rendering Error in Interactive Mode:", error, "Block:", block);
            if (typeof createErrorBlock === 'function') {
                container.appendChild(createErrorBlock(error, block));
            }
        }
    });

    wrapper.appendChild(container);
    placeholder.appendChild(wrapper);

    // --- 3. FADE IN & REVEAL ---
    container.style.visibility = 'visible';

    // Select all direct children of the container to animate
    const elementsToAnimate = Array.from(container.children);
    
    elementsToAnimate.forEach((el, index) => {
        const delay = index * 100; // Stagger delay of 100ms
        el.style.animation = `block-fade-in-up 0.5s ${delay}ms ease-out forwards`;
    });


    // Add click-to-copy functionality back to choices
    const choiceLists = container.querySelectorAll('.type-ordered-list, .type-list');
    choiceLists.forEach(listContainer => {
        listContainer.querySelectorAll('li').forEach(li => {
            li.style.cursor = 'pointer';
            li.title = '클릭하여 채팅창에 입력';
            li.addEventListener('click', () => {
                if (chatInput) {
                    chatInput.value = li.innerText;
                    chatInput.focus();
                    autoResizeTextarea(chatInput);
                }
            });
        });
    });
}
