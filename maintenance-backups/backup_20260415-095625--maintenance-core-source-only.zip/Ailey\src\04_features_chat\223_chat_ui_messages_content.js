/* --- Ailey & Bailey Canvas --- */
// File: 223_chat_ui_messages_content.js
// Version: 1.2 (Conditional Collapse)
// Description: Implemented conditional collapsing. New messages arrive expanded, while historical messages are loaded in a collapsed state.

const CHAR_PER_SECOND = 150; // Kept for legacy calculations, but not used for rendering.

function inferCodeBlockDisplayLabel(code, infostring) {
    const lang = (infostring || '').match(/\S*/)?.[0] || '';
    const normalizedLang = lang.trim().toLowerCase();
    const trimmedCode = String(code || '').trim();

    const looksLikeViz =
        (typeof window.looksLikeVisualizationHtmlFragment === 'function' && window.looksLikeVisualizationHtmlFragment(trimmedCode)) ||
        (/<(div|section|svg|canvas|script|style)\b/i.test(trimmedCode) && /vizContainer|querySelector|appendChild|createElement|d3\.|echarts|Plotly|new\s+Chart|THREE\.|p5\b/i.test(trimmedCode));

    if (normalizedLang === 'html' && looksLikeViz) {
        return 'Visualization Fragment';
    }

    if (normalizedLang) {
        return normalizedLang.toUpperCase();
    }

    if (trimmedCode.startsWith('{') || trimmedCode.startsWith('[')) {
        return 'JSON';
    }

    if (looksLikeViz) {
        return 'Visualization Fragment';
    }

    if (/<[a-z][\s\S]*>/i.test(trimmedCode)) {
        return 'HTML Fragment';
    }

    return 'Code Block';
}

function shouldKeepMessageExpanded(contentString, contentElement) {
    const normalizedContent = String(contentString || '').trim();
    if (!normalizedContent) return false;

    if (/```/.test(normalizedContent)) {
        return true;
    }

    if (contentElement?.querySelector('details.code-details, pre, code')) {
        return true;
    }

    if (typeof window.looksLikeVisualizationHtmlFragment === 'function' && window.looksLikeVisualizationHtmlFragment(normalizedContent)) {
        return true;
    }

    return false;
}

function _addCollapsibleFeature(contentElement, containerElement, contentString, isNewlyArrived = false) {
    // Heuristic to decide if the button is needed.
    // Checks for more than 3 newlines or a character length over 250.
    const lineBreaks = (contentString.match(/\n/g) || []).length;
    const isLong = contentString.length > 250;

    if (lineBreaks >= 3 || isLong) {
        if (shouldKeepMessageExpanded(contentString, contentElement)) {
            return;
        }

        // Conditionally collapse based on whether the message is new or historical.
        if (!isNewlyArrived) {
            contentElement.classList.add('collapsed');
        }

        const toggleBtn = document.createElement('button');
        toggleBtn.className = 'toggle-visibility-btn with-icon';
        
        const expandIcon = `<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z" /></svg>`;
        const collapseIcon = `<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M7.41,15.41L12,10.83L16.59,15.41L18,14L12,8L6,14L7.41,15.41Z" /></svg>`;
        
        const isInitiallyCollapsed = contentElement.classList.contains('collapsed');
        toggleBtn.innerHTML = isInitiallyCollapsed 
            ? `${expandIcon}<span>더 보기</span>` 
            : `${collapseIcon}<span>간략히</span>`;
        containerElement.appendChild(toggleBtn);

        toggleBtn.addEventListener('click', () => {
            const isNowCollapsed = contentElement.classList.toggle('collapsed');
            toggleBtn.innerHTML = isNowCollapsed 
                ? `${expandIcon}<span>더 보기</span>` 
                : `${collapseIcon}<span>간략히</span>`;
        });
    }
}

// [NEW] Helper function to remove empty text nodes created by the markdown parser.
function cleanupWhitespaceNodes(element) {
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, null, false);
    const nodesToRemove = [];
    let node;
    while (node = walker.nextNode()) {
        // A text node is empty if it only contains whitespace characters.
        if (!/\S/.test(node.nodeValue)) {
            nodesToRemove.push(node);
        }
    }
    // Remove collected nodes after traversal to avoid modifying the list while iterating.
    nodesToRemove.forEach(node => node.parentNode.removeChild(node));
}

function renderStaticMarkdown(element, text) {
    if (!element || typeof text !== 'string') return;
    const processedText = renderKatexInString(text);
    if (typeof marked === 'undefined') {
        element.innerHTML = processedText;
        return;
    }

    // [MODIFIED] Use a custom renderer for collapsible code blocks
    const renderer = new marked.Renderer();
    const originalCodeRenderer = renderer.code.bind(renderer);

    renderer.code = (code, infostring, escaped) => {
        const originalCode = code;
        const originalInfoString = infostring;
        const originalEscaped = escaped;
        let normalizedCode = code;
        let normalizedInfoString = infostring;

        if (normalizedCode && typeof normalizedCode === 'object') {
            normalizedInfoString = normalizedCode.lang || normalizedCode.language || '';
            normalizedCode = normalizedCode.text || normalizedCode.raw || '';
        }

        const langDisplay = inferCodeBlockDisplayLabel(normalizedCode, normalizedInfoString);
        
        // Use the original renderer to get the standard <pre><code> block which Prism.js needs
        const preCodeBlock = originalCodeRenderer(originalCode, originalInfoString, originalEscaped);

        return `
            <details class="code-details">
                <summary class="code-summary">${langDisplay}</summary>
                ${preCodeBlock}
            </details>
        `;
    };

    element.innerHTML = marked.parse(processedText, { renderer: renderer, gfm: true, breaks: true, sanitize: false });
    
    cleanupWhitespaceNodes(element);

    if (typeof Prism !== 'undefined') {
        Prism.highlightAllUnder(element);
    }
}


// [OBSOLETE] This function is no longer called but kept for reference.
function renderStreamingMarkdown(element, text, offset = 0) {}

function startSummaryAnimation(blockElement, reasoningSteps) {}
function typewriterEffect(element, text, onComplete) {}
function clearTimers(blockId) {
    if (activeTimers[blockId]) {
        activeTimers[blockId].forEach(clearInterval);
        delete activeTimers[blockId];
    }
}
