# Ailey Standalone Export Phase 0 Report

- Artifact Type: implementation-report
- Created: 2026-04-12 08:45:13 +09:00
- Scope: Execute Phase 0 from `20260412-083100--standalone-export-plan--ailey--v01.md`
- Status: completed

---

## Summary

Phase 0 is complete.

- Added `exportAsLiveHtml()` to export the current Canvas content as a live, standalone HTML file.
- The exported HTML bootstraps Ailey through `renderAppShell()` using the GitHub-hosted bundle assets.
- Existing static export functions were left intact.
- Rebundling completed successfully after the source change.

---

## Implemented Changes

### `src/02_utils/018_utils_html_exporter.js`

Added a new live-export path with supporting helpers:

- `LIVE_EXPORT_BUNDLE_BASE` for the hosted bundle base URL
- `_escapeHtmlForExport()` for safe title/body-class injection
- `_copyIframeSrcdocForExport()` so visualization `iframe.srcdoc` survives cloning
- `_downloadHtmlForExport()` for shared HTML file download flow
- `window.exportAsLiveHtml()` as the new standalone live-export entry point

Behavior of `exportAsLiveHtml()`:

- captures the current rendered content from `#learning-content` when available
- preserves iframe `srcdoc`
- removes hover-only overlay controls from the exported DOM snapshot
- builds a full HTML file that loads:
  - `bundle/main.css`
  - `katex.min.css`
  - Toast UI CSS
  - `bundle/main.js`
- waits for `DOMContentLoaded`
- calls `renderAppShell(exportedHtml, title, 'exported-root')`

This means the downloaded HTML is designed to boot the full Ailey shell rather than remain a static snapshot-only viewer.

---

## Verification

Executed checks:

1. `node --check Ailey/src/02_utils/018_utils_html_exporter.js`
2. `node ./bundler.js` in `Ailey`
3. source confirmation that `exportAsLiveHtml()` and the live bundle links are present

Observed result:

- Syntax check passed.
- Bundling passed and regenerated `bundle/main.js` and `bundle/main.css`.
- The new live export entry exists in source and targets the hosted runtime bundle path.

---

## Residual Risks

- Phase 0 did not add UI wiring yet, so the new export path is implemented but not surfaced in the menu.
- Browser-level validation of an actually downloaded live-export HTML file is still pending.
- If exported content contains unusual raw HTML edge cases, template embedding may still need hardening in a later phase.

---

## Next Recommended Step

Proceed to Phase 1:

- add the new live export option to the UI,
- export a real file from Canvas or local mode,
- and verify that the downloaded file boots Ailey correctly under `file://`.
