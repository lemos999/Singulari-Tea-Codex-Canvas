# Work Plan: Minimized Panels And Chat Auto-Compact

- Timestamp: 2026-04-14 21:41 KST
- Owner: Codex
- User approval: granted
- Rollback posture: if this pass regresses runtime stability, revert only this bounded pass
- Root backup for this pass: [backup_20260414-212950--pre-compact-pass.zip](</abs/path/c:/Users/Lemos/Desktop/새 폴더 (2)/backup_20260414-212950--pre-compact-pass.zip>)

## Goals

1. Fix legacy minimized panel visuals so chat and notes minimize into a clean, intentional shell instead of a malformed strip.
2. Verify how `참조할 이전 대화 수` currently behaves and replace raw overflow with rolling auto-compaction.
3. Add persisted `auto compact` user setting with default `ON`.
4. When compaction is enabled, compact every 20 accumulated prior messages into a durable summary memory, reset the rolling counter, and continue.
5. Preserve context as much as possible by feeding compact memory plus recent raw turns into the payload.
6. Keep desktop and mobile behavior safe.
7. Prepare a concrete modernization plan for advanced options UI and semantics without mixing that redesign into this behavior pass.

## Current Findings

### Minimized panels

- Current minimize behavior is mostly `panel.classList.toggle('minimized')`.
- Current CSS only forces height to `42px`, so width, header spacing, body clipping, and control alignment remain legacy and inconsistent.
- Risk: fix should stay local to panel shell behavior and avoid disturbing mobile full-panel mode.

### Previous-chat reference behavior

- Current logic is raw message slicing:
  - temporary session: `temporarySession.messages.slice(-historyLimit)`
  - persisted session: `fetchPastMessages(..., historyLimit).reverse()`
- Current `chatHistoryLimit` is a hard cap on raw messages, not a compacting memory policy.
- No compaction state exists in session state or persisted settings right now.

### Good integration points

- `buildChatPayload(...)` can safely prepend extra synthetic memory messages.
- `sendQueryToAI(...)` is the narrowest place to normalize context for both UI sends and programmatic sends.
- `programmaticChatSendDetailed(...)` already supports `ignoreHistory`, which is useful for compaction summarization calls.
- `userApiSettings.universalModelSettings` and preset settings already persist temperature, top-p, grounding, thinking budget, and history limit.

## Design Intent

### Minimized panel shell

- Keep minimize as a reversible window state.
- When minimized on desktop:
  - header stays visible and aligned
  - content body is fully collapsed
  - width clamps to a sane compact size
  - controls stay usable
  - chat and notes titles remain readable
- On mobile:
  - preserve current behavior of hiding/closing instead of desktop-style minimized strips

### Auto-compact memory

- Persist a user-facing setting:
  - `autoCompactEnabled: true` by default
- Keep current `chatHistoryLimit`, but reinterpret overflow when auto-compact is enabled:
  - every 20 prior messages become one compact memory entry
  - rolling uncompacted counter resets after each successful compaction
- Store compaction state per session:
  - for temporary chat in `temporarySession`
  - for persisted sessions on the session document so the state survives reload
- Payload composition target:
  - system instruction
  - compact memory summary messages
  - recent uncompacted raw messages
  - current user message
- Compaction must be history-safe:
  - summarize only older chunks already covered by the compact cursor
  - never re-summarize the same chunk twice
  - do not compact if the setting is disabled
  - do not compact while another send is already in flight for the same session

## Proposed Data Additions

### Universal / preset settings

- `autoCompactEnabled: true`

### Per-session compaction state

- `compactionState:`
  - `enabled`: boolean snapshot
  - `compactedChunks`: array of compact summaries
  - `compactedMessageCount`: number of older raw messages already absorbed
  - `lastCompactedAt`: timestamp

### Temporary session state

- extend `temporarySession` with:
  - `compactionState`

## Implementation Steps

1. Add plan-safe defaults and persistence for auto compact setting.
2. Normalize minimized panel shell in panel manager and panel CSS.
3. Add chat compaction helpers:
   - build session compaction state
   - decide if new compaction is needed
   - summarize one 20-message chunk
   - merge compact memory with recent raw messages
4. Wire compaction into:
   - regular chat send
   - temporary chat send
   - programmatic chat send
5. Keep compaction summarizer isolated:
   - dedicated instruction
   - ignore prior chat history
   - minimal retry surface
6. Expose compact toggle in API settings modal and keep it mobile-safe.
7. Validate:
   - minimized chat shell
   - minimized notes shell
   - mobile non-regression
   - compaction trigger at 20 messages
   - second compaction after next 20 messages
   - compact memory survives session reload

## Verification Targets

- Desktop minimized chat and notes look intentional and aligned.
- Mobile still closes/hides panels instead of showing broken strips.
- `autoCompactEnabled` defaults to `true` on fresh load.
- Turning compact off restores plain raw-history behavior.
- At 20 accumulated prior messages, one compact summary is created and cursor advances.
- After another 20 messages, a second compact summary is created.
- Payload still includes recent raw turns plus compact memory.
- No page/console errors.

## Deferred But Planned

The following are explicitly kept out of this behavior patch and will be documented for the next pass:

- temperature / top-p control redesign
- grounding control modernization
- thinking budget control modernization
- clearer semantics and validation around advanced model knobs
- mobile-first redesign of the full advanced settings surface

## Scoreboard

- User score carried from prior milestone: 100
- Current pass score target: stability first, then behavior completeness
