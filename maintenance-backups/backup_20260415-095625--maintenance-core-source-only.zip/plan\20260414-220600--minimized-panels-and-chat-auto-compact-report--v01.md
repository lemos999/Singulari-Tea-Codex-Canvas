# Report: Minimized Panels And Chat Auto-Compact

- Timestamp: 2026-04-14 22:06 KST
- Root backup: `backup_20260414-212950--pre-compact-pass.zip`
- Work plan: `plan/20260414-214100--work-plan--minimized-panels-and-chat-auto-compact--v01.md`

## What Changed

### 1. Minimized panel shells

- Chat and notes panels now minimize into a consistent compact shell instead of keeping legacy malformed geometry.
- Desktop minimize stores the pre-minimized size and restores it cleanly.
- Mobile minimize behavior remains close/hide instead of desktop strip mode.

### 2. Previous-chat reference behavior

- Existing raw-history behavior was confirmed to be simple slicing, not rolling memory.
- A real bug was fixed at the same time:
  - `historyLimit = 0` could still leak full temporary history because `slice(-0)` returns the full array.
- The send path now strips accidental duplicate current-user history before payload assembly.

### 3. Rolling auto compact

- Added persisted `autoCompactEnabled` with default `true`.
- Added rolling compaction state for temporary and persisted sessions.
- When enabled, older context is compacted into durable memory before payload assembly.
- Payload now combines:
  - compact memory
  - recent raw turns
  - current user message

## Files Changed

- `Ailey/src/01_state/001_state_globalVars.js`
- `Ailey/src/02_utils/013_utils_panel_manager.js`
- `Ailey/src/03_core/110_core_api_settings.js`
- `Ailey/src/03_core/111_core_api_settings_data.js`
- `Ailey/src/03_core/112_core_api_settings_ui_structure.js`
- `Ailey/src/03_core/113_core_api_settings_ui_logic.js`
- `Ailey/src/03_core/114_core_api_settings_ui_refresh.js`
- `Ailey/src/04_features_chat/210_chat_ui_actions.js`
- `Ailey/src/04_features_chat/215_chat_orchestrator.js`
- `Ailey/src/04_features_chat/216_chat_context_compaction.js`
- `Ailey/src/04_features_chat/234_chat_session_manager.js`
- `Ailey/src_css/004_panels.css`
- `Ailey/src_css/015_notes_panel_base.css`
- `Ailey/src_css/020_chat_panel_base.css`

## Validation

- Script: `visual-tests/validate_panel_minimize_and_auto_compact.mjs`
- Latest result dir: `visual-tests/panel-minimize-auto-compact-2026-04-14T12-58-14-808Z`
- Summary: `visual-tests/panel-minimize-auto-compact-2026-04-14T12-58-14-808Z/validation-summary.txt`

Key checks:

- desktop minimized chat height = `52`
- desktop minimized notes height = `52`
- compact toggle default checked = `true`
- first temp compaction count = `20`
- second temp compaction count = `40`
- persisted compaction count = `40`
- history limit `0` produces empty prior context
- mobile minimize still hides panels
- page/console errors = `0`

## Follow-up Plan

- Advanced settings modernization plan: `plan/20260414-220200--advanced-model-controls-modernization-plan--v01.md`

## Publish

- Publish repo: `Singulari-Tea-Codex-Canvas-pr`
- GitHub repo: `lemos999/Singulari-Tea-Codex-Canvas`
- Commit: `086eba8`
