/* --- Ailey & Bailey Canvas --- */
// File: 250_immersion_controller.js
// Version: 5.0 (Compatibility Stub)
// Description: Immersion mode was removed during UI surface rationalization.
// A no-op stub is kept temporarily so stale callers do not crash.

const ImmersionController = {
    initialize() {
        return false;
    }
};
