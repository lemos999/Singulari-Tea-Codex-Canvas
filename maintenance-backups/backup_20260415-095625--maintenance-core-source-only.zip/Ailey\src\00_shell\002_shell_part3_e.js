/* --- Ailey & Bailey Canvas --- */
// File: 002_shell_part3_e.js
// Version: 1.0 (Modularization)
// Description: Contains the HTML for the Image Generation Studio modal (Part 2: Composition and Lighting Tabs).

const SHELL_PART_3_E = `
                        <!-- Composition Tab -->
                        <div id="img-gen-tab-composition" class="img-gen-tab-panel">
                             <div class="accordion-container">
                                <div class="accordion-header">대상 크기와 거리</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="close-up shot" data-tooltip="인물의 얼굴과 표정에 초점">클로즈업</button>
                                    <button class="option-btn" data-prompt="extreme close-up" data-tooltip="눈, 입 등 특정 부위를 극도로 확대">익스트림 클로즈업</button>
                                    <button class="option-btn" data-prompt="medium shot" data-tooltip="인물의 허리 위 상반신을 촬영">미디엄 샷</button>
                                    <button class="option-btn" data-prompt="full shot" data-tooltip="인물의 전신을 보여주는 촬영">풀 샷</button>
                                    <button class="option-btn" data-prompt="long shot" data-tooltip="인물과 주변 배경을 함께 넓게 촬영">롱 샷</button>
                                </div>
                            </div>
                            <div class="accordion-container">
                                <div class="accordion-header">카메라 각도</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="eye-level angle" data-tooltip="눈높이에서 평범하게 촬영">아이 레벨</button>
                                    <button class="option-btn" data-prompt="high-angle shot" data-tooltip="위에서 아래로 내려다보는 앵글">하이 앵글</button>
                                    <button class="option-btn" data-prompt="low-angle shot" data-tooltip="아래에서 위로 올려다보는 앵글">로우 앵글</button>
                                    <button class="option-btn" data-prompt="dutch angle" data-tooltip="카메라를 기울여 불안정감을 연출">더치 앵글</button>
                                    <button class="option-btn" data-prompt="bird's-eye view" data-tooltip="새가 보듯 수직으로 내려다보는 뷰">버드 아이 뷰</button>
                                    <button class="option-btn" data-prompt="worm's-eye view" data-tooltip="벌레가 보듯 지면에서 올려다보는 뷰">웜 아이 뷰</button>
                                </div>
                            </div>
                             <div class="accordion-container">
                                <div class="accordion-header">프레이밍과 특수 구도</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="rule of thirds" data-tooltip="화면을 3x3으로 나누어 주요 피사체를 배치">3분할 구도</button>
                                    <button class="option-btn" data-prompt="golden ratio" data-tooltip="황금 비율에 따라 안정적인 구도 연출">황금 비율</button>
                                    <button class="option-btn" data-prompt="symmetrical composition" data-tooltip="좌우 또는 상하가 대칭을 이루는 구도">대칭 구도</button>
                                    <button class="option-btn" data-prompt="leading lines" data-tooltip="시선을 이끄는 선을 활용한 구도">선도선 구도</button>
                                    <button class="option-btn" data-prompt="cinematic" data-tooltip="영화의 한 장면 같은 와이드스크린 비율">시네마틱</button>
                                    <button class="option-btn" data-prompt="panorama" data-tooltip="좌우로 넓게 펼쳐진 파노라마 뷰">파노라마</button>
                                    <button class="option-btn" data-prompt="fisheye lens" data-tooltip="어안 렌즈로 왜곡된 독특한 뷰">어안 렌즈</button>
                                    <button class="option-btn" data-prompt="macro shot" data-tooltip="피사체를 매우 가깝게 촬영하는 접사">매크로</button>
                                </div>
                            </div>
                            <div class="accordion-container">
                                <div class="accordion-header">추천 구도</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="character sheet, turnaround sheet, multiple views, front view, side view, back view" data-tooltip="캐릭터의 정면, 측면, 후면을 한 번에 보여주는 구도입니다.">턴어라운드 시트</button>
                                    <button class="option-btn" data-prompt="flat lay photography, top-down view, neatly arranged" data-tooltip="의상이나 사물을 위에서 평평하게 내려다보며 배치하는 구도입니다.">플랫 레이</button>
                                    <button class="option-btn" data-prompt="diorama, miniature scene, isometric view" data-tooltip="특정 장면을 축소 모형처럼 입체적으로 보여주는 구도입니다.">디오라마</button>
                                    <button class="option-btn" data-prompt="high-angle artistic view" data-tooltip="높은 곳에서 비스듬히 내려다보는 예술적인 앵글입니다.">하이 앵글 뷰</button>
                                    <button class="option-btn" data-prompt="top-down blueprint view, orthographic" data-tooltip="천장에서 수직으로 내려다보는 건축 설계도 같은 뷰입니다.">탑다운 설계도</button>
                                    <button class="option-btn" data-prompt="Contextual POV Mode, First-person view from the character's perspective, immersive body cam footage" data-tooltip="주인공의 1인칭 시점으로 서사를 재해석하여 이미지를 생성합니다. '자신의 손을 본다'와 같은 묘사를 지능적으로 반영합니다.">[👁️ 서사 기반 1인칭]</button>
                                </div>
                            </div>
                        </div>
                        <!-- Lighting Tab -->
                        <div id="img-gen-tab-lighting" class="img-gen-tab-panel">
                            <div class="accordion-container">
                                <div class="accordion-header">시간대와 자연광</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="golden hour lighting" data-tooltip="해질녘의 따뜻하고 부드러운 황금빛">골든 아워</button>
                                    <button class="option-btn" data-prompt="blue hour lighting" data-tooltip="해 뜨기 전, 진 후의 푸른빛">블루 아워</button>
                                    <button class="option-btn" data-prompt="midday sun" data-tooltip="그림자가 짧고 강렬한 한낮의 태양">한낮</button>
                                    <button class="option-btn" data-prompt="overcast" data-tooltip="구름이 껴 빛이 부드럽게 분산된 날">흐린 날</button>
                                    <button class="option-btn" data-prompt="moonlight" data-tooltip="은은하고 신비로운 달빛">달빛</button>
                                </div>
                            </div>
                            <div class="accordion-container">
                                <div class="accordion-header">조명 종류와 효과</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="dramatic lighting" data-tooltip="대비가 강하고 영화적인 느낌">극적인 조명</button>
                                    <button class="option-btn" data-prompt="soft light" data-tooltip="부드럽고 은은하며 그림자가 약한 빛">부드러운 빛</button>
                                    <button class="option-btn" data-prompt="studio lighting" data-tooltip="인물 사진에 쓰이는 전문적인 스튜디오 조명">스튜디오 조명</button>
                                    <button class="option-btn" data-prompt="Rembrandt lighting" data-tooltip="얼굴 한쪽에 삼각형 빛이 생기는 렘브란트 조명">렘브란트 조명</button>
                                    <button class="option-btn" data-prompt="backlight" data-tooltip="피사체 뒤에서 비추어 테두리를 강조하는 역광">역광</button>
                                    <button class="option-btn" data-prompt="silhouette" data-tooltip="역광으로 피사체를 검게 표현하는 실루엣">실루엣</button>
                                    <button class="option-btn" data-prompt="neon lighting" data-tooltip="화려한 네온사인 불빛">네온</button>
                                    <button class="option-btn" data-prompt="volumetric lighting" data-tooltip="공기 중의 빛줄기가 보이는 효과">체적 조명</button>
                                    <button class="option-btn" data-prompt="lens flare" data-tooltip="광원이 렌즈에 반사되어 생기는 플레어 효과">렌즈 플레어</button>
                                </div>
                            </div>
                             <div class="accordion-container">
                                <div class="accordion-header">장면 분위기</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="mysterious mood" data-tooltip="안개, 어둠 등을 활용한 신비로운 분위기">신비로운</button>
                                    <button class="option-btn" data-prompt="peaceful mood" data-tooltip="고요하고 평온한 분위기">평화로운</button>
                                    <button class="option-btn" data-prompt="energetic mood" data-tooltip="역동적이고 활기찬 분위기">활기찬</button>
                                    <button class="option-btn" data-prompt="melancholic mood" data-tooltip="비, 어두운 색조 등을 활용한 우울한 분위기">우울한</button>
                                    <button class="option-btn" data-prompt="majestic mood" data-tooltip="웅장한 자연이나 건축물로 장엄한 분위기 연출">장엄한</button>
                                    <button class="option-btn" data-prompt="eerie mood" data-tooltip="기묘하고 으스스한 분위기">으스스한</button>
                                    <button class="option-btn" data-prompt="dreamy mood" data-tooltip="꿈 속 같이 몽환적인 분위기">몽환적인</button>
                                </div>
                            </div>
                            <div class="accordion-container">
                                <div class="accordion-header">추천 조명</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="emissive light, glowing from within" data-tooltip="사물 자체가 빛을 발하는 듯한 신비로운 조명 효과입니다.">발광 조명</button>
                                    <button class="option-btn" data-prompt="rim lighting, silhouette" data-tooltip="피사체의 외곽선만 빛으로 강조하여 실루엣을 만드는 조명입니다.">림 라이트</button>
                                </div>
                            </div>
                        </div>
`;
