﻿# Work Plan: CC Module Main.js Runtime Requirement Tightening

- Timestamp: 2026-04-15 07:32 KST
- Owner: Codex
- User approval: granted
- Type: work-plan
- Status: completed
- Scope: tighten the `.cc` module contract in `cc_universal_module_mm.md` so the official `bundle/main.js` runtime load is explicitly mandatory and the bootstrap must genuinely depend on it

## Understanding

The user wants a small, surgical improvement to the `.cc` universal module contract. The current file already names the canonical bootstrap shell and lists the required assets, but the user wants the requirement for the official `bundle/main.js` runtime to be more explicit so downstream generators cannot treat it as a decorative reference. The real goal is not to redesign the module, but to make the contract clearer that `.cc` output must actually load the official runtime script and wire the bootstrap through the runtime's `renderAppShell(...)` path.

## Goals

1. Keep the edit narrow to `cc_universal_module_mm.md` only.
2. Preserve the module's current semantics, style, and ordering as much as possible.
3. Strengthen the shell/bootstrap contract so `bundle/main.js` is clearly mandatory, official, and operational rather than optional or replaceable.
4. Strengthen the self-check so emitters must confirm that `bundle/main.js` is really loaded and used, not stubbed, omitted, or replaced with a fake local equivalent.
5. Avoid widening scope into unrelated `.cc` design rules.

## Planned Changes

1. Update the canonical shell paragraph to clarify that the official `bundle/main.js` script is a required runtime dependency, not a decorative asset.
2. Add explicit language that `.cc` artifacts must not omit, replace, inline-fake, or bypass the official runtime bootstrap path.
3. Extend the self-check to require confirmation that the official runtime script is present and that `renderAppShell(...)` is genuinely being invoked through that runtime.
4. Re-read the edited section for coherence and preserve the surrounding MM-style contract voice.

## Risks And Constraints

- The file is a behavior contract, so wording changes can have downstream effects on prompt behavior.
- Over-editing would risk changing unrelated `.cc` semantics, which the user did not ask for.
- The safest implementation is a textual strengthening of the shell/bootstrap and self-check sections only.

## Validation

- Confirmed the file still references the canonical bootstrap assets in stable order.
- Confirmed the canonical shell paragraph now explicitly marks the official `bundle/main.js` as a required runtime dependency rather than a decorative reference.
- Confirmed the self-check now requires real runtime loading/use and rejects stubbed, bypassed, or surrogate bootstrap paths.
- Confirmed the change stayed narrow to the canonical shell and self-check paragraphs only.

## Definition Of Done

The file `cc_universal_module_mm.md` explicitly states that the official `https://lemos999.github.io/Singulari-Tea-Codex-Canvas/bundle/main.js` must be loaded and genuinely used for `.cc` output, and the self-check explicitly requires verifying that runtime usage path.

## Rollback Boundary

- `cc_universal_module_mm.md`
- `plan/20260415-073200--work-plan--cc-module-mainjs-runtime-requirement--v01.md`

## Scoreboard

- Current score: 50
- Score source: provisional
- Last updated: 2026-04-15 07:42 KST
- Score rationale: the requested wording change landed cleanly and stayed narrow, but no explicit user score has been provided yet so the provisional score remains capped
- What improved: `cc_universal_module_mm.md` now states that the official `bundle/main.js` must be genuinely loaded and that bootstrap must flow through the real runtime path
- What remains unsatisfactory: no broader prompt-behavior validation has been run beyond the textual contract check, and no explicit user satisfaction score has been given yet
- Next score action: wait for user readout on whether the stronger runtime wording is exactly what they wanted

### Score History

- 2026-04-15 07:32 KST | 50 | provisional | approved narrow `.cc` module runtime requirement pass opened
- 2026-04-15 07:42 KST | 50 | provisional | wording landed; canonical shell and self-check now explicitly require the official runtime `bundle/main.js`
