/* --- Ailey & Bailey Canvas --- */
// File: 011_utils_helpers.js
// Version: 10.0 (Clean Date Labels)
// Description: Shared helpers for date grouping, KaTeX rendering, and textarea autosizing.

function getRelativeDateGroup(timestamp, isPinned = false) {
    if (isPinned) return { key: 0, label: '고정됨' };
    if (!timestamp) return { key: 99, label: '날짜 정보 없음' };

    const now = new Date();
    const date = timestamp instanceof Date ? timestamp : timestamp.toDate();
    now.setHours(0, 0, 0, 0);
    date.setHours(0, 0, 0, 0);

    const diffTime = now.getTime() - date.getTime();
    const diffDays = diffTime / (1000 * 60 * 60 * 24);

    if (diffDays < 1) return { key: 1, label: '오늘' };
    if (diffDays < 2) return { key: 2, label: '어제' };
    if (diffDays < 7) return { key: 3, label: '최근 7일' };

    const nowMonth = now.getMonth();
    const dateMonth = date.getMonth();
    const nowYear = now.getFullYear();
    const dateYear = date.getFullYear();

    if (nowYear === dateYear && nowMonth === dateMonth) {
        return { key: 4, label: '이번 달' };
    }

    const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    if (dateYear === lastMonth.getFullYear() && dateMonth === lastMonth.getMonth()) {
        return { key: 5, label: '지난달' };
    }

    return {
        key: 6 + (nowYear - dateYear) * 12 + (nowMonth - dateMonth),
        label: `${dateYear}년 ${dateMonth + 1}월`
    };
}

function renderKatexInString(text) {
    if (typeof katex === 'undefined' || !text) return text;
    const regex = /\$\$([\s\S]*?)\$\$|\\\[([\s\S]*?)\\\]|\$([\s\S]*?)\$|\\\(([\s\S]*?)\\\)/g;

    return text.replace(regex, (match, display1, display2, inline, parenthesis) => {
        const formula = display1 || display2 || inline || parenthesis;
        const isDisplayMode = !!(display1 || display2);
        if (!formula) return match;

        const decodedFormula = formula
            .replace(/&amp;/g, '&')
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>');

        try {
            return katex.renderToString(decodedFormula, {
                throwOnError: false,
                displayMode: isDisplayMode,
                macros: {
                    "\\Dslash": "{\\not\\!D}"
                }
            });
        } catch (error) {
            console.warn('KaTeX rendering error:', error);
            return match;
        }
    });
}

function renderLatexInNode(rootElement) {
    if (!rootElement || typeof katex === 'undefined') return;

    const walker = document.createTreeWalker(rootElement, NodeFilter.SHOW_TEXT, null, false);
    const nodesToReplace = [];

    while (walker.nextNode()) {
        const node = walker.currentNode;
        const parent = node.parentNode;
        if (['SCRIPT', 'STYLE', 'TEXTAREA', 'PRE', 'CODE', 'KBD', 'SAMP', 'VAR', 'NOSCRIPT'].includes(parent.tagName)) {
            continue;
        }
        if (parent.closest('.katex')) {
            continue;
        }
        if (node.nodeValue && (node.nodeValue.includes('$') || node.nodeValue.includes('\\(') || node.nodeValue.includes('\\['))) {
            nodesToReplace.push(node);
        }
    }

    nodesToReplace.forEach(node => {
        const text = node.nodeValue;
        const renderedHtml = renderKatexInString(text);
        if (renderedHtml !== text) {
            const span = document.createElement('span');
            span.innerHTML = renderedHtml;
            node.parentNode.replaceChild(span, node);
        }
    });
}

function autoResizeTextarea(element) {
    if (!element) return;
    element.style.height = 'auto';
    const scrollHeight = element.scrollHeight;
    const maxHeight = parseInt(window.getComputedStyle(element).maxHeight, 10);
    if (scrollHeight > maxHeight) {
        element.style.height = `${maxHeight}px`;
        element.scrollTop = element.scrollHeight;
    } else {
        element.style.height = `${scrollHeight}px`;
    }
}

function isNarrativeArchiveFormat(text) {
    if (typeof text !== 'string' || text.trim() === '') {
        return false;
    }
    const startsWithTurn = /^\s*##\s*\[\s*턴\s*\d+\s*\]/.test(text);
    const hasChoices = /###\s*제시된\s*선택지/.test(text);
    return startsWithTurn && hasChoices;
}
