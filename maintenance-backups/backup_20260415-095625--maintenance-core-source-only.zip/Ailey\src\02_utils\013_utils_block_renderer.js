/* --- Ailey & Bailey Canvas --- */
// File: 013_utils_block_renderer.js
// Version: 31.0 (Latest CDN Normalization And Hex Repair)
// Description: Added latest-track CDN normalization, JS bare-hex repair for generated scenes, block-local DOM scoping, scoped style ownership, stronger preflight repair rules, and renderer-level contrast normalization for generated visualization fragments.

// [HCA] A centralized, Promise-based script loader to handle asynchronous loading and prevent duplicates.
const loadedScripts = new Set();
const loadingScripts = new Map();
const VISUALIZATION_CDN_NORMALIZERS = [
    {
        matches: (url) => /chart(?:\.umd)?\.min\.js$/i.test(url) && /chart\.js/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/chart.js/dist/chart.umd.min.js'
    },
    {
        matches: (url) => /echarts\.min\.js$/i.test(url) && /echarts/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/echarts/dist/echarts.min.js'
    },
    {
        matches: (url) => /apexcharts(?:\.min)?\.js$/i.test(url) && /apexcharts/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/apexcharts/dist/apexcharts.min.js'
    },
    {
        matches: (url) => /\/d3(?:\.min)?\.js$/i.test(url) && /(?:cdnjs|jsdelivr|unpkg)/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/d3/dist/d3.min.js'
    },
    {
        matches: (url) => /p5(?:\.min)?\.js$/i.test(url) && /p5\.js/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/p5/lib/p5.min.js'
    },
    {
        matches: (url) => /three(?:\.min)?\.js$/i.test(url) && /three(?:\.js)?/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/three/build/three.min.js'
    },
    {
        matches: (url) => /leaflet\.js$/i.test(url) && /leaflet/i.test(url),
        replacement: 'https://unpkg.com/leaflet/dist/leaflet.js'
    },
    {
        matches: (url) => /leaflet\.css$/i.test(url) && /leaflet/i.test(url),
        replacement: 'https://unpkg.com/leaflet/dist/leaflet.css'
    },
    {
        matches: (url) => /plotly(?:-[\w.-]+)?\.min\.js$/i.test(url) && /plot\.ly|plotly/i.test(url),
        replacement: 'https://cdn.plot.ly/plotly-latest.min.js'
    },
    {
        matches: (url) => /vega\.min\.js$/i.test(url) && /vega/i.test(url) && !/vega-lite|vega-embed/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/vega/build/vega.min.js'
    },
    {
        matches: (url) => /vega-lite\.min\.js$/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/vega-lite/build/vega-lite.min.js'
    },
    {
        matches: (url) => /vega-embed\.min\.js$/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/vega-embed/build/vega-embed.min.js'
    },
    {
        matches: (url) => /plot\.umd\.min\.js$/i.test(url) && /@observablehq\/plot/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/@observablehq/plot/dist/plot.umd.min.js'
    },
    {
        matches: (url) => /uPlot\.iife\.min\.js$/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/uplot/dist/uPlot.iife.min.js'
    },
    {
        matches: (url) => /uPlot\.min\.css$/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/uplot/dist/uPlot.min.css'
    },
    {
        matches: (url) => /cytoscape(?:\.min)?\.js$/i.test(url) && /cytoscape/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/cytoscape/dist/cytoscape.min.js'
    },
    {
        matches: (url) => /vis-network\.min\.js$/i.test(url) && /vis-network/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/vis-network/standalone/umd/vis-network.min.js'
    },
    {
        matches: (url) => /mermaid(?:\.min)?\.js$/i.test(url) && /mermaid/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js'
    },
    {
        matches: (url) => /maplibre-gl\.js$/i.test(url),
        replacement: 'https://unpkg.com/maplibre-gl/dist/maplibre-gl.js'
    },
    {
        matches: (url) => /maplibre-gl\.css$/i.test(url),
        replacement: 'https://unpkg.com/maplibre-gl/dist/maplibre-gl.css'
    },
    {
        matches: (url) => /\/ol(?:\.js)?$/i.test(url) && /cdn\.jsdelivr\.net|unpkg\.com/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/ol/dist/ol.js'
    },
    {
        matches: (url) => /\/ol\.css$/i.test(url) && /cdn\.jsdelivr\.net|unpkg\.com/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/ol/ol.css'
    },
    {
        matches: (url) => /deck\.gl.*dist(?:\.min)?\.js$/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/deck.gl/dist.min.js'
    },
    {
        matches: (url) => /pixi(?:\.min)?\.js$/i.test(url) && /pixi\.js/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/pixi.js/dist/pixi.min.js'
    },
    {
        matches: (url) => /konva(?:\.min)?\.js$/i.test(url) && /konva/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/konva/konva.min.js'
    },
    {
        matches: (url) => /paper-full\.min\.js$/i.test(url) && /paper/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/paper/dist/paper-full.min.js'
    },
    {
        matches: (url) => /gridjs\.umd\.js$/i.test(url) && /gridjs/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/gridjs/dist/gridjs.umd.js'
    },
    {
        matches: (url) => /theme\/mermaid\.min\.css$/i.test(url) && /gridjs/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/gridjs/dist/theme/mermaid.min.css'
    },
    {
        matches: (url) => /tabulator\.min\.js$/i.test(url) && /tabulator-tables/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/tabulator-tables/dist/js/tabulator.min.js'
    },
    {
        matches: (url) => /tabulator\.min\.css$/i.test(url) && /tabulator-tables/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/tabulator-tables/dist/css/tabulator.min.css'
    },
    {
        matches: (url) => /\/g2(?:\.min)?\.js$/i.test(url) && /@antv\/g2/i.test(url),
        replacement: 'https://cdn.jsdelivr.net/npm/@antv/g2/dist/g2.min.js'
    }
];

function normalizeVisualizationDependencyUrl(url) {
    const rawUrl = String(url || '').trim();
    if (!rawUrl) return rawUrl;

    const matchedEntry = VISUALIZATION_CDN_NORMALIZERS.find((entry) => {
        try {
            return entry.matches(rawUrl);
        } catch (error) {
            trace("System.Render", "loadScript.normalize.matcherError", { rawUrl, error: error.message }, {}, "WARN");
            return false;
        }
    });

    return matchedEntry ? matchedEntry.replacement : rawUrl;
}

function resolveVisualizationDependencyUrl(url) {
    const rawUrl = String(url || '').trim();
    if (!rawUrl) return rawUrl;

    try {
        return new URL(rawUrl, window.location.href).href;
    } catch (error) {
        return rawUrl;
    }
}

function findExistingVisualizationScriptNode(url) {
    const normalizedTargetUrl = resolveVisualizationDependencyUrl(normalizeVisualizationDependencyUrl(url));
    if (!normalizedTargetUrl) return null;

    return Array.from(document.querySelectorAll('script[src]')).find((scriptNode) => {
        const existingUrl = scriptNode.getAttribute('src') || '';
        const normalizedExistingUrl = resolveVisualizationDependencyUrl(
            normalizeVisualizationDependencyUrl(existingUrl)
        );
        return normalizedExistingUrl === normalizedTargetUrl;
    }) || null;
}

function waitForManagedVisualizationScriptLoad(scriptNode, cacheKey, normalizedUrl, requestedUrl) {
    if (!scriptNode) {
        return Promise.reject(new Error(`Managed visualization script node missing for ${normalizedUrl}`));
    }

    if (loadedScripts.has(cacheKey) || scriptNode.dataset.vizRuntimeState === 'loaded') {
        scriptNode.dataset.vizRuntimeState = 'loaded';
        loadedScripts.add(cacheKey);
        return Promise.resolve();
    }

    if (loadingScripts.has(cacheKey)) {
        return loadingScripts.get(cacheKey);
    }

    const waitPromise = new Promise((resolve, reject) => {
        let settled = false;
        let timeoutHandle = null;

        const cleanupListeners = () => {
            scriptNode.removeEventListener('load', handleLoad);
            scriptNode.removeEventListener('error', handleError);
            if (timeoutHandle) {
                clearTimeout(timeoutHandle);
                timeoutHandle = null;
            }
        };

        const settleSuccess = () => {
            if (settled) return;
            settled = true;
            cleanupListeners();
            scriptNode.dataset.vizRuntimeState = 'loaded';
            loadedScripts.add(cacheKey);
            loadingScripts.delete(cacheKey);
            trace("System.Render", "loadScript.awaitExisting.success", { url: normalizedUrl, requestedUrl, cacheKey });
            resolve();
        };

        const settleFailure = (message) => {
            if (settled) return;
            settled = true;
            cleanupListeners();
            scriptNode.dataset.vizRuntimeState = 'error';
            loadingScripts.delete(cacheKey);
            trace("System.Render", "loadScript.awaitExisting.error", { url: normalizedUrl, requestedUrl, cacheKey, message }, {}, "ERROR");
            reject(new Error(message));
        };

        const handleLoad = () => {
            settleSuccess();
        };

        const handleError = () => {
            settleFailure(`Failed to load existing managed script: ${normalizedUrl}`);
        };

        scriptNode.addEventListener('load', handleLoad);
        scriptNode.addEventListener('error', handleError);

        timeoutHandle = setTimeout(() => {
            if (scriptNode.dataset.vizRuntimeState === 'loaded') {
                settleSuccess();
                return;
            }

            if (scriptNode.readyState === 'loaded' || scriptNode.readyState === 'complete') {
                settleSuccess();
                return;
            }

            settleFailure(`Existing managed script loading timed out: ${normalizedUrl}`);
        }, 10000);
    });

    loadingScripts.set(cacheKey, waitPromise);
    return waitPromise;
}

function loadScript(url) {
    const requestedUrl = String(url || '').trim();
    const normalizedUrl = normalizeVisualizationDependencyUrl(requestedUrl);
    const cacheKey = resolveVisualizationDependencyUrl(normalizedUrl) || normalizedUrl;
    const existingScriptNode = findExistingVisualizationScriptNode(normalizedUrl);

    if (loadedScripts.has(cacheKey)) {
        trace("System.Render", "loadScript.cacheHit", { url: normalizedUrl, requestedUrl, cacheKey });
        return Promise.resolve();
    }
    if (loadingScripts.has(cacheKey)) {
        trace("System.Render", "loadScript.inFlight", { url: normalizedUrl, requestedUrl, cacheKey });
        return loadingScripts.get(cacheKey);
    }
    if (existingScriptNode) {
        if (existingScriptNode.dataset.vizRuntimeScript === 'true') {
            trace("System.Render", "loadScript.awaitExisting", {
                url: normalizedUrl,
                requestedUrl,
                cacheKey,
                state: existingScriptNode.dataset.vizRuntimeState || 'unknown'
            });
            return waitForManagedVisualizationScriptLoad(existingScriptNode, cacheKey, normalizedUrl, requestedUrl);
        }

        loadedScripts.add(cacheKey);
        trace("System.Render", "loadScript.domPresentAssumedLoaded", { url: normalizedUrl, requestedUrl, cacheKey });
        return Promise.resolve();
    }

    const loadPromise = new Promise((resolve, reject) => {
        trace("System.Render", "loadScript.request", { url: normalizedUrl, requestedUrl, cacheKey });
        const script = document.createElement('script');
        script.src = normalizedUrl;
        script.async = false; // Maintain execution order
        script.dataset.vizRuntimeScript = 'true';
        script.dataset.vizRuntimeSrc = cacheKey;
        script.dataset.vizRuntimeState = 'loading';
        let settled = false;
        let timeoutHandle = null;

        const cleanupTimeout = () => {
            if (timeoutHandle) {
                clearTimeout(timeoutHandle);
                timeoutHandle = null;
            }
        };

        const settleSuccess = () => {
            if (settled) return;
            settled = true;
            cleanupTimeout();
            script.dataset.vizRuntimeState = 'loaded';
            loadedScripts.add(cacheKey);
            loadingScripts.delete(cacheKey);
            trace("System.Render", "loadScript.success", { url: normalizedUrl, requestedUrl, cacheKey });
            resolve();
        };

        const settleFailure = (message) => {
            if (settled) return;
            settled = true;
            cleanupTimeout();
            script.dataset.vizRuntimeState = 'error';
            loadingScripts.delete(cacheKey);
            trace("System.Render", "loadScript.error", { url: normalizedUrl, requestedUrl, cacheKey, message }, {}, "ERROR");
            console.error(message);
            script.remove();
            reject(new Error(message));
        };

        script.onload = () => {
            settleSuccess();
        };

        script.onerror = () => {
            settleFailure(`Failed to load script: ${normalizedUrl}`);
        };

        // Timeout safety
        timeoutHandle = setTimeout(() => {
             if (!loadedScripts.has(cacheKey)) {
                 settleFailure(`Script loading timed out: ${normalizedUrl}`);
             }
        }, 10000);

        document.head.appendChild(script);
    });
    loadingScripts.set(cacheKey, loadPromise);
    return loadPromise;
}

function buildVisualizationOverflowItems(blockData, containerElement) {
    const items = [];

    if (blockData.noteId && typeof archiveVisualizationToNote === 'function') {
        items.push({
            label: '노트에 저장',
            action: async () => {
                await archiveVisualizationToNote(blockData.noteId, blockData);
            }
        });
        items.push({ separator: true });
    }

    items.push({
        label: '빠른 조정',
        submenu: [
            {
                label: '더 쉽게 설명형으로',
                action: () => {
                    if (typeof handleVisualizationIntentRefinement === 'function') {
                        handleVisualizationIntentRefinement(blockData, containerElement, 'simplify');
                    }
                }
            },
            {
                label: '더 상호작용적으로',
                action: () => {
                    if (typeof handleVisualizationIntentRefinement === 'function') {
                        handleVisualizationIntentRefinement(blockData, containerElement, 'interactive');
                    }
                }
            },
            {
                label: '안정성 우선으로 재생성',
                action: () => {
                    if (typeof handleVisualizationIntentRefinement === 'function') {
                        handleVisualizationIntentRefinement(blockData, containerElement, 'stable');
                    }
                }
            }
        ]
    });

    items.push({
        label: '세부 편집',
        submenu: [
            {
                label: '옵션 조정 후 재생성',
                action: () => {
                    if (typeof handleModifyVisualization === 'function') {
                        handleModifyVisualization(blockData, containerElement);
                    }
                }
            },
            {
                label: '코드 문제 자동 수정',
                action: () => {
                    if (typeof handleCodeFixRequest === 'function') {
                        handleCodeFixRequest(blockData, containerElement);
                    }
                }
            }
        ]
    });

    items.push({
        label: '채팅으로 설명',
        action: () => explainVisualizationInChat(blockData)
    });

    items.push({
        label: '원본 복사',
        submenu: [
            { label: 'HTML 복사', action: () => copyVisualizationHtmlSource(blockData) },
            { label: 'JSON 복사', action: () => copyVisualizationBlockJson(blockData) }
        ]
    });

    return items;
}

function escapeVisualizationHtml(value) {
    return String(value || '').replace(/[&<>"']/g, (char) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    }[char]));
}

function escapeVisualizationCssIdentifier(value) {
    const rawValue = String(value || '');
    if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') {
        return CSS.escape(rawValue);
    }
    return rawValue.replace(/[^a-zA-Z0-9_-]/g, (char) => `\\${char.codePointAt(0).toString(16)} `);
}

function buildVisualizationScopeSelector(scopeId) {
    return `[data-viz-scope-id="${scopeId}"]`;
}

function scopeVisualizationCss(cssText, scopeSelector) {
    if (!cssText || !scopeSelector) return cssText;

    return String(cssText).replace(/(^|[{}])\s*([^@{}][^{}]*)\{/g, (match, prefix, selectorGroup) => {
        const selectors = selectorGroup
            .split(',')
            .map((selector) => selector.trim())
            .filter(Boolean)
            .map((selector) => {
                if (
                    selector.startsWith(scopeSelector) ||
                    selector === 'from' ||
                    selector === 'to' ||
                    /^\d+%$/.test(selector)
                ) {
                    return selector;
                }

                if (selector === ':root') {
                    return scopeSelector;
                }

                return `${scopeSelector} ${selector}`;
            });

        if (selectors.length === 0) {
            return match;
        }

        return `${prefix} ${selectors.join(', ')} {`;
    });
}

function createScopedVisualizationDocument(vizContainer) {
    const realDocument = window.document;
    const scopedGetElementById = (id) => {
        if (!vizContainer || !id) return null;
        const escapedId = escapeVisualizationCssIdentifier(id);
        return vizContainer.querySelector(`#${escapedId}`);
    };

    return new Proxy(realDocument, {
        get(target, prop) {
            if (prop === 'getElementById') {
                return scopedGetElementById;
            }
            if (prop === 'querySelector') {
                return (selector) => vizContainer.querySelector(selector);
            }
            if (prop === 'querySelectorAll') {
                return (selector) => vizContainer.querySelectorAll(selector);
            }
            if (prop === 'body') {
                return vizContainer;
            }

            const value = target[prop];
            return typeof value === 'function' ? value.bind(target) : value;
        }
    });
}

function buildVisualizationDiagnosticHtml(title, diagnostics = [], suggestion = '') {
    const diagnosticItems = diagnostics.map((item) => {
        const levelLabel = item.level === 'repair'
            ? 'Auto-repair'
            : item.level === 'fatal'
                ? 'Blocked'
                : 'Error';
        return `<li><strong>${escapeVisualizationHtml(levelLabel)}:</strong> ${escapeVisualizationHtml(item.message)}</li>`;
    }).join('');

    const suggestionHtml = suggestion
        ? `<p style="margin:10px 0 0 0; font-size:12px; opacity:0.85;">${escapeVisualizationHtml(suggestion)}</p>`
        : '';

    return `
        <div class="bg-red-50 viz-diagnostic-error" style="color:#721c24; background:#f8d7da; border:1px solid #f5c6cb; padding:16px; border-radius:8px; font-family:sans-serif;">
            <strong>${escapeVisualizationHtml(title)}</strong>
            ${diagnosticItems ? `<ul style="margin:10px 0 0 18px; padding:0;">${diagnosticItems}</ul>` : ''}
            ${suggestionHtml}
        </div>
    `;
}

window.buildVisualizationDiagnosticHtml = buildVisualizationDiagnosticHtml;
window.createScopedVisualizationDocument = createScopedVisualizationDocument;

function resolveVisualizationMountDisplayMode(targetElement) {
    const explicitMode = String(
        targetElement?.dataset?.placeholderDisplayResolved
        || targetElement?.dataset?.placeholderDisplay
        || ''
    ).trim().toLowerCase();

    if (explicitMode === 'slot') return 'slot';
    if (targetElement?.classList?.contains('type-visualization-slot')) return 'slot';
    if (targetElement?.classList?.contains('type-visualization-placeholder-slot')) return 'slot';
    return 'block';
}

function createVisualizationStageHost(targetElement) {
    const rect = targetElement?.getBoundingClientRect?.() || {};
    const stageHost = document.createElement('div');
    stageHost.className = 'viz-transaction-stage-host';
    stageHost.setAttribute('aria-hidden', 'true');
    stageHost.style.position = 'fixed';
    stageHost.style.left = '-20000px';
    stageHost.style.top = '0';
    stageHost.style.width = `${Math.max(Math.ceil(rect.width || 720), 320)}px`;
    stageHost.style.height = `${Math.max(Math.ceil(rect.height || 560), 220)}px`;
    stageHost.style.visibility = 'hidden';
    stageHost.style.opacity = '0';
    stageHost.style.pointerEvents = 'none';
    stageHost.style.overflow = 'hidden';
    stageHost.style.contain = 'layout style paint';
    stageHost.style.zIndex = '-1';
    document.body.appendChild(stageHost);
    return stageHost;
}

function extractVisualizationRenderFailureMessage(targetElement) {
    if (!targetElement) return '';

    const explicitError = targetElement.querySelector('.viz-error-message, .viz-diagnostic-error');
    if (explicitError) {
        return explicitError.textContent.trim();
    }

    const scriptFailure = Array.from(targetElement.querySelectorAll('div, p')).find((node) => {
        return /Script Execution Failed/i.test(node.textContent || '');
    });
    if (scriptFailure) {
        return scriptFailure.textContent.trim();
    }

    return '';
}

function waitForVisualizationStageSettle() {
    return new Promise((resolve) => {
        window.requestAnimationFrame(() => {
            window.requestAnimationFrame(() => {
                window.setTimeout(resolve, 140);
            });
        });
    });
}

function cleanupStagedVisualizationMount(transaction) {
    if (!transaction) return;

    const stagedElement = transaction.stagedElement;
    const vizInstanceId = stagedElement?.dataset?.vizInstanceId;
    if (vizInstanceId && window.VizLifecycle) {
        try {
            window.VizLifecycle.cleanup(vizInstanceId);
        } catch (cleanupError) {
            trace("System.Render", "viz.transaction.cleanup.error", { error: cleanupError.message }, {}, "WARN");
        }
    }

    if (transaction.stageHost?.parentNode) {
        transaction.stageHost.remove();
    }
}

async function stageVisualizationBlockTransaction(blockData, targetElement) {
    if (!targetElement) {
        throw new Error('Visualization transaction target is missing.');
    }
    if (typeof renderVisualizationBlock !== 'function') {
        throw new Error('Visualization renderer not loaded.');
    }

    const displayMode = resolveVisualizationMountDisplayMode(targetElement);
    const stageHost = createVisualizationStageHost(targetElement);
    let stagedElement;

    try {
        if (displayMode === 'slot') {
            stagedElement = targetElement.cloneNode(false);
            stagedElement.removeAttribute('id');
            stagedElement.dataset.placeholderDisplayResolved = 'slot';
            if (blockData?.prompt) {
                stagedElement.dataset.prompt = blockData.prompt;
            }
            stagedElement.classList.remove(
                'type-visualization-loading',
                'type-visualization-placeholder',
                'type-visualization-placeholder-slot',
                'type-visualization-error'
            );
            stagedElement.classList.add('content-section', 'type-visualization', 'type-visualization-slot');
        } else {
            stagedElement = document.createElement(targetElement.tagName || 'div');
            stagedElement.className = 'content-section type-visualization';
            if (targetElement?.dataset?.blockId) {
                stagedElement.dataset.blockId = targetElement.dataset.blockId;
            }
        }

        stageHost.appendChild(stagedElement);
        await renderVisualizationBlock(blockData, stagedElement);
        await waitForVisualizationStageSettle();

        const failureMessage = extractVisualizationRenderFailureMessage(stagedElement);
        if (failureMessage) {
            throw new Error(failureMessage);
        }

        if (!stagedElement.querySelector('.visualization-execution-wrapper')) {
            throw new Error('Visualization renderer did not produce a stable mount surface.');
        }

        return { stagedElement, stageHost };
    } catch (error) {
        cleanupStagedVisualizationMount({ stagedElement, stageHost });
        throw error;
    }
}

function commitStagedVisualizationTransaction(targetElement, transaction) {
    if (!targetElement || !transaction?.stagedElement) return null;

    const { stagedElement, stageHost } = transaction;
    if (targetElement.parentNode) {
        targetElement.replaceWith(stagedElement);
    }
    if (stageHost?.parentNode) {
        stageHost.remove();
    }
    return stagedElement;
}

window.stageVisualizationBlockTransaction = stageVisualizationBlockTransaction;
window.commitStagedVisualizationTransaction = commitStagedVisualizationTransaction;
window.cleanupStagedVisualizationMount = cleanupStagedVisualizationMount;

function pushVisualizationDiagnostic(diagnostics, level, message) {
    diagnostics.push({ level, message });
}

const VIZ_MIN_TEXT_CONTRAST = 4.5;
const VIZ_MIN_LARGE_TEXT_CONTRAST = 3.2;
const VIZ_SAFE_DARK_TEXT = { r: 17, g: 24, b: 39, a: 1 };
const VIZ_SAFE_LIGHT_TEXT = { r: 248, g: 250, b: 252, a: 1 };
const VIZ_NON_TEXT_TAGS = new Set([
    'SCRIPT', 'STYLE', 'SVG', 'CANVAS', 'IMG', 'VIDEO', 'AUDIO', 'PATH', 'RECT', 'CIRCLE', 'ELLIPSE',
    'LINE', 'POLYLINE', 'POLYGON', 'G', 'DEFS', 'MARKER', 'STOP', 'FILTER', 'FEGAUSSIANBLUR'
]);

function parseVisualizationColor(colorValue) {
    if (!colorValue) return null;
    const value = String(colorValue).trim().toLowerCase();

    if (!value) return null;
    if (value === 'transparent') {
        return { r: 0, g: 0, b: 0, a: 0 };
    }

    const hexMatch = value.match(/^#([\da-f]{3,8})$/i);
    if (hexMatch) {
        const hex = hexMatch[1];
        if (hex.length === 3 || hex.length === 4) {
            const [r, g, b, a = 'f'] = hex.split('');
            return {
                r: parseInt(r + r, 16),
                g: parseInt(g + g, 16),
                b: parseInt(b + b, 16),
                a: parseInt(a + a, 16) / 255
            };
        }
        if (hex.length === 6 || hex.length === 8) {
            return {
                r: parseInt(hex.slice(0, 2), 16),
                g: parseInt(hex.slice(2, 4), 16),
                b: parseInt(hex.slice(4, 6), 16),
                a: hex.length === 8 ? parseInt(hex.slice(6, 8), 16) / 255 : 1
            };
        }
    }

    const rgbMatch = value.match(/^rgba?\(([^)]+)\)$/i);
    if (rgbMatch) {
        const parts = rgbMatch[1].split(',').map((part) => part.trim());
        if (parts.length >= 3) {
            const parseChannel = (channel) => channel.endsWith('%')
                ? Math.round((parseFloat(channel) / 100) * 255)
                : parseFloat(channel);
            return {
                r: Math.max(0, Math.min(255, parseChannel(parts[0]))),
                g: Math.max(0, Math.min(255, parseChannel(parts[1]))),
                b: Math.max(0, Math.min(255, parseChannel(parts[2]))),
                a: parts[3] !== undefined ? Math.max(0, Math.min(1, parseFloat(parts[3]))) : 1
            };
        }
    }

    return null;
}

function blendVisualizationColors(foreground, background) {
    const fgAlpha = foreground?.a ?? 1;
    const bgAlpha = background?.a ?? 1;
    const alpha = fgAlpha + bgAlpha * (1 - fgAlpha);

    if (alpha <= 0) {
        return { r: 255, g: 255, b: 255, a: 1 };
    }

    return {
        r: Math.round(((foreground.r * fgAlpha) + (background.r * bgAlpha * (1 - fgAlpha))) / alpha),
        g: Math.round(((foreground.g * fgAlpha) + (background.g * bgAlpha * (1 - fgAlpha))) / alpha),
        b: Math.round(((foreground.b * fgAlpha) + (background.b * bgAlpha * (1 - fgAlpha))) / alpha),
        a: alpha
    };
}

function visualizationChannelToLinear(channel) {
    const normalized = channel / 255;
    return normalized <= 0.03928 ? normalized / 12.92 : ((normalized + 0.055) / 1.055) ** 2.4;
}

function getVisualizationLuminance(color) {
    return (
        0.2126 * visualizationChannelToLinear(color.r) +
        0.7152 * visualizationChannelToLinear(color.g) +
        0.0722 * visualizationChannelToLinear(color.b)
    );
}

function getVisualizationContrastRatio(foreground, background) {
    const lighter = Math.max(getVisualizationLuminance(foreground), getVisualizationLuminance(background));
    const darker = Math.min(getVisualizationLuminance(foreground), getVisualizationLuminance(background));
    return (lighter + 0.05) / (darker + 0.05);
}

function formatVisualizationColor(color) {
    return `rgb(${color.r}, ${color.g}, ${color.b})`;
}

function chooseVisualizationForeground(backgroundColor) {
    const darkContrast = getVisualizationContrastRatio(VIZ_SAFE_DARK_TEXT, backgroundColor);
    const lightContrast = getVisualizationContrastRatio(VIZ_SAFE_LIGHT_TEXT, backgroundColor);
    return darkContrast >= lightContrast ? VIZ_SAFE_DARK_TEXT : VIZ_SAFE_LIGHT_TEXT;
}

function extractVisualizationBackgroundColor(declarationText) {
    if (!declarationText) return null;
    const backgroundMatch = String(declarationText).match(/(?:^|;)\s*background(?:-color)?\s*:\s*([^;]+)/i);
    if (!backgroundMatch) return null;

    const backgroundValue = backgroundMatch[1].trim();
    if (/gradient|url\(/i.test(backgroundValue)) return null;

    const colorMatch = backgroundValue.match(/#(?:[\da-f]{3,8})\b|rgba?\([^)]+\)/i);
    return colorMatch ? parseVisualizationColor(colorMatch[0]) : null;
}

function hasVisualizationForegroundDeclaration(declarationText) {
    return /(?:^|;)\s*(?:color|fill)\s*:/i.test(String(declarationText || ''));
}

function patchVisualizationCssContrast(cssText) {
    let repairedCount = 0;

    const patchedCss = String(cssText || '').replace(/([^{}]+)\{([^{}]+)\}/g, (match, selector, declarations) => {
        const normalizedSelector = selector.trim();
        if (!normalizedSelector || normalizedSelector.startsWith('@') || normalizedSelector === 'from' || normalizedSelector === 'to' || /^\d+%$/.test(normalizedSelector)) {
            return match;
        }
        if (hasVisualizationForegroundDeclaration(declarations)) {
            return match;
        }

        const backgroundColor = extractVisualizationBackgroundColor(declarations);
        if (!backgroundColor) {
            return match;
        }

        const safeForeground = formatVisualizationColor(chooseVisualizationForeground(backgroundColor));
        repairedCount += 1;
        return `${selector}{${declarations.trim().replace(/;?\s*$/, ';')} color: ${safeForeground};}`;
    });

    return { patchedCss, repairedCount };
}

function patchVisualizationInlineSurfaceContrast(rootNode) {
    if (!(rootNode instanceof Element)) return 0;

    let repairedCount = 0;
    const styledElements = [];
    if (rootNode.hasAttribute('style')) {
        styledElements.push(rootNode);
    }
    styledElements.push(...rootNode.querySelectorAll('[style]'));

    styledElements.forEach((element) => {
        const styleText = element.getAttribute('style') || '';
        if (hasVisualizationForegroundDeclaration(styleText)) return;

        const backgroundColor = extractVisualizationBackgroundColor(styleText);
        if (!backgroundColor) return;

        const safeForeground = formatVisualizationColor(chooseVisualizationForeground(backgroundColor));
        element.setAttribute('style', `${styleText.trim().replace(/;?\s*$/, ';')} color: ${safeForeground};`);
        repairedCount += 1;
    });

    return repairedCount;
}

function resolveVisualizationBackgroundColor(element, fallbackColor, depth = 0) {
    if (!element || depth > 12) {
        return fallbackColor || { r: 255, g: 255, b: 255, a: 1 };
    }

    const computed = window.getComputedStyle(element);
    const background = parseVisualizationColor(computed.backgroundColor);

    if (!background || background.a === 0) {
        return element.parentElement
            ? resolveVisualizationBackgroundColor(element.parentElement, fallbackColor, depth + 1)
            : (fallbackColor || { r: 255, g: 255, b: 255, a: 1 });
    }

    if (background.a >= 0.999) {
        return background;
    }

    const parentBackground = element.parentElement
        ? resolveVisualizationBackgroundColor(element.parentElement, fallbackColor, depth + 1)
        : (fallbackColor || { r: 255, g: 255, b: 255, a: 1 });

    return blendVisualizationColors(background, parentBackground);
}

function shouldNormalizeVisualizationElement(element) {
    if (!(element instanceof Element)) return false;
    if (VIZ_NON_TEXT_TAGS.has(element.tagName)) return false;
    if (!element.textContent || !element.textContent.replace(/\s+/g, ' ').trim()) return false;

    const computed = window.getComputedStyle(element);
    return computed.display !== 'none' && computed.visibility !== 'hidden' && computed.opacity !== '0';
}

function normalizeVisualizationTextContrast(vizContainer, diagnostics) {
    if (!vizContainer) return;

    const rootElement = vizContainer.firstElementChild || vizContainer;
    const fallbackBackground = parseVisualizationColor(window.getComputedStyle(vizContainer).backgroundColor) || { r: 255, g: 255, b: 255, a: 1 };
    const rootBackground = resolveVisualizationBackgroundColor(rootElement, fallbackBackground);
    const rootForeground = parseVisualizationColor(window.getComputedStyle(rootElement).color) || VIZ_SAFE_DARK_TEXT;
    const safeRootForeground = chooseVisualizationForeground(rootBackground);
    let repairedCount = 0;

    if (getVisualizationContrastRatio(rootForeground, rootBackground) < VIZ_MIN_TEXT_CONTRAST) {
        rootElement.style.color = formatVisualizationColor(safeRootForeground);
        repairedCount += 1;
    }

    const elements = Array.from(vizContainer.querySelectorAll('*'));
    elements.forEach((element) => {
        if (!shouldNormalizeVisualizationElement(element)) return;

        const computed = window.getComputedStyle(element);
        const fontSize = parseFloat(computed.fontSize || '0');
        const fontWeight = parseInt(computed.fontWeight || '400', 10);
        const contrastThreshold = (fontSize >= 18 || (fontSize >= 14 && fontWeight >= 600))
            ? VIZ_MIN_LARGE_TEXT_CONTRAST
            : VIZ_MIN_TEXT_CONTRAST;

        if (element.namespaceURI === 'http://www.w3.org/2000/svg' || element.closest('svg')) {
            if (element.tagName !== 'text' && element.tagName !== 'tspan') return;
            const fillColor = parseVisualizationColor(computed.fill);
            if (!fillColor) return;
            const contrast = getVisualizationContrastRatio(fillColor, rootBackground);
            if (contrast < contrastThreshold) {
                element.setAttribute('fill', formatVisualizationColor(chooseVisualizationForeground(rootBackground)));
                repairedCount += 1;
            }
            return;
        }

        const foreground = parseVisualizationColor(computed.color);
        if (!foreground) return;

        const background = resolveVisualizationBackgroundColor(element, rootBackground);
        const contrast = getVisualizationContrastRatio(foreground, background);

        if (contrast < contrastThreshold) {
            element.style.color = formatVisualizationColor(chooseVisualizationForeground(background));
            repairedCount += 1;
        }
    });

    if (repairedCount > 0 && diagnostics) {
        pushVisualizationDiagnostic(
            diagnostics,
            'repair',
            `Applied ${repairedCount} contrast normalization override(s) to keep text readable across host theme changes.`
        );
    }
}

function observeVisualizationContrast(vizContainer, uniqueId, diagnostics) {
    if (!vizContainer || !window.MutationObserver || !window.VizLifecycle) return;

    if (vizContainer.__vizContrastObserver) {
        vizContainer.__vizContrastObserver.disconnect();
    }

    let pending = false;
    const scheduleNormalization = () => {
        if (pending) return;
        pending = true;
        const timerHandle = window.setTimeout(() => {
            pending = false;
            normalizeVisualizationTextContrast(vizContainer, null);
        }, 32);
        window.VizLifecycle.register(uniqueId, 'timer', timerHandle);
    };

    const observer = new MutationObserver((mutations) => {
        if (mutations.some((mutation) => mutation.type === 'childList' || mutation.type === 'attributes' || mutation.type === 'characterData')) {
            scheduleNormalization();
        }
    });

    observer.observe(vizContainer, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: true,
        attributeFilter: ['style', 'class', 'fill']
    });

    vizContainer.__vizContrastObserver = observer;
    window.VizLifecycle.register(uniqueId, 'observer', observer);
}

function expandVisualizationHexShorthand(hexValue) {
    const normalized = String(hexValue || '').trim();
    if (normalized.length !== 3) return normalized;
    return normalized.split('').map((char) => `${char}${char}`).join('');
}

function patchVisualizationBareJsHexColorLiterals(scriptText, diagnostics) {
    let repairedCount = 0;
    const replaceBareHex = (match, prefix, hexValue) => {
        repairedCount += 1;
        return `${prefix}0x${expandVisualizationHexShorthand(hexValue)}`;
    };

    let patchedScript = String(scriptText || '').replace(
        /(\b(?:color|emissive|specular|ambient|clearColor|fogColor)\s*:\s*)#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})\b/g,
        replaceBareHex
    );

    patchedScript = patchedScript.replace(
        /(\b(?:setClearColor|setHex)\s*\(\s*)#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})\b/g,
        replaceBareHex
    );

    if (repairedCount > 0 && diagnostics) {
        pushVisualizationDiagnostic(
            diagnostics,
            'repair',
            `Repaired ${repairedCount} bare CSS-style hex literal(s) inside JavaScript so generated scenes do not fail during script parsing.`
        );
    }

    return patchedScript;
}

function applyVisualizationPreflightRepairs(doc, inlineScriptContent, diagnostics) {
    let repairedScript = inlineScriptContent || '';
    let contrastCssRepairCount = 0;
    let contrastInlineRepairCount = 0;
    const usesP5CanvasFactory = /new\s+p5\s*\(|createCanvas\s*\(/i.test(repairedScript);

    if (usesP5CanvasFactory) {
        const staticCanvasNodes = Array.from(doc.body.querySelectorAll('canvas'));
        if (staticCanvasNodes.length > 0) {
            staticCanvasNodes.forEach((canvasNode) => canvasNode.remove());
            pushVisualizationDiagnostic(
                diagnostics,
                'repair',
                `Removed ${staticCanvasNodes.length} pre-rendered <canvas> node(s) because p5.createCanvas() owns the runtime drawing surface.`
            );
        }
    }

    repairedScript = patchVisualizationBareJsHexColorLiterals(repairedScript, diagnostics);

    let globalDocumentRepairCount = 0;
    repairedScript = repairedScript.replace(
        /\b(?:window|globalThis)\.document\.(getElementById|querySelector|querySelectorAll)\(/g,
        (match, methodName) => {
            globalDocumentRepairCount += 1;
            return `document.${methodName}(`;
        }
    );

    repairedScript = repairedScript.replace(
        /\b(?:window|globalThis)\.document\.body\b/g,
        () => {
            globalDocumentRepairCount += 1;
            return 'document.body';
        }
    );

    if (globalDocumentRepairCount > 0) {
        pushVisualizationDiagnostic(
            diagnostics,
            'repair',
            `Repaired ${globalDocumentRepairCount} global document access pattern(s) so DOM lookups stay inside the current visualization container.`
        );
    }

    const d3EaseAliasMap = {
        easeSineIn: 'easeSinIn',
        easeSineOut: 'easeSinOut',
        easeSineInOut: 'easeSinInOut'
    };
    let d3EaseAliasRepairCount = 0;
    repairedScript = repairedScript.replace(/\bd3\.(easeSineInOut|easeSineIn|easeSineOut)\b/g, (match, aliasName) => {
        const canonicalName = d3EaseAliasMap[aliasName];
        if (!canonicalName) return match;
        d3EaseAliasRepairCount += 1;
        return `d3.${canonicalName}`;
    });

    if (d3EaseAliasRepairCount > 0) {
        pushVisualizationDiagnostic(
            diagnostics,
            'repair',
            `Repaired ${d3EaseAliasRepairCount} common D3 easing alias typo(s) so generated transitions use the canonical d3.easeSin* API names.`
        );
    }

    let d3QuerySelectorRepairCount = 0;
    repairedScript = repairedScript.replace(
        /d3\.select\(\s*((?:vizContainer|container|host|holder|root|wrapper|[a-zA-Z_$][\w$]*|document\.getElementById\([^)]*\)|document\.querySelector\([^)]*\)|vizContainer\.querySelector\([^)]*\)|container\.querySelector\([^)]*\)))\s*\)\.querySelector(All)?\(/g,
        (match, baseExpression, queryAllSuffix) => {
            d3QuerySelectorRepairCount += 1;
            return `${baseExpression}.querySelector${queryAllSuffix || ''}(`;
        }
    );

    if (d3QuerySelectorRepairCount > 0) {
        pushVisualizationDiagnostic(
            diagnostics,
            'repair',
            `Repaired ${d3QuerySelectorRepairCount} D3 selection/DOM mix-up pattern(s) by removing invalid .querySelector calls on d3.select(...).`
        );
    }

    Array.from(doc.querySelectorAll('style')).forEach((styleNode) => {
        const { patchedCss, repairedCount } = patchVisualizationCssContrast(styleNode.textContent || '');
        if (repairedCount > 0) {
            styleNode.textContent = patchedCss;
            contrastCssRepairCount += repairedCount;
        }
    });

    contrastInlineRepairCount += patchVisualizationInlineSurfaceContrast(doc.body);

    if (contrastCssRepairCount > 0) {
        pushVisualizationDiagnostic(
            diagnostics,
            'repair',
            `Added ${contrastCssRepairCount} scoped CSS foreground declaration(s) to keep text-bearing surfaces readable across host themes.`
        );
    }

    if (contrastInlineRepairCount > 0) {
        pushVisualizationDiagnostic(
            diagnostics,
            'repair',
            `Added ${contrastInlineRepairCount} inline foreground declaration(s) for surfaces that defined a background without readable text color.`
        );
    }

    if (/d3\.select\([^)]*\)\.querySelector(All)?\(/.test(repairedScript)) {
        pushVisualizationDiagnostic(
            diagnostics,
            'fatal',
            'Detected an unresolved D3 misuse pattern: DOM query methods are still being called on a D3 selection.'
        );
    }

    return repairedScript;
}

// [NEW] Lifecycle Manager for Zombie Process Cleanup
const VizLifecycle = {
    registry: {},
    
    // Register a resource (timer, interval, frame, observer) to a specific container ID
    register(id, type, handle) {
        if (!this.registry[id]) {
            this.registry[id] = { timers: [], intervals: [], frames: [], observers: [], cleanups: [] };
        }
        if (type === 'timer') this.registry[id].timers.push(handle);
        if (type === 'interval') this.registry[id].intervals.push(handle);
        if (type === 'frame') this.registry[id].frames.push(handle);
        if (type === 'observer') this.registry[id].observers.push(handle);
        if (type === 'cleanup' && typeof handle === 'function') this.registry[id].cleanups.push(handle);
    },

    // Kill all resources associated with a container ID
    cleanup(id) {
        if (!this.registry[id]) return;
        
        const { timers, intervals, frames, observers, cleanups } = this.registry[id];
        
        timers.forEach(t => clearTimeout(t));
        intervals.forEach(i => clearInterval(i));
        frames.forEach(f => cancelAnimationFrame(f));
        observers.forEach((observer) => observer?.disconnect?.());
        cleanups.forEach((cleanupFn) => {
            try {
                cleanupFn();
            } catch (error) {
                console.warn(`[VizLifecycle] Cleanup callback failed for ${id}:`, error);
            }
        });
        
        if (timers.length > 0 || intervals.length > 0 || frames.length > 0 || observers.length > 0 || cleanups.length > 0) {
            console.log(`[VizLifecycle] Cleaned up ${timers.length} timers, ${intervals.length} intervals, ${frames.length} frames, ${observers.length} observers, ${cleanups.length} cleanup callbacks for ${id}`);
        }
        
        delete this.registry[id];
    }
};
window.VizLifecycle = VizLifecycle;

function runGeneratedVisualizationCleanup(rootNode) {
    if (!(rootNode instanceof Element)) return 0;

    const cleanupEntries = [];
    const seenCleanupFns = new Set();
    const nodes = [rootNode, ...rootNode.querySelectorAll('*')];

    nodes.forEach((node) => {
        if (typeof node._cleanup === 'function' && !seenCleanupFns.has(node._cleanup)) {
            seenCleanupFns.add(node._cleanup);
            cleanupEntries.push({ node, fn: node._cleanup });
        }
    });

    cleanupEntries.forEach(({ node, fn }) => {
        try {
            fn.call(node);
        } catch (error) {
            console.warn('[VizLifecycle] Generated visualization DOM cleanup failed:', error);
        }
    });

    return cleanupEntries.length;
}

// [NEW] Helper to convert markdown links to HTML anchors for JSON data
function processMarkdownLinks(text) {
    if (!text || typeof text !== 'string') return text;
    // Convert [map](URL) -> <a href="URL" target="_blank">map</a>
    // Convert [wiki](URL) -> <a href="URL" target="_blank">wiki</a>
    return text.replace(/\[(map|wiki)\]\(([^)]+)\)/gi, (match, type, url) => {
        return `<a href="${url}" target="_blank">${type}</a>`;
    });
}

// [NEW] Renders the Status Dashboard from injected JSON data
function renderStatusDashboardFromJSON(jsonData, targetContainer) {
    if (!jsonData || !targetContainer) return;

    const dashboardDiv = document.createElement('div');
    dashboardDiv.className = 'status-dashboard';

    // 1. Render Core Modules (6 Grids)
    if (jsonData.core && Array.isArray(jsonData.core)) {
        jsonData.core.forEach(mod => {
            const moduleDiv = document.createElement('div');
            moduleDiv.className = 'status-module';
            
            const title = `<h4><span>${mod.i || ''}</span> ${mod.t || 'Info'}</h4>`;
            let listItems = '';
            
            if (mod.d && Array.isArray(mod.d)) {
                listItems = mod.d.map(item => {
                    const val = processMarkdownLinks(item.v);
                    return `<li><span class="term">${item.k}</span><span class="definition">${val}</span></li>`;
                }).join('');
            }
            
            moduleDiv.innerHTML = `${title}<ul>${listItems}</ul>`;
            dashboardDiv.appendChild(moduleDiv);
        });
    }

    // 2. Render Event Module
    if (jsonData.event) {
        const ev = jsonData.event;
        const eventDiv = document.createElement('div');
        eventDiv.className = 'status-module';
        eventDiv.style.gridColumn = '1 / -1';
        
        let displayTitle = ev.t || 'Event';
        // Only append title if not already redundant
        // (This logic mimics the older renderer fix)
        // Actually, in the JSON schema, 't' is usually "{{var_event_name}}". 
        // If the JSON structure is fixed as {"t": "Event Name"}, we just use it.
        
        const titleHtml = `<h4><span>${ev.i || '📜'}</span> ${displayTitle}</h4>`;
        const progressHtml = `
            <div class="progress-bar-container"><div class="progress-bar" style="width: ${ev.p || 0}%;"></div></div>
            <span class="progress-percent-text">${ev.p || 0}%</span>
        `;
        
        eventDiv.innerHTML = titleHtml + progressHtml;
        dashboardDiv.appendChild(eventDiv);
    }

    // 3. Render Scan Module (Table)
    if (jsonData.scan && jsonData.scan.rows && Array.isArray(jsonData.scan.rows)) {
        const sc = jsonData.scan;
        const scanDiv = document.createElement('div');
        scanDiv.className = 'status-module scan-table-module';
        scanDiv.style.gridColumn = '1 / -1';
        
        const titleHtml = `<h4><span>${sc.i || '🔍'}</span> ${sc.t || 'Scan'}</h4>`;
        
        let tableHtml = '<table>';
        const rows = sc.rows;
        
        if (rows.length > 0) {
            // Header
            tableHtml += '<thead><tr>';
            rows[0].forEach(headerText => {
                tableHtml += `<th>${headerText}</th>`;
            });
            tableHtml += '</tr></thead>';
            
            // Body
            tableHtml += '<tbody>';
            for (let i = 1; i < rows.length; i++) {
                tableHtml += '<tr>';
                rows[i].forEach(cellText => {
                    tableHtml += `<td>${processMarkdownLinks(cellText)}</td>`;
                });
                tableHtml += '</tr>';
            }
            tableHtml += '</tbody>';
        }
        tableHtml += '</table>';
        
        scanDiv.innerHTML = titleHtml + tableHtml;
        dashboardDiv.appendChild(scanDiv);
    }

    targetContainer.innerHTML = '';
    targetContainer.appendChild(dashboardDiv);
}


// [NEW] Hydration Logic for HTML Mode
function normalizePlaceholderDisplayMode(rawValue) {
    const normalized = String(rawValue || '').trim().toLowerCase();
    if (!normalized) return '';

    if (['slot', 'frame', 'inline-slot', 'media-slot', 'embedded'].includes(normalized)) return 'slot';
    if (['block', 'standalone', 'section'].includes(normalized)) return 'block';
    return '';
}

function resolvePlaceholderPresentation(placeholder, kind = 'image') {
    const explicitMode = normalizePlaceholderDisplayMode(placeholder?.dataset?.placeholderDisplay);
    const authoredClassName = placeholder?.getAttribute?.('class') || '';
    const authoredStyle = placeholder?.getAttribute?.('style') || '';
    const hasFrameSizingHints = /\b(?:w-full|h-full|object-cover|object-contain|overflow-hidden|aspect-[\w[\]-]+|h-\[[^\]]+\]|min-h-\[[^\]]+\]|rounded[\w:-]*)\b/.test(authoredClassName)
        || /(?:^|;)\s*(?:height|min-height|max-height|width|aspect-ratio)\s*:/.test(authoredStyle);

    let mode = explicitMode;
    if (!mode) {
        if (kind === 'image') {
            mode = hasFrameSizingHints && !placeholder.classList.contains('content-section') ? 'slot' : 'block';
        } else {
            mode = explicitMode === 'slot' ? 'slot' : 'block';
        }
    }

    const explicitFit = String(
        placeholder?.dataset?.imageFit
        || placeholder?.dataset?.mediaFit
        || ''
    ).trim().toLowerCase();

    let fit = explicitFit;
    if (!['cover', 'contain'].includes(fit)) {
        if (/\bobject-contain\b/.test(authoredClassName)) {
            fit = 'contain';
        } else if (/\bobject-cover\b/.test(authoredClassName)) {
            fit = 'cover';
        } else {
            fit = mode === 'slot' ? 'cover' : 'contain';
        }
    }

    return { mode, fit };
}

function applyPlaceholderPresentationClasses(placeholder, kind, presentation) {
    const safePresentation = presentation || { mode: 'block', fit: kind === 'image' ? 'contain' : '' };

    placeholder.classList.add('content-section');
    if (kind === 'image') {
        placeholder.classList.add('type-generated-image');
        placeholder.classList.toggle('type-generated-image-slot', safePresentation.mode === 'slot');
        placeholder.dataset.placeholderDisplayResolved = safePresentation.mode;
        placeholder.dataset.imageFitResolved = safePresentation.fit;
    } else {
        placeholder.classList.add('type-visualization-placeholder');
        placeholder.classList.toggle('type-visualization-placeholder-slot', safePresentation.mode === 'slot');
        placeholder.dataset.placeholderDisplayResolved = safePresentation.mode;
    }
}

function hydrateDOM(rootElement) {
    if (!rootElement) return;
    trace("Renderer", "hydrateDOM.start", { root: rootElement.id || 'unknown' });

    if (rootElement.id === 'ai-content-placeholder' && rootElement.style.display === 'none') {
         rootElement.style.display = 'block';
    } else {
        const hiddenMain = rootElement.querySelector('#ai-content-placeholder[style*="display:none"], #ai-content-placeholder[style*="display: none"]');
        if (hiddenMain) {
            hiddenMain.style.display = 'block';
        }
    }

    // 0. Status Dashboard Injection (JSON Mode)
    const dashboardJsonDiv = rootElement.querySelector('#dashboard-json-data');
    const dashboardTarget = rootElement.querySelector('#dashboard-render-target');
    
    if (dashboardJsonDiv && dashboardTarget && !dashboardTarget.dataset.hydrated) {
        try {
            const rawJson = dashboardJsonDiv.textContent.trim();
            const jsonData = JSON.parse(rawJson);
            renderStatusDashboardFromJSON(jsonData, dashboardTarget);
            dashboardTarget.dataset.hydrated = 'true';
            trace("Renderer", "StatusDashboard.injected");
        } catch (e) {
            console.error("Failed to parse dashboard JSON:", e);
            dashboardTarget.innerHTML = `<div class="status-error">Dashboard Error: ${e.message}</div>`;
        }
    }

    // 1. Interactive Maps
    const mapContainers = rootElement.querySelectorAll('[data-component="interactive-map"]');
    mapContainers.forEach((container, index) => {
        if (container.dataset.hydrated) return;
        
        const blockData = {
            latitude: parseFloat(container.dataset.lat),
            longitude: parseFloat(container.dataset.lng),
            locationName: container.dataset.location,
            zoom: parseInt(container.dataset.zoom || '15', 10)
        };

        const accordionContainer = document.createElement('div');
        accordionContainer.className = 'map-accordion-container';

        const header = document.createElement('div');
        header.className = 'map-accordion-header';
        
        const processedLocationName = typeof renderKatexInString === 'function' 
            ? renderKatexInString(blockData.locationName || '지도 보기') 
            : (blockData.locationName || '지도 보기');

        header.innerHTML = `
            <span class="map-location-name">📍 ${processedLocationName}</span>
            <span class="map-toggle-icon">▶</span>
        `;

        const content = document.createElement('div');
        content.className = 'map-accordion-content';
        const mapDiv = document.createElement('div');
        mapDiv.id = `map-container-hydrated-${Date.now()}-${index}`;
        content.appendChild(mapDiv);

        accordionContainer.appendChild(header);
        accordionContainer.appendChild(content);
        
        container.replaceWith(accordionContainer);

        header.addEventListener('click', () => {
            const isExpanded = accordionContainer.classList.toggle('expanded');
            const isInitialized = accordionContainer.dataset.initialized === 'true';

            if (isExpanded && !isInitialized) {
                if (typeof renderInteractiveMapBlock === 'function') {
                    renderInteractiveMapBlock(blockData, mapDiv);
                    accordionContainer.dataset.initialized = 'true';
                }
            }
        });
    });

    // 2. Visualization Placeholders
    const vizPlaceholders = rootElement.querySelectorAll('[data-component="visualization-placeholder"]');
    vizPlaceholders.forEach(placeholder => {
        if (placeholder.dataset.hydrated) return;
        const prompt = placeholder.dataset.prompt;
        const presentation = resolvePlaceholderPresentation(placeholder, 'visualization');
        
        applyPlaceholderPresentationClasses(placeholder, 'visualization', presentation);
        placeholder.innerHTML = `
            <div class="placeholder-content">
                <svg viewBox="0 0 24 24" width="48" height="48" fill="currentColor" style="opacity: 0.3;"><path d="M5,9.5H7.5V19H5V9.5M12.5,4.5H15V19H12.5V4.5M19.5,13.5H22V19H19.5V13.5Z" /></svg>
                <p style="color: inherit; opacity: 0.6; margin-top: 10px;">이곳에 데이터 시각화 자료를 추가할 수 있습니다.</p>
            </div>
            <div class="placeholder-actions">
                <button class="placeholder-action-btn generate-viz">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M2,2H4V20H22V22H2V2M7,10H9V18H7V10M12,15H14V18H12V15M17,6H19V18H17V6Z"></path></svg>
                    <span>시각화 자료 생성</span>
                </button>
            </div>
        `;
        
        placeholder.querySelector('.generate-viz').addEventListener('click', () => {
            if (typeof window.openVisualizationOptionsModal === 'function') {
                window.openVisualizationOptionsModal(
                    { description: prompt || '' },
                    (options) => {
                        if (typeof window._generateAndPlaceVisualization === 'function') {
                            window._generateAndPlaceVisualization(options, placeholder, true);
                        }
                    },
                    placeholder
                );
            }
        });
        
        placeholder.addEventListener('contextmenu', (event) => {
            event.preventDefault();
            event.stopPropagation();
            const menuItems = [
                { label: '이 시각화 영역 제거', action: () => placeholder.remove() }
            ];
            createContextMenu(menuItems, event);
        });

        placeholder.dataset.hydrated = 'true';
    });

    // 3. Immediate Visualizations (.ccc)
    const vizContainers = rootElement.querySelectorAll('[data-component="visualization-container"]');
    vizContainers.forEach(container => {
        if (container.dataset.hydrated) return;
        
        const scriptTag = container.querySelector('script.viz-source');
        if (scriptTag) {
            let scriptContent = scriptTag.textContent;
            
            // [FIX] Robustly remove "code", "Code", "```" artifacts common in AI output
            scriptContent = scriptContent.replace(/^\s*(code|Code)\s*$/gim, '');
            scriptContent = scriptContent.replace(/```(javascript|js|html|xml)?/gi, '').replace(/```/g, '');

            // [CRITICAL FIX] Unescape script tags (<\/script> -> </script>) 
            scriptContent = scriptContent.replace(/<\\\/script>/gi, '</script>');

            let finalHtmlContent = '';

            // [CRITICAL FIX] Enhanced HTML Detection
            const isHtmlOrSvg = /^\s*<(!doctype|html|svg|div|section|style|head|body)/i.test(scriptContent) || scriptContent.includes('<html');

            if (isHtmlOrSvg) {
                finalHtmlContent = scriptContent;
            } else {
                let siblingHtml = '';
                Array.from(container.childNodes).forEach(node => {
                    if (node === scriptTag) return; // Skip the script tag itself
                    
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        siblingHtml += node.outerHTML;
                    } else if (node.nodeType === Node.TEXT_NODE && node.nodeValue.trim()) {
                        let textVal = node.nodeValue.replace(/^\s*(code|Code)\s*$/gim, '');
                        siblingHtml += textVal;
                    }
                });

                if (siblingHtml.trim()) {
                    finalHtmlContent = `${siblingHtml}\n<script>${scriptContent}</script>`;
                } else {
                    finalHtmlContent = `<script>${scriptContent}</script>`;
                }
            }

            const blockData = { type: 'visualization', htmlContent: finalHtmlContent };
            
            container.className = 'content-section type-visualization';
            renderVisualizationBlock(blockData, container);
            
            container.dataset.hydrated = 'true';
        }
    });

    // 4. Image Placeholders
    const imgPlaceholders = rootElement.querySelectorAll('[data-component="image-placeholder"]');
    imgPlaceholders.forEach(placeholder => {
        if (placeholder.dataset.hydrated) return;
        const prompt = placeholder.dataset.prompt;
        const presentation = resolvePlaceholderPresentation(placeholder, 'image');

        applyPlaceholderPresentationClasses(placeholder, 'image', presentation);
        placeholder.innerHTML = `
            <div class="placeholder-content">
                <svg viewBox="0 0 24 24" width="48" height="48" fill="currentColor" style="opacity: 0.3;"><path d="M21.58,16.09L17.17,11.67C17.45,11.12,17.62,10.5,17.62,9.88C17.62,7.66,15.95,5.88,13.81,5.88C13.5,5.88,13.2,5.93,12.91,6L11.5,4.58L10.08,6L11.5,7.41L6,12.91L4.59,11.5L3.17,12.91L4.59,14.33L2.38,16.54L1,15.17L0.99,17.38L3.19,18.6L4.41,17.38L6.62,15.17L8.04,16.59L9.46,15.17L8.04,13.75L13.55,8.25L15.67,10.37L15.22,10.82L16.64,12.24L18.76,10.12L23,14.36L21.58,15.77M13.81,8.88C13.26,8.88,12.81,9.33,12.81,9.88C12.81,10.43,13.26,10.88,13.81,10.88C14.36,10.88,14.81,10.43,14.81,9.88C14.81,9.33,14.36,8.88,13.81,8.88Z"></path></svg>
                <p style="color: inherit; opacity: 0.6; margin-top: 10px;">이 장면을 이미지로 생성할 수 있습니다.</p>
            </div>
            <div class="placeholder-actions">
                <button class="placeholder-action-btn quick"><span>빠른 생성</span></button>
                <button class="placeholder-action-btn refined"><span>정제 후 생성</span></button>
                <button class="placeholder-action-btn options"><span>옵션</span></button>
                <button class="placeholder-action-btn settings"><span>설정</span></button>
            </div>
        `;

        placeholder.querySelector('.quick').addEventListener('click', () => {
            if(typeof window.handleGeneration === 'function') window.handleGeneration('quick', { targetElement: placeholder });
        });
        placeholder.querySelector('.refined')?.remove();
        placeholder.querySelector('.options').addEventListener('click', () => {
            if (typeof window.openImageGenerationOptionsModal === 'function') {
                let contextText = placeholder.dataset.studioPrompt || placeholder.dataset.prompt || '';
                let sibling = placeholder.previousElementSibling;
                while (!contextText && sibling) {
                    if (sibling.tagName === 'P' || sibling.tagName === 'H2') {
                        contextText = sibling.innerText;
                        break;
                    }
                    sibling = sibling.previousElementSibling;
                }
                window.openImageGenerationOptionsModal(contextText, placeholder, true);
            }
        });
        placeholder.querySelector('.settings').addEventListener('click', () => {
             if(typeof window.openVisionWeaverSettingsModal === 'function') window.openVisionWeaverSettingsModal();
        });

        placeholder.dataset.hydrated = 'true';
    });

    // 5. Rehydrate saved visualizations in Live HTML or Archives
    const activeViz = rootElement.querySelectorAll('.type-visualization[data-block-data]');
    activeViz.forEach(container => {
        if (container.dataset.hydrated) return;
        Promise.resolve().then(async () => {
            try {
                const blockData = JSON.parse(container.dataset.blockData);
                const transaction = await stageVisualizationBlockTransaction(blockData, container);
                commitStagedVisualizationTransaction(container, transaction);
            } catch(e) {
                console.error("Rehydration failed:", e);
                if (typeof window.renderVisualizationFailureState === 'function') {
                    window.renderVisualizationFailureState(container, 'Visualization rehydrate failed', e.message);
                } else {
                    container.innerHTML = buildVisualizationDiagnosticHtml(
                        'Visualization rehydrate failed',
                        [{ level: 'error', message: e.message }],
                        'Regenerate the visualization or use AI code fix if the saved block can no longer run.'
                    );
                }
            }
        });
    });

    if (typeof restoreGeneratedImageControls === 'function') {
        restoreGeneratedImageControls(rootElement);
    }

    initializeDynamicContentListeners(rootElement);
}

window.hydrateDOM = hydrateDOM;

async function handleCodeFixRequest(blockData, containerElement) {
    if (activeCodeFixJob) {
        showToastNotification("이미 다른 코드 수정 작업이 진행 중입니다.", "", "code-fix-busy");
        return;
    }

    trace("UI.Action", "viz.codeFix.start");

    if (!containerElement.id) {
        containerElement.id = `viz-block-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    }

    const originalHTML = containerElement.innerHTML;
    const originalClassName = containerElement.className;

    try {
        const correctorTemplate = promptTemplatesCache.find(p => p.name === "Code Corrector");
        if (!correctorTemplate) {
            throw new Error("Could not find 'Code Corrector' prompt template.");
        }

        const isPlaceholderFix = blockData.type === 'visualization-placeholder';
        const promptText = blockData.prompt || '';

        let errorMessage = '';
        const errorElement = containerElement.querySelector('.placeholder-content p, .bg-red-50');
        if (errorElement) {
            errorMessage = errorElement.innerText.trim();
             if (errorMessage.includes('이곳에 데이터 시각화 자료를 추가할 수 있습니다')) {
                errorMessage = '';
            }
        }
        
        const systemInstruction = correctorTemplate.promptText;
        
        let userContent = '';
        if (errorMessage) {
            userContent += `[발생한 오류 메시지]\n${errorMessage}\n\n---\n\n`;
        }

        if (isPlaceholderFix) {
            userContent += `[오류가 발생한 원본 프롬프트]\n${promptText}`;
        } else {
            userContent += `[오류가 발생한 코드 원본]\n\`\`\`html\n${blockData.htmlContent}\n\`\`\``;
        }

        activeCodeFixJob = {
            targetElementId: containerElement.id,
            originalHTML: originalHTML,
            originalClassName: originalClassName
        };
        
        containerElement.className = 'content-section type-visualization-loading';
        containerElement.innerHTML = `<div class="loading-animation"><div class="dot"></div><div class="dot"></div><div class="dot"></div></div><p style="text-align:center; opacity: 0.7;">AI가 코드를 수정하는 중...</p>`;

        const systemSessionId = await findOrCreateSystemSession('[System] Visualization Engine');
        if (!systemSessionId) {
            throw new Error("Could not create or find system session for code correction.");
        }

        showToastNotification("AI에게 코드 수정을 요청했습니다...", "채팅 패널에서 진행 상황을 확인하세요.", `code-fix-start-${Date.now()}`);
        togglePanel(chatPanel, true);
        await selectSession(systemSessionId);
        
        await programmaticChatSend(systemSessionId, userContent, systemInstruction, true);

    } catch (error) {
        console.error("Failed to initiate code fix request:", error);
        showModal(`코드 수정 요청 실패: ${error.message}`, () => {});
        
        if (containerElement && activeCodeFixJob) {
            containerElement.className = originalClassName;
            containerElement.innerHTML = originalHTML;
        }

        activeCodeFixJob = null;
    }
}

/*
function copyVisualizationBlockJson(blockData) {
    navigator.clipboard.writeText(JSON.stringify(blockData, null, 2));
    showToastNotification("✅ 시각화 블록 JSON이 복사되었습니다.", "클립보드", `viz-copy-json-${Date.now()}`);
}

function copyVisualizationHtmlSource(blockData) {
    navigator.clipboard.writeText(blockData.htmlContent || '');
    showToastNotification("✅ 시각화 HTML 코드가 복사되었습니다.", "클립보드", `viz-copy-html-${Date.now()}`);
}

function explainVisualizationInChat(blockData) {
    if (!chatInput) return;
    togglePanel(chatPanel, true);
    const prompt = `아래 시각화 자료의 코드를 자세히 설명해줘. 어떤 원리로 동작하는지 풀어서 설명해줘.\n\n\`\`\`html\n${blockData.htmlContent}\n\`\`\``;
    chatInput.value = prompt;
    autoResizeTextarea(chatInput);
    chatInput.focus();
}

function buildVisualizationOverflowItems(blockData, containerElement) {
    const items = [];

    if (blockData.noteId && typeof archiveVisualizationToNote === 'function') {
        items.push({
            label: '노트에 저장',
            action: async () => {
                await archiveVisualizationToNote(blockData.noteId, blockData);
            }
        });
        items.push({ separator: true });
    }

    items.push({
        label: 'AI 편집',
        submenu: [
            {
                label: '옵션 다시 열기',
                action: () => {
                    if (typeof handleModifyVisualization === 'function') {
                        handleModifyVisualization(blockData, containerElement);
                    }
                }
            },
            {
                label: '깨진 코드 수리',
                action: () => {
                    if (typeof handleCodeFixRequest === 'function') {
                        handleCodeFixRequest(blockData, containerElement);
                    }
                }
            }
        ]
    });
    items.push({
        label: 'AI 설명 요청',
        action: () => explainVisualizationInChat(blockData)
    });
    items.push({
        label: '소스 복사',
        submenu: [
            { label: 'HTML 코드 복사', action: () => copyVisualizationHtmlSource(blockData) },
            { label: '블록 JSON 복사', action: () => copyVisualizationBlockJson(blockData) }
        ]
    });

    return items;
}
*/

function copyVisualizationBlockJson(blockData) {
    navigator.clipboard.writeText(JSON.stringify(blockData, null, 2));
    showToastNotification("시각화 JSON을 복사했습니다.", "클립보드", `viz-copy-json-${Date.now()}`);
}

function copyVisualizationHtmlSource(blockData) {
    navigator.clipboard.writeText(blockData.htmlContent || '');
    showToastNotification("시각화 HTML을 복사했습니다.", "클립보드", `viz-copy-html-${Date.now()}`);
}

function explainVisualizationInChat(blockData) {
    if (!chatInput) return;
    togglePanel(chatPanel, true);
    const prompt = `아래 시각화 코드가 어떤 구조로 동작하는지 자세히 설명해줘. 런타임에서 어떤 순서로 렌더링되는지도 함께 알려줘.\n\n\`\`\`html\n${blockData.htmlContent}\n\`\`\``;
    chatInput.value = prompt;
    autoResizeTextarea(chatInput);
    chatInput.focus();
}

function buildVisualizationOverflowItems(blockData, containerElement) {
    const items = [];

    if (blockData.noteId && typeof archiveVisualizationToNote === 'function') {
        items.push({
            label: '노트에 저장',
            action: async () => {
                await archiveVisualizationToNote(blockData.noteId, blockData);
            }
        });
        items.push({ separator: true });
    }

    items.push({
        label: 'AI로 다듬기',
        submenu: [
            {
                label: '스튜디오에서 다시 구성',
                action: () => {
                    if (typeof handleModifyVisualization === 'function') {
                        handleModifyVisualization(blockData, containerElement);
                    }
                }
            },
            {
                label: '코드 오류 고치기',
                action: () => {
                    if (typeof handleCodeFixRequest === 'function') {
                        handleCodeFixRequest(blockData, containerElement);
                    }
                }
            }
        ]
    });
    items.push({
        label: '작동 원리 설명',
        action: () => explainVisualizationInChat(blockData)
    });
    items.push({
        label: '원본 코드 복사',
        submenu: [
            { label: 'HTML 복사', action: () => copyVisualizationHtmlSource(blockData) },
            { label: 'JSON 복사', action: () => copyVisualizationBlockJson(blockData) }
        ]
    });

    return items;
}

// [CoreDNA] The main entry point for rendering a visualization block using Direct DOM Injection.
async function renderVisualizationBlock(blockData, containerElement) {
    if (!containerElement) {
        console.error("renderVisualizationBlock called with no containerElement.");
        return;
    }
    if (!blockData || !blockData.htmlContent) {
        console.error("Invalid visualization block data:", blockData);
        containerElement.innerHTML = '<p style="color:red;">[오류] 시각화 블록 데이터가 올바르지 않습니다. (htmlContent가 필요합니다)</p>';
        return;
    }

    if (typeof containerElement.__exitVizCinema === 'function') {
        try {
            containerElement.__exitVizCinema({ skipLayoutSync: true });
        } catch (cinemaCleanupError) {
            trace("System.Render", "viz.cinema.cleanupOnRerender.error", { error: cinemaCleanupError.message }, {}, "WARN");
        }
        containerElement.__exitVizCinema = null;
    }
    
    containerElement.dataset.blockData = JSON.stringify(blockData);
    containerElement.dataset.hydrated = 'true';

    const previousVisualizationId = containerElement.dataset.vizInstanceId;
    if (previousVisualizationId && window.VizLifecycle) {
        window.VizLifecycle.cleanup(previousVisualizationId);
    }
    runGeneratedVisualizationCleanup(containerElement);

    const htmlContent = blockData.htmlContent || '';
    const isSceneLikeVisualization = /three(?:\.min)?\.js|THREE\.|WebGLRenderer|p5(?:\.min)?\.js|createCanvas\(|scatter3d|surface|mesh3d/i.test(htmlContent);
    const needsInteractiveRoom = /<input|<button|type=["']range["']|addEventListener\(['"]wheel['"]|onwheel\s*=|mousePressed|mousedown|drag/i.test(htmlContent);
    const visualizationProfile = (isSceneLikeVisualization || needsInteractiveRoom) ? 'scene' : 'standard';

    const executionWrapper = document.createElement('div');
    executionWrapper.className = 'visualization-execution-wrapper';
    executionWrapper.dataset.vizProfile = visualizationProfile;
    
    const vizContentContainer = document.createElement('div');
    vizContentContainer.className = 'visualization-content-container';
    vizContentContainer.dataset.vizProfile = visualizationProfile;
    // IMPORTANT: For Direct DOM Injection, we set a unique ID to scope logic.
    const uniqueId = `viz-container-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    vizContentContainer.id = uniqueId;
    containerElement.dataset.vizInstanceId = uniqueId;
    
    // [CRITICAL] Force relative positioning and adaptive dimensions to avoid 0-height issues
    // while giving larger scene-like visualizations enough room in normal mode.
    vizContentContainer.style.position = 'relative';
    vizContentContainer.style.width = '100%';
    vizContentContainer.style.height = visualizationProfile === 'scene'
        ? 'clamp(560px, 72vh, 860px)'
        : 'clamp(420px, 54vh, 560px)';
    vizContentContainer.style.overflow = 'hidden'; // Keep absolute-positioned charts inside the box

    containerElement.classList.toggle('viz-scene-block', visualizationProfile === 'scene');

    if (visualizationProfile === 'scene') {
        executionWrapper.classList.add('viz-scene-layout');
        vizContentContainer.classList.add('viz-scene-layout');
    }

    if (document.body.classList.contains('dark-mode')) {
        vizContentContainer.classList.add('viz-dark-mode');
    }
    
    executionWrapper.appendChild(vizContentContainer);
    
    const controlsGroup = document.createElement('div');
    controlsGroup.className = 'viz-controls-group';

    const controls = [
        { action: 'expand', title: '전체 화면 (시네마 모드)', svg: '<svg viewBox="0 0 24 24"><path d="M7,14H5V19H10V17H7V14M5,10H7V7H10V5H5V10M17,17H14V19H19V14H17V17M14,5V7H17V10H19V5H14Z"/></svg>' },
        { action: 'pin', title: '노트에 이 시각화 고정', svg: '<svg viewBox="0 0 24 24"><path d="M16,12V4H17V2H7V4H8V12L6,14V16H11.2V22H12.8V16H18V14L16,12Z"></path></svg>' },
        { action: 'replay', title: '다시 재생', svg: '<svg viewBox="0 0 24 24"><path d="M12,5V1L7,6L12,11V7A6,6 0 0,1 18,13A6,6 0 0,1 12,19C9.5,19 7.35,17.64 6.34,15.54L4.34,16.5C5.7,19.33 8.61,21.5 12,21.5A8.5,8.5 0 0,0 20.5,13A8.5,8.5 0 0,0 12,4.5V5Z"></path></svg>' },
        { action: 'regenerate', title: '재생성 (AI)', svg: '<svg viewBox="0 0 24 24"><path d="M16.5,2C15.9,2.4 15,3.5 15,3.5L12.5,1L10,3.5C10,3.5 9.1,2.4 8.5,2C7.9,1.6 7.1,1.5 6.5,1.7C5.9,1.9 5.3,2.3 5,2.9C4.4,3.9 4.8,5.1 5.3,5.8C5.6,6.2 6.1,6.8 6.1,6.8L3,9.9L9.1,16L12.2,12.9L15.3,16L21.4,9.9L18.3,6.8C18.3,6.8 18.8,6.2 19.1,5.8C19.6,5.1 20,3.9 19.4,2.9C19.1,2.3 18.5,1.9 17.9,1.7C17.3,1.5 16.5,1.6 15.9,2H16.5M15.3,9.7L11.8,13.2L10.4,11.8L13.9,8.3L15.3,9.7M17,17.2L19.8,20L17,22.8L14.2,20L17,17.2Z"></path></svg>' },
        { action: 'fix', title: 'AI로 코드 수정', svg: '<svg viewBox="0 0 24 24"><path d="M12,2.5L14.04,7.12L19,7.5L15.25,10.87L16.4,15.69L12,13.25L7.6,15.69L8.75,10.87L5,7.5L9.96,7.12L12,2.5Z"></path></svg>' },
        { action: 'modify', title: '옵션 수정 및 재성성', svg: '<svg viewBox="0 0 24 24"><path d="M12,8A4,4 0 0,1 16,12A4,4 0 0,1 12,16A4,4 0 0,1 8,12A4,4 0 0,1 12,8M12,10A2,2 0 0,0 10,12A2,2 0 0,0 12,14A2,2 0 0,0 14,12A2,2 0 0,0 12,10M19.03,7.39L20.45,5.97C20,5.46 19.54,5 19.03,4.55L17.61,5.97C16.07,4.74 14.12,4 12,4C9.88,4 7.93,4.74 6.39,5.97L5,4.55C4.5,5 4,5.46 3.55,5.97L4.97,7.39C3.74,8.93 3,10.88 3,13C3,15.12 3.74,17.07 4.97,18.61L3.55,20.03C4,20.54 4.5,21 5,21.45L6.39,20.03C7.93,21.26 9.88,22 12,22C14.12,22 16.07,21.26 17.61,20.03L19.03,21.45C19.54,21 20,20.54 20.45,20.03L19.03,18.61C20.26,17.07 21,15.12 21,13C21,10.88 20.26,8.93 19.03,7.39Z"></path></svg>' },
        { action: 'export', title: '내보내기', svg: '<svg viewBox="0 0 24 24"><path d="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z"></path></svg>' },
        { action: 'explain', title: 'AI에게 코드 설명 요청', svg: '<svg viewBox="0 0 24 24"><path d="M20,2H4A2,2 0 0,0 2,4V22L6,18H20A2,2 0 0,0 22,16V4A2,2 0 0,0 20,2M13,15H11V13H13V15M13,11H11V6H13V11Z"></path></svg>' }
    ];

    /*
    controls.length = 0;
    controls.push(
        { action: 'expand', title: '전체 화면', svg: '<svg viewBox="0 0 24 24"><path d="M7,14H5V19H10V17H7V14M5,10H7V7H10V5H5V10M17,17H14V19H19V14H17V17M14,5V7H17V10H19V5H14Z"/></svg>' },
        { action: 'regenerate', title: '다시 생성', svg: '<svg viewBox="0 0 24 24"><path d="M16.5,2C15.9,2.4 15,3.5 15,3.5L12.5,1L10,3.5C10,3.5 9.1,2.4 8.5,2C7.9,1.6 7.1,1.5 6.5,1.7C5.9,1.9 5.3,2.3 5,2.9C4.4,3.9 4.8,5.1 5.3,5.8C5.6,6.2 6.1,6.8 6.1,6.8L3,9.9L9.1,16L12.2,12.9L15.3,16L21.4,9.9L18.3,6.8C18.3,6.8 18.8,6.2 19.1,5.8C19.6,5.1 20,3.9 19.4,2.9C19.1,2.3 18.5,1.9 17.9,1.7C17.3,1.5 16.5,1.6 15.9,2H16.5M15.3,9.7L11.8,13.2L10.4,11.8L13.9,8.3L15.3,9.7M17,17.2L19.8,20L17,22.8L14.2,20L17,17.2Z"></path></svg>' },
        { action: 'more', title: '더보기', svg: '<svg viewBox="0 0 24 24"><path d="M12,2A2,2 0 1,0 12,6A2,2 0 1,0 12,2M12,10A2,2 0 1,0 12,14A2,2 0 1,0 12,10M12,18A2,2 0 1,0 12,22A2,2 0 1,0 12,18Z"></path></svg>' }
    );

    */
    controls.length = 0;
    controls.push(
        { action: 'expand', title: '확대 보기', svg: '<svg viewBox="0 0 24 24"><path d="M7,14H5V19H10V17H7V14M5,10H7V7H10V5H5V10M17,17H14V19H19V14H17V17M14,5V7H17V10H19V5H14Z"/></svg>' },
        { action: 'regenerate', title: '다시 생성', svg: '<svg viewBox="0 0 24 24"><path d="M16.5,2C15.9,2.4 15,3.5 15,3.5L12.5,1L10,3.5C10,3.5 9.1,2.4 8.5,2C7.9,1.6 7.1,1.5 6.5,1.7C5.9,1.9 5.3,2.3 5,2.9C4.4,3.9 4.8,5.1 5.3,5.8C5.6,6.2 6.1,6.8 6.1,6.8L3,9.9L9.1,16L12.2,12.9L15.3,16L21.4,9.9L18.3,6.8C18.3,6.8 18.8,6.2 19.1,5.8C19.6,5.1 20,3.9 19.4,2.9C19.1,2.3 18.5,1.9 17.9,1.7C17.3,1.5 16.5,1.6 15.9,2H16.5M15.3,9.7L11.8,13.2L10.4,11.8L13.9,8.3L15.3,9.7M17,17.2L19.8,20L17,22.8L14.2,20L17,17.2Z"></path></svg>' },
        { action: 'more', title: '더보기', svg: '<svg viewBox="0 0 24 24"><path d="M12,2A2,2 0 1,0 12,6A2,2 0 1,0 12,2M12,10A2,2 0 1,0 12,14A2,2 0 1,0 12,10M12,18A2,2 0 1,0 12,22A2,2 0 1,0 12,18Z"></path></svg>' }
    );

    controls.forEach(control => {
        const button = document.createElement('button');
        button.className = 'viz-control-btn';
        button.dataset.action = control.action;
        button.title = control.title;
        button.innerHTML = control.svg;
        controlsGroup.appendChild(button);
    });

    executionWrapper.appendChild(controlsGroup);
    containerElement.innerHTML = '';
    containerElement.appendChild(executionWrapper);

    let settleFrameHandle = null;
    let settleFollowupFrameHandle = null;
    let settleTimerHandle = null;
    let cinemaSyncNonce = 0;
    let cinemaEscListener = null;
    let cinemaBackdropListener = null;
    let cinemaRestoreMarker = null;
    let cinemaHost = null;

    function clearVisualizationSettleWork() {
        if (settleFrameHandle !== null) {
            window.cancelAnimationFrame(settleFrameHandle);
            settleFrameHandle = null;
        }
        if (settleFollowupFrameHandle !== null) {
            window.cancelAnimationFrame(settleFollowupFrameHandle);
            settleFollowupFrameHandle = null;
        }
        if (settleTimerHandle !== null) {
            window.clearTimeout(settleTimerHandle);
            settleTimerHandle = null;
        }
    }

    function scheduleVisualizationLayoutSync(reason) {
        clearVisualizationSettleWork();
        const syncNonce = ++cinemaSyncNonce;
        let didSync = false;

        const runSync = async () => {
            if (didSync || syncNonce !== cinemaSyncNonce) return;
            didSync = true;
            clearVisualizationSettleWork();
            trace("System.Render", "viz.layoutSync", { uniqueId, reason, profile: visualizationProfile });
            window.dispatchEvent(new Event('resize'));

            if (isSceneLikeVisualization) {
                await executeDirectVisualization(vizContentContainer);
                return;
            }

            normalizeVisualizationTextContrast(vizContentContainer, null);
            const frameHandle = window.requestAnimationFrame(() => {
                normalizeVisualizationTextContrast(vizContentContainer, null);
            });
            if (window.VizLifecycle) {
                window.VizLifecycle.register(uniqueId, 'frame', frameHandle);
            }
        };

        settleFrameHandle = window.requestAnimationFrame(() => {
            settleFollowupFrameHandle = window.requestAnimationFrame(() => {
                void runSync();
            });
        });
        settleTimerHandle = window.setTimeout(() => {
            void runSync();
        }, isSceneLikeVisualization ? 260 : 140);
    }

    function createCinemaHost() {
        const host = document.createElement('div');
        host.className = 'viz-cinema-host';
        host.dataset.vizCinemaId = uniqueId;
        return host;
    }

    function restoreCinemaShellPosition() {
        if (cinemaRestoreMarker && cinemaRestoreMarker.parentNode) {
            cinemaRestoreMarker.parentNode.replaceChild(executionWrapper, cinemaRestoreMarker);
        } else if (containerElement && containerElement.isConnected) {
            containerElement.appendChild(executionWrapper);
        }

        cinemaRestoreMarker = null;

        if (cinemaHost && cinemaHost.parentNode) {
            cinemaHost.remove();
        }
        cinemaHost = null;
    }

    let hideControlsTimer;
    executionWrapper.addEventListener('mouseenter', () => {
        clearTimeout(hideControlsTimer);
        executionWrapper.classList.add('show-controls');
    });

    executionWrapper.addEventListener('mouseleave', () => {
        hideControlsTimer = setTimeout(() => {
            executionWrapper.classList.remove('show-controls');
        }, 500);
    });

    // [HCA] Direct DOM Injection Execution Logic
    async function executeDirectVisualization(targetContainer) {
        clearVisualizationSettleWork();

        // [LIFECYCLE] Cleanup any zombie processes from previous runs
        if (window.VizLifecycle) {
            window.VizLifecycle.cleanup(uniqueId);
        }
        runGeneratedVisualizationCleanup(targetContainer);

        const previousScopeId = targetContainer.dataset.vizScopeId;
        if (previousScopeId && window.vizScopes) {
            delete window.vizScopes[previousScopeId];
        }

        targetContainer.innerHTML = '';
        
        // 1. Parse the HTML Content
        const parser = new DOMParser();
        const doc = parser.parseFromString(blockData.htmlContent, 'text/html');
        
        // 2. Handle Scripts
        const scripts = Array.from(doc.querySelectorAll('script'));
        const externalScripts = [];
        let inlineScriptContent = '';
        const diagnostics = [];

        scripts.forEach(script => {
            if (script.src) {
                externalScripts.push(script.src);
            } else {
                inlineScriptContent += script.textContent + '\n';
            }
            script.remove(); // Remove from doc so it doesn't double-execute when we inject body
        });

        inlineScriptContent = applyVisualizationPreflightRepairs(doc, inlineScriptContent, diagnostics);

        const cleanId = uniqueId.replace(/[^a-zA-Z0-9_]/g, '_');
        const scopeSelector = buildVisualizationScopeSelector(cleanId);
        targetContainer.dataset.vizScopeId = cleanId;

        // 3. Inject Styles (Append to Head) with Sanitization
        const styles = Array.from(doc.querySelectorAll('style'));
        document.head.querySelectorAll(`style[data-viz-style-owner="${cleanId}"]`).forEach((styleNode) => styleNode.remove());
        styles.forEach(style => {
            // [SECURITY] Strip aggressive global body styles that might lock scroll
            let css = style.textContent;
            css = css.replace(/body\s*\{[^}]*overflow:\s*hidden[^}]*\}/gi, '');
            css = css.replace(/body\s*\{[^}]*margin:\s*0[^}]*\}/gi, '');
            css = scopeVisualizationCss(css, scopeSelector);
            style.textContent = css;
            style.dataset.vizStyleOwner = cleanId;
            document.head.appendChild(style);
        });

        // 4. Inject Body Content with Scope Bridge
        Array.from(doc.querySelectorAll('link[href]')).forEach((linkNode) => {
            const rawHref = linkNode.getAttribute('href') || '';
            const normalizedHref = normalizeVisualizationDependencyUrl(rawHref);
            if (normalizedHref && normalizedHref !== rawHref) {
                linkNode.setAttribute('href', normalizedHref);
            }
        });

        let modifiedBodyContent = doc.body.innerHTML;
        
        // Setup global namespace for this block
        window.vizScopes = window.vizScopes || {};
        window.vizScopes[cleanId] = {};

        const capturedFunctions = new Set();
        // Regex to find function calls in onclick. Matches onclick="func(" or onclick='func('
        const onclickRegex = /onclick=(["'])\s*([a-zA-Z0-9_$]+)\s*\(/g;
        
        let match;
        while ((match = onclickRegex.exec(modifiedBodyContent)) !== null) {
            capturedFunctions.add(match[2]);
        }

        // Rewrite HTML to use namespaced functions
        capturedFunctions.forEach(funcName => {
            const replaceRegex = new RegExp(`(onclick=["'])\\s*${funcName}\\s*\\(`, 'g');
            modifiedBodyContent = modifiedBodyContent.replace(replaceRegex, `$1window.vizScopes.${cleanId}.${funcName}(`);
        });

        targetContainer.innerHTML = modifiedBodyContent;
        normalizeVisualizationTextContrast(targetContainer, diagnostics);
        observeVisualizationContrast(targetContainer, uniqueId, diagnostics);

        // 5. Load External Dependencies
        try {
            for (const url of externalScripts) {
                await loadScript(url);
            }
        } catch (err) {
            console.error("Error loading external scripts:", err);
            pushVisualizationDiagnostic(diagnostics, 'error', err.message);
            targetContainer.innerHTML = buildVisualizationDiagnosticHtml(
                'Visualization library load failed',
                diagnostics,
                'Regenerate the visualization or use AI code fix if the requested library setup is invalid.'
            );
            return;
        }

        // 6. Execute Inline Script with IIFE Scoping, Sanitization, and Scope Bridge
        if (inlineScriptContent.trim()) {
            try {
                let safeCode = inlineScriptContent;
                
                // [CRITICAL] Prevent Full Screen Takeover
                // Replace direct calls to window dimensions with container dimensions
                safeCode = safeCode.replace(/window\.innerWidth/g, 'vizContainer.clientWidth');
                safeCode = safeCode.replace(/window\.innerHeight/g, 'vizContainer.clientHeight');
                
                // [CRITICAL] Prevent Scroll Locking via JS
                safeCode = safeCode.replace(/document\.body\.style\.overflow\s*=\s*['"]hidden['"]/g, '');
                safeCode = safeCode.replace(/document\.body\.style\.margin\s*=\s*['"]0['"]/g, '');

                // Redirect direct body insertions into the visualization container without
                // rewriting unrelated global body reads such as classList/style checks.
                safeCode = safeCode.replace(
                    /document\.body\.(appendChild|insertBefore|append|prepend|removeChild)/g,
                    'vizContainer.$1'
                );
                safeCode = safeCode.replace(/document\.body\.querySelectorAll/g, 'vizContainer.querySelectorAll');
                safeCode = safeCode.replace(/document\.body\.querySelector/g, 'vizContainer.querySelector');

                // [SANDBOX FIX] Intercept document.currentScript usage
                safeCode = safeCode.replace(/document\.currentScript\.parentElement/g, 'vizContainer');
                safeCode = safeCode.replace(/document\.currentScript\.parentNode/g, 'vizContainer');
                safeCode = safeCode.replace(/document\.currentScript/g, '({ parentElement: vizContainer, parentNode: vizContainer })');

                // Escape closing script tags instead of deleting them from legitimate strings.
                safeCode = safeCode.replace(/<\/script>/gi, '<\\/script>');

                if (/d3\.select\([^)]*\)\.querySelector(All)?\(/.test(safeCode)) {
                    pushVisualizationDiagnostic(
                        diagnostics,
                        'fatal',
                        'Execution was blocked because unresolved D3 selection misuse remained after preflight repair.'
                    );
                }

                if (diagnostics.some((item) => item.level === 'fatal')) {
                    targetContainer.innerHTML = buildVisualizationDiagnosticHtml(
                        'Visualization preflight blocked execution',
                        diagnostics,
                        'Regenerate the visualization with the updated prompt or use AI code fix for this block.'
                    );
                    return;
                }

                if (diagnostics.length > 0) {
                    trace("System.Render", "viz.preflight.diagnostics", {
                        uniqueId,
                        diagnostics: diagnostics.map((item) => `${item.level}:${item.message}`)
                    });
                }

                // [SCOPE BRIDGE] Export captured functions to the namespaced global object
                let exportCode = '';
                capturedFunctions.forEach(funcName => {
                    exportCode += `\nif (typeof ${funcName} === 'function') { window.vizScopes['${cleanId}']['${funcName}'] = ${funcName}; }`;
                });
                safeCode += exportCode;

                // [LIFECYCLE SANDBOXING] 
                // Override setInterval, setTimeout, requestAnimationFrame with versions that register IDs.
                const lifecycleOverrides = `
                    const setInterval = (fn, delay) => {
                        const id = window.setInterval(fn, delay);
                        window.VizLifecycle.register('${uniqueId}', 'interval', id);
                        return id;
                    };
                    const setTimeout = (fn, delay) => {
                        const id = window.setTimeout(fn, delay);
                        window.VizLifecycle.register('${uniqueId}', 'timer', id);
                        return id;
                    };
                    const requestAnimationFrame = (fn) => {
                        const id = window.requestAnimationFrame(fn);
                        window.VizLifecycle.register('${uniqueId}', 'frame', id);
                        return id;
                    };
                    const ResizeObserver = typeof window.ResizeObserver === 'function'
                        ? function(callback) {
                            const observer = new window.ResizeObserver(callback);
                            window.VizLifecycle.register('${uniqueId}', 'observer', observer);
                            return observer;
                        }
                        : undefined;
                    if (ResizeObserver && window.ResizeObserver && window.ResizeObserver.prototype) {
                        ResizeObserver.prototype = window.ResizeObserver.prototype;
                    }
                    const MutationObserver = typeof window.MutationObserver === 'function'
                        ? function(callback) {
                            const observer = new window.MutationObserver(callback);
                            window.VizLifecycle.register('${uniqueId}', 'observer', observer);
                            return observer;
                        }
                        : undefined;
                    if (MutationObserver && window.MutationObserver && window.MutationObserver.prototype) {
                        MutationObserver.prototype = window.MutationObserver.prototype;
                    }
                    const IntersectionObserver = typeof window.IntersectionObserver === 'function'
                        ? function(callback, options) {
                            const observer = new window.IntersectionObserver(callback, options);
                            window.VizLifecycle.register('${uniqueId}', 'observer', observer);
                            return observer;
                        }
                        : undefined;
                    if (IntersectionObserver && window.IntersectionObserver && window.IntersectionObserver.prototype) {
                        IntersectionObserver.prototype = window.IntersectionObserver.prototype;
                    }
                `;

                // [TEMPLATE LITERAL FIX] Use string concatenation instead of template literals to wrap the code.
                const wrappedCode = 
                    "(function(vizContainer) {\n" + 
                    "    if (!vizContainer) return;\n" +
                    "    const __vizDocument = window.createScopedVisualizationDocument ? window.createScopedVisualizationDocument(vizContainer) : window.document;\n" +
                    "    const document = __vizDocument;\n" +
                    "    const container = vizContainer;\n" +
                    "    const previousOnload = window.onload;\n" +
                    "    const __registerVizCleanup = (cleanupFn) => {\n" +
                    "        if (typeof cleanupFn === 'function' && window.VizLifecycle) {\n" +
                    "            window.VizLifecycle.register('" + uniqueId + "', 'cleanup', cleanupFn);\n" +
                    "        }\n" +
                    "        return cleanupFn;\n" +
                    "    };\n" +
                    "    const __trackedEventListeners = [];\n" +
                    "    const __realWindowAddEventListener = typeof window.addEventListener === 'function' ? window.addEventListener.bind(window) : null;\n" +
                    "    const __realWindowRemoveEventListener = typeof window.removeEventListener === 'function' ? window.removeEventListener.bind(window) : null;\n" +
                    "    const __realDocumentAddEventListener = typeof window.document.addEventListener === 'function' ? window.document.addEventListener.bind(window.document) : null;\n" +
                    "    const __realDocumentRemoveEventListener = typeof window.document.removeEventListener === 'function' ? window.document.removeEventListener.bind(window.document) : null;\n" +
                    "    const __trackEventListener = (addFn, removeFn) => function(type, listener, options) {\n" +
                    "        if (listener && typeof removeFn === 'function') {\n" +
                    "            __trackedEventListeners.push({ type: type, listener: listener, options: options, remove: removeFn });\n" +
                    "        }\n" +
                    "        return typeof addFn === 'function' ? addFn(type, listener, options) : undefined;\n" +
                    "    };\n" +
                    "    const __restoreTrackedTargets = () => {\n" +
                    "        if (__realWindowAddEventListener) window.addEventListener = __realWindowAddEventListener;\n" +
                    "        if (__realWindowRemoveEventListener) window.removeEventListener = __realWindowRemoveEventListener;\n" +
                    "        if (__realDocumentAddEventListener) window.document.addEventListener = __realDocumentAddEventListener;\n" +
                    "        if (__realDocumentRemoveEventListener) window.document.removeEventListener = __realDocumentRemoveEventListener;\n" +
                    "    };\n" +
                    "    if (__realWindowAddEventListener && __realWindowRemoveEventListener) {\n" +
                    "        window.addEventListener = __trackEventListener(__realWindowAddEventListener, __realWindowRemoveEventListener);\n" +
                    "        window.removeEventListener = __realWindowRemoveEventListener;\n" +
                    "    }\n" +
                    "    if (__realDocumentAddEventListener && __realDocumentRemoveEventListener) {\n" +
                    "        window.document.addEventListener = __trackEventListener(__realDocumentAddEventListener, __realDocumentRemoveEventListener);\n" +
                    "        window.document.removeEventListener = __realDocumentRemoveEventListener;\n" +
                    "    }\n" +
                    "    __registerVizCleanup(function() {\n" +
                    "        __trackedEventListeners.forEach(function(entry) {\n" +
                    "            try { entry.remove(entry.type, entry.listener, entry.options); } catch (listenerCleanupError) {}\n" +
                    "        });\n" +
                    "    });\n" +
                    "    try {\n" + 
                         lifecycleOverrides + "\n" +
                    safeCode + "\n" + 
                    "        if (window.onload !== previousOnload && typeof window.onload === 'function') {\n" +
                    "            const pendingOnload = window.onload;\n" +
                    "            window.onload = previousOnload || null;\n" +
                    "            pendingOnload.call(window);\n" +
                    "        }\n" +
                    "    } catch(e) {\n" + 
                    "        console.error('Visualization Runtime Error:', e);\n" + 
                    "        const diagnosticHtml = window.buildVisualizationDiagnosticHtml\n" +
                    "            ? window.buildVisualizationDiagnosticHtml('Visualization runtime error', [{ level: 'error', message: e.message }], 'Use regenerate or AI code fix if the generated script is invalid.')\n" +
                    "            : '<div class=\"bg-red-50\" style=\"color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px; margin-top:10px; border-radius: 4px; font-family: monospace;\"><strong>Runtime Error:</strong> ' + e.message + '</div>';\n" +
                    "        vizContainer.innerHTML += diagnosticHtml;\n" +
                    "    } finally {\n" +
                    "        __restoreTrackedTargets();\n" +
                    "        if (vizContainer && typeof vizContainer._cleanup === 'function') {\n" +
                    "            __registerVizCleanup(vizContainer._cleanup.bind(vizContainer));\n" +
                    "        }\n" +
                    "    }\n" + 
                    "})(document.getElementById('" + uniqueId + "'));";

                const scriptEl = document.createElement('script');
                scriptEl.textContent = wrappedCode;
                document.body.appendChild(scriptEl);
                normalizeVisualizationTextContrast(targetContainer, null);
                const settleFrameHandle = window.requestAnimationFrame(() => {
                    normalizeVisualizationTextContrast(targetContainer, null);
                });
                const settleTimerHandle = window.setTimeout(() => {
                    normalizeVisualizationTextContrast(targetContainer, null);
                }, 96);
                if (window.VizLifecycle) {
                    window.VizLifecycle.register(uniqueId, 'frame', settleFrameHandle);
                    window.VizLifecycle.register(uniqueId, 'timer', settleTimerHandle);
                }
                window.dispatchEvent(new Event('resize'));
                setTimeout(() => scriptEl.remove(), 100);

            } catch (err) {
                console.error("Error executing inline visualization script:", err);
                targetContainer.innerHTML += `<div style="color:red; border:1px solid red; padding:10px;">Script Execution Failed: ${err.message}</div>`;
            }
        }
    }

    const exitCinemaMode = (options = {}) => {
        const activeCinemaHost = cinemaHost;
        vizContentContainer.classList.remove('cinema-mode');
        executionWrapper.classList.remove('cinema-mode-shell');

        if (cinemaBackdropListener && activeCinemaHost) {
            activeCinemaHost.removeEventListener('click', cinemaBackdropListener);
            cinemaBackdropListener = null;
        }

        restoreCinemaShellPosition();

        const previousBodyOverflow = vizContentContainer.dataset.previousBodyOverflow;
        const previousHtmlOverflow = vizContentContainer.dataset.previousHtmlOverflow;
        document.body.style.overflow = previousBodyOverflow !== undefined ? previousBodyOverflow : '';
        document.documentElement.style.overflow = previousHtmlOverflow !== undefined ? previousHtmlOverflow : '';
        delete vizContentContainer.dataset.previousBodyOverflow;
        delete vizContentContainer.dataset.previousHtmlOverflow;

        if (cinemaEscListener) {
            document.removeEventListener('keydown', cinemaEscListener);
            cinemaEscListener = null;
        }
        if (window.__activeVizCinemaExit === exitCinemaMode) {
            delete window.__activeVizCinemaExit;
        }

        containerElement.__exitVizCinema = null;

        if (!options.skipLayoutSync) {
            scheduleVisualizationLayoutSync('cinema-exit');
        }
    };

    containerElement.__exitVizCinema = exitCinemaMode;

    controlsGroup.addEventListener('click', (e) => {
        const button = e.target.closest('.viz-control-btn');
        if (!button) return;

        switch(button.dataset.action) {
            case 'expand':
                if (vizContentContainer.classList.contains('cinema-mode')) {
                    exitCinemaMode();
                } else {
                    if (typeof window.__activeVizCinemaExit === 'function' && window.__activeVizCinemaExit !== exitCinemaMode) {
                        window.__activeVizCinemaExit({ skipLayoutSync: true });
                    }

                    vizContentContainer.dataset.previousBodyOverflow = document.body.style.overflow || '';
                    vizContentContainer.dataset.previousHtmlOverflow = document.documentElement.style.overflow || '';
                    cinemaRestoreMarker = document.createComment(`viz-cinema-restore-${uniqueId}`);
                    if (executionWrapper.parentNode) {
                        executionWrapper.parentNode.replaceChild(cinemaRestoreMarker, executionWrapper);
                    }
                    cinemaHost = createCinemaHost();
                    cinemaHost.appendChild(executionWrapper);
                    document.body.appendChild(cinemaHost);

                    executionWrapper.classList.add('cinema-mode-shell');
                    vizContentContainer.classList.add('cinema-mode');
                    document.body.style.overflow = 'hidden';
                    document.documentElement.style.overflow = 'hidden';
                    scheduleVisualizationLayoutSync('cinema-enter');

                    cinemaEscListener = (ev) => {
                        if (ev.key === 'Escape') {
                            exitCinemaMode();
                        }
                    };
                    document.addEventListener('keydown', cinemaEscListener);

                    cinemaBackdropListener = (ev) => {
                        if (ev.target === cinemaHost || ev.target === executionWrapper) {
                            exitCinemaMode();
                        }
                    };
                    cinemaHost.addEventListener('click', cinemaBackdropListener);
                    window.__activeVizCinemaExit = exitCinemaMode;
                }
                break;
            case 'regenerate':
                if (vizContentContainer.classList.contains('cinema-mode')) {
                    exitCinemaMode({ skipLayoutSync: true });
                }
                if (typeof window.handleRegenerateVisualization === 'function') {
                    window.handleRegenerateVisualization(blockData, containerElement);
                }
                break;
            case 'more':
                createContextMenu(buildVisualizationOverflowItems(blockData, containerElement), e);
                break;
            case 'export':
                const exportItems = [
                    { label: '코드로 복사 (JSON)', action: () => {
                        navigator.clipboard.writeText(JSON.stringify(blockData, null, 2));
                        showToastNotification("✅ 시각화 코드가 복사되었습니다.", "클립보드", `viz-copy-${Date.now()}`);
                    }}
                ];
                createContextMenu(exportItems, e);
                break;
            case 'explain':
                togglePanel(chatPanel, true);
                const prompt = `아래 시각화 자료의 코드를 자세히 설명해줘. 어떤 원리로 작동하는지 알려줘.\n\n\`\`\`html\n${blockData.htmlContent}\n\`\`\``;
                chatInput.value = prompt;
                autoResizeTextarea(chatInput);
                chatInput.focus();
                break;
        }
    });

    requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            void executeDirectVisualization(vizContentContainer);
        });
    });
}

// [MODIFIED] Helper function to fix markdown parsing bugs.
function applyMarkdownFixes(content) {
    if (typeof content !== 'string') return content;
    let fixedContent = content;
    fixedContent = fixedContent.replace(/(\S)(\*\*(?!\s|\*))/g, '$1&zwnj;$2');
    fixedContent = fixedContent.replace(/((?<!\*)\*\*)([a-zA-Z0-9\uAC00-\uD7A3])/g, '$1&zwnj;$2');
    return fixedContent;
}

function renderBlock(block, index) {
    if (!block || !block.type) return null;

    function processInlineContent(content) {
        if (typeof content !== 'string') return '';
        const fixedContent = applyMarkdownFixes(content);
        const katexProcessedContent = renderKatexInString(fixedContent);
        return typeof marked !== 'undefined' ? marked.parseInline(katexProcessedContent, { gfm: true, breaks: true, sanitize: false }) : katexProcessedContent;
    }

    function processBlockContent(content) {
        if (typeof content !== 'string') return '';
        const fixedContent = applyMarkdownFixes(content);
        const katexProcessedContent = renderKatexInString(fixedContent);
        return typeof marked !== 'undefined' ? marked.parse(katexProcessedContent, { gfm: true, breaks: true, sanitize: false }) : katexProcessedContent;
    }

    function renderContentFragments(fragments) {
        if (!Array.isArray(fragments)) return '';
        return fragments.map(fragment => {
            if (typeof fragment === 'string') {
                return processInlineContent(fragment);
            }
            switch (fragment.type) {
                case 'text': return processInlineContent(fragment.text);
                case 'latex': return processInlineContent(fragment.text);
                default: return '';
            }
        }).join('');
    }

    let element;

    switch (block.type) {
        case 'curriculum-map':
            element = document.createElement('div');
            element.className = 'content-section type-curriculum-map';
            element.dataset.blockId = `block-${index}`;
            let curriculumHtml = `<h2>${processInlineContent(block.title || 'Curriculum')}</h2>`;
            if (Array.isArray(block.modules)) {
                block.modules.forEach(module => {
                    curriculumHtml += `<details open class="curriculum-module">`;
                    curriculumHtml += `<summary>${processInlineContent(module.title)}</summary>`;
                    if (Array.isArray(module.subtopics)) {
                        curriculumHtml += `<ul>`;
                        module.subtopics.forEach(topic => {
                            curriculumHtml += `<li>${processInlineContent(topic)}</li>`;
                        });
                        curriculumHtml += `</ul>`;
                    }
                    curriculumHtml += `</details>`;
                });
            }
            element.innerHTML = curriculumHtml;
            return element;

        case 'interactive_map':
            element = document.createElement('div');
            element.className = 'content-section type-interactive-map';
            element.dataset.blockId = `block-${index}`;
            element.dataset.component = "interactive-map";
            element.dataset.lat = block.latitude;
            element.dataset.lng = block.longitude;
            element.dataset.location = block.locationName;
            element.dataset.zoom = block.zoom || 15;
            setTimeout(() => hydrateDOM(element.parentElement), 0);
            return element;

        case 'visualization':
            element = document.createElement('div');
            element.className = 'content-section type-visualization';
            element.dataset.blockId = `block-${index}`;
            element.addEventListener('contextmenu', (event) => {
                event.preventDefault();
                event.stopPropagation();
                const menuItems = [ { label: '이 시각화 자료 제거', action: () => element.remove() } ];
                createContextMenu(menuItems, event);
            });
            if (typeof renderVisualizationBlock === 'function') {
                renderVisualizationBlock(block, element);
            } else {
                element.textContent = '[Error: Visualization renderer not loaded]';
            }
            return element;

        case 'visualization-placeholder':
            element = document.createElement('div');
            element.dataset.component = "visualization-placeholder";
            element.dataset.prompt = block.prompt;
            return element;

        case 'generated-image-placeholder':
            element = document.createElement('div');
            element.dataset.component = "image-placeholder";
            element.dataset.prompt = block.prompt;
            return element;

        case 'main-header':
            element = document.createElement('div');
            element.className = 'header';
            let headerHTML = `<h1>${processInlineContent(block.title)}</h1>`; 
            if (block.subtitle) {
                headerHTML += `<p class="subtitle">${processInlineContent(block.subtitle)}</p>`;
            }
            element.innerHTML = headerHTML;
            return element;

        case 'heading':
        case 'subheading':
            const level = block.level || (block.type === 'subheading' ? 3 : 2);
            element = document.createElement(`h${level}`);
            element.innerHTML = processInlineContent(block.text || '');
            
            const headingSection = document.createElement('div');
            // [MODIFIED] Use 'content-section' only, rely on CSS targeting 'hN' inside.
            // This prevents double borders caused by 'type-heading-hN' class styling.
            headingSection.className = 'content-section'; 
            // Preserve blockId for highlighting logic if needed
            headingSection.dataset.blockId = `block-${index}`;
            headingSection.appendChild(element);
            return headingSection;

        case 'paragraph':
            element = document.createElement('div');
            element.className = 'content-section type-paragraph';
            element.dataset.blockId = `block-${index}`;
            if (Array.isArray(block.content)) {
                element.innerHTML = `<p>${renderContentFragments(block.content)}</p>`;
            } else {
                element.innerHTML = processBlockContent(block.content);
            }
            return element;

        case 'formula':
            element = document.createElement('div');
            element.className = 'content-section type-formula';
            element.dataset.blockId = `block-${index}`;
            const formulaContainer = document.createElement('div');
            formulaContainer.className = 'katex-display';
            try {
                formulaContainer.innerHTML = katex.renderToString(block.latex, { throwOnError: false, displayMode: true });
            } catch (e) {
                formulaContainer.textContent = `[수식 렌더링 오류: ${block.latex}]`;
            }
            element.appendChild(formulaContainer);
            return element;

        case 'blockquote':
            element = document.createElement('div');
            element.className = 'content-section type-blockquote';
            element.dataset.blockId = `block-${index}`;
            element.innerHTML = `<blockquote>${processBlockContent(block.content)}</blockquote>`;
            return element;

        case 'keywords':
            element = document.createElement('div');
            element.className = 'content-section type-key-terms';
            element.dataset.blockId = `block-${index}`;
            const list = block.keywords.map(term => `<span class="keyword-chip">${processInlineContent(term)}</span>`).join('');
            element.innerHTML = `<div class="keyword-list">${list}</div>`;
            return element;

        case 'list':
        case 'ordered-list':
        case 'unordered-list':
            element = document.createElement('div');
            element.className = 'content-section type-list';
            element.dataset.blockId = `block-${index}`;
            let listType = 'ul';
            if (block.style === 'ordered' || block.type === 'ordered-list') listType = 'ol';
            const listItems = block.items.map(item => `<li>${typeof item === 'string' ? processInlineContent(item) : renderContentFragments(item.content)}</li>`).join('');
            element.innerHTML = `<${listType}>${listItems}</${listType}>`;
            return element;

        case 'definition-list':
            element = document.createElement('div');
            element.className = 'content-section type-definition-list';
            element.dataset.blockId = `block-${index}`;
            const defItems = block.items.map(item => `<li><strong>${processInlineContent(item.term)}:</strong> ${processInlineContent(item.definition)}</li>`).join('');
            element.innerHTML = `<ul>${defItems}</ul>`;
            return element;

        case 'horizontal-rule':
            element = document.createElement('div');
            element.className = 'content-section type-hr';
            element.dataset.blockId = `block-${index}`;
            element.appendChild(document.createElement('hr'));
            return element;

        case 'summary':
            element = document.createElement('div');
            element.className = 'content-section type-summary';
            element.dataset.blockId = `block-${index}`;
            element.innerHTML = `<h3><strong>${processInlineContent(block.title)}</strong></h3><div>${processBlockContent(block.content)}</div>`;
            return element;

        case 'status_dashboard':
            element = document.createElement('div');
            element.className = 'content-section type-status-dashboard';
            element.dataset.blockId = `block-${index}`;
            const dashboard = document.createElement('div');
            dashboard.className = 'status-dashboard';
            if (Array.isArray(block.modules)) {
                block.modules.forEach(module => {
                    const moduleElement = document.createElement('div');
                    moduleElement.className = 'status-module';
                    let headerHTML = `<h4><span>${module.icon || ''}</span> ${processInlineContent(module.title || '')}</h4>`;
                    if (module.event_name) {
                        moduleElement.style.gridColumn = '1 / -1';
                        let displayTitle = processInlineContent(module.title);
                        if (module.event_name && module.event_name !== module.title) {
                             displayTitle += `: ${processInlineContent(module.event_name)}`;
                        }
                        headerHTML = `<h4><span>${module.icon || ''}</span> ${displayTitle}</h4>`;
                        moduleElement.innerHTML = `${headerHTML}<div class="progress-bar-container"><div class="progress-bar" style="width: ${module.progress_percent || 0}%;"></div></div><span class="progress-percent-text">${module.progress_percent || 0}%</span>`;
                    } else if (module.scan_table_markdown) {
                        moduleElement.classList.add('scan-table-module');
                        moduleElement.style.gridColumn = '1 / -1';
                        moduleElement.innerHTML = headerHTML + processBlockContent(module.scan_table_markdown);
                    } else if (Array.isArray(module.items)) {
                        const itemsHTML = module.items.map(item => `<li><span class="term">${processInlineContent(item.term)}</span><span class="definition">${processInlineContent(item.definition)}</span></li>`).join('');
                        moduleElement.innerHTML = `${headerHTML}<ul>${itemsHTML}</ul>`;
                    }
                    dashboard.appendChild(moduleElement);
                });
            }
            element.appendChild(dashboard);
            return element;

        default:
            console.warn(`Unknown block type: ${block.type}`);
            return null;
    }
}

function initializeDynamicContentListeners(containerElement) {
    if (!containerElement) return;

    containerElement.addEventListener('contextmenu', (event) => {
        const targetElement = event.target;
        const vizErrorBlock = targetElement.closest('.type-visualization-error');
        
        if (vizErrorBlock) {
            event.preventDefault();
            event.stopPropagation();
            const replacementTarget = vizErrorBlock.closest('.type-visualization, .type-visualization-placeholder');

            if (replacementTarget) {
                let blockData = {};
                if (replacementTarget.dataset.blockData) {
                    try { blockData = JSON.parse(replacementTarget.dataset.blockData); } catch (e) { console.warn("Could not parse block data", e); }
                } else if (replacementTarget.dataset.prompt) {
                    blockData = { type: 'visualization-placeholder', prompt: replacementTarget.dataset.prompt };
                }

                const menuItems = [
                    { label: '다시 생성', action: () => {
                        if (blockData?.htmlContent && typeof window.handleRegenerateVisualization === 'function') {
                            window.handleRegenerateVisualization(blockData, replacementTarget);
                            return;
                        }
                        if (typeof window._generateAndPlaceVisualization === 'function') {
                            const options = blockData?.generationOptions || {};
                            if (!options.description) {
                                options.description = blockData?.originalPrompt || blockData?.prompt || replacementTarget.dataset.prompt || '';
                            }
                            window._generateAndPlaceVisualization(options, replacementTarget, true, blockData?.noteId || null);
                        }
                    }},
                    { label: '이 시각화 영역 제거', action: () => replacementTarget.remove() },
                    { label: 'AI로 코드 수정', action: () => handleCodeFixRequest(blockData, replacementTarget) }
                ];
                createContextMenu(menuItems, event);
            } else {
                createContextMenu([{ label: '이 오류 메시지 제거', action: () => vizErrorBlock.remove() }], event);
            }
            return;
        }

        if (targetElement.closest('.type-generated-image, .type-visualization, .type-visualization-placeholder')) return;
        return;
        
        event.preventDefault();
        const targetBlock = targetElement.closest('.content-section');
        const menuItems = [
            { label: '🎨 이미지 자료 추가', action: () => {
                const placeholder = document.createElement('div');
                placeholder.dataset.component = "image-placeholder";
                placeholder.dataset.prompt = "";
                targetBlock ? targetBlock.after(placeholder) : targetElement.after(placeholder);
                hydrateDOM(placeholder.parentElement);
            }},
            { label: '📊 시각화 자료 추가', action: () => {
                const placeholder = document.createElement('div');
                placeholder.dataset.component = "visualization-placeholder";
                placeholder.dataset.prompt = "";
                targetBlock ? targetBlock.after(placeholder) : targetElement.after(placeholder);
                hydrateDOM(placeholder.parentElement);
            }}
        ];
        createContextMenu(menuItems, event);
    });

    containerElement.querySelectorAll('.content-section').forEach(section => {
        const blockType = Array.from(section.classList).find(c => c.startsWith('type-'))?.replace('type-', '');
        const nonVisualizableTypes = ['main-header', 'hr', 'status-dashboard', 'visualization', 'generated-image-placeholder', 'interactive-map', 'heading', 'subheading', 'curriculum-map'];
        if (blockType && !nonVisualizableTypes.includes(blockType) && !section.querySelector('.viz-hover-btn')) {
             const vizButton = document.createElement('button');
             vizButton.className = 'viz-hover-btn';
             vizButton.title = '이 내용으로 시각화 자료 생성';
             vizButton.innerHTML = `📊`;
             section.appendChild(vizButton);
             vizButton.addEventListener('click', (e) => {
                 e.stopPropagation();
                 const textToVisualize = section.innerText.replace(/\n📊$/, '').trim();
                 const noteId = section.closest('#recall-content-area')?.dataset.noteId;
                 handleAddVisualization(textToVisualize, section, noteId);
             });
        }
    });

    containerElement.querySelectorAll('.content-section').forEach(section => {
        const blockType = Array.from(section.classList).find(c => c.startsWith('type-'))?.replace('type-', '');
        const nonImageableTypes = ['main-header', 'hr', 'status-dashboard', 'visualization', 'generated-image-placeholder', 'interactive-map', 'heading', 'subheading', 'formula', 'keywords', 'curriculum-map'];
        if (blockType && !nonImageableTypes.includes(blockType) && !section.querySelector('.img-gen-hover-btn')) {
             const imgGenButton = document.createElement('button');
             imgGenButton.className = 'img-gen-hover-btn';
             imgGenButton.title = '이 문단으로 장면 이미지화';
             imgGenButton.innerHTML = `🎨`;
             section.appendChild(imgGenButton);
             imgGenButton.addEventListener('click', (e) => {
                 e.stopPropagation();
                 const textToGenerate = section.innerText.replace(/\n[🎨📊]$/, '').trim();
                 if (typeof openImageGenerationOptionsModal === 'function') {
                    openImageGenerationOptionsModal(textToGenerate, section);
                 }
             });
        }
    });
}
