
/* --- Ailey & Bailey Canvas --- */
// File: 130_core_archiver.js
// Version: 9.5 (Chunk Size Default Change)
// Description: Changed ARCHIVE_CHUNK_SIZE from 10 to 1. This ensures that by default, every narrative turn creates a new, separate note file instead of accumulating in a single note, aligning with user expectations for granular archiving.

const ARCHIVE_CHUNK_SIZE = 1;

/**
 * Helper to convert innerHTML to Markdown, preserving bold/italic tags, links, and line breaks.
 */
function _processHtmlTextToMarkdown(element) {
    if (!element) return '';
    let html = element.innerHTML;
    
    // [NEW] Preserve <mark> tags (Highlighter)
    html = html.replace(/<mark>(.*?)<\/mark>/gi, '___MARK_START___$1___MARK_END___');

    // Preserve Bold
    html = html.replace(/<strong>(.*?)<\/strong>/gi, '**$1**');
    html = html.replace(/<b>(.*?)<\/b>/gi, '**$1**');
    
    // [NEW] Preserve Italics/Emphasis
    html = html.replace(/<em>(.*?)<\/em>/gi, '*$1*');
    html = html.replace(/<i>(.*?)<\/i>/gi, '*$1*');
    
    // Preserve Links
    // Matches <a ... href="...">text</a> and converts to [text](href)
    html = html.replace(/<a\s+(?:[^>]*?\s+)?href="([^"]*)"(?:[^>]*?)?>(.*?)<\/a>/gi, '[$2]($1)');
    
    // Convert <br> to newlines to preserve formatting
    html = html.replace(/<br\s*\/?>/gi, '\n');

    // Decode HTML entities (e.g., &lt; to <) using a temporary textarea
    const txt = document.createElement("textarea");
    txt.innerHTML = html;
    let decoded = txt.value;
    
    // Strip any remaining HTML tags (like <p>, <span>, <div> etc.)
    decoded = decoded.replace(/<[^>]+>/g, '');
    
    // [NEW] Restore <mark> tags
    decoded = decoded.replace(/___MARK_START___/g, '<mark>').replace(/___MARK_END___/g, '</mark>');
    
    return decoded.trim();
}

/**
 * [NARRATIVE-ONLY] Formats the snapshot data from a narrative payload into a structured Markdown string.
 * @param {object} payload - The archivePayload object from a narrative turn.
 * @returns {string} A formatted Markdown string representing the turn's snapshot.
 */
function formatNarrativeSnapshot(payload) {
    const { turn, snapshot } = payload;
    if (!snapshot) return '';

    const stripHtml = (html) => {
        if (!html) return '';
        const doc = new DOMParser().parseFromString(html, 'text/html');
        return doc.body.textContent || "";
    };

    let md = `\n\n## [턴 ${turn}]\n\n`;

    if (snapshot.mainTitle) md += `### @mainTitle: ${snapshot.mainTitle}\n\n`;
    if (snapshot.mainSubtitle) md += `### @mainSubtitle: ${snapshot.mainSubtitle}\n\n`;
    if (snapshot.headingText) md += `### @heading: ${snapshot.headingText}\n\n`;
    if (snapshot.userChoice) md += `### 사용자 선택\n> ${snapshot.userChoice}\n\n---\n\n`;
    if (snapshot.interactiveMap) md += `<!-- MAP_DATA:${JSON.stringify(snapshot.interactiveMap)} -->\n\n`;
    if (snapshot.narrative) md += `### 생성된 서사\n${snapshot.narrative.trim()}\n\n---\n\n`;
    if (snapshot.statusDashboard && snapshot.statusDashboard.length > 0) {
        md += `### 상태 정보\n`;
        snapshot.statusDashboard.forEach(module => {
            if (module.scan_table_markdown || !module.title) {} 
            else if (module.event_name) md += `**${stripHtml(module.title)}:** ${stripHtml(module.event_name)} (${module.progress_percent}%)\n\n`;
            else if (module.items && module.items.length > 0) {
                md += `**${stripHtml(module.title)}**\n`;
                module.items.forEach(item => { md += `- **${stripHtml(item.term)}:** ${stripHtml(item.definition)}\n`; });
                md += `\n`;
            }
        });
        md += `---\n\n`;
    }
    if (snapshot.scanTable) md += `### 주변 탐색\n${snapshot.scanTable.trim()}\n\n---\n\n`;
    if (snapshot.presentedChoices && snapshot.presentedChoices.length > 0) {
        md += `### 제시된 선택지\n`;
        snapshot.presentedChoices.forEach((choice, index) => { md += `${index + 1}. ${choice}\n`; });
        md += `\n`;
    }
    return md;
}

/**
 * [LEARNING-ONLY] Converts content blocks from a learning canvas into a simple Markdown string for archiving.
 * @returns {string} A Markdown representation of the current learning canvas.
 */
function buildMarkdownFromContentBlocks() {
    if (!currentDataPayload || !currentDataPayload.contentBlocks) return '';

    return currentDataPayload.contentBlocks.map(block => {
        switch (block.type) {
            case 'main-header': return `# ${block.title}\n*${block.subtitle}*\n`;
            case 'heading': return `\n### ${block.text}\n`;
            case 'paragraph': return block.content + '\n';
            case 'blockquote': return block.content.split('\n').map(l => `> ${l}`).join('\n') + '\n';
            case 'keywords': return `**키워드:** ${block.keywords.join(', ')}\n`;
            case 'ordered-list': return block.items.map((item, i) => `${i + 1}. ${item}`).join('\n') + '\n';
            case 'unordered-list': return block.items.map(item => `- ${item}`).join('\n') + '\n';
            case 'summary': return `\n**${block.title}**\n${block.content}\n`;
            case 'horizontal-rule': return '\n---\n';
            case 'curriculum-map':
                // Embed the block data as a JSON comment to preserve its structure perfectly.
                return `<!-- CURRICULUM_DATA:${JSON.stringify(block)} -->\n`;
            default: return '';
        }
    }).join('\n');
}


/**
 * Dynamically builds the snapshot object by analyzing the contentBlocks from the payload.
 * This is used for narrative turns to extract implicit data from the rendered content.
 * @returns {object} A snapshot object containing main title, narrative, dashboard, scan table, and choices.
 */
function buildSnapshotFromContentBlocks() {
    const contentBlocks = currentDataPayload.contentBlocks || [];
    const snapshot = {
        mainTitle: '',
        mainSubtitle: '',
        headingText: '',
        narrative: '',
        statusDashboard: null,
        scanTable: '',
        presentedChoices: [],
        interactiveMap: null
    };

    const narrativeParts = [];
    for(const block of contentBlocks) {
        if (block.type === 'main-header') {
            snapshot.mainTitle = block.title;
            snapshot.mainSubtitle = block.subtitle;
        } else if (block.type === 'heading') {
            snapshot.headingText = block.text;
        } else if (block.type === 'paragraph') {
            const content = block.content || '';
            if (!content.startsWith('[SYSTEM]') && !content.startsWith('[Singulari-Tea Codex]')) {
                narrativeParts.push(content);
            }
        } else if (block.type === 'blockquote') {
            const content = block.content || '';
            if (content) {
                const markdownBlockquote = content.split('\n').map(line => `> ${line}`).join('\n');
                narrativeParts.push(markdownBlockquote);
            }
        } else if (block.type === 'status_dashboard' && block.modules) {
            snapshot.statusDashboard = block.modules;
            const scanModule = block.modules.find(m => m.scan_table_markdown);
            if (scanModule) {
                snapshot.scanTable = scanModule.scan_table_markdown;
            }
        } else if (block.type === 'ordered-list') {
            snapshot.presentedChoices = block.items || [];
        } else if (block.type === 'interactive_map') {
            snapshot.interactiveMap = {
                locationName: block.locationName,
                latitude: block.latitude,
                longitude: block.longitude
            };
        }
    }
    
    snapshot.narrative = narrativeParts.join('\n\n').trim();

    return snapshot;
}

/**
 * [NEW] Parses a raw HTML string into Markdown format for archiving.
 * Uses recursive traversal to handle mixed content types and nested headers correctly.
 * @param {string} htmlString - The raw HTML content string.
 * @returns {string} Converted Markdown.
 */
function convertHtmlToMarkdown(htmlString) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlString, 'text/html');
    const container = doc.body;
    const exportedTemplate = doc.getElementById('exported-content');
    const exportedTemplateRoot = exportedTemplate?.content?.querySelector('#learning-content')
        || exportedTemplate?.content?.querySelector('#ai-content-placeholder')
        || exportedTemplate?.content?.querySelector('main')
        || null;
    const contentRoot =
        exportedTemplateRoot
        || doc.getElementById('learning-content')
        || doc.getElementById('ai-content-placeholder')
        || container.querySelector('.wrapper .container')
        || container.querySelector('main')
        || container;

    let markdown = '';
    const normalizeMarkdown = (value) => value
        .replace(/[ \t]+\n/g, '\n')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
    const appendBlock = (value) => {
        const cleanValue = (value || '').trim();
        if (cleanValue) markdown += `${cleanValue}\n\n`;
    };

    const processLegacyNode = (node) => {
        if (node.nodeType === Node.TEXT_NODE) {
            const text = node.nodeValue.trim();
            if (text) appendBlock(text);
            return;
        }

        if (node.nodeType !== Node.ELEMENT_NODE) return;

        const tagName = node.tagName.toLowerCase();

        if (tagName === 'div' && node.classList.contains('rich-text-content')) {
            appendBlock(_processHtmlTextToMarkdown(node));
            return;
        }

        if (tagName === 'h2') {
            appendBlock(`## ${node.textContent.trim()}`);
        } else if (tagName === 'h3') {
            appendBlock(`### ${node.textContent.trim()}`);
        } else if (tagName === 'p') {
            if (!node.classList.contains('subtitle') && !node.parentElement?.classList.contains('placeholder-content')) {
                appendBlock(_processHtmlTextToMarkdown(node));
            }
        } else if (tagName === 'blockquote') {
            appendBlock(node.textContent.trim().split('\n').map(line => `> ${line.trim()}`).join('\n'));
        } else if (tagName === 'ul') {
            appendBlock(Array.from(node.children)
                .filter(child => child.tagName?.toLowerCase() === 'li')
                .map(li => `- ${_processHtmlTextToMarkdown(li)}`)
                .join('\n'));
        } else if (tagName === 'ol') {
            appendBlock(Array.from(node.children)
                .filter(child => child.tagName?.toLowerCase() === 'li')
                .map((li, index) => `${index + 1}. ${_processHtmlTextToMarkdown(li)}`)
                .join('\n'));
        } else if (tagName === 'div' && node.classList.contains('math-latex-display')) {
            appendBlock(`$$\n${node.textContent.trim().replace(/^\$\$|\$\$$/g, '')}\n$$`);
        } else if (tagName === 'hr') {
            appendBlock('---');
        } else if (tagName === 'div' || tagName === 'section') {
            Array.from(node.childNodes).forEach(child => processLegacyNode(child));
        }
    };

    const legacyChildren = Array.from(contentRoot.querySelectorAll('.header, .content-section'));
    legacyChildren.forEach(el => {
        if (el.classList.contains('header')) {
            const title = el.querySelector('h1')?.textContent?.trim() || '';
            const subtitle = el.querySelector('.subtitle')?.textContent?.trim() || '';
            appendBlock(`# ${title}\n*${subtitle}*`);
            return;
        }

        if (el.classList.contains('type-key-terms')) {
            const chips = Array.from(el.querySelectorAll('.keyword-chip')).map(c => c.textContent.trim());
            if (chips.length > 0) appendBlock(`**키워드:** ${chips.join(', ')}`);
            return;
        }

        if (el.classList.contains('type-summary')) {
            const title = el.querySelector('h3')?.textContent?.trim() || '요약';
            const listItems = el.querySelectorAll('li');
            const content = listItems.length > 0
                ? Array.from(listItems).map(li => `- ${li.textContent.trim()}`).join('\n')
                : (el.querySelector('div')?.textContent?.trim() || '');
            appendBlock(`**${title}**\n${content}`);
            return;
        }

        if (el.classList.contains('type-curriculum-map')) {
            const mainTitle = el.querySelector('h2')?.textContent?.trim() || 'Curriculum';
            let curriculumMarkdown = `### ${mainTitle}\n`;
            el.querySelectorAll('details').forEach(det => {
                const summary = det.querySelector('summary')?.textContent?.trim();
                if (summary) curriculumMarkdown += `\n- **${summary}**\n`;
                det.querySelectorAll('li').forEach(li => {
                    curriculumMarkdown += `  - ${li.textContent.trim()}\n`;
                });
            });
            appendBlock(curriculumMarkdown);
            return;
        }

        Array.from(el.childNodes).forEach(child => processLegacyNode(child));
    });

    if (normalizeMarkdown(markdown)) {
        return normalizeMarkdown(markdown);
    }

    markdown = '';
    const structuralGenericTags = new Set(['article', 'section', 'div', 'figure', 'aside']);
    const hasStructuralChildren = (node) => Array.from(node.children || []).some((child) => {
        if (!child?.tagName) return false;
        const childTag = child.tagName.toLowerCase();
        if (structuralGenericTags.has(childTag)) return true;
        return /^(h[1-6]|p|ul|ol|blockquote|table|details|hr)$/.test(childTag);
    });

    const tableToMarkdown = (tableNode) => {
        const rows = Array.from(tableNode.querySelectorAll('tr'));
        if (!rows.length) return '';

        const extractCells = (row, selector) => Array.from(row.querySelectorAll(selector))
            .map((cell) => _processHtmlTextToMarkdown(cell))
            .filter(Boolean);

        const headerCells = extractCells(rows[0], 'th');
        const bodyRows = [];

        if (headerCells.length) {
            rows.slice(1).forEach((row) => {
                const cells = extractCells(row, 'td, th');
                if (cells.length) bodyRows.push(cells);
            });

            if (!bodyRows.length) return '';
            return [
                `| ${headerCells.join(' | ')} |`,
                `| ${headerCells.map(() => ':---').join(' | ')} |`,
                ...bodyRows.map((cells) => `| ${cells.join(' | ')} |`)
            ].join('\n');
        }

        rows.forEach((row) => {
            const cells = extractCells(row, 'td, th');
            if (cells.length) bodyRows.push(cells);
        });
        return bodyRows.map((cells) => `- ${cells.join(' | ')}`).join('\n');
    };

    const shouldIgnoreGenericNode = (node) => {
        if (!node) return false;
        if (node.nodeType === Node.TEXT_NODE) return !node.nodeValue.trim();
        if (node.nodeType !== Node.ELEMENT_NODE) return true;
        if (node.matches('script, style, noscript, canvas, svg, video, audio, iframe, button, input, textarea, select, option, template')) return true;
        if (node.matches('[data-component="image-placeholder"], [data-component="visualization-placeholder"]')) return true;
        if (node.matches('.placeholder-content, .message-toolbar, .toolbar-button, .message-inline-actions, .message-inline-action-button, .viz-controls-group')) return true;
        return node.classList.contains('placeholder-content')
            || node.classList.contains('type-visualization')
            || node.classList.contains('type-visualization-placeholder')
            || node.classList.contains('viz-scene-block')
            || node.classList.contains('type-generated-image')
            || node.classList.contains('type-generated-image-placeholder')
            || node.classList.contains('message-inline-actions')
            || node.classList.contains('message-meta-row');
    };

    const processGenericNode = (node) => {
        if (!node || shouldIgnoreGenericNode(node)) return;
        if (node.nodeType === Node.TEXT_NODE) {
            appendBlock(node.nodeValue.replace(/\s+/g, ' ').trim());
            return;
        }
        if (node.nodeType !== Node.ELEMENT_NODE) return;

        const tagName = node.tagName.toLowerCase();

        if (tagName === 'div' && node.classList.contains('rich-text-content')) {
            appendBlock(_processHtmlTextToMarkdown(node));
            return;
        }

        if (tagName === 'h1') return appendBlock(`# ${node.textContent.trim()}`);
        if (tagName === 'h2') return appendBlock(`## ${node.textContent.trim()}`);
        if (tagName === 'h3') return appendBlock(`### ${node.textContent.trim()}`);
        if (tagName === 'h4') return appendBlock(`#### ${node.textContent.trim()}`);
        if (tagName === 'p' || tagName === 'figcaption') return appendBlock(_processHtmlTextToMarkdown(node));
        if (tagName === 'blockquote') return appendBlock(node.textContent.trim().split('\n').map(line => `> ${line.trim()}`).join('\n'));
        if (tagName === 'ul') {
            return appendBlock(Array.from(node.children)
                .filter(child => child.tagName?.toLowerCase() === 'li')
                .map(li => `- ${_processHtmlTextToMarkdown(li)}`)
                .join('\n'));
        }
        if (tagName === 'ol') {
            return appendBlock(Array.from(node.children)
                .filter(child => child.tagName?.toLowerCase() === 'li')
                .map((li, index) => `${index + 1}. ${_processHtmlTextToMarkdown(li)}`)
                .join('\n'));
        }
        if (tagName === 'table') {
            return appendBlock(tableToMarkdown(node));
        }
        if (tagName === 'hr') return appendBlock('---');
        if (tagName === 'details') {
            const summary = node.querySelector('summary')?.textContent?.trim();
            if (summary) appendBlock(`### ${summary}`);
        }

        if ((structuralGenericTags.has(tagName) || tagName === 'span' || tagName === 'figcaption') && !hasStructuralChildren(node)) {
            const text = _processHtmlTextToMarkdown(node);
            if (text) {
                appendBlock(text);
                return;
            }
        }

        Array.from(node.childNodes).forEach(child => processGenericNode(child));
    };

    Array.from(contentRoot.childNodes).forEach(child => processGenericNode(child));
    if (!normalizeMarkdown(markdown)) {
        processGenericNode(contentRoot);
    }

    return normalizeMarkdown(markdown);
}

// Helper to convert HTML DOM to the specific Narrative Snapshot Markdown format
function _convertHtmlToNarrativeSnapshot(doc, turnNumber) {
    let md = `\n\n## [턴 ${turnNumber}]\n\n`;

    // 1. Headers
    const headerDiv = doc.querySelector('.header');
    if (headerDiv) {
        const h1 = headerDiv.querySelector('h1');
        const pSub = headerDiv.querySelector('.subtitle');
        if (h1) md += `### @mainTitle: ${h1.textContent.trim()}\n`;
        if (pSub) md += `### @mainSubtitle: ${pSub.textContent.trim()}\n`;
        md += `\n`;
    }

    // 2. Narrative & Headings extraction
    let narrativeText = "";
    let headingText = ""; // [NEW] To capture specific scene heading

    const contentSections = doc.querySelectorAll('.content-section');
    
    // Components to exclude from narrative body
    const ignoredComponents = [
        'type-status-dashboard',
        'type-ordered-list',
        'type-interactive-map',
        'type-generated-image', // Replaced placeholder with generated image
        'type-generated-image-placeholder',
        'type-visualization',
        'type-visualization-placeholder',
        'type-hr'
    ];

    // Recursive processor for narrative text extraction
    const processNarrativeNode = (node) => {
        const tagName = node.tagName ? node.tagName.toUpperCase() : 'TEXT';
        
        if (tagName === 'TEXT') {
             const text = node.nodeValue.trim();
             if (text) narrativeText += text + "\n\n";
        }
        else if (tagName === 'P') {
            if (node.classList.contains('subtitle')) return; // Skip header subtitles
            narrativeText += _processHtmlTextToMarkdown(node) + "\n\n";
        } 
        else if (tagName === 'BLOCKQUOTE') {
            const rawText = _processHtmlTextToMarkdown(node);
            narrativeText += "> " + rawText.split('\n').map(line => line.trim()).join('\n> ') + "\n\n";
        }
        else if (/^H[1-6]$/.test(tagName)) {
            const level = parseInt(tagName.substring(1));
            // Align heading levels: H2 -> ##, H3 -> ###
            narrativeText += `${'#'.repeat(level)} ${_processHtmlTextToMarkdown(node)}\n\n`;
        }
        else if (tagName === 'UL') {
            Array.from(node.querySelectorAll('li')).forEach(li => { narrativeText += `- ${_processHtmlTextToMarkdown(li)}\n`; });
            narrativeText += "\n";
        }
        else if (tagName === 'OL') {
            Array.from(node.querySelectorAll('li')).forEach((li, idx) => { narrativeText += `${idx + 1}. ${_processHtmlTextToMarkdown(li)}\n`; });
            narrativeText += "\n";
        }
        else if (tagName === 'DIV') {
            // [CRITICAL FIX] Handle rich-text-content specifically for narrative too
            if (node.classList.contains('rich-text-content')) {
                narrativeText += _processHtmlTextToMarkdown(node) + "\n\n";
            } else {
                // Recurse or handle plain text
                if (node.childNodes.length > 0) {
                    Array.from(node.childNodes).forEach(child => processNarrativeNode(child));
                } else if (node.innerText.trim()) {
                    narrativeText += _processHtmlTextToMarkdown(node) + "\n\n";
                }
            }
        }
    };

    contentSections.forEach(section => {
        // [NEW] Explicitly capture the H2 heading block from Raw HTML structure
        if (section.classList.contains('type-heading-h2')) {
            headingText = section.textContent.trim();
            return; // Don't add this to narrative text
        }

        // Exclusion Logic
        const isIgnored = ignoredComponents.some(cls => section.classList.contains(cls)) || section.dataset.component;
        if (isIgnored) return;
        if (section.innerText.includes('[SYSTEM]')) return;

        // Traverse children using the recursive processor
        Array.from(section.childNodes).forEach(child => processNarrativeNode(child));
    });
    
    // [NEW] Insert the captured heading into metadata
    if (headingText) {
        md += `### @heading: ${headingText}\n\n`;
    } else {
        // Fallback if no heading found
        md += `### @heading: **현재 상황**\n\n`;
    }

    // Append Map Data if present
    const mapSection = doc.querySelector('.content-section[data-component="interactive-map"]');
    if (mapSection) {
         const mapData = {
            locationName: mapSection.dataset.location,
            latitude: parseFloat(mapSection.dataset.lat),
            longitude: parseFloat(mapSection.dataset.lng)
         };
         md += `<!-- MAP_DATA:${JSON.stringify(mapData)} -->\n\n`;
    }
    
    if (narrativeText) {
        md += `### 생성된 서사\n${narrativeText.trim()}\n\n---\n\n`;
    }

    // 3. Status Dashboard (JSON Source Logic)
    const jsonBlock = doc.querySelector('#dashboard-json-data');
    if (jsonBlock) {
        try {
            const data = JSON.parse(jsonBlock.textContent.trim());
            md += `### 상태 정보\n`;
            
            if (data.core && Array.isArray(data.core)) {
                data.core.forEach(mod => {
                    const title = mod.t || 'Info';
                    md += `**${title}**\n`;
                    if (mod.d && Array.isArray(mod.d)) {
                        mod.d.forEach(item => {
                            const val = item.v.replace(/<a[^>]*>(.*?)<\/a>/g, '$1'); 
                            md += `- **${item.k}:** ${val}\n`;
                        });
                    }
                    md += `\n`;
                });
            }
            
            if (data.event) {
                md += `**${data.event.t}**\n`;
                md += `- **진행도:** ${data.event.p}%\n\n`;
            }
            
            md += `---\n\n`;
            
            if (data.scan && data.scan.rows) {
                md += `### 주변 탐색\n`;
                const rows = data.scan.rows;
                if (rows.length > 0) {
                    md += `| ${rows[0].join(' | ')} |\n`;
                    md += `| ${rows[0].map(() => ':---').join(' | ')} |\n`;
                    for (let i = 1; i < rows.length; i++) {
                        md += `| ${rows[i].join(' | ')} |\n`;
                    }
                }
                md += `\n---\n\n`;
            }
            
        } catch (e) {
            console.error("Archiver: Failed to parse dashboard JSON", e);
        }
    } else {
        // [FALLBACK] Visual Scraping Logic
        const dashboard = doc.querySelector('.status-dashboard');
        if (dashboard) {
            md += `### 상태 정보\n`;
            const modules = dashboard.querySelectorAll('.status-module');
            modules.forEach(mod => {
                if (mod.classList.contains('scan-table-module')) return;

                const titleEl = mod.querySelector('h4');
                let title = "";
                if (titleEl) {
                    title = titleEl.textContent.trim();
                }

                const progressBar = mod.querySelector('.progress-bar-container');
                if (progressBar) {
                    const percentText = mod.querySelector('.progress-percent-text')?.textContent.replace('%', '') || "0";
                    md += `**${title}**\n`;
                    md += `- **진행도:** ${percentText}%\n\n`;
                } else {
                    md += `**${title}**\n`;
                    const lis = mod.querySelectorAll('li');
                    lis.forEach(li => {
                        const term = li.querySelector('.term')?.textContent.trim();
                        const defEl = li.querySelector('.definition');
                        const def = defEl ? _processHtmlTextToMarkdown(defEl) : '';
                        if (term && def) {
                            md += `- **${term}:** ${def}\n`;
                        }
                    });
                    md += `\n`;
                }
            });
            md += `---\n\n`;
        }

        // 4. Scan Table (Visual Scraping Fallback)
        const scanModule = doc.querySelector('.scan-table-module');
        if (scanModule) {
            md += `### 주변 탐색\n`;
            const table = scanModule.querySelector('table');
            if (table) {
                const rows = Array.from(table.querySelectorAll('tr'));
                if (rows.length > 0) {
                    const headers = Array.from(rows[0].querySelectorAll('th')).map(th => th.textContent.trim());
                    md += `| ${headers.join(' | ')} |\n`;
                    md += `| ${headers.map(() => ':---').join(' | ')} |\n`;
                    for (let i = 1; i < rows.length; i++) {
                        const cols = Array.from(rows[i].querySelectorAll('td')).map(td => _processHtmlTextToMarkdown(td));
                        md += `| ${cols.join(' | ')} |\n`;
                    }
                }
            }
            md += `\n---\n\n`;
        }
    }

    // 5. Choices
    const choicesDiv = doc.querySelector('.type-ordered-list ol');
    if (choicesDiv) {
        md += `### 제시된 선택지\n`;
        const lis = choicesDiv.querySelectorAll('li');
        lis.forEach((li, idx) => {
            md += `${idx + 1}. ${_processHtmlTextToMarkdown(li)}\n`;
        });
        md += `\n`;
    }

    return md;
}

async function handleHtmlSourceArchiving(payload) {
    const { rawHtml, canvasId, title } = payload;
    trace("Archiver", "handleHtml.start", { canvasId });

    const parser = new DOMParser();
    const doc = parser.parseFromString(rawHtml, 'text/html');
    
    // Find metadata element (root wrapper or placeholder)
    const metadataElement = doc.querySelector('.canvas-content') || doc.querySelector('[data-subject]') || doc.getElementById('ai-content-placeholder');

    let subjectName = '일반 학습';
    let conceptName = title || '무제 개념';
    let turnNumber = null;

    if (metadataElement) {
        if (metadataElement.dataset.subject) subjectName = metadataElement.dataset.subject;
        if (metadataElement.dataset.concept) conceptName = metadataElement.dataset.concept;
        if (metadataElement.dataset.turn) turnNumber = parseInt(metadataElement.dataset.turn, 10);
    } else {
        // Fallback regex extraction
        const subjectMatch = rawHtml.match(/data-subject=["'](.*?)["']/i);
        const conceptMatch = rawHtml.match(/data-concept=["'](.*?)["']/i);
        const turnMatch = rawHtml.match(/data-turn=["'](\d+)["']/i);
        
        if (subjectMatch) subjectName = subjectMatch[1];
        if (conceptMatch) conceptName = conceptMatch[1];
        if (turnMatch) turnNumber = parseInt(turnMatch[1], 10);
    }
    
    subjectName = subjectName.trim();
    conceptName = conceptName.trim();

    // LOGIC SPLIT: Narrative vs Learning
    if (turnNumber) {
        // --- NARRATIVE ARCHIVING PATH ---
        trace("Archiver", "handleHtml.narrative", { subject: subjectName, turn: turnNumber });
        
        try {
            const project = await findOrCreateNoteProjectByName(subjectName);
            if (!project || !project.id) throw new Error(`Failed to find/create project: ${subjectName}`);

            const chunkSize = project.chunkSize || ARCHIVE_CHUNK_SIZE;
            const notePage = Math.floor((turnNumber - 1) / chunkSize) + 1;
            const noteTitle = `[${subjectName}] 서사 기록 #${notePage}`;
            
            const note = await findOrCreateNoteByTitle(noteTitle, project.id);
            if (!note || !note.id) throw new Error(`Failed to find/create note: ${noteTitle}`);

            const turnIdentifier = `## [턴 ${turnNumber}]`;
            // [CRITICAL FIX] Bypass cache to prevent stale read overwrite
            const currentContent = await getNoteContent(note.id, true);

            if (currentContent && currentContent.includes(turnIdentifier)) {
                trace("Archiver", "handleHtml.skip.duplicate", { turn: turnNumber, noteId: note.id });
                return;
            }

            // Convert HTML DOM to Narrative Snapshot Markdown using the improved function
            const snapshotMarkdown = _convertHtmlToNarrativeSnapshot(doc, turnNumber);

            const newContent = (currentContent || '') + snapshotMarkdown;
            await replaceNoteContentSerial(note.id, newContent);
            trace("Archiver", "handleHtml.success.narrative", { turn: turnNumber, noteId: note.id });

        } catch (error) {
            console.error("HTML narrative archiving failed:", error);
            trace("Archiver", "handleHtml.error.narrative", { error: error.message }, {}, "ERROR");
        }

    } else {
        // --- LEARNING ARCHIVING PATH (Existing Logic) ---
        trace("Archiver", "handleHtml.learning", { subject: subjectName, concept: conceptName });
        try {
            const project = await findOrCreateNoteProjectByName(subjectName);
            if (!project || !project.id) throw new Error(`Failed to find/create project: ${subjectName}`);

            const noteTitle = `[학습] ${conceptName}`;
            const note = await findOrCreateNoteByTitle(noteTitle, project.id);
            if (!note || !note.id) throw new Error(`Failed to find/create note: ${noteTitle}`);

            const newContent = convertHtmlToMarkdown(rawHtml);
            await replaceNoteContentSerial(note.id, newContent);
            trace("Archiver", "handleHtml.success.learning", { noteId: note.id, title: note.title });

        } catch (error) {
            console.error("HTML source archiving failed:", error);
            trace("Archiver", "handleHtml.error.learning", { error: error.message }, {}, "ERROR");
        }
    }
}


/**
 * [MODIFIED] Main handler for automatic archiving. Now intelligently routes to different
 * archiving logic based on the payload type (learning vs. narrative vs. html source).
 */
async function handleAutomaticArchiving() {
    // [NEW] Check for HTML Source payload (Canvas Mode)
    if (currentDataPayload?.type === 'html_source') {
        await handleHtmlSourceArchiving(currentDataPayload);
        return;
    }

    if (!currentDataPayload || !currentDataPayload.archivePayload) {
        trace("Archiver", "handle.skip", { reason: "No archivePayload found" });
        return;
    }

    const payload = currentDataPayload.archivePayload;
    
    // --- INTELLIGENT ROUTING ---
    if (payload.subjectName && payload.conceptName) {
        // --- Learning Canvas Archiving Logic (JSON Mode) ---
        trace("Archiver", "handle.start.learning", { subject: payload.subjectName, concept: payload.conceptName });
        try {
            const project = await findOrCreateNoteProjectByName(payload.subjectName);
            if (!project || !project.id) throw new Error(`Failed to find/create project: ${payload.subjectName}`);

            const noteTitle = `[학습] ${payload.conceptName}`;
            const note = await findOrCreateNoteByTitle(noteTitle, project.id);
            if (!note || !note.id) throw new Error(`Failed to find/create note: ${noteTitle}`);
            
            // For learning content, we always overwrite with the latest version.
            const newContent = buildMarkdownFromContentBlocks();
            await replaceNoteContentSerial(note.id, newContent);
            trace("Archiver", "handle.success.learning", { noteId: note.id, title: note.title });

        } catch (error) {
            console.error("Learning canvas archiving failed:", error);
            trace("Archiver", "handle.error.learning", { error: error.message }, {}, "ERROR");
        }

    } else if (payload.theme && payload.turn) {
        // --- Narrative Simulation Archiving Logic (JSON) ---
        trace("Archiver", "handle.start.narrative", { theme: payload.theme, turn: payload.turn });
        try {
            const dynamicSnapshotPart = buildSnapshotFromContentBlocks();
            payload.snapshot = { ...dynamicSnapshotPart, ...payload.snapshot };
            trace("Archiver", "handle.snapshotBuilt", { narrativeChars: payload.snapshot.narrative.length });

            const project = await findOrCreateNoteProjectByName(payload.theme);
            if (!project || !project.id) throw new Error(`Failed to find/create project: ${payload.theme}`);
            
            const chunkSize = project.chunkSize || ARCHIVE_CHUNK_SIZE;
            const notePage = Math.floor((payload.turn - 1) / chunkSize) + 1;
            const noteTitle = `[${payload.theme}] 서사 기록 #${notePage}`;
            
            const note = await findOrCreateNoteByTitle(noteTitle, project.id);
            if (!note || !note.id) throw new Error(`Failed to find/create note: ${noteTitle}`);

            const turnIdentifier = `## [턴 ${payload.turn}]`;
            const snapshotMarkdown = formatNarrativeSnapshot(payload);
            const appendResult = await appendNoteContentSerial(note.id, snapshotMarkdown, {
                dedupeMarker: turnIdentifier
            });
            if (!appendResult.updated && appendResult.reason === 'duplicate-marker') {
                trace("Archiver", "handle.skip.duplicate", { turn: payload.turn, noteId: note.id });
                return;
            }
            trace("Archiver", "handle.success.narrative", { turn: payload.turn, noteId: note.id });

        } catch (error) {
            console.error("Narrative archiving failed:", error);
            trace("Archiver", "handle.error.narrative", { error: error.message }, {}, "ERROR");
        }
    } else {
        trace("Archiver", "handle.skip.unknownPayload", { payload: JSON.stringify(payload) });
    }
}

async function archiveMarkdownSnapshot(theme, turn, markdown) {
    if (!theme || !turn || !markdown) {
        trace("Archiver", "archiveSnapshot.skip", { reason: "Missing data" });
        return;
    }
    trace("Archiver", "archiveSnapshot.start", { theme, turn });

    try {
        const project = await findOrCreateNoteProjectByName(theme);
        if (!project || !project.id) throw new Error(`Failed to find/create project: ${theme}`);
        
        const chunkSize = project.chunkSize || ARCHIVE_CHUNK_SIZE;
        const notePage = Math.floor((turn - 1) / chunkSize) + 1;
        const noteTitle = `[${theme}] 서사 기록 #${notePage}`;
        
        const note = await findOrCreateNoteByTitle(noteTitle, project.id);
        if (!note || !note.id) throw new Error(`Failed to find/create note: ${noteTitle}`);

        await appendNoteContentSerial(note.id, `\n\n${markdown.trim()}`, {
            dedupeMarker: `## [??${turn}]`
        });
        trace("Archiver", "archiveSnapshot.success", { turn, noteId: note.id });
    } catch (error) {
        console.error("Markdown snapshot archiving failed:", error);
        trace("Archiver", "archiveSnapshot.error", { error: error.message }, {}, "ERROR");
    }
}
