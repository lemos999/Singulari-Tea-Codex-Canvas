# Revision Plan

Plan Type: revision-plan
Workstream: Rewrite the bilingual `.ccc` MM documents into host-neutral generic HTML runtime rules
Version: v01
Status: Completed
Created: 2026-04-15 09:07:44 +09:00
Last Updated: 2026-04-15 09:32:04 +09:00
Supersedes: `plan/20260415-085809--work-plan--ccc-mm-extract-and-bilingual-docs--v01.md`
Related Plan: `plan/20260415-080000--work-plan--canvas-mm-transformation--v01.md`
Current Completion State: Planning, rewriting, and verification completed
Completed So Far: The user explicitly confirmed that the previous `.ccc` extraction should be generalized. The current English and Korean files were inspected and the study-specific material was located. Generic canvas-layer reference material from the workspace backups was reviewed so the rewrite could keep runtime-specific precision while dropping educational framing. Both target files were then rewritten in place as host-neutral `.ccc` HTML runtime rule documents. The new versions now define `.ccc` as an out-of-band runtime trigger, preserve host-owned semantics, specify the standalone HTML5 shell and required asset URLs, keep the visual-surface minimum, define the control panel actions, retain `apiKey`, `TARGET_MODEL`, `visualData`, `generateSingleImage`, `runImageGeneration`, `downloadPage`, `Promise.all(...)`, and `DOMContentLoaded`, and replace the old educational follow-up logic with generic host-follow-up preservation and self-check rules. Verification then confirmed that banned educational terms such as `Ailey`, `M-UGE`, `M-1.5`, `State 1`, `State 2`, `State 3`, `discovery`, `planning`, `learning`, `curriculum`, `lesson`, `roadmap`, `proposal compass`, `exploration gateway`, and `study scaffolding` no longer appear in either file, while the key runtime terms and URLs remain present. After that, a user-provided correction was incorporated so the `apiKey` wording now reflects that the empty string is intentional and is parsed automatically inside the sandbox runtime when that path is supported, rather than being described as a host-injected slot.
Remaining Work: None
Current Blockers: None
Next Step: Wait for user review and perform narrow refinement only if they want the wording even more abstract, more compact, or more universal.

## Objective

The revised request is narrower and more infrastructural than the prior one. The user no longer wants a `.ccc` extraction that preserves study, curriculum, discovery, planning, learning, lecture, gateway, or compass logic. The user wants `.ccc` expressed as a generic HTML runtime rule set. That means the deliverables should stop reading like an educational content flow and start reading like a reusable runtime contract for freestyle standalone HTML artifacts.

The smallest complete design is to keep the same two output files and rewrite them in place. No new end-user files are required because the prior filenames remain semantically appropriate: both already represent `.ccc` MM documents, and the new request changes their content direction rather than their role. Overwriting the current two files reduces clutter, preserves discoverability, and keeps rollback simple because the superseded plan already records the previous state. The original source prompt will remain untouched.

The design intent of this revision is to preserve the useful parts of the existing `.ccc` documents while removing their local educational bias. The retained parts should be: trigger handling, dormant behavior, out-of-band token treatment, generic host-semantics preservation, standalone HTML5 shell requirements, valid tag constraints, Tailwind and Font Awesome asset requirements, image id requirements, visual surface minimums, runtime function and network call obligations, download behavior, `DOMContentLoaded` behavior, host-follow-up preservation, and a final self-check. The removed parts should be: Ailey-specific persona references, curriculum-specific state names when used as educational flow, references to `[M-UGE]`, `[M-1.5]`, roadmap, skill tree as a curriculum artifact, proposal compass, gateway, lesson progression, and any text that frames `.ccc` as an instructional or study interface.

## Confirmed Facts

The current English and Korean `.ccc` MM files still carry educational assumptions because they were derived from the `.ccc` path inside the Ailey prompt rather than from a fully generic runtime module. Those documents currently mention Ailey as the active text identity, distinguish State 1, State 2, and State 3 in educational terms, refer to source engines such as `[M-UGE]` and `[M-1.5]`, tie state behavior to topics, roadmap choices, and deep-dive learning transitions, and require a proposal compass or exploration gateway after the HTML artifact. All of that is now out of scope.

The reviewed backup material shows the more reusable direction that the user now wants. The generic `.cc/.ccc` module material frames `.ccc` as a standalone HTML runtime layer that keeps host semantics while owning the freestyle shell. It avoids education-specific state routing and instead emphasizes out-of-band trigger handling, host-answer freezing, visual-system freedom, HTML validity, asset constraints, runtime function requirements, safe fallback behavior, and preservation of host-owned side effects or UI contracts. That is a closer fit to the user’s new wording.

The current derivative files are short enough that a surgical rewrite is safer than a line-by-line micro-edit. Replacing the entire body of each file is less error-prone than trying to delete every educational trace from the existing text. Because the files are documentation artifacts rather than executable programs, the main verification burden is rule coverage and unwanted-term removal.

## Assumptions

The smallest safe assumption is that the user wants the same two files rewritten rather than new filenames. The request said to make the current material feel generic and to treat `.ccc` as just HTML runtime rules. There was no instruction to preserve the previous educational version as an additional file, and keeping multiple near-identical variants would likely add maintenance noise. Therefore the revision will update:

`Ailey/Ailey & Bailey X_260304_ccc_mm.md`

`Ailey/Ailey & Bailey X_260304_ccc_mm_ko.md`

Another safe assumption is that “범용 느낌” means host-neutral rather than host-empty. A truly generic `.ccc` runtime document still needs some notion of how it relates to the surrounding prompt or answer. The safest abstraction is not to delete semantic preservation entirely, but to rephrase it generically: `.ccc` should treat the trigger as an out-of-band control token, preserve the host’s meaning and contract, and own only the standalone freestyle HTML shell and its runtime behavior. This keeps the runtime rules useful in other prompt systems.

A third safe assumption is that “그냥 html 런타임규칙으로 .ccc를” means that the post-generation behavior should become generic too. Instead of mandating a curriculum proposal compass or gateway, the rewritten files should say that host-owned follow-up UI, side effects, or closing behaviors must be preserved or substituted with the closest canvas-native equivalent when necessary. This is faithful to a universal runtime rule set and removes the study-specific aftercare logic.

Another safe assumption is that the Korean file should remain Korean-first and natural, not translated word-for-word. Technical literals such as `.ccc`, `<!DOCTYPE html>`, `<img id="...">`, `Tailwind CSS`, `Font Awesome`, `visualData`, `TARGET_MODEL`, `generateSingleImage`, `runImageGeneration`, `downloadPage`, `Promise.all(...)`, and `DOMContentLoaded` should stay literal where precision matters. The rest should read as clear Korean operational prose.

## Deliverables

This revision will produce three artifacts. The first is this new active revision plan. The second is the rewritten English `.ccc` MM document. The third is the rewritten Korean `.ccc` MM document. The output paths remain unchanged:

`Ailey/Ailey & Bailey X_260304_ccc_mm.md`

`Ailey/Ailey & Bailey X_260304_ccc_mm_ko.md`

These files should emerge as host-neutral `.ccc` runtime references. They should no longer be specialized to a study workflow. They should still be MM-style narrative serializations, which means no long list formatting, no dependency on excerpt tables, and no loose summary tone. Each file should instead read as a dense operational contract in prose.

## Scope Boundaries

The rewrite should keep only the pieces required for a generic `.ccc` runtime contract. That includes the activation boundary, the distinction between dormant and active behavior, the treatment of `.ccc` as an out-of-band control token, the rule that standalone HTML generation begins only when `.ccc` is present, the preservation of host meaning and response contract, and the ownership split in which `.ccc` controls the standalone shell but does not author new semantics.

The rewrite should also keep the technical shell contract. The `<head>` still needs `<title>`, the Tailwind CDN script, the Font Awesome stylesheet, the Google font link, and a local `<style>` block. The `<body>` should still be described as a valid HTML surface built from standard HTML tags and free of React, Vue, JSX, or bundlers. Images should still use unique `<img id="...">` elements. The runtime script still needs `apiKey`, `TARGET_MODEL = "gemini-2.5-flash-image-preview"`, `visualData`, `generateSingleImage`, `runImageGeneration`, `downloadPage`, parallel generation via `Promise.all(...)`, and automatic startup via `DOMContentLoaded`.

The rewrite should preserve the visual-support contract while making it generic. The previous wording already required at least three visual surfaces and at least one structured explanatory surface. That can stay, but it should be framed in domain-neutral terms such as diagrammatic, comparative, process, spatial, or structured support rather than in classroom language.

The rewrite must remove all educational routing logic. That means no State 1, State 2, State 3, no discovery/planning/learning labels, no source-engine names like `[M-UGE]` or `[M-1.5]`, no curriculum references, no roadmap option selection, no lesson flow, no proposal compass, no gateway, and no mandatory educational menu appended after the HTML file. If the file still contains those ideas after the rewrite, the revision has failed.

The rewrite should also remove Ailey-specific ownership from the generic runtime rules. Instead of “keep Ailey as the active text identity,” the new files should say that `.ccc` inherits or preserves the host prompt’s identity, tone, language, safety rules, and response contract, while only changing the rendering surface into a standalone freestyle HTML artifact.

## Transformation Strategy

The easiest way to make the documents genuinely generic is to rebuild each file around four functional blocks, but to express them as continuous prose rather than as section lists. The first block is trigger discipline. It should define `.ccc` as an out-of-band control token, specify dormant behavior when absent, and make clear that artifact generation is not allowed without the literal trigger.

The second block is semantic ownership. It should explain that once `.ccc` is present, the runtime should preserve the host answer’s meaning, sequencing, omissions, interface obligations, and side effects rather than inventing a new semantic layer. This avoids tying the document to any specific teaching engine or persona while still making the rules interoperable with complex host prompts.

The third block is the standalone freestyle shell and runtime contract. This is the densest part of the rewrite and should describe the HTML head requirements, valid body structure, asset dependencies, visual-surface minimum, unique image id rule, control panel actions, `visualData` requirement, image generation request flow, parallel execution, page download behavior, and startup hook. This should read like a general-purpose runtime spec, not like a themed lesson page.

The fourth block is post-generation and self-check behavior. Because the earlier mandatory compass rule is no longer wanted, the generic version should instead say that host-owned follow-up UI, side effects, terminal no-UI states, and closing behaviors must either be preserved or replaced by the closest canvas-native equivalent when needed. The final paragraph should then define a self-check that confirms trigger handling, semantic preservation, shell completeness, runtime hook presence, and absence of unwanted educational scaffolding.

The Korean file should not be created by direct sentence substitution from the English version. The better approach is to use the same four-block rule inventory and recompose it as natural Korean imperative prose. That will keep the content aligned while avoiding translation stiffness. Technical literals remain identical where exactness matters.

## Risks And Controls

The main risk is leaving behind educational residue. Because the current files are short and explicit, even one retained phrase like “curriculum,” “lesson,” “proposal compass,” or “learning state” would make the result feel less generic than the user asked for. To control that, the final verification will include a targeted scan for a blocklist of educational terms in both files.

The second risk is over-correction. In trying to remove study-specific content, it would be easy to also remove the useful runtime obligations and leave behind something vague and ornamental. To control that, the rewritten files must still explicitly mention the HTML5 standalone requirement, the Tailwind and Font Awesome dependencies, valid tag restrictions, unique `<img id="...">` usage, the control panel actions, `apiKey`, `TARGET_MODEL`, `visualData`, `generateSingleImage`, `runImageGeneration`, `downloadPage`, `Promise.all(...)`, `DOMContentLoaded`, and a visual-support minimum. If those details disappear, the document has stopped being a runtime rule set.

The third risk is turning `.ccc` into a fully semantic author instead of a renderer. The user asked for HTML runtime rules, not for an unconstrained microsite generator that can ignore the host answer. To control that, both documents should clearly state that `.ccc` changes the rendering layer and the standalone shell, but continues to preserve host-owned meaning, ordering, omissions, and response obligations.

The fourth risk is mismatch between the English and Korean files. A generic runtime doc is most valuable when both language variants are aligned. To control that, both versions will be checked against the same runtime coverage checklist and the same banned-term list.

The fifth risk is file churn without explicit record. Because the prior plan is already completed, a reader could otherwise misunderstand why the same files changed direction so quickly. To control that, this revision plan supersedes the earlier plan explicitly and the earlier plan now points here as the active successor.

## Work Sequence

First, rewrite the English file in full. It should open by defining `.ccc` as a standalone freestyle runtime trigger within a larger dormant-or-active boundary. It should then explain that the trigger is out-of-band, that the host meaning remains authoritative, and that `.ccc` owns only the standalone freestyle shell and runtime. After that it should narrate the technical shell requirements and runtime function behavior in dense operational prose. It should close with host-follow-up preservation and a self-check.

Second, rewrite the Korean file to match the English rule inventory. It should use Korean-first wording, preserve exact technical literals, and avoid educational traces. The tone should be directive and neutral, not teacherly or conversational.

Third, verify that the outputs are generic. The verification should explicitly confirm that the files no longer mention Ailey, `[M-UGE]`, `[M-1.5]`, discovery, planning, learning, roadmap, lesson, curriculum, proposal compass, gateway, or similar study-specific signals. It should also confirm that the required runtime tokens and URLs are still present.

Fourth, update this plan file to reflect implementation and verification results, mark remaining work as none, and raise the provisional score only conservatively because no explicit user score has been given yet.

## Validation Approach

Validation is textual but contract-driven. The first validation layer is banned-term removal. The English and Korean files should be checked for unwanted domain residue including `Ailey`, `M-UGE`, `M-1.5`, `State 1`, `State 2`, `State 3`, `discovery`, `planning`, `learning`, `curriculum`, `lesson`, `roadmap`, `proposal compass`, and `exploration gateway`. If any of these remain in a way that implies educational flow, the rewrite is incomplete.

The second validation layer is runtime-rule preservation. Each file should clearly state or imply all of the following: `.ccc` is a literal trigger; no trigger means dormant text mode; the trigger is out-of-band control rather than semantic content; host semantics remain authoritative; the output is one standalone HTML5 artifact; the head includes the required asset URLs; the body uses valid HTML tags; React, Vue, JSX, and bundlers are excluded; AI images use unique ids; the page contains at least three visual surfaces and at least one structured explanatory or comparative surface when structured support is warranted; the control panel exposes regenerate and save actions; the script defines `apiKey`, `TARGET_MODEL`, `visualData`, `generateSingleImage`, `runImageGeneration`, and `downloadPage`; `runImageGeneration()` uses `Promise.all(...)`; startup is bound to `DOMContentLoaded`; and host-owned follow-up or side effects are preserved or substituted rather than silently erased.

The third validation layer is MM-style integrity. The rewritten files should still read like compressed operational prose, not like a bare checklist or a copy of code comments. The point is not only to keep the rules; it is to keep them in the MM narrative-serialization style the user requested earlier.

The fourth validation layer is practical usability. A maintainer should be able to open either file and understand `.ccc` as a generic HTML runtime rule set without knowing anything about the Ailey educational flow. If the file still requires that local context to make sense, the rewrite has not gone far enough.

## Definition Of Done

This revision is done when both target files have been rewritten in place, both now read as generic `.ccc` HTML runtime rule documents, both have lost their study-specific routing and terminology, both preserve the required standalone shell and runtime mechanics, and the active revision plan has been updated with completion and verification notes.

Done does not require introducing new code, changing the original source prompt, or building a larger universal module. Done also does not require merging `.cc` and `.ccc` into a single file. The requested outcome is narrower: make the current `.ccc` material generic and runtime-focused.

## Design Intent

The long-term health goal here is clarity and reuse. A `.ccc` document that still smells like one specific teaching flow is hard to reuse in other prompts or other runtime experiments. A host-neutral runtime rule document is much more portable. At the same time, stripping away all host-awareness would make the runtime dangerous or too unconstrained. The best middle position is to keep `.ccc` as a disciplined rendering layer with strong shell and runtime rules and explicit respect for host-owned meaning.

This approach also minimizes rollback risk. Only two derived Markdown files are changing. The original source remains untouched, the prior plan remains preserved as history, and the revision plan clearly records the semantic reason for the rewrite. If the user later wants a stricter “pure runtime only” version or a separate universal module, that can build on this cleaner generic base.

## Scoreboard

Current Score: 50
Score Source: provisional
Last Updated: 2026-04-15 09:32:04 +09:00
Score Rationale: The active revision has been implemented and verified. The `.ccc` documents now read as generic HTML runtime rules, the study-specific vocabulary is gone, and the core runtime contract remains intact. A follow-up correction from the user about `apiKey` handling was incorporated so the wording now matches the intended sandbox behavior more precisely. No explicit user score has been provided yet, so the recorded score should still remain conservative.
What Improved: The English and Korean files are now host-neutral, runtime-focused, free of the prior educational routing language, and more accurate about the empty-string `apiKey` behavior.
What Remains Unsatisfactory: Only user taste remains unknown, such as whether they want the wording even more minimal, even more abstract, or split into a stricter machine-spec version.
What Should Happen Next To Raise Or Maintain The Score: Wait for feedback and make only narrow wording refinements if requested.

## Score History

- 2026-04-15 09:07:44 +09:00 | 45 | provisional | New approved revision plan created to replace the earlier study-oriented `.ccc` extraction with generic `.ccc` HTML runtime rules.
- 2026-04-15 09:12:24 +09:00 | 50 | provisional | Rewrote both `.ccc` files as generic HTML runtime rules and verified that educational terms were removed while the core runtime contract remained present.
- 2026-04-15 09:32:04 +09:00 | 50 | provisional | Applied a follow-up correction so the `apiKey` wording now reflects intentional empty-string sandbox parsing instead of host-side key injection.
