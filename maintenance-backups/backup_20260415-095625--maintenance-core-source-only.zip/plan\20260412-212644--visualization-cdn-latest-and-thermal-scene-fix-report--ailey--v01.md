# Visualization CDN Latest-Track And Thermal Scene Fix Report

- Artifact Type: implementation-report
- Created: 2026-04-12 21:26:44 +09:00
- Scope: latest-track CDN normalization for generated visualization dependencies, renderer-level repair for bare JavaScript hex color literals, image-generation studio memo-width improvement, and thermal-scene root-cause analysis
- Related Plan: `20260412-181504--visualization-options-upgrade-plan--ailey--v01.md`

## What Changed

- new visualization generations now prefer latest-track or versionless CDN URLs in the prompt contract instead of many hard-pinned version URLs
- the renderer now normalizes known visualization dependency URLs to canonical latest-track equivalents before loading them
- stylesheet links inside generated fragments are normalized through the same dependency pass
- the visualization preflight repair layer now converts bare CSS-style JavaScript color literals such as `color: #1a1a1a` into valid numeric literals such as `color: 0x1a1a1a`
- the image-generation studio widened the left-side scene memo surface so the `장면 설명 메모` area is less cramped for longer prompts

## Root Cause Analysis

The reported `대기 기단 열역학 시뮬레이션` block in `기단의 성질 (Properties of Air Masses) (2).html` is a generated code failure first, not a host DOM-collision failure.

Key evidence:

- the block script used `document.getElementById(...)`, but the current renderer already rewrites that access to scoped lookups during preflight, so document-global lookup is not the primary reason the scene stayed blank
- the block contains invalid JavaScript in the Three.js setup:
  - `const groundMat = new THREE.MeshPhongMaterial({ color: #1a1a1a, side: THREE.DoubleSide });`
- because `#1a1a1a` is not a valid JavaScript literal in that position, the script fails during parsing
- when parsing fails:
  - static overlay HTML still renders
  - the canvas holder remains empty
  - the user sees UI chrome without the actual scene

## Primary Files

- `Ailey/src/02_utils/013_utils_block_renderer.js`
- `Ailey/src/03_core/102_template_data_visualizer.js`
- `Ailey/src_css/027_image_gen_studio.css`

## Verification

- `node --check Ailey/src/02_utils/013_utils_block_renderer.js`
- `node --check Ailey/src/03_core/102_template_data_visualizer.js`
- `node Ailey/bundler.js`

## Deployment

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `35a22da`
- commit message: `Harden visualization runtime and studio dependency loading`

## Remaining Step

- manual browser validation by the user on exported/live HTML
