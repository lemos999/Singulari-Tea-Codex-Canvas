# Corner Dock Header Follow-up Plan

- Created: 2026-04-12 23:29:26 +09:00
- Last Updated: 2026-04-12 23:48:17 +09:00
- Status: completed_pending_user_validation
- Plan Type: implementation
- Scope: immersive header follow-up

## Objective

Replace the current thin floating action bar with a smaller upper-right corner dock.

The new header should:

- remove the visible brand surface entirely
- keep only the core action icons
- avoid spanning the reading width
- auto-hide when scrolling down
- reappear when scrolling up or near the top
- stay usable on narrow desktop widths and mobile widths

## Approved Direction

- Upper-right floating icon dock
- No `Codex Canvas` label
- No `슬림 액션 바` helper copy
- No quick query
- No clock
- No explicit header visibility toggle

## Files In Scope

- `Ailey/src/00_shell/000_shell_template.js`
- `Ailey/src_css/001_base.css`
- `Ailey/src_css/010_widget_header_addons.css`
- `Ailey/src/03_core/120_core_main_initializer.js`

## Execution Steps

1. Reduce header markup to an icon-only action cluster.
2. Rebuild the header CSS as a compact upper-right floating dock.
3. Restore scroll-direction show/hide behavior without restoring the old toggle UI.
4. Remove brand-specific runtime loading that is no longer needed.
5. Rebundle and deploy the hosted bundle.

## Scoreboard

- Current Score: 93
- Score Source: provisional
- Last Updated: 2026-04-12 23:48:17 +09:00
- Rationale: the header is now an icon-only upper-right corner dock with direct GitHub and coffee-style support links, scroll-direction reveal behavior is restored, and the hosted bundle was pushed to `main`, but the user has not manually validated the live pages yet
- What Improved: the wide header surface is gone, brand/helper copy is gone, the corner dock now auto-hides on scroll-down and reappears on scroll-up, mobile spacing is tighter, and GitHub/support shortcuts are directly accessible from the dock with the support action now using a coffee icon
- What Remains Unsatisfactory: final UX judgment for narrow desktop and mobile still depends on user-side runtime validation
- Next Step: user validates the new corner-dock header in exported/live HTML pages

## Score History

- 2026-04-12 23:29:26 +09:00 | 72 | provisional | user approved the upper-right corner dock direction after the thin action bar iteration
- 2026-04-12 23:35:55 +09:00 | 93 | provisional | corner dock header implemented, rebundled, and deployed to hosted bundle commit `c2dd929`
- 2026-04-12 23:43:17 +09:00 | 94 | provisional | GitHub and support shortcuts added to the corner dock and deployed to hosted bundle commit `c3d8ce5`
- 2026-04-12 23:48:17 +09:00 | 94 | provisional | support shortcut icon changed to a coffee cup and deployed to hosted bundle commit `5a4ae0f`
