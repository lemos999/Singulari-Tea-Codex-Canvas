# Ailey Visualization DOM Stability Follow-up Report

- Artifact Type: implementation-report
- Created: 2026-04-12 15:47:03 +09:00
- Scope: follow-up repair pass under `20260412-145425--visualization-generation-stability-plan--ailey--v01.md`
- Status: shipped-awaiting-user-validation

## Summary

This follow-up addressed the newly confirmed DOM-collision failure mode in exported multi-visualization HTML pages.

The observed bug pattern was:

- generated scene blocks reused generic IDs such as `three-canvas-holder`
- generated scripts resolved those nodes with document-global lookup such as `document.getElementById(...)`
- later visualizations could therefore mount their renderer into an earlier block's DOM while leaving the correct controls visible in the current section

The renderer now enforces block-local DOM scoping by default and the prompt contract was tightened so future generations are less likely to recreate the same class of bug.

## Implemented Changes

### 1. Renderer DOM scope hardening

Updated:

- `Ailey/src/02_utils/013_utils_block_renderer.js`

Changes:

- Added `createScopedVisualizationDocument(vizContainer)` and exposed it as `window.createScopedVisualizationDocument`
- Wrapped generated scripts with a block-local `document` proxy so:
  - `document.getElementById(...)`
  - `document.querySelector(...)`
  - `document.querySelectorAll(...)`
  resolve inside the active visualization subtree rather than the whole page
- Kept `document.body` scoped to the active visualization container during generated-script execution
- Added preflight repair for `window.document` and `globalThis.document` lookup patterns so they downgrade to the scoped `document`

### 2. Style ownership hardening

Updated:

- `Ailey/src/02_utils/013_utils_block_renderer.js`

Changes:

- Added per-block scope IDs on visualization containers
- Scoped generated `<style>` content to the active visualization block before injection
- Tagged injected style elements with `data-viz-style-owner`
- Removed prior style elements owned by the same block before re-injecting on replay/re-render

### 3. Prompt contract hardening

Updated:

- `Ailey/src/03_core/102_template_data_visualizer.js`

Changes:

- Bumped `Data Visualizer` version from `24.0` to `25.0`
- Explicitly banned:
  - `window.document`
  - `globalThis.document`
  - generic repeated fragment IDs
- Strengthened guidance to:
  - resolve nodes from `vizContainer` or the fragment root only
  - use fragment-local selectors
  - scope any `<style>` rules to the fragment root

## Verification

Completed:

- `node --check Ailey/src/02_utils/013_utils_block_renderer.js`
- `node --check Ailey/src/03_core/102_template_data_visualizer.js`
- `node Ailey/bundler.js`

Observed:

- bundle regeneration succeeded
- `Singulari-Tea-Codex-Canvas-pr/bundle/main.js` changed
- `bundle/main.css` did not require an external-repo update in this pass

## Deployment

Hosted bundle repository:

- repo: `lemos999/Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `acb1063b51e47faeadde608743854ed1a971c300`
- commit message: `Harden visualization DOM scoping`

## Remaining Risk

- This pass hardens DOM lookup and style scoping, but user-side browser validation is still required for real exported HTML pages with multiple scene blocks.
- Scene visibility quality can still be weak when the model generates visually underpowered Three.js content even if the DOM target is now correct.
- Future follow-up, if needed, should focus on scene legibility and first-frame visibility rather than document-global DOM collisions.
