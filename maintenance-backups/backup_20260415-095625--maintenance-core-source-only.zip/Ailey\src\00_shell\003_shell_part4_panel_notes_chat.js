/* --- Ailey & Bailey Canvas --- */
// File: 003_shell_part4_panel_notes_chat.js
// Version: 3.0 (Chat Composer Refresh)
// Description: Provides the notes panel shell and the refreshed chat shell with a modern multi-attachment composer.

const SHELL_PART_4 = `
    <div id="notes-app-panel" class="draggable-panel">
        <div id="note-list-view" class="notes-view active"></div>
        <div id="note-editor-view" class="notes-view">
            <div class="editor-header">
                <button id="back-to-list-btn" class="notes-btn">
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M20,11V13H8L13.5,18.5L12.08,19.92L4.16,12L12.08,4.08L13.5,5.5L8,11H20Z" /></svg>
                    <span>목록</span>
                </button>
                <div id="auto-save-status"></div>
            </div>
            <input type="text" id="note-title-input" placeholder="제목을 입력하세요...">
            <div id="toast-editor"></div>
        </div>
        <div id="note-recall-view" class="notes-view">
            <div class="editor-header">
                <div class="recall-header-group left">
                    <button id="recall-back-to-list-btn" class="notes-btn">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M20,11V13H8L13.5,18.5L12.08,19.92L4.16,12L12.08,4.08L13.5,5.5L8,11H20Z"></path></svg>
                        <span>목록</span>
                    </button>
                    <button id="recall-sidebar-toggle-btn" class="panel-control-btn" title="턴 목록 접기/펼치기">
                        <svg viewBox="0 0 24 24" width="24" height="24"><path d="M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z"/></svg>
                    </button>
                    <div id="recall-note-title" class="recall-title"></div>
                </div>
                <div class="recall-header-group right">
                    <button id="recall-compatibility-toggle" class="note-project-action-btn" title="호환 보기 (Markdown)">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M21,17H7V15H21M21,13H7V11H21M21,9H7V7H21M5,17H3V15H5M5,13H3V11H5M5,9H3V7H5M21,21H7V19H21M5,21H3V19H5" /></svg>
                        <span>호환 보기</span>
                    </button>
                    <button id="recall-editor-toggle" class="note-project-action-btn" title="에디터 보기">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M14.06,9.02L14.98,9.94L5.92,19H5V18.08M18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.13,5.12L18.88,8.87L20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29Z" /></svg>
                        <span>에디터 보기</span>
                    </button>
                    <input type="search" id="recall-search-input" placeholder="내용 검색...">
                </div>
            </div>
            <div class="recall-container">
                <div id="recall-turn-list-container"></div>
                <div id="recall-content-container">
                    <div id="recall-content-area"></div>
                </div>
            </div>
        </div>
    </div>
    <div id="chat-panel" class="draggable-panel">
        <div id="chat-session-sidebar">
            <div id="sidebar-header">
                <div class="mobile-sidebar-return-row">
                    <button id="mobile-sidebar-return-btn" type="button" title="Back to chat" aria-label="Back to chat">
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z"/></svg>
                        <span>Back to Chat</span>
                    </button>
                </div>
                <div class="sidebar-controls">
                    <input type="text" id="search-sessions-input" placeholder="프로젝트/대화 검색...">
                    <button id="temp-session-toggle" title="임시 대화 모드">
                        <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M12,5A7,7 0 0,0 5,12A7,7 0 0,0 12,19A7,7 0 0,0 19,12A7,7 0 0,0 12,5M11,7H13V12.59L16.71,16.29L15.29,17.71L11,13.41V7Z" /></svg>
                    </button>
                </div>
                <div class="sidebar-button-group">
                    <button id="new-chat-btn" title="새 대화 시작">
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M20,14H14V20H12V14H6V12H12V6H14V12H20V14Z" /></svg>
                        <span>새 대화</span>
                    </button>
                    <button id="new-project-btn" title="새 프로젝트 생성">
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M4,6H2V20A2,2 0 0,0 4,22H18V20H4V6M20,2H8A2,2 0 0,0 6,4V16A2,2 0 0,0 8,18H20A2,2 0 0,0 22,16V4A2,2 0 0,0 20,2M13,13H11V10H8V8H11V5H13V8H16V10H13V13Z" /></svg>
                        <span>새 프로젝트</span>
                    </button>
                </div>
            </div>
            <div id="session-list-container"></div>
        </div>

        <div id="chat-main-view">
            <div class="panel-header">
                <button id="sidebar-toggle-btn" title="사이드바 접기/펼치기">
                    <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z"/></svg>
                </button>
                <span id="chat-session-title">Ailey & Bailey</span>
                <div class="panel-controls">
                    <button class="panel-control-btn panel-minimize-btn" title="최소화">
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M20,14H4V10H20" /></svg>
                    </button>
                    <button class="panel-control-btn panel-maximize-btn" title="최대화">
                        <span class="icon-maximize"><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M4,4H20V20H4V4M6,8V18H18V8H6Z"/></svg></span>
                        <span class="icon-restore"><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M4,8H8V4H20V16H16V20H4V8M16,8V14H18V6H10V8H16M6,10V18H14V10H6Z"/></svg></span>
                    </button>
                    <button class="panel-control-btn close-btn" title="닫기">
                        <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z" /></svg>
                    </button>
                </div>
            </div>

            <div id="chat-control-deck">
                <button id="grounding-quick-toggle-btn" class="panel-control-btn" data-tooltip="Google 검색 기반 응답 켜기/끄기" style="display: none;">🌐</button>
                <button id="context-toggle-btn" class="panel-control-btn" data-tooltip="이전 대화 참조 켜기/끄기" aria-label="이전 대화 참조 켜기/끄기">
                    <span class="icon-context-on" aria-hidden="true">
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M10.59,13.41L9.17,12L13.41,7.76A3,3 0 0,1 17.66,12L15.54,14.12L14.12,12.71L16.24,10.59A1,1 0 0,0 14.83,9.17L10.59,13.41M13.41,10.59L14.83,12L10.59,16.24A3,3 0 0,1 6.34,12L8.46,9.88L9.88,11.29L7.76,13.41A1,1 0 0,0 9.17,14.83L13.41,10.59M8.46,15.54L7.05,16.95A5,5 0 0,1 7.05,9.88L9.17,7.76L10.59,9.17L8.46,11.29A3,3 0 0,0 12.71,15.54L14.83,13.41L16.24,14.83L14.12,16.95A5,5 0 0,1 8.46,15.54M15.54,8.46L13.41,10.59L12,9.17L14.12,7.05A5,5 0 0,1 21.19,14.12L19.07,16.24L17.66,14.83L19.78,12.71A3,3 0 0,0 15.54,8.46Z"/></svg>
                    </span>
                    <span class="icon-context-off" aria-hidden="true">
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M17,7H22V9H19V12H17V7M7,17V12H9V15H12V17H7M17.59,5L19,6.41L6.41,19L5,17.59L17.59,5M14.83,9.17A1,1 0 0,1 16.24,10.59L15.54,11.29L14.12,9.88L14.83,9.17M9.88,14.12L11.29,15.54L10.59,16.24A1,1 0 0,1 9.17,14.83L9.88,14.12M7.76,13.41A1,1 0 0,0 9.17,14.83L9.88,14.12L8.46,12.71L7.76,13.41M16.24,10.59A1,1 0 0,0 14.83,9.17L14.12,9.88L15.54,11.29L16.24,10.59Z"/></svg>
                    </span>
                </button>

                <div id="settings-control-container">
                    <button id="settings-button" title="AI 모델 및 프롬프트 설정">
                        <span class="settings-icon">
                            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12,8A4,4 0 0,1 16,12A4,4 0 0,1 12,16A4,4 0 0,1 8,12A4,4 0 0,1 12,8M12,10A2,2 0 0,0 10,12A2,2 0 0,0 12,14A2,2 0 0,0 14,12A2,2 0 0,0 12,10M19.43,12.97C19.47,12.65 19.5,12.33 19.5,12C19.5,11.67 19.47,11.34 19.43,11L21.54,9.37C21.73,9.22 21.78,8.95 21.66,8.73L19.66,5.27C19.54,5.05 19.27,4.96 19.05,5.05L16.56,6.05C16.04,5.66 15.5,5.32 14.87,5.07L14.5,2.42C14.46,2.18 14.25,2 14,2H10C9.75,2 9.54,2.18 9.5,2.42L9.13,5.07C8.5,5.32 7.96,5.66 7.44,6.05L4.95,5.05C4.73,4.96 4.46,5.05 4.34,5.27L2.34,8.73C2.21,8.95 2.27,9.22 2.46,9.37L4.57,11C4.53,11.34 4.5,11.67 4.5,12C4.5,12.33 4.53,12.65 4.57,12.97L2.46,14.63C2.27,14.78 2.21,15.05 2.34,15.27L4.34,18.73C4.46,18.95 4.73,19.03 4.95,18.95L7.44,17.94C7.96,18.34 8.5,18.68 9.13,18.93L9.5,21.58C9.54,21.82 9.75,22 10,22H14C14.25,22 14.46,21.82 14.5,21.58L14.87,18.93C15.5,18.68 16.04,18.34 16.56,17.94L19.05,18.95C19.27,19.03 19.54,18.95 19.66,18.73L21.66,15.27C21.78,15.05 21.73,14.78 21.54,14.63L19.43,12.97Z" /></svg>
                        </span>
                        <span id="settings-display-text" class="settings-copy"></span>
                        <span class="settings-chevron" aria-hidden="true">
                            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M7,10L12,15L17,10H7Z" /></svg>
                        </span>
                    </button>
                    <div id="settings-popover" class="custom-popover">
                        <div class="popover-section">
                            <div class="popover-section-head">
                                <span class="popover-kicker">Connection</span>
                                <label>API 프리셋</label>
                                <p>활성 프리셋을 바꾸거나 상세 설정을 열 수 있습니다.</p>
                            </div>
                            <div class="prompt-popover-group">
                                <select id="api-preset-selector"></select>
                                <button id="manage-api-settings-btn" class="popover-manage-btn" title="API 프리셋 관리" aria-label="API 프리셋 관리">
                                    <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12,8A4,4 0 0,1 16,12A4,4 0 0,1 12,16A4,4 0 0,1 8,12A4,4 0 0,1 12,8M12,10A2,2 0 0,0 10,12A2,2 0 0,0 12,14A2,2 0 0,0 14,12A2,2 0 0,0 12,10M19.43,12.97C19.47,12.65 19.5,12.33 19.5,12C19.5,11.67 19.47,11.34 19.43,11L21.54,9.37C21.73,9.22 21.78,8.95 21.66,8.73L19.66,5.27C19.54,5.05 19.27,4.96 19.05,5.05L16.56,6.05C16.04,5.66 15.5,5.32 14.87,5.07L14.5,2.42C14.46,2.18 14.25,2 14,2H10C9.75,2 9.54,2.18 9.5,2.42L9.13,5.07C8.5,5.32 7.96,5.66 7.44,6.05L4.95,5.05C4.73,4.96 4.46,5.05 4.34,5.27L2.34,8.73C2.21,8.95 2.27,9.22 2.46,9.37L4.57,11C4.53,11.34 4.5,11.67 4.5,12C4.5,12.33 4.53,12.65 4.57,12.97L2.46,14.63C2.27,14.78 2.21,15.05 2.34,15.27L4.34,18.73C4.46,18.95 4.73,19.03 4.95,18.95L7.44,17.94C7.96,18.34 8.5,18.68 9.13,18.93L9.5,21.58C9.54,21.82 9.75,22 10,22H14C14.25,22 14.46,21.82 14.5,21.58L14.87,18.93C15.5,18.68 16.04,18.34 16.56,17.94L19.05,18.95C19.27,19.03 19.54,18.95 19.66,18.73L21.66,15.27C21.78,15.05 21.73,14.78 21.54,14.63L19.43,12.97Z" /></svg>
                                </button>
                            </div>
                        </div>
                        <div class="popover-section">
                            <div class="popover-section-head">
                                <span class="popover-kicker">Model</span>
                                <label>AI 모델</label>
                                <p>현재 프리셋에서 사용할 모델을 빠르게 전환합니다.</p>
                            </div>
                            <div class="prompt-popover-group">
                                <select id="ai-model-selector"></select>
                            </div>
                        </div>
                        <div class="popover-section">
                            <div class="popover-section-head">
                                <span class="popover-kicker">Template</span>
                                <label>프롬프트 템플릿</label>
                                <p>대화 스타일과 역할 템플릿을 선택하거나 관리합니다.</p>
                            </div>
                            <div class="prompt-popover-group">
                                <select id="quick-prompt-select"></select>
                                <button id="manage-prompts-btn" class="popover-manage-btn" title="프롬프트 템플릿 관리" aria-label="프롬프트 템플릿 관리">
                                    <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M6,2H18A2,2 0 0,1 20,4V20A2,2 0 0,1 18,22H6A2,2 0 0,1 4,20V4A2,2 0 0,1 6,2M6,4V20H18V4H6M9,9H15V11H9V9M9,13H15V15H9V13Z" /></svg>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="chat-messages" id="chat-messages">
                <div id="chat-welcome-message">
                    <h3>Ailey & Bailey</h3>
                    <p>새 대화를 시작해보세요.</p>
                </div>
            </div>

            <div id="chat-composer-shell">
                <div id="attached-file-display" aria-live="polite"></div>
                <form class="chat-input-form" id="chat-form">
                    <button type="button" id="chat-attach-btn" title="파일 추가">
                        <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M16.5,6V17.5A4,4 0 0,1 12.5,21.5A4,4 0 0,1 8.5,17.5V5A2.5,2.5 0 0,1 11,2.5A2.5,2.5 0 0,1 13.5,5V15.5A1,1 0 0,1 12.5,16.5A1,1 0 0,1 11.5,15.5V6H10V15.5A2.5,2.5 0 0,0 12.5,18A2.5,2.5 0 0,0 15,15.5V5A4,4 0 0,0 11,1A4,4 0 0,0 7,5V17.5A5.5,5.5 0 0,0 12.5,23A5.5,5.5 0 0,0 18,17.5V6H16.5Z" /></svg>
                    </button>
                    <textarea id="chat-input" placeholder="Ailey & Bailey에게 질문하기..." rows="1" disabled></textarea>
                    <button type="submit" id="chat-send-btn" title="전송">
                        <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M2,21L23,12L2,3V10L17,12L2,14V21Z" /></svg>
                    </button>
                </form>
                <div class="chat-composer-meta">
                    <span id="chat-attachment-hint">이미지, PDF, 텍스트 파일을 여러 개 붙여넣거나 끌어놓을 수 있습니다.</span>
                </div>
            </div>
        </div>
    </div>
`;
