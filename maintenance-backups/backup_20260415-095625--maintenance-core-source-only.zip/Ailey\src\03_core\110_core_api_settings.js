/* --- Ailey & Bailey Canvas --- */
// File: 110_core_api_settings.js
// Version: 9.6 (Thinking Budget Slider)
// Description: Updated saving logic to read from the new toggle switch and slider for 'Thinking Budget'.

// [GLOBAL STATE] These are managed by the modal's internal logic
let tempPresets = [];
let selectedPresetId = null;
let isEditingNewPreset = false;
let tokenUsageCountdownInterval = null; // For dynamic countdown

function syncLocalApiSettingsStorage() {
    const isCanvasMode = (typeof __firebase_config !== 'undefined');
    if (!isCanvasMode && typeof persistLocalApiSettingsToStorage === 'function') {
        persistLocalApiSettingsToStorage();
    }
}

function openApiSettingsModal() {
    const isCanvasMode = (typeof __firebase_config !== 'undefined');
    if (!isCanvasMode) {
        if (typeof hydrateLocalApiSettingsFromStorage === 'function') {
            hydrateLocalApiSettingsFromStorage();
        } else {
            const localPresets = localStorage.getItem('ailey_local_api_presets');
            const localActiveId = localStorage.getItem('ailey_local_active_preset_id');
            if (localPresets) {
                userApiSettings.apiPresets = JSON.parse(localPresets);
            }
            if (localActiveId) {
                userApiSettings.activePresetId = localActiveId;
            }
        }
    }

    let modal = document.getElementById('api-settings-modal-overlay');

    if (!modal || !modal.dataset.listenersAttached) {
        if (!modal) createApiSettingsModal();
        attachApiSettingsEventListeners();
        modal = document.getElementById('api-settings-modal-overlay');
        modal.dataset.listenersAttached = 'true';
    }

    // Clear any previous interval when opening the modal
    if (tokenUsageCountdownInterval) {
        clearInterval(tokenUsageCountdownInterval);
    }

    // [NEW] Proactive Daily Rollover Check for better UX
    const currentDateInPST = new Date().toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' });
    let settingsChanged = false;

    (userApiSettings.apiPresets || []).forEach(preset => {
        const usage = preset.tokenUsage;
        if (usage && usage.lastRequestDate && usage.lastRequestDate !== currentDateInPST) {
            trace("API.Usage", "ModalOpen.Rollover", { preset: preset.name, lastDate: usage.lastRequestDate, newDate: currentDateInPST });
            
            usage.totalRequests = (usage.totalRequests || 0) + (usage.todayRequests || 0);
            usage.prompt = (usage.prompt || 0) + (usage.todayPromptTokens || 0);
            usage.completion = (usage.completion || 0) + (usage.todayCompletionTokens || 0);

            usage.todayRequests = 0;
            usage.todayPromptTokens = 0;
            usage.todayCompletionTokens = 0;
            usage.dailyModelUsage = {};
            // Don't update lastRequestDate here, let the next API call set it,
            // or it might prevent rollover if the user opens/closes the modal without making a call.
            
            settingsChanged = true;
        }
    });

    if (settingsChanged) {
        saveUserSettingsToFirebase(true);
    }
    
    // Deep copy presets for temporary editing state
    tempPresets = JSON.parse(JSON.stringify(userApiSettings.apiPresets || []));
    
    const universalPreset = { id: 'universal', name: '범용 모델 (기본)', provider: 'Google', isUniversal: true };
    tempPresets.unshift(universalPreset);

    isEditingNewPreset = false;
    
    if (userApiSettings.activePresetId === null) {
        selectedPresetId = 'universal';
    } else if (tempPresets.some(p => p.id === userApiSettings.activePresetId)) {
        selectedPresetId = userApiSettings.activePresetId;
    } else {
        selectedPresetId = 'universal'; // Fallback
    }
    
    handlePresetSelection(selectedPresetId); // This will render editor, list, and usage

    // Set a new interval to update the countdown
    tokenUsageCountdownInterval = setInterval(() => {
        const preset = tempPresets.find(p => p.id === selectedPresetId);
        // Only call renderTokenUsage if the usage tab is visible to save resources
        const usageTab = document.querySelector('#api-settings-tab-usage');
        if (usageTab && usageTab.classList.contains('active')) {
            renderTokenUsage(preset);
        }
    }, 1000);


    highestZIndex++;
    modal.style.zIndex = highestZIndex;
    modal.style.display = 'flex';
}

function closeApiSettingsModal() {
    const modal = document.getElementById('api-settings-modal-overlay');
    if (modal) modal.style.display = 'none';

    // Clear the interval when closing the modal
    if (tokenUsageCountdownInterval) {
        clearInterval(tokenUsageCountdownInterval);
        tokenUsageCountdownInterval = null;
    }

    updateChatHeaderModelSelector();
}

function handlePresetSelection(presetId) {
    isEditingNewPreset = false;
    selectedPresetId = presetId;
    const preset = tempPresets.find(p => p.id === presetId);
    
    // Switch to the basic tab when a new preset is selected
    const modal = document.getElementById('api-settings-modal-overlay');
    if (modal) {
        modal.querySelectorAll('.api-settings-tab-btn').forEach(btn => btn.classList.remove('active'));
        modal.querySelectorAll('.api-settings-tab-panel').forEach(panel => panel.classList.remove('active'));
        modal.querySelector('.api-settings-tab-btn[data-tab="basic"]').classList.add('active');
        modal.querySelector('#api-settings-tab-basic').classList.add('active');
    }

    renderApiPresetsList();
    renderApiPresetEditor(preset);
    renderTokenUsage(preset);
}

function handleAddNewPreset() {
    isEditingNewPreset = true;
    selectedPresetId = `new-${Date.now()}`;
    const selectedItem = document.querySelector('.api-preset-item.selected');
    if(selectedItem) selectedItem.classList.remove('selected');
    renderApiPresetEditor(null);
    renderTokenUsage(null); // Clear usage tab as well
    document.getElementById('api-preset-name-input').focus();
}

async function handleSaveAndActivatePreset() {
    if (selectedPresetId === 'universal') {
        userApiSettings.activePresetId = null;
        
        const maxOutputTokens = Number(document.getElementById('max-output-tokens-input').value) || 65536;
        const temperature = parseFloat(document.getElementById('api-temperature-slider').value);
        const topP = parseFloat(document.getElementById('api-top-p-slider').value);
        const useGrounding = document.getElementById('google-grounding-toggle').checked;
        const chatHistoryLimit = Number(document.getElementById('chat-history-limit-input').value);
        const autoCompactEnabled = document.getElementById('chat-auto-compact-toggle')?.checked !== false;

        userApiSettings.universalModelSettings = {
            maxOutputTokens,
            temperature,
            topP,
            useGrounding,
            chatHistoryLimit: isNaN(chatHistoryLimit) ? 20 : chatHistoryLimit,
            autoCompactEnabled
        };
        
        syncLocalApiSettingsStorage();
        
        await saveUserSettingsToFirebase();
        closeApiSettingsModal();
        return;
    }

    const name = document.getElementById('api-preset-name-input').value.trim();
    const key = document.getElementById('api-key-input').value.trim();
    
    if (!name || !key) {
        showModal("프리셋 이름과 API 키를 모두 입력해야 합니다.", () => {});
        return;
    }
    
    const provider = detectProvider(key);
    if (!provider) {
        showModal("유효하지 않은 API 키 형식입니다. 키를 다시 확인하거나 재검증해주세요.", () => {});
        return;
    }

    const modelSelect = document.getElementById('api-model-select');
    if (modelSelect.disabled || modelSelect.options.length === 0 || !modelSelect.options[0].value) {
        showModal("API 키를 먼저 검증해주세요.", () => {});
        return;
    }
    
    const selectedModel = modelSelect.value;
    const availableModels = Array.from(modelSelect.options).map(opt => opt.value);
    const maxOutputTokens = Number(document.getElementById('max-output-tokens-input').value) || 65536;
    const temperature = parseFloat(document.getElementById('api-temperature-slider').value);
    const topP = parseFloat(document.getElementById('api-top-p-slider').value);
    const useGrounding = document.getElementById('google-grounding-toggle').checked;
    const chatHistoryLimit = Number(document.getElementById('chat-history-limit-input').value);
    const autoCompactEnabled = document.getElementById('chat-auto-compact-toggle')?.checked !== false;

    // --- Thinking Budget Saving Logic ---
    let finalThinkingBudget = null;
    const thinkingBudgetToggle = document.getElementById('thinking-budget-toggle');
    if (thinkingBudgetToggle && thinkingBudgetToggle.checked) {
        const thinkingBudgetSlider = document.getElementById('api-thinking-budget-slider');
        finalThinkingBudget = parseInt(thinkingBudgetSlider.value, 10);
    }
    // --- End Saving Logic ---


    const presetData = {
        name, key, provider, selectedModel, availableModels, maxOutputTokens,
        temperature, topP, useGrounding, chatHistoryLimit: isNaN(chatHistoryLimit) ? 20 : chatHistoryLimit,
        autoCompactEnabled,
        thinkingBudget: finalThinkingBudget,
        tokenUsage: { prompt: 0, completion: 0, todayRequests: 0, totalRequests: 0, lastRequestDate: null, dailyModelUsage: {}, todayPromptTokens: 0, todayCompletionTokens: 0 } 
    };

    if (isEditingNewPreset) {
        presetData.id = selectedPresetId;
        userApiSettings.apiPresets.push(presetData);
    } else {
        presetData.id = selectedPresetId;
        const index = userApiSettings.apiPresets.findIndex(p => p.id === selectedPresetId);
        if (index !== -1) {
            presetData.tokenUsage = userApiSettings.apiPresets[index].tokenUsage; // Preserve usage
            userApiSettings.apiPresets[index] = presetData;
        } else {
             userApiSettings.apiPresets.push(presetData); // Should not happen, but as a fallback
        }
    }
    
    userApiSettings.activePresetId = presetData.id;
    
    syncLocalApiSettingsStorage();
    
    await saveUserSettingsToFirebase();
    closeApiSettingsModal();
}

function handleDeletePreset() {
    if (isEditingNewPreset || !selectedPresetId || selectedPresetId === 'universal') return;

    const preset = tempPresets.find(p => p.id === selectedPresetId);
    if (!preset) return;

    showModal(`프리셋 '${preset.name}'을(를) 정말 삭제하시겠습니까?`, async () => {
        userApiSettings.apiPresets = userApiSettings.apiPresets.filter(p => p.id !== selectedPresetId);
        
        if (userApiSettings.activePresetId === selectedPresetId) {
            userApiSettings.activePresetId = null; // Revert to universal
        }
        
        syncLocalApiSettingsStorage();
        
        await saveUserSettingsToFirebase();

        // Refresh modal state
        tempPresets = JSON.parse(JSON.stringify(userApiSettings.apiPresets));
        const universalPreset = { id: 'universal', name: '범용 모델 (기본)', provider: 'Google', isUniversal: true };
        tempPresets.unshift(universalPreset);
        
        selectedPresetId = userApiSettings.activePresetId === null ? 'universal' : userApiSettings.activePresetId;
        isEditingNewPreset = false;

        handlePresetSelection(selectedPresetId);

        showToastNotification("✅ 프리셋이 삭제되었습니다.", "", `preset-delete-${Date.now()}`);
    });
}

function resetTokenUsage() {
    if (!selectedPresetId || selectedPresetId === 'universal') return;
    
    const presetInTemp = tempPresets.find(p => p.id === selectedPresetId);
    if (!presetInTemp) return;

    showModal(`'${presetInTemp.name}' 프리셋의 누적 사용량을 정말로 초기화하시겠습니까?`, async () => {
        const emptyUsage = { prompt: 0, completion: 0, todayRequests: 0, totalRequests: 0, lastRequestDate: null, dailyModelUsage: {}, todayPromptTokens: 0, todayCompletionTokens: 0 };

        // Update temp state for immediate UI refresh
        presetInTemp.tokenUsage = { ...emptyUsage };

        // Update permanent state for saving
        const presetInReal = userApiSettings.apiPresets.find(p => p.id === selectedPresetId);
        if (presetInReal) {
            presetInReal.tokenUsage = { ...emptyUsage };
        }
        
        syncLocalApiSettingsStorage();
        
        await saveUserSettingsToFirebase(true);
        
        // Re-render the usage tab with the updated (now empty) data
        renderTokenUsage(presetInTemp); 
    });
}

function attachApiSettingsEventListeners() {
    const modal = document.getElementById('api-settings-modal-overlay');
    if (!modal) return;

    modal.querySelector('#api-add-new-preset-btn').addEventListener('click', handleAddNewPreset);
    modal.querySelector('#verify-api-key-btn').addEventListener('click', handleVerifyApiKey);
    modal.querySelector('#api-settings-save-btn').addEventListener('click', handleSaveAndActivatePreset);
    modal.querySelector('#api-settings-delete-btn').addEventListener('click', handleDeletePreset);
    modal.querySelector('#api-settings-cancel-btn').addEventListener('click', closeApiSettingsModal);
    modal.querySelector('#reset-token-usage-btn').addEventListener('click', resetTokenUsage);
    
    modal.addEventListener('click', (e) => { if (e.target === modal) closeApiSettingsModal(); });

    modal.querySelector('#api-temperature-slider').addEventListener('input', (e) => {
        modal.querySelector('#api-temperature-value').textContent = parseFloat(e.target.value).toFixed(2);
    });
    modal.querySelector('#api-top-p-slider').addEventListener('input', (e) => {
        modal.querySelector('#api-top-p-value').textContent = parseFloat(e.target.value).toFixed(2);
    });

    // New Thinking Budget listeners
    const thinkingBudgetToggle = modal.querySelector('#thinking-budget-toggle');
    const thinkingBudgetControls = modal.querySelector('#thinking-budget-controls');
    const thinkingBudgetSlider = modal.querySelector('#api-thinking-budget-slider');
    const thinkingBudgetValue = modal.querySelector('#api-thinking-budget-value');
    const modelSelect = modal.querySelector('#api-model-select');

    if (thinkingBudgetToggle) {
        thinkingBudgetToggle.addEventListener('change', () => {
            const isEnabled = thinkingBudgetToggle.checked;
            thinkingBudgetControls.classList.toggle('disabled', !isEnabled);
            if (isEnabled) {
                 const currentVal = parseInt(thinkingBudgetSlider.value, 10);
                 if (currentVal === 0) {
                     const isPro = (modelSelect.value || '').includes('pro');
                     const defaultVal = isPro ? 128 : 1024;
                     thinkingBudgetSlider.value = defaultVal;
                     thinkingBudgetValue.textContent = defaultVal;
                 }
            }
        });
    }

    if (thinkingBudgetSlider) {
        thinkingBudgetSlider.addEventListener('input', () => {
            thinkingBudgetValue.textContent = thinkingBudgetSlider.value;
        });
    }


    const tabsContainer = modal.querySelector('.api-settings-tabs');
    if (tabsContainer) {
        tabsContainer.addEventListener('click', (e) => {
            const tabBtn = e.target.closest('.api-settings-tab-btn');
            if (!tabBtn || tabBtn.disabled) return;

            const targetTab = tabBtn.dataset.tab;
            
            modal.querySelectorAll('.api-settings-tab-btn').forEach(btn => btn.classList.remove('active'));
            modal.querySelectorAll('.api-settings-tab-panel').forEach(panel => panel.classList.remove('active'));

            tabBtn.classList.add('active');
            const targetPanel = modal.querySelector(`#api-settings-tab-${targetTab}`);
            if (targetPanel) {
                targetPanel.classList.add('active');
                // When switching to the usage tab, render it immediately
                if (targetTab === 'usage') {
                    const preset = tempPresets.find(p => p.id === selectedPresetId);
                    renderTokenUsage(preset);
                }
            }
        });
    }
}
