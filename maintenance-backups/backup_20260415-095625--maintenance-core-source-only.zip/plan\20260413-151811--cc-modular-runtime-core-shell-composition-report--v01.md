# Report: `.cc` Modular Runtime With Always-On Core Shell

## Outcome

Implemented a first-pass runtime modularization that keeps the shared shell alive while separating shell mounting from content mounting.

## What Changed

### 1. Core shell is now a reusable mount path

- Added runtime helpers in `Ailey/src/00_shell/005_shell_part6_main_assembler.js`:
  - `ensureCoreShellMounted(...)`
  - `mountCanvasContent(...)`
  - `renderCanvasRuntime(...)`
- `renderAppShell(...)` now acts as a compatibility wrapper instead of owning the whole render pipeline itself.

### 2. Header, chat, and notes stay part of the guaranteed shell

- The runtime now checks whether the core shell is already mounted.
- If it is already present, it reuses it and swaps content instead of rebuilding the entire body by default.
- This protects the long-lived shell surfaces the user explicitly wanted:
  - top header
  - chat
  - notes

### 3. Content mounting gained a freer path

- Added layout detection for HTML content:
  - default: `standard`
  - opt-in: `free` via `data-shell-layout="free"` or equivalent future layout option
- The standard path still uses the classic `wrapper` + `container`.
- The free path mounts content through the canonical learning root without forcing the classic narrow article wrapper.

### 4. Core initialization is no longer blindly repeated

- Added `isCoreShellInitialized` state.
- `initializeCoreFeatures()` now:
  - runs the full shell boot only once
  - reuses the existing shell on later content renders
  - still runs content-side auto-generation checks for newly mounted placeholders

### 5. Small resilience improvements

- Canvas metadata is now upserted instead of appended blindly every render.
- `rebindDOMElements()` now falls back more safely when `learning-content` is mounted through a freer path.
- Added minimal CSS support for `.canvas-content-host`.

## Files Changed

- `Ailey/src/00_shell/005_shell_part6_main_assembler.js`
- `Ailey/src/01_state/001_state_globalVars.js`
- `Ailey/src/03_core/120_core_main_initializer.js`
- `Ailey/src_css/001_base.css`
- `visual-tests/runtime_modular_free_mode_fixture.html`

## Backups

- Runtime pre-edit backup:
  - `backups/runtime-modularization/20260413-151811/`

## Verification

### Build

- Rebuilt successfully with:
  - `node Ailey/bundler.js`

### DOM checks

Verified through headless browser automation against:

1. `Ailey/index.html`
2. `visual-tests/runtime_modular_free_mode_fixture.html`

Both pages contained:

- `#immersive-header`
- `#chat-panel`
- `#notes-app-panel`
- `#ai-content-placeholder`
- `#learning-content`

The free-mode fixture also preserved:

- `data-shell-layout="free"`

### Artifacts

- Screenshots:
  - `visual-tests/20260413-151811-runtime-modular-check/local-mode.png`
  - `visual-tests/20260413-151811-runtime-modular-check/free-mode.png`
- DOM captures:
  - `visual-tests/20260413-151811-runtime-modular-check/local-mode.dom.html`
  - `visual-tests/20260413-151811-runtime-modular-check/free-mode.dom.html`

## Notes

- For this pass, `renderAppShell(...)` remains the public compatibility contract.
- The meaningful change is internal: it no longer has to own both shell construction and content transformation as one inseparable step.
- This gives the runtime a safer base for future work such as:
  - alternate content mount modes
  - richer hybrid layouts
  - reduced dependence on a single rigid article surface

## Remaining Follow-up Opportunities

- Move more shell/runtime helpers into dedicated source files instead of keeping the first refactor concentrated in the shell assembler.
- Add an explicit documented layout contract for future `.cc` outputs.
- Decide whether live export should continue targeting `renderAppShell(...)` only or graduate to the newer runtime helpers over time.
