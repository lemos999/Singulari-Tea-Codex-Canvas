Plan Type: Work Plan
Workstream: Mobile Chat Session Return Affordance
Version: v01
Status: Completed
Created: 2026-04-14 17:09:35 +09:00
Last Updated: 2026-04-14 17:19:10 +09:00
Supersedes or Related Plan: Supersedes `plan/20260414-100500--work-plan--mobile-ui-refinement-and-scroll-reliability--v01.md` as the active mobile follow-up plan while staying in the same broader refinement stream
Current Completion State: Implemented, validated, documented, and published
Completed So Far: Collected the new mobile feedback, confirmed the issue from screenshots, traced the sidebar open-close behavior through the shell markup, state bindings, click delegation, and mobile CSS, added a mobile-only return affordance inside the session list, wired it to the existing `mobile-sidebar-open` state path, extended validation to prove the new button closes the drawer and restores main chat interaction, rebuilt the bundle, synced the publish repo, and pushed GitHub commit `b3530d1`.
Remaining Work: None inside the approved scope
Current Blockers: None
Next Step: Hold for new user feedback or a future larger mobile navigation redesign pass.

# Scoreboard

Current Score: 90
Score Source: user
Last Updated: 2026-04-14 17:19:10 +09:00
Score Rationale: The user explicitly kept the mobile effort at 90 and this approved follow-up closed the remaining discoverability gap without destabilizing the earlier mobile fixes.
What Improved: The mobile chat session list now contains an explicit, in-context return affordance that closes the drawer and restores the main chat surface immediately. The validation suite now covers that path directly.
What Remains Unsatisfactory: The shell is still a refined desktop-derived mobile shell rather than a full route-based mobile app, so broader future UX work could still improve long-form phone use.
What Should Happen Next To Raise Or Maintain The Score: Wait for user reaction to the new return affordance. If the user still wants more mobile polish, the next high-value step is a more explicit mobile navigation model rather than further one-off density tweaks.

## Score History

- 2026-04-14 10:05:00 +09:00 | score=90 | source=user | User explicitly rated the earlier mobile foundation pass at 90 and approved follow-up mobile refinement work.
- 2026-04-14 10:48:00 +09:00 | score=90 | source=user | The previous mobile refinement pass completed successfully and retained the user score of 90.
- 2026-04-14 17:09:35 +09:00 | score=90 | source=user | The user approved a new mobile follow-up focused on a more discoverable return path from the chat session list back to the chat view. The authoritative user score remains 90 while this pass is in progress.
- 2026-04-14 17:19:10 +09:00 | score=90 | source=user | The explicit return affordance pass completed, validated, and shipped while preserving the authoritative user score of 90.

# Objective

Make the mobile chat session list self-explanatory by adding an explicit, clearly visible way to return to the active chat surface after opening the session list drawer. The result should remove the need to infer that tapping the blurred main panel will close the list, while preserving the clean layered behavior achieved in the previous pass.

# Why This Work Exists

The prior mobile refinement pass solved the structural problems that made the mobile chat shell unreliable: the drawer layering was cleaned up, the main content was de-emphasized when the drawer opened, and the scroll owner stopped trapping the user at the bottom. Those fixes made the mobile shell functionally sound, but they also exposed a second-order usability problem. Once the session list is open, the user can no longer rely on desktop instincts such as clicking a visible close affordance in the same area. The current mobile flow expects the user either to pick a different chat session or to intuit that tapping the faded main chat surface will dismiss the list. That behavior is technically acceptable yet discoverability-poor. The user explicitly reported that returning by re-clicking chat is not intuitive enough. This work exists to close that gap without undoing the stability work that already landed.

# In Scope

- The mobile chat session list drawer inside `#chat-panel`
- The visible header area of the mobile session list, especially `#sidebar-header`
- A new mobile-only return control or affordance that communicates "go back to chat"
- Close behavior for that control, including clean removal of `mobile-sidebar-open`
- Validation that the new control works on mobile and does not alter desktop sidebar collapse behavior
- Bundle rebuild, local verification evidence, publish sync, and final maintenance notes

# Out Of Scope

- A larger redesign of the entire mobile navigation model
- Changing how sessions are selected or rendered in the list
- Reworking the desktop chat sidebar UX
- Altering the current settings surface, chat composer, note panel, or visualization studio unless the new return control reveals a direct regression in those surfaces

# Confirmed Facts

- The user explicitly approved this follow-up.
- The user explicitly retained a score of 90 for the mobile work done so far.
- The mobile chat drawer already opens as a strong sheet-like surface and visually suppresses the main chat area.
- The current close behavior on mobile depends on either selecting a session or tapping outside the drawer region.
- The user considers that interaction insufficiently intuitive and wants a visible return path from the list back to the chat.
- The user supplied screenshots that show the current drawer state and clarify that the missing affordance is a discoverability issue, not a rendering crash.

# Safe Assumptions

- The smallest complete change is to add a mobile-only return button inside the session-list sheet rather than redesigning the whole header stack.
- The button should be physically close to the list header so the user sees it immediately after opening the drawer.
- The safest behavior is to reuse the existing `mobile-sidebar-open` state and close path instead of introducing a second visibility state.
- Desktop should continue using the current sidebar collapse toggle without seeing the new mobile-only control.

# User Experience Intent

The user should be able to open the mobile chat list, instantly understand that the current view is a temporary overlay, and see a plainly labeled or clearly iconized way to get back to the active chat. The affordance should feel native to touch use, visually belong to the drawer rather than the hidden main view, and never require guesswork. The drawer should still close when the user selects a session or taps outside, but those should become secondary convenience paths rather than the primary explicit instruction path.

# Technical Approach

Use a bounded, state-preserving enhancement:

1. Add a dedicated mobile-only return control inside the sidebar header markup so the button lives with the open drawer rather than the dimmed chat surface.
2. Bind the new control to the existing `mobile-sidebar-open` removal path so the drawer closes through the same state contract already used elsewhere.
3. Style the control to be visible and legible at mobile sizes without increasing header thickness materially.
4. Keep the control hidden in desktop layouts and avoid changing the desktop collapse affordance.
5. Extend the mobile validation script to assert that the drawer can be closed by the new button and that no page errors are introduced.

# Phased Work Sequence

## Phase 1: Plan And State Audit

Record the new follow-up plan and verify the exact state path that opens and closes the mobile drawer. Confirm where a new control can be added without breaking existing delegation or focus rules.

## Phase 2: Mobile Drawer Affordance Implementation

Add the new return button in the sidebar header, bind it to close the mobile drawer, and keep the implementation symmetrical with the existing toggle logic. Ensure the change is minimal and does not add a second state machine.

## Phase 3: Presentation Tuning

Style the new control so it is obvious, touch-friendly, and visually coherent with the renewed chat shell. Keep the mobile header slim and avoid reintroducing the oversized top chrome the user previously disliked.

## Phase 4: Validation

Extend the existing mobile test flow so it checks not only that the drawer opens, but also that the user can return to the chat surface via the new in-drawer affordance. Capture screenshots and assertion data for the new path.

## Phase 5: Publish And Record

Rebuild the local bundle, sync the publish repo, push the new GitHub commit, and record the outcome plus any remaining caveats in a new report file.

# Hidden Rules And Consistency Requirements

- The new return affordance must be visible from inside the open drawer; it must not depend on seeing or tapping the background content.
- The new control must not create a second source of truth for drawer state. The drawer should still be governed by `mobile-sidebar-open`.
- Desktop behavior must remain unchanged. The new button should either not render there or be visually suppressed there.
- The mobile header must remain slim; solving discoverability must not recreate a thick header band.
- Existing close behaviors should remain valid. Selecting a session and tapping outside the drawer can still close it, but they should no longer be the only intuitive options.
- The change should avoid pointer-event traps, duplicate buttons, or stale invisible layers that could regress the prior fix.

# Risks

## Risk: The new button duplicates or conflicts with the existing header toggle

Mitigation: Scope the new control to the sidebar sheet itself and keep the main-header toggle responsible only for opening the list from the chat surface.

## Risk: The new control makes the mobile header visually noisy

Mitigation: Keep the button compact, align it with the session-list header, and prefer one clear affordance over multiple explanatory labels.

## Risk: The button closes the drawer on desktop unexpectedly

Mitigation: Bind the close behavior so it only acts when the app is in `mobile-shell-mode`, and hide the control outside that mode.

## Risk: Existing outside-tap dismissal stops working

Mitigation: Reuse the current state transition and verify both the new button path and the old outside-dismiss fallback after the change.

# Validation Strategy

Validation should prove the following observable behaviors:

- On a mobile viewport, opening the chat session list still sets `mobile-sidebar-open`.
- The new return control is visible inside the open drawer.
- Activating the control clears `mobile-sidebar-open` and returns interaction to the main chat surface.
- The drawer no longer requires tapping the background to feel closable.
- Existing mobile behaviors from the previous pass still hold: the main surface becomes inert when the drawer is open, settings can still be opened cleanly, and no page or trace errors appear.
- On a desktop viewport, the chat shell continues using the normal sidebar collapse path and does not accidentally enter the mobile drawer flow.

# Definition Of Done

This pass is done when:

- the mobile chat session list contains an obvious in-context return affordance
- tapping that affordance returns the user to the chat view reliably
- desktop chat sidebar behavior is unchanged
- the mobile shell remains visually slim and no new overlap problems appear
- bundle rebuild succeeds
- validation evidence is saved
- the publish repo is updated and the GitHub Pages bundle is pushed
- this plan and the completion report clearly document the change

# Rollback And Safety Notes

Rollback should be trivial because this pass should only touch the chat shell markup, related CSS, the existing event binding surface, and validation coverage. If the new affordance causes unexpected interaction regressions, the safest rollback is to remove the control and its handler while leaving the previous mobile drawer mechanics intact. No data model, storage, or network behavior should be involved.

# Maintenance Notes

Future maintainers should treat this change as a discoverability enhancement layered on top of the mobile drawer architecture that already exists. If a later mobile redesign introduces a full bottom-tab or route-based navigation model, this button may become unnecessary and should then be removed deliberately rather than left as redundant chrome. Until then, it serves as the explicit "return to live conversation" affordance inside the current sheet model.

# Progress Log

- 2026-04-14 17:09:35 +09:00 | Created the new active follow-up plan after user approval. Confirmed the request is a bounded mobile discoverability fix: the session list needs a visible in-drawer return control, not another major shell redesign.
- 2026-04-14 17:13:00 +09:00 | Added the mobile-only return button to the session-list shell, bound it to the existing mobile drawer close path, and tuned the sidebar CSS so it appears inside the open drawer without thickening the mobile header elsewhere.
- 2026-04-14 17:17:08 +09:00 | Validation passed using `visual-tests/mobile-ui-refinement-2026-04-14T08-17-08-624Z/`. The new return button was visible, closed the sidebar, restored main-chat interaction, and preserved all prior mobile and desktop assertions with `pageErrorCount=0` and `traceErrorCount=0`.
- 2026-04-14 17:19:10 +09:00 | Synced `Ailey/bundle/main.js` and `Ailey/bundle/main.css` to the publish repo, pushed GitHub commit `b3530d1` on `lemos999/Singulari-Tea-Codex-Canvas`, and prepared the completion report for this follow-up.

