# Work Plan

Plan Type: Work Plan
Workstream: Universal `.cc` multi-topic visual validation
Version: v01
Status: Completed
Created: 2026-04-13 13:30:00 +09:00
Last Updated: 2026-04-13 13:48:00 +09:00
Related Plan:
- `plan/20260413-131000--work-plan--cc-universal-blind-render-test--v01.md`
Supersedes: None

Approval Record

- The user approved a new validation pass focused on actual rendered feel, not only HTML structure.
- The user asked that I test multiple topics by applying `.cc` directly and checking how they really look.
- The current approved instruction is: `응 너가 다양한주제로도 .cc 붙여서 테스트해봐 실시`.

Objective

Validate the universal `.cc` module across multiple topic types by generating representative `.cc` artifacts, rendering them visually, and checking whether the resulting pages follow shell rules while also feeling structurally and visually credible.

Scope

This run includes:

1. generating several `.cc` sample artifacts for different topic classes
2. saving those HTML artifacts
3. rendering screenshots from the generated artifacts
4. reviewing structural metrics and visual feel together
5. refining `cc_universal_module_mm.md` if recurring failures appear

The goal of this run is not only contract fidelity but also visible quality: heading discipline, emphasis balance, placeholder judgment, and avoidance of repetitive template leakage.

Test Topics

1. `대항해시대` for historical and spatial explanation
2. `블랙홀` for scientific conceptual explanation
3. `TCP 3-way handshake` for technical process explanation
4. `세포호흡` for biological mechanism explanation

Current Completion State

- The universal module passed hostile-host review and a repaired blind single-topic test before this run.
- This run produced multi-topic rendered samples and screenshots across history, astronomy, networking, and biology.
- Two refinement passes were applied during the run.
- The current module now has broader rendered validation for minimal-host `.cc` use.

Validation Criteria

Each sample should be checked for:

1. exact `.cc` shell fidelity
2. sane heading behavior or credible plain-body fallback
3. reasonable `<strong>` density
4. no obvious classroom-template symmetry unless the topic genuinely demands it
5. appropriate use or non-use of `image-placeholder`
6. appropriate use or non-use of `visualization-placeholder`
7. placeholder prompt quality when present
8. overall rendered feel inside the Ailey runtime shell

Definition Of Done

This run is complete when the selected topics have been rendered and visually checked, recurring weaknesses have been documented, and the module has either been accepted for this broader bar or refined to correct the most important repeated defects.

Result: completed. The selected topics were rendered, recurring issues were identified, the module was refined twice, and the final visual batch reached an acceptable quality level.

Risks

1. A module can pass one topic and still drift on others.
2. Visual polish and structural honesty can conflict if the fallback stays too plain.
3. The minimal-host fallback may still overuse `<strong>` or underuse headings when tested across multiple subjects.

Next Step

Report the multi-topic findings to the user and, if requested, continue with a new batch or `.ccc`-specific visual validation.

Findings Summary

Initial Batch Findings

1. All four first-pass samples rendered without visible heading anchors inside `#ai-content-placeholder`.
2. The pages felt structurally flatter than they should, even when the shell itself was correct.
3. On several process-heavy samples, runtime placeholder behavior surfaced settings overlays that visually dominated the page.
4. `<strong>` density and title-less fallback behavior still skewed toward generic explainer output.

Refinement Passes Applied

1. Added minimal-host fallback guidance favoring one honest `<h1>` for named-topic explanation queries.
2. Tightened sparse-`<strong>` guidance for short direct answers.
3. Added one-placeholder proportionality guidance for short minimal-host answers.
4. Added a more conservative placeholder rule when runtime readiness is unknown, especially for process topics where text alone can remain clear.

Final Visual Batch Result

Topic-level visual audit:

1. `대항해시대`
   - final feel: stable and readable
   - heading anchor: good
   - placeholder use: acceptable
   - visual audit score: `95`

2. `블랙홀`
   - final feel: strong heading anchor and readable body
   - image placeholder call: structurally valid, but local runtime still showed only a loading state instead of a resolved image
   - visual audit score: `93`

3. `TCP 3-way handshake`
   - final feel after targeted rerun: much cleaner without a placeholder-dominated center block
   - heading anchor: good
   - visual audit score: `96`

4. `세포호흡`
   - final feel after targeted rerun: clean and balanced
   - heading anchor: good
   - visual audit score: `96`

Visual Audit Average

- Final self-audited rendered average across the four topic classes: `95.0`

Scoreboard

Current Score: 50
Score Source: provisional
Last Updated: 2026-04-13 13:30:00 +09:00
Score Rationale: The multi-topic rendered batch was completed, issues were found and corrected, and the final visual batch reached a self-audited 95.0 average across four topic classes. The local provisional score still remains capped because the user has not yet provided an explicit score.
What Improved:
- The validation scope now covers multiple subject types.
- Screenshot-based inspection will expose visible weaknesses that HTML-only review can miss.
- Heading behavior is now materially better for minimal-host direct answers.
- Process topics no longer needlessly degrade into placeholder-dominated screens when text alone is clearer.
What Remains Unsatisfactory:
- Local runtime image resolution is still environment-sensitive, so the image-placeholder path is structurally tested more strongly than it is visually proven in this local run.
- The final batch is strong, but it still reflects hand-curated representative samples rather than uncontrolled live production traffic.
Actions To Raise Or Maintain The Score:
- Keep the new minimal-host heading guidance.
- Keep the conservative placeholder guidance for short process explanations.
- If needed, run a future `.ccc` batch or a larger uncontrolled `.cc` sample set.

Score History

- 2026-04-13 13:30:00 +09:00 | score 50 | source provisional | Multi-topic visual validation run started after the user asked for several direct `.cc` topic tests and visible quality checks.
- 2026-04-13 13:48:00 +09:00 | score 50 | source provisional | Multi-topic rendered batch completed with two refinements. Final self-audited visual average reached 95.0 across four topic classes, but the provisional score remains capped pending explicit user feedback.
