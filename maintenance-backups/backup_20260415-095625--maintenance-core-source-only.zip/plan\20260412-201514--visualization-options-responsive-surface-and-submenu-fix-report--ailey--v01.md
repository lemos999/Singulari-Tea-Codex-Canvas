# Visualization Options Responsive Surface And Submenu Fix Report

- Artifact Type: implementation-report
- Created: 2026-04-12 20:15:14 +09:00
- Scope: harden the visualization options studio during window resize and make the AI edit submenu reliably reachable
- Status: implemented-and-deployed-awaiting-user-validation

## User-Reported Symptoms

- shrinking the browser window could make the visualization options studio feel inaccessible or partially lost until the window was enlarged again
- moving from `AI edit` to `adjust options then regenerate` required an unnaturally fast pointer motion because the submenu could disappear across a tiny gap

## Root Cause

### 1. Visualization studio resize behavior

- the studio modal was large and centered inside a fixed overlay
- the overlay was not yet configured as a viewport-safe scrolling surface for aggressive resize cases
- the split layout also held onto the two-column arrangement too long while width was shrinking

### 2. AI edit submenu hover path

- the submenu sat with a visible horizontal gap from the parent menu item
- leaving the parent item closed the submenu immediately
- ordinary pointer travel could therefore drop out of the hover chain before the pointer reached the submenu

## Fix

### Visualization studio

- added viewport-safe padding and scrolling to `#visualization-options-modal-overlay`
- centered the modal with `margin: auto` instead of relying only on overlay centering
- clamped modal width and height directly against current viewport size
- moved the stacked-layout breakpoint earlier so the studio becomes columnar sooner

### AI edit submenu

- removed the effective hover gap by overlapping submenu placement slightly with the parent item
- added delayed close behavior
- kept the submenu open when the pointer enters the submenu itself

## Files Changed

- `Ailey/src_css/004_widget_visualization_options.css`
- `Ailey/src_css/008_context_menu.css`
- `Ailey/src/02_utils/012_utils_context_menu.js`

## Verification

- `node --check Ailey/src/02_utils/012_utils_context_menu.js`
- `node Ailey/bundler.js`

## Deployment

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `41a2670`
- commit message: `Harden visualization studio resize and submenu hover`

## Remaining Step

Manual browser validation by the user on real exported/live HTML is still required.
