# Ailey Visualization Scene Sizing Follow-up Report

- Artifact Type: implementation-report
- Created: 2026-04-12 14:12:00 +09:00
- Scope: reduce the “cropped scene” problem in exported Three.js and p5 visualizations by replacing the rigid normal-mode host box with profile-based sizing
- Related Plan: [20260412-095100--viz-rendering-fix-plan--ailey--v01.md](</c:/Users/Lemos/Desktop/새 폴더 (2)/plan/20260412-095100--viz-rendering-fix-plan--ailey--v01.md:1>)

## Problem

After the selector-collision fix, exported visualizations no longer escaped into full-screen overlay behavior, but some scene-like visualizations became too tightly boxed.

The concrete user repro was:

- file: [태양의 성계- 중력과 빛의 대서사시.html](</c:/Users/Lemos/Desktop/새 폴더 (2)/태양의 성계- 중력과 빛의 대서사시.html:114>)
- symptom: large Three.js and p5 scenes were technically rendering, but only a small or cropped portion felt visible by default

The underlying issue was that the current host policy still treated all visualizations the same:

- fixed bounded normal-mode sizing
- hidden overflow
- no distinction between a compact chart and a large interactive scene

## Code Changes

### [013_utils_block_renderer.js](</c:/Users/Lemos/Desktop/새 폴더 (2)/Ailey/src/02_utils/013_utils_block_renderer.js:524>)

- Added lightweight content heuristics that classify a block as either:
  - `standard`
  - `scene`
- Scene detection currently keys off common immersive-rendering signals such as:
  - `three.min.js`
  - `THREE.`
  - `WebGLRenderer`
  - `p5.min.js`
  - `createCanvas(...)`
  - common interactive-control markers
- Standard blocks now keep a moderate bounded height:
  - `clamp(420px, 54vh, 560px)`
- Scene-like blocks now receive a larger adaptive host height:
  - `clamp(560px, 72vh, 860px)`
- Scene-like blocks also receive:
  - `.viz-scene-block`
  - `.viz-scene-layout`

### [004_widget_visualization_options.css](</c:/Users/Lemos/Desktop/새 폴더 (2)/Ailey/src_css/004_widget_visualization_options.css:330>)

- Updated the default visualization host height to a moderate adaptive range for standard blocks
- Added scene-profile height rules for `.viz-scene-block` and `.viz-scene-layout`
- Added exported-live-only wide layout for scene blocks on large screens:
  - `width: min(1180px, calc(100vw - 48px))`
  - centered with `margin-left: 50%` and `transform: translateX(-50%)`
- Added responsive fallback so the wide layout collapses back to `width: 100%` on narrower screens
- Added mobile-specific height caps for both standard and scene profiles

## Verification

- `node --check Ailey/src/02_utils/013_utils_block_renderer.js`
- `node Ailey/bundler.js`
- Verified source changes for:
  - `viz-scene-block`
  - `viz-scene-layout`
  - scene height `clamp(560px, 72vh, 860px)`
  - export-only wide layout using `body[data-export-mode="live"]`
- Verified that new bundle hashes differed from the currently deployed hosted bundle before deployment

## Deployment

- Hosted bundle repo: `lemos999/Singulari-Tea-Codex-Canvas`
- Deployment method: direct push to `main`
- Bundle commit: `7dadd92`
- Reflected assets:
  - `bundle/main.js`
  - `bundle/main.css`

## Current Status

- Previous full-screen takeover bug: still fixed
- New scene-sizing follow-up: implemented and deployed
- Current score state in the active plan: `45` provisional
- Remaining step: user re-test of the exported scene-heavy HTML
