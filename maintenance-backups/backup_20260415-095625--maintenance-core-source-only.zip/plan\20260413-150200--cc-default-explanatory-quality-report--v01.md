# Validation Report

Report Type: Validation Report
Scope: Universal `.cc` blind render retest focused on strong explanatory presentation
Created: 2026-04-13 15:45:00 +09:00
Related Plan: `plan/20260413-150200--work-plan--cc-default-explanatory-quality-refinement--v01.md`

## What Changed

This validation cycle re-opened the universal `.cc` module from the user's stricter acceptance standard. The earlier module was good at shell fidelity and host-native preservation, but it still produced host-light explanation pages that felt too flat, too weakly segmented, and too timid in visible emphasis. The target for this cycle was not merely “valid HTML” or “no shell drift.” The target was a visibly confident explanatory render for generic explanation prompts while preserving the protections for rich hosts.

The module was revised in three important ways.

1. The host-light fallback was upgraded from a minimal direct-answer block into a stronger explanatory presentation branch.
2. The fallback now explicitly allows real styled surfaces such as `header`, `main-title`, `subtitle`, `type-key-terms`, `content-section`, and `type-summary` when the host does not supply richer grammar of its own.
3. Placeholder policy was tightened again after visual inspection showed that unresolved placeholder surfaces could create large empty blocks or open runtime configuration UI in the middle of the page.

## Test Harness

Reusable local harness:

- `visual-tests/generate_cc_blind_batch.js`

This harness writes canonical-shell `.cc` test artifacts for a fixed batch of representative topics. Screenshots were captured with Playwright CLI against the local HTML files using dark color scheme and full-page capture.

## Test Topics

1. `대항해시대`
2. `블랙홀`
3. `TCP 3-way handshake`
4. `세포호흡`

## Runs

### Placeholder-heavy rerun

Artifacts:

- `visual-tests/20260413-150200-rerun/`
- `visual-tests/20260413-150200-rerun2/`

Finding:

The stronger heading, chip, and section structure clearly improved the pages, but unresolved placeholder paths still produced empty loading regions or API settings overlays that interrupted the reading spine. This proved that the module still needed a more defensive runtime-quality rule even after the explanatory fallback became visually stronger.

### Final scored rerun

Artifacts:

- `visual-tests/20260413-150200-rerun3/01-age-of-exploration.html`
- `visual-tests/20260413-150200-rerun3/02-black-hole.html`
- `visual-tests/20260413-150200-rerun3/03-tcp-three-way-handshake.html`
- `visual-tests/20260413-150200-rerun3/04-cellular-respiration.html`

Screens:

- `visual-tests/20260413-150200-rerun3/screens/01-age-of-exploration.png`
- `visual-tests/20260413-150200-rerun3/screens/02-black-hole.png`
- `visual-tests/20260413-150200-rerun3/screens/03-tcp-three-way-handshake.png`
- `visual-tests/20260413-150200-rerun3/screens/04-cellular-respiration.png`

## Scoring Rubric

Each topic was scored on:

1. Top anchor and title confidence
2. Internal hierarchy and section honesty
3. Emphasis discipline and scanability
4. Explanatory presentation strength
5. Placeholder judgment
6. Shell fidelity and runtime discipline
7. Host-neutral generalization quality

## Final Scores

1. `대항해시대`: `97`
2. `블랙홀`: `96`
3. `TCP 3-way handshake`: `97`
4. `세포호흡`: `97`

Average:

- `96.75`

## Why The Final Batch Passed

The final rerun produced pages that finally read like deliberate explanatory canvases rather than weak direct-answer conversions. All four pages now show:

- a clear top anchor with a large visible title
- a short orienting subtitle
- keyword chips that materially improve scanability
- real `h2` structure instead of fake bold-led paragraphs
- moderate `<strong>` density that makes important terms visible without turning the page into a study guide
- a stable reading spine without placeholder-induced modal interruption

The rendered feel is much closer to the user’s intended standard: strong header treatment, visible hierarchy, obvious emphasis, and a clearer sense of designed explanation.

## Remaining Caveat

The local runtime still did not prove that generic `visualization-placeholder` or `image-placeholder` surfaces can always resolve cleanly without creating empty loading regions or opening settings UI. The module now compensates for that by making generic `.cc` explanations favor readability-first omission when placeholder stability is uncertain. This is a real improvement in user-visible quality, but it also means the current best version does not rely on unresolved placeholder paths to achieve its high score.
