Plan Type: Work Plan
Workstream: Universal `.cc` blind freedom stress test
Version: v01
Status: Completed
Created: 2026-04-13 16:14:43 +09:00
Last Updated: 2026-04-13 16:49:00 +09:00
Supersedes or Related Plan: Related `plan/20260413-155032--work-plan--cc-free-layout-and-visualization-hardening--v01.md`; Related `plan/20260413-160500--cc-single-trigger-unification-report--v01.md`
Current Completion State: The `/sub` run kit was executed end-to-end. Two generator workers produced four blind artifacts, those artifacts were landed into the parent workspace without intentional redesign, runtime screenshots were captured through a file-based browser path, and the harsh auditor delivered a final verdict. The run completed with a `revise` outcome rather than a clean pass.
Completed So Far: Re-read the active `cc_universal_module_mm.md`, confirmed the current single-trigger `.cc` contract, reviewed prior unification and free-layout validation work, launched the generator and auditor workers, received two free-layout artifacts and two standard-layout artifacts, landed all four artifacts under `visual-tests/20260413-161443-cc-blind-freedom-stress-test/`, and captured screenshot evidence for each artifact. Source-level evidence confirms free-layout signals in two artifacts, payload-local style blocks in three artifacts, and active visual placeholders in all four artifacts. A separate grep check confirms `.ccc` no longer appears in `cc_universal_module_mm.md`.
Remaining Work: None for this run. The next work should be a targeted rewrite plus a fresh rerun.
Current Blockers: No execution blocker remains. The recorded product blockers are now known findings: runtime modal interference on some visual-support paths, comparative-layout weakness, and fallback convergence toward the title/chips/sections/summary scaffold.
Next Step: Use the findings in the final report to drive the next targeted rewrite.

# Scoreboard

Current Score: 69 / 100
Score Source: audited
Last Updated: 2026-04-13 16:49:00 +09:00
Score Rationale: The final audited result shows real progress but not enough consistency. The batch proves one strong free-layout win and one competent standard-layout upgrade, but it also shows a runtime-occluded route artifact and a weak comparison artifact with malformed markup. The run therefore closes as a useful failure rather than a pass.
What Improved:
1. The run moved from theory into concrete multi-artifact evidence.
2. The batch included both `free` and `standard` layouts rather than collapsing into one mode.
3. Visual support was active in all four artifacts and not timid in topic selection.
What Remains Unsatisfactory:
1. Some rendered outputs show an API-key modal overlay from the visual path, which can overwhelm the page and weaken the reading spine.
2. The comparison artifact still feels much closer to an upgraded house article than to a strongly re-shaped composition.
3. The batch still converges too easily on the same fallback grammar of title, key terms, section stack, and recap.
Actions To Raise Or Maintain The Score:
1. Preserve the screenshot evidence, especially the modal-overlay cases, in the acceptance record.
2. Target comparative-layout behavior and runtime visual-path robustness before changing broader prompt areas.
3. Re-run the same harsh blind matrix after the targeted rewrite.

Score History:
1. 2026-04-13 16:14:43 +09:00 | score 50 | source provisional | New approved `/sub` blind stress-test run opened to determine whether `.cc` now composes freely in practice rather than only in theory.
2. 2026-04-13 16:41:00 +09:00 | score 72 | source provisional | Four blind artifacts landed and rendered; real freedom is visible, but final auditor verdict and runtime modal risk still keep the run provisional.
3. 2026-04-13 16:49:00 +09:00 | score 69 | source audited | Final audit closed the run as revise: one strong free-layout proof exists, but batch-wide reliability and runtime robustness are still not there.

# Objective

Stress-test the active `cc_universal_module_mm.md` under blind conditions to determine whether it actually causes `.cc` artifacts to compose with real range. The run should answer a concrete question:

Does the current prompt produce genuinely varied, confident, mounted-payload compositions under the persistent runtime shell, including wide free-layout cases, utility-style or Tailwind-like local composition thinking, stronger hero rhythm, stronger sectional grouping, and active visual support, or does it still collapse back into the same narrow article pattern across subjects?

This is explicitly not a casual visual spot-check. It is a hostile validation pass designed to catch three failure modes that are easy to miss:

1. paper freedom that does not become real artifact freedom,
2. “freedom” that only appears as decorative style on top of the same old structure,
3. freedom that breaks runtime boundaries and starts behaving like a forbidden standalone shell.

# Confirmed Facts

The active English module now presents `.cc` as the only public trigger.

The active module now explicitly allows a freer mounted-content path through `data-shell-layout="free"` or `data-cc-layout="free"` when justified.

The current runtime preserves a persistent core shell and treats freer layout as a mounted-content variation rather than a second page system.

The current runtime still expects the canonical external shell bootstrap and still exposes `renderAppShell(...)` as the compatibility entry point for that external shell.

The user has now explicitly requested `/sub`, maximum reasoning, and a harsh blind test focused on whether the prompt truly composes freely, including “Tailwind and etc” style freedom in a composite sense.

# Working Assumptions

The smallest safe assumption is that the user does not literally require the prompt to inject the Tailwind CDN, because the active `.cc` contract still forbids standalone page-shell replacement and external shell drift. Instead, the right interpretation is that the user wants proof of broad compositional freedom: local style blocks, utility-style grouping, wide mounted-layout structure, card/grid rhythm, hero variation, and strong visual staging that feel as unconstrained as modern utility-first composition without crossing the runtime boundary.

The safest assumption is that the test should reward these freedoms when they appear:

1. wider or more asymmetrical payload layout,
2. subject-specific compositional shifts,
3. payload-local style or variable systems,
4. utility-like class grouping or similar compositional shorthand,
5. richer section rhythm,
6. stronger visual anchor usage.

The test should penalize these failures:

1. every artifact using the same article wrapper and cadence,
2. the model never choosing `free` layout even when the subject clearly wants it,
3. the model choosing free layout but still looking like the old house article,
4. the model trying to replace the runtime shell,
5. the model overusing placeholders or decorative chrome with weak explanatory value.

The safest assumption is that four to six artifacts are enough to expose pattern collapse while staying reviewable. Fewer than four risks false confidence; many more would create review noise rather than stronger signal.

# Test Matrix

The batch should cover at least four distinct subject shapes that materially challenge the prompt to vary its composition:

## 1. Historical route / exploration topic

Example: Age of Exploration or Silk Road.

Desired pressure:

1. route or chronology spine,
2. map-like or voyage visual anchor,
3. possibility of a wider hero or route-led layout.

Failure if:

1. it becomes another simple article with ordinary sections only,
2. route logic is present in text but not reflected in layout or support surfaces.

## 2. Architectural / place-heavy topic

Example: Gothic cathedral or Haussmann Paris.

Desired pressure:

1. visual-first staging,
2. possibility of split layout or gallery rhythm,
3. strong place/structure image support,
4. maybe payload-local styling for atmosphere.

Failure if:

1. it does not use a freer mounted layout where clearly justified,
2. it feels indistinguishable from the history route artifact except for words.

## 3. Protocol / system-heavy topic

Example: TCP three-way handshake or TLS handshake.

Desired pressure:

1. clearer banded or stepwise structure,
2. diagram-like support surface,
3. maybe utility-like grouped cards or process rail.

Failure if:

1. the artifact uses the same general article skeleton again,
2. the “visual support” is generic rather than structurally explanatory.

## 4. Comparative analytical topic

Example: Romanesque vs Gothic architecture, or supervised vs unsupervised learning.

Desired pressure:

1. contrast surface,
2. two-column or matrix-like grouping,
3. stronger sectional grouping than a normal explanatory article.

Failure if:

1. comparison remains only textual and linear,
2. there is no layout response to the comparative nature of the subject.

## 5. Optional fifth artifact if needed

Use a biological process or astronomy topic if the first four still look too similar. This fifth case is a tie-breaker if compositional variety remains ambiguous.

# `/sub` Team Design

This run should use a mixed-but-mostly-serial team with one parallel generation stage and a later audit stage.

## Parent

Owns:

1. worker briefs,
2. artifact landing into the primary workspace,
3. runtime rendering,
4. screenshot capture,
5. final acceptance.

## Worker G1

Role: blind generator for route and place-heavy topics.

Mission:

1. generate two blind `.cc` artifacts with no special extra design instructions beyond the prompt contract and the topic,
2. maximize reasoning,
3. intentionally allow the prompt to decide whether `standard` or `free` layout is justified.

## Worker G2

Role: blind generator for system and comparison-heavy topics.

Mission:

1. generate two blind `.cc` artifacts for system/protocol and comparison topics,
2. maximize reasoning,
3. again let the prompt decide whether `free` layout, utility-style structure, payload-local styling, and stronger visual support should appear.

## Worker A1

Role: harsh auditor.

Mission:

1. define a scoring rubric before seeing final screenshots,
2. then audit the landed artifacts and score each one for real freedom versus false freedom,
3. explicitly look for forbidden shell drift and fake variety.

This team shape is justified because:

1. the two generator missions have disjoint deliverables,
2. variety is easier to measure when different generators handle different subject shapes,
3. the final auditor can use a consistent rubric across the whole batch.

# Expected Artifact Surface

The parent should land each accepted blind artifact under `visual-tests/20260413-161443-cc-blind-freedom-stress-test/` using a runtime-compatible external shell so they can be rendered locally.

Each artifact should preserve:

1. the canonical external bootstrap shell,
2. the mounted payload inside `#ai-content-placeholder`,
3. any `data-shell-layout="free"` or `data-cc-layout="free"` signals chosen by the generator,
4. visual-support units,
5. payload-local style blocks if the generator uses them.

Artifacts should not be manually beautified by the parent before rendering. The point is to preserve the blind-generated character of the outputs.

# Validation Strategy

Validation should happen in four layers.

## Layer A: blind artifact capture

Collect the generators’ outputs with minimal parent editing. The parent may normalize quoting or escape issues if needed for file validity, but may not redesign the content.

## Layer B: structural rubric

Audit each artifact for:

1. whether it used `standard` or `free` layout,
2. whether the choice matched the subject,
3. whether the composition is materially distinct from the others,
4. whether payload-local style or utility-like grouping appears,
5. whether visual support is active and meaningful.

## Layer C: rendered screenshot review

Render the accepted artifacts through a local browser path and inspect screenshots for:

1. visible range across artifacts,
2. reading spine preservation,
3. shell boundary discipline,
4. support-surface placement quality,
5. whether “free” artifacts actually look freer.

## Layer D: harsh acceptance threshold

The run should only pass if the batch shows real variation. The threshold is not “the HTML validates” or “the pages look pretty.” The threshold is:

1. at least two artifacts visibly depart from the default house article cadence in a subject-justified way,
2. at least one artifact uses the free-layout path convincingly,
3. visual support is active in suitable cases,
4. no artifact crosses into forbidden standalone shell behavior,
5. the auditor agrees that the variety is structural, not just cosmetic.

# Risks

The biggest risk is false compositional diversity. The model may rename sections, add chips, and use slightly different sentence rhythm while still producing the same underlying page.

The second risk is over-reading utility style. A few extra classes are not enough. The auditor must look for real composition: cards, grids, asymmetric hero, local styling, free layout, comparison surfaces, or route/diagram logic.

The third risk is accidental parent contamination. The parent must not “improve” blind outputs too much while landing them.

The fourth risk is rendering-path weakness in the environment. The local environment has already shown unreliable headless loopback behavior. The plan should therefore allow file-based rendering as an acceptable fallback if networked headless capture misbehaves again.

# Definition Of Done

This run is complete when:

1. the `/sub` worker team has produced a multi-artifact blind batch,
2. the parent has landed and rendered the artifacts,
3. the auditor has scored them for real compositional freedom,
4. evidence files and screenshots exist on disk,
5. and the final report clearly answers whether the current prompt truly composes freely or still needs another targeted rewrite.

# Evidence Paths

Primary run directory:

`subagent-runs/20260413-161443-cc-blind-freedom-stress-test/`

Primary visual output directory:

`visual-tests/20260413-161443-cc-blind-freedom-stress-test/`

Planned evidence files:

1. `orchestration-plan.md`
2. `status.md`
3. `worker-briefs/*.md`
4. `results/*.md`
5. `review-verdict.md`
6. `acceptance.md`
7. rendered artifact `.html` files
8. rendered screenshot `.png` files

# Reporting Intent

The final user-facing summary should not just say “it passed” or “it failed.” It should show:

1. whether the prompt genuinely produced wide/free composition,
2. whether payload-local style or utility-like composition showed up,
3. whether visual support became more assertive in practice,
4. which artifacts proved the point best,
5. and what exact prompt behavior still needs fixing if the batch underperforms.
