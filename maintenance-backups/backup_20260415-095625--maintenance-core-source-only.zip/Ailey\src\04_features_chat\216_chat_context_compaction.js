/* --- Ailey & Bailey Canvas --- */
// File: 216_chat_context_compaction.js
// Version: 1.0 (Rolling Auto-Compact Memory)
// Description: Builds rolling compact conversation memory so older context can stay available without resending every raw message.

const CHAT_AUTO_COMPACT_VERSION = 1;
const CHAT_AUTO_COMPACT_FALLBACK_THRESHOLD = 20;
const CHAT_AUTO_COMPACT_SUMMARY_MAX_OUTPUT_TOKENS = 4096;

function normalizeChatHistoryLimitValue(value, fallback = CHAT_AUTO_COMPACT_FALLBACK_THRESHOLD) {
    const parsed = Number.parseInt(value, 10);
    if (!Number.isFinite(parsed) || parsed < 0) {
        return fallback;
    }
    return Math.min(parsed, 100);
}

function getEffectiveChatHistoryLimit(activePreset = null) {
    if (activePreset) {
        return normalizeChatHistoryLimitValue(activePreset.chatHistoryLimit, CHAT_AUTO_COMPACT_FALLBACK_THRESHOLD);
    }
    return normalizeChatHistoryLimitValue(userApiSettings.universalModelSettings?.chatHistoryLimit, CHAT_AUTO_COMPACT_FALLBACK_THRESHOLD);
}

function getEffectiveAutoCompactEnabled(activePreset = null) {
    if (activePreset) {
        return activePreset.autoCompactEnabled !== false;
    }
    return userApiSettings.universalModelSettings?.autoCompactEnabled !== false;
}

function getChatMessageComparableText(message) {
    return String(message?.displayName || message?.content || '').trim();
}

function doChatMessagesMatch(left, right) {
    if (!left || !right) return false;
    if (String(left.role || '') !== String(right.role || '')) return false;
    return getChatMessageComparableText(left) === getChatMessageComparableText(right);
}

function stripTrailingCurrentUserMessage(history, currentUserMessage) {
    const normalizedHistory = Array.isArray(history) ? history.slice() : [];
    if (!currentUserMessage || normalizedHistory.length === 0) return normalizedHistory;

    const lastMessage = normalizedHistory[normalizedHistory.length - 1];
    if (String(lastMessage?.role || '') === 'user' && doChatMessagesMatch(lastMessage, currentUserMessage)) {
        normalizedHistory.pop();
    }
    return normalizedHistory;
}

function isEligibleCompactMessage(message) {
    const role = String(message?.role || '').toLowerCase();
    if (role !== 'user' && role !== 'ai') return false;
    const text = getChatMessageComparableText(message);
    return !!text;
}

function getMessageTimestampMs(message) {
    const rawTimestamp = message?.timestamp;
    if (!rawTimestamp) return 0;
    if (typeof rawTimestamp.toMillis === 'function') return rawTimestamp.toMillis();
    if (typeof rawTimestamp.toDate === 'function') {
        const asDate = rawTimestamp.toDate();
        return asDate instanceof Date ? asDate.getTime() : 0;
    }
    if (rawTimestamp instanceof Date) return rawTimestamp.getTime();
    const numeric = Number(rawTimestamp);
    return Number.isFinite(numeric) ? numeric : 0;
}

function normalizeChatCompactionState(state = null, threshold = CHAT_AUTO_COMPACT_FALLBACK_THRESHOLD) {
    const normalizedThreshold = Math.max(1, normalizeChatHistoryLimitValue(threshold, CHAT_AUTO_COMPACT_FALLBACK_THRESHOLD));
    return {
        version: CHAT_AUTO_COMPACT_VERSION,
        threshold: normalizedThreshold,
        memoryText: typeof state?.memoryText === 'string' ? state.memoryText.trim() : '',
        compactedMessageCount: Math.max(0, Number.parseInt(state?.compactedMessageCount, 10) || 0),
        compactedChunkCount: Math.max(0, Number.parseInt(state?.compactedChunkCount, 10) || 0),
        compactedThroughMs: Math.max(0, Number.parseInt(state?.compactedThroughMs, 10) || 0),
        lastCompactedAtMs: Math.max(0, Number.parseInt(state?.lastCompactedAtMs, 10) || 0),
    };
}

function getCompactionStateForSession(sessionId, isTemporary, threshold) {
    if (isTemporary || sessionId === 'temporary-chat') {
        return normalizeChatCompactionState(temporarySession?.compactionState, threshold);
    }

    const session = localChatSessionsCache.find((item) => item.id === sessionId);
    return normalizeChatCompactionState(session?.compactionState, threshold);
}

async function persistCompactionStateForSession(sessionId, isTemporary, state) {
    const normalizedState = normalizeChatCompactionState(state, state?.threshold || CHAT_AUTO_COMPACT_FALLBACK_THRESHOLD);

    if (isTemporary || sessionId === 'temporary-chat') {
        if (!temporarySession) {
            temporarySession = typeof createEmptyTemporarySession === 'function'
                ? createEmptyTemporarySession()
                : { messages: [], contextSent: false, compactionState: null };
        }
        temporarySession.compactionState = normalizedState;
        return normalizedState;
    }

    const session = localChatSessionsCache.find((item) => item.id === sessionId);
    if (session) {
        session.compactionState = normalizedState;
    }

    if (chatSessionsCollectionRef && sessionId) {
        await chatSessionsCollectionRef.doc(sessionId).set({
            compactionState: normalizedState
        }, { merge: true });
    }

    return normalizedState;
}

function createCompactionCursorValue(ms) {
    if (!ms) return null;
    if (typeof firebase !== 'undefined' && firebase?.firestore?.Timestamp?.fromMillis) {
        return firebase.firestore.Timestamp.fromMillis(ms);
    }
    return new Date(ms);
}

async function fetchSessionMessagesForCompaction(sessionId, compactedThroughMs = 0) {
    if (!chatSessionsCollectionRef || !sessionId || sessionId === 'temporary-chat') return [];

    let query = chatSessionsCollectionRef
        .doc(sessionId)
        .collection('messages')
        .orderBy('timestamp', 'asc');

    if (compactedThroughMs > 0) {
        query = query.startAfter(createCompactionCursorValue(compactedThroughMs));
    }

    const snapshot = await query.get();
    return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
}

function trimCompactionMessageText(text) {
    const normalized = String(text || '').replace(/\s+\n/g, '\n').trim();
    if (normalized.length <= 4000) return normalized;
    return `${normalized.slice(0, 4000)}\n...[truncated for compaction]`;
}

function formatMessagesForCompaction(messages) {
    return (Array.isArray(messages) ? messages : [])
        .filter(isEligibleCompactMessage)
        .map((message, index) => {
            const roleLabel = String(message.role || '').toLowerCase() === 'user' ? 'USER' : 'AI';
            const stamp = getMessageTimestampMs(message);
            const heading = `[${index + 1}] ${roleLabel}${stamp ? ` @ ${new Date(stamp).toISOString()}` : ''}`;
            return `${heading}\n${trimCompactionMessageText(getChatMessageComparableText(message))}`;
        })
        .join('\n\n');
}

function buildCompactionHiddenContext(existingMemoryText) {
    if (!existingMemoryText) return null;
    return [
        'Here is the previously compacted conversation memory.',
        'Preserve durable facts, user preferences, decisions, unresolved tasks, and current direction.',
        '',
        existingMemoryText
    ].join('\n');
}

function getCompactionSystemInstruction() {
    return [
        'You are a conversation memory compactor.',
        'Your job is to preserve durable context with minimal information loss.',
        'Return plain text only. Do not use code fences. Do not narrate the task.',
        'Write in Korean.',
        'Organize the memory into short labeled sections when helpful.',
        'Always preserve:',
        '- user goals, preferences, constraints, and explicit requests',
        '- accepted and rejected implementation directions',
        '- durable facts, filenames, settings, thresholds, and important values',
        '- unresolved problems, follow-ups, and rollback boundaries',
        '- the latest working state and why it matters',
        'If an older detail is no longer relevant, omit it.',
        'If the new chunk revises an older fact, keep only the newest valid fact.',
        'Do not invent anything.'
    ].join('\n');
}

async function requestChatCompactionSummary(runtimeConfig, existingMemoryText, messagesToCompact, threshold, compactedChunkCount) {
    const chunkBody = formatMessagesForCompaction(messagesToCompact);
    if (!chunkBody) {
        return existingMemoryText || '';
    }

    const payload = buildChatPayload(
        getCompactionSystemInstruction(),
        [{
            role: 'user',
            content: [
                `Compact the following conversation chunk into durable rolling memory.`,
                `Current threshold: ${threshold}`,
                `Chunk groups included in this pass: ${compactedChunkCount}`,
                '',
                '[New conversation chunk]',
                chunkBody
            ].join('\n')
        }],
        buildCompactionHiddenContext(existingMemoryText),
        null
    );

    const response = await _fetchFromApi(
        runtimeConfig.provider,
        runtimeConfig.model,
        runtimeConfig.key,
        payload,
        Math.min(runtimeConfig.maxTokens || CHAT_AUTO_COMPACT_SUMMARY_MAX_OUTPUT_TOKENS, CHAT_AUTO_COMPACT_SUMMARY_MAX_OUTPUT_TOKENS),
        0.2,
        0.4,
        false,
        null
    );

    const content = String(response?.content || '').trim();
    if (!content) {
        throw new Error('Auto-compact returned an empty memory summary.');
    }

    const meta = response?.responseMeta || null;
    if (!isAiResponseComplete(runtimeConfig.provider, meta)) {
        throw new Error(describeAiCompletionIssue(runtimeConfig.provider, meta, content) || 'Auto-compact returned an incomplete summary.');
    }

    return content;
}

async function prepareHistoryForAutoCompact({
    sessionId,
    isTemporary,
    userMessage,
    baseHistory,
    historyLimit,
    autoCompactEnabled,
    runtimeConfig
}) {
    const threshold = normalizeChatHistoryLimitValue(historyLimit, CHAT_AUTO_COMPACT_FALLBACK_THRESHOLD);
    const strippedBaseHistory = stripTrailingCurrentUserMessage(baseHistory, userMessage).filter(isEligibleCompactMessage);
    const emptyResult = {
        historyForPayload: threshold > 0 ? strippedBaseHistory.slice(-threshold) : [],
        compactMemoryText: '',
        didCompact: false,
        compactedMessageCount: 0,
        compactedChunkCount: 0,
        threshold,
        compactionState: getCompactionStateForSession(sessionId, isTemporary, threshold)
    };

    if (threshold <= 0) {
        return {
            ...emptyResult,
            historyForPayload: [],
        };
    }

    if (!autoCompactEnabled) {
        return emptyResult;
    }

    let compactionState = getCompactionStateForSession(sessionId, isTemporary, threshold);
    let uncompactedMessages = [];

    try {
        if (isTemporary || sessionId === 'temporary-chat') {
            uncompactedMessages = stripTrailingCurrentUserMessage(temporarySession?.messages || [], userMessage)
                .filter(isEligibleCompactMessage)
                .slice(compactionState.compactedMessageCount);
        } else if (sessionId) {
            uncompactedMessages = (await fetchSessionMessagesForCompaction(sessionId, compactionState.compactedThroughMs))
                .filter(isEligibleCompactMessage);
            uncompactedMessages = stripTrailingCurrentUserMessage(uncompactedMessages, userMessage);
        } else {
            uncompactedMessages = strippedBaseHistory;
        }
    } catch (error) {
        trace('Chat.Compact', 'HistoryFetchFailed', { sessionId, error: error.message }, {}, 'WARN');
        return emptyResult;
    }

    const fullChunkCount = Math.floor(uncompactedMessages.length / threshold);
    if (fullChunkCount < 1) {
        return {
            historyForPayload: uncompactedMessages.slice(-threshold),
            compactMemoryText: compactionState.memoryText || '',
            didCompact: false,
            compactedMessageCount: 0,
            compactedChunkCount: 0,
            threshold,
            compactionState
        };
    }

    const messagesToCompactCount = fullChunkCount * threshold;
    const messagesToCompact = uncompactedMessages.slice(0, messagesToCompactCount);
    const recentMessages = uncompactedMessages.slice(messagesToCompactCount);

    try {
        const nextMemoryText = await requestChatCompactionSummary(
            runtimeConfig,
            compactionState.memoryText,
            messagesToCompact,
            threshold,
            fullChunkCount
        );

        compactionState = normalizeChatCompactionState({
            ...compactionState,
            threshold,
            memoryText: nextMemoryText,
            compactedMessageCount: compactionState.compactedMessageCount + messagesToCompactCount,
            compactedChunkCount: compactionState.compactedChunkCount + fullChunkCount,
            compactedThroughMs: getMessageTimestampMs(messagesToCompact[messagesToCompact.length - 1]),
            lastCompactedAtMs: Date.now()
        }, threshold);

        await persistCompactionStateForSession(sessionId, isTemporary, compactionState);

        trace('Chat.Compact', 'CompactionApplied', {
            sessionId: sessionId || 'temporary-chat',
            compactedChunkCount: fullChunkCount,
            compactedMessageCount: messagesToCompactCount,
            memoryLength: nextMemoryText.length
        });

        return {
            historyForPayload: recentMessages.slice(-threshold),
            compactMemoryText: compactionState.memoryText,
            didCompact: true,
            compactedMessageCount: messagesToCompactCount,
            compactedChunkCount: fullChunkCount,
            threshold,
            compactionState
        };
    } catch (error) {
        trace('Chat.Compact', 'CompactionFailed', {
            sessionId: sessionId || 'temporary-chat',
            error: error.message
        }, {}, 'WARN');
        return {
            historyForPayload: uncompactedMessages.slice(-threshold),
            compactMemoryText: compactionState.memoryText || '',
            didCompact: false,
            compactedMessageCount: 0,
            compactedChunkCount: 0,
            threshold,
            compactionState
        };
    }
}

function mergeCompactionMemoryIntoHiddenContext(hiddenContext, compactMemoryText) {
    const memoryText = String(compactMemoryText || '').trim();
    if (!memoryText) return hiddenContext;

    const compactSection = [
        '[Compact Conversation Memory]',
        memoryText
    ].join('\n');

    return hiddenContext
        ? `${hiddenContext}\n\n${compactSection}`
        : compactSection;
}
