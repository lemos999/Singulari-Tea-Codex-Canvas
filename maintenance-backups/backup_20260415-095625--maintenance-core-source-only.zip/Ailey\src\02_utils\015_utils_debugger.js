/* --- Ailey & Bailey Canvas --- */
// File: 015_utils_debugger.js
// Version: 2.0 (Headless Trace Logger)
// Description: Preserves the `trace` API after debugger UI removal by
// routing logs into an in-memory buffer and optional console output.

const TRACE_BUFFER_LIMIT = 400;

function getTraceBuffer() {
    if (typeof window === 'undefined') return [];
    if (!Array.isArray(window.__aileyTraceBuffer)) {
        window.__aileyTraceBuffer = [];
    }
    return window.__aileyTraceBuffer;
}

function formatTraceValue(value) {
    if (value && typeof value.toDate === 'function') {
        try {
            return value.toDate().toISOString();
        } catch (error) {
            return '[Timestamp Conversion Failed]';
        }
    }

    if (value instanceof Date) {
        return value.toISOString();
    }

    if (value instanceof Set) {
        return `Set(${value.size}) {${[...value].map((item) => String(item).substring(0, 10)).join(', ')}}`;
    }

    if (typeof value === 'object' && value !== null) {
        try {
            return JSON.stringify(value);
        } catch (error) {
            return '[Unserializable Object]';
        }
    }

    return value;
}

function trace(source, eventName, details = {}, context = {}, stateSnapshot = {}, level = 'INFO') {
    const timestamp = new Date().toLocaleTimeString('ko-KR', {
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    }) + `.${String(new Date().getMilliseconds()).padStart(3, '0')}`;

    const entry = {
        timestamp,
        level,
        source,
        eventName,
        details,
        context,
        stateSnapshot: Object.fromEntries(
            Object.entries(stateSnapshot).map(([key, value]) => [key, formatTraceValue(value)])
        )
    };

    const buffer = getTraceBuffer();
    buffer.push(entry);
    if (buffer.length > TRACE_BUFFER_LIMIT) {
        buffer.splice(0, buffer.length - TRACE_BUFFER_LIMIT);
    }

    if (typeof window !== 'undefined') {
        window.getAileyTraceBuffer = () => [...getTraceBuffer()];
        window.clearAileyTraceBuffer = () => {
            getTraceBuffer().length = 0;
        };
    }

    const shouldEchoToConsole =
        level === 'WARN' ||
        level === 'ERROR' ||
        (typeof window !== 'undefined' && window.__AILEY_TRACE_TO_CONSOLE__ === true);

    if (shouldEchoToConsole && typeof console !== 'undefined') {
        const consoleMethod = level === 'ERROR'
            ? 'error'
            : level === 'WARN'
                ? 'warn'
                : 'log';
        console[consoleMethod](`[${timestamp}] [${source}] ${eventName}`, {
            details,
            context,
            stateSnapshot: entry.stateSnapshot
        });
    }
}

function setupDebugger() {
    trace('System', 'TraceLoggerInitialized', { mode: 'headless-buffer' });
}
