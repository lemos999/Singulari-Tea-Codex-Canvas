## Task

직전 패스(`Clamp panels on restore and simplify live export`) 적용 후 로드 실패가 발생해, 마지막 패스만 이전 정상 상태로 롤백한다.

## Trigger

- User reported shell no longer loads after latest pass.
- Requested explicit restore to previous working state.

## Rollback target

- Revert only the latest panel/export simplification pass.
- Restore prior export dropdown flow.
- Restore prior panel manager logic.
- Rebuild bundle and republish previous-working runtime state.

## Scope

- `Ailey/src/00_shell/000_shell_template.js`
- `Ailey/src/02_utils/013_utils_panel_manager.js`
- `Ailey/src/03_core/120_core_main_initializer.js`
- `Ailey/src_css/010_widget_header_addons.css`
- `Ailey/bundle/main.js`
- `Ailey/bundle/main.css`
- `Singulari-Tea-Codex-Canvas-pr/bundle/*`

## Validation

- `Ailey/index.html` loads and mounts shell again.
- `chat-panel` exists after bootstrap.
- No new page error during basic load check.
- Publish repo reflects rollback commit.
