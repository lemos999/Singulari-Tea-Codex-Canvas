/* --- Ailey & Bailey Canvas --- */
// File: 125_core_initializer_vision_ui.js
// Version: 2.9 (Prompt-First Image Studio Prefill)
// Description: Keeps the image studio memo focused on the selected image block prompt instead of dumping full-page context by default.

const IMAGE_STUDIO_CONTEXT_SEPARATOR = '\n\n---\n[CURRENT_SCREEN_CONTEXT]:\n';

function stripImageStudioAppendedContext(text = '') {
    if (!text) return '';
    const separatorIndex = text.indexOf(IMAGE_STUDIO_CONTEXT_SEPARATOR);
    return (separatorIndex === -1 ? text : text.slice(0, separatorIndex)).trim();
}

function resolveImageStudioPromptCarrier(targetElement) {
    if (!targetElement || !(targetElement instanceof Element)) return null;
    if (targetElement.dataset?.studioPrompt || targetElement.dataset?.prompt) return targetElement;

    return targetElement.querySelector?.('.type-generated-image[data-studio-prompt], .type-generated-image[data-prompt], [data-studio-prompt], [data-prompt]') || null;
}

function resolveImageStudioPrefill(prefilledText, targetElement) {
    const promptCarrier = resolveImageStudioPromptCarrier(targetElement);
    const storedStudioPrompt = stripImageStudioAppendedContext(promptCarrier?.dataset?.studioPrompt || '');
    if (storedStudioPrompt) return storedStudioPrompt;

    const storedPrompt = stripImageStudioAppendedContext(promptCarrier?.dataset?.prompt || '');
    if (storedPrompt) return storedPrompt;

    return stripImageStudioAppendedContext(prefilledText || '');
}

async function _generateImageFromParagraph(mode, finalPrompt, targetElement, replace = false, uploadedImage = null, studioPrompt = '') {
    if (isImageGenerating) {
        showToastNotification("??? ?? ?? ????.", "?? ??? ?? ? ?? ??? ???.", `image-gen-busy-${Date.now()}`);
        return;
    }

    const placeholder = replace ? targetElement : renderBlock({ type: 'generated-image-placeholder' });
    if (!placeholder || !targetElement) return;
    const normalizedStudioPrompt = stripImageStudioAppendedContext(studioPrompt);

    if (normalizedStudioPrompt) {
        placeholder.dataset.prompt = normalizedStudioPrompt;
        placeholder.dataset.studioPrompt = normalizedStudioPrompt;
    }
    
    if (!replace) {
        targetElement.after(placeholder);
    }
    placeholder.scrollIntoView({ behavior: 'smooth', block: 'center' });
    
    const placeholderButtons = placeholder.querySelectorAll('.placeholder-action-btn');

    try {
        isImageGenerating = true;
        placeholderButtons.forEach(btn => btn.disabled = true);
        
        const loaderHTML = `
            <div class="media-loading-state">
                <div class="loading-animation" aria-hidden="true">
                    <div class="dot"></div>
                    <div class="dot"></div>
                    <div class="dot"></div>
                </div>
            </div>
        `;
        placeholder.innerHTML = loaderHTML;

        const settings = userApiSettings.visionWeaverSettings;
        let promptForApi = finalPrompt;
        
        if (settings.disableTextOutput) {
            promptForApi = `absolutely no text, no letters, no characters, no speech bubbles. visual-only output. ${promptForApi}`;
            trace("VisionWeaver", "generate.disableText", { active: true });
        }
        
        const activePresetNum = settings.activePreset;
        let referenceImages = [];

        if (uploadedImage) {
            referenceImages.push(uploadedImage);
        }

        if (activePresetNum && activePresetNum !== 'none' && settings.presets[activePresetNum]) {
            const preset = settings.presets[activePresetNum];
            const urlsToFetch = [preset.main, preset.face, preset.clothing].filter(Boolean);
            
            if (urlsToFetch.length > 0) {
                const base64Promises = urlsToFetch.map(url => fetchImageAsBase64(url));
                const presetImages = await Promise.all(base64Promises);
                referenceImages.push(...presetImages);
            }
        }
        
        const imageDataUrl = await generateImage(promptForApi, referenceImages);

        insertImageIntoDOM(imageDataUrl, placeholder, 'learning-content');

    } catch (error) {
        console.error("Image generation from paragraph failed:", error);
        _renderGenerationFailure(placeholder, true);
    } finally {
        isImageGenerating = false;
    }
}

function openImageGenerationOptionsModal(prefilledText, targetElement, replace = false) {
    if (prefilledText === undefined && targetElement === undefined) {
        const contextSource = document.getElementById('learning-content') || document.getElementById('recall-content-area');
        if (!contextSource) {
            showModal("오류: 이미지 옵션을 열 컨텍스트를 찾을 수 없습니다.", () => {});
            return;
        }
        targetElement = contextSource.querySelector('.type-generated-image');
        if (!targetElement) {
            showModal("오류: 대상 이미지 영역을 찾을 수 없습니다.", () => {});
            return;
        }
        const previousContentSection = targetElement.previousElementSibling;
        prefilledText = previousContentSection ? previousContentSection.innerText.replace(/\n[🎨📊]$/, '').trim() : '';
        replace = true;
    }

    if (!imageGenerationOptionsModalOverlay) return;

    const modal = imageGenerationOptionsModalOverlay;
    const textarea = document.getElementById('img-gen-options-textarea');
    const searchInput = document.getElementById('img-gen-search-input');
    const cancelButton = document.getElementById('img-gen-options-cancel-btn');
    const quickButton = document.getElementById('img-gen-options-quick-btn');
    const disableTextToggle = document.getElementById('img-gen-disable-text-toggle');
    const includeAllDomButton = document.getElementById('img-gen-include-all-dom');
    const allOptionButtons = modal.querySelectorAll('.option-btn[data-prompt]');
    const rememberToggle = document.getElementById('img-gen-remember-options-toggle');
    
    const uploadButton = document.getElementById('img-gen-studio-upload-btn');
    const removeButton = document.getElementById('img-gen-studio-remove-btn');
    const fileInput = document.getElementById('img-gen-studio-file-input');
    const previewWrapper = document.getElementById('img-gen-studio-preview-wrapper');
    const preview = document.getElementById('img-gen-studio-preview');
    const studioLeft = modal.querySelector('.img-gen-studio-left');
    const tabPanels = modal.querySelector('.img-gen-tab-panels-new');
    document.getElementById('img-gen-options-refined-btn')?.remove();

    const debouncedSaveRemembered = debounce(() => {
        _saveRememberedOptions();
        saveUserSettingsToFirebase(true);
    }, 1000);

    function _saveRememberedOptions() {
        if (!modal || !userApiSettings.visionWeaverSettings.rememberOptions) return;
        const remembered = {};
        modal.querySelectorAll('.img-gen-tab-panel').forEach(panel => {
            const category = panel.id.replace('img-gen-tab-', '');
            const activeButtons = panel.querySelectorAll('.option-btn.active[data-prompt]');
            if (activeButtons.length > 0) {
                remembered[category] = Array.from(activeButtons).map(btn => btn.dataset.prompt);
            }
        });
        userApiSettings.visionWeaverSettings.rememberedOptions = remembered;
        trace("VisionWeaver", "rememberedOptions.staged", { options: JSON.stringify(remembered) });
    }

    const _filterOptions = debounce(() => {
        const term = searchInput.value.toLowerCase();
        modal.querySelectorAll('.option-btn[data-prompt]').forEach(btn => {
            const promptText = btn.dataset.prompt.toLowerCase();
            const btnText = btn.textContent.toLowerCase();
            const tooltipText = (btn.dataset.tooltip || '').toLowerCase();
            const isVisible = promptText.includes(term) || btnText.includes(term) || tooltipText.includes(term);
            btn.classList.toggle('hidden', !isVisible);
        });

        modal.querySelectorAll('.accordion-container').forEach(container => {
            const content = container.querySelector('.accordion-content');
            const visibleButtons = content.querySelectorAll('.option-btn:not(.hidden)');
            container.style.display = visibleButtons.length > 0 ? 'block' : 'none';
        });
    }, 200);

    // --- Reset UI State ---
    const resolvedPrefillText = resolveImageStudioPrefill(prefilledText, targetElement);
    textarea.value = resolvedPrefillText;
    searchInput.value = '';
    if (studioLeft) {
        studioLeft.scrollTop = 0;
        studioLeft.scrollLeft = 0;
    }
    if (tabPanels) {
        tabPanels.scrollTop = 0;
        tabPanels.scrollLeft = 0;
    }
    if (textarea) {
        textarea.scrollTop = 0;
    }
    
    studioUploadedImage = null;
    if (previewWrapper) previewWrapper.style.display = 'none';
    if (preview) preview.style.backgroundImage = 'none';
    if (fileInput) fileInput.value = '';

    allOptionButtons.forEach(b => b.classList.remove('active'));
    if (includeAllDomButton) includeAllDomButton.classList.remove('active');
    modal.querySelectorAll('.accordion-header.expanded').forEach(h => h.classList.remove('expanded'));
    modal.querySelectorAll('.accordion-content.expanded').forEach(c => c.classList.remove('expanded'));
    modal.querySelectorAll('.img-gen-tab-btn.active').forEach(b => b.classList.remove('active'));
    modal.querySelectorAll('.img-gen-tab-panel.active').forEach(p => p.classList.remove('active'));
    
    modal.querySelector('.img-gen-tab-btn[data-tab="style"]').classList.add('active');
    const stylePanel = modal.querySelector('#img-gen-tab-style');
    if(stylePanel) stylePanel.classList.add('active');

    modal.querySelectorAll('.img-gen-tab-panel').forEach(panel => {
        const firstHeader = panel.querySelector('.accordion-header');
        if (firstHeader) {
            firstHeader.classList.add('expanded');
            firstHeader.nextElementSibling.classList.add('expanded');
        }
    });

    // Apply remembered settings
    const visionSettings = userApiSettings.visionWeaverSettings;
    rememberToggle.classList.toggle('active', visionSettings.rememberOptions);
    disableTextToggle.classList.toggle('active', visionSettings.disableTextOutput);
    
    if (visionSettings.rememberOptions && visionSettings.rememberedOptions) {
        for (const category in visionSettings.rememberedOptions) {
            const prompts = visionSettings.rememberedOptions[category];
            prompts.forEach(prompt => {
                const btnToActivate = modal.querySelector(`.option-btn[data-prompt="${CSS.escape(prompt)}"]`);
                if (btnToActivate) btnToActivate.classList.add('active');
            });
        }
    } else {
        const defaultStyleButton = modal.querySelector('#img-gen-tab-style .option-btn[data-prompt="photorealistic"]');
        if(defaultStyleButton) defaultStyleButton.classList.add('active');
    }
    
    _filterOptions();

    // --- Event Handlers ---
    const handleModalClick = (e) => {
        const target = e.target;
        const optionBtn = target.closest('.option-btn');

        if (target.closest('.img-gen-tab-btn')) {
            const tabBtn = target.closest('.img-gen-tab-btn');
            modal.querySelectorAll('.img-gen-tab-btn').forEach(b => b.classList.remove('active'));
            modal.querySelectorAll('.img-gen-tab-panel').forEach(p => p.classList.remove('active'));
            tabBtn.classList.add('active');
            const targetPanel = document.getElementById(`img-gen-tab-${tabBtn.dataset.tab}`);
            if (targetPanel) targetPanel.classList.add('active');
        } else if (target.closest('.accordion-header')) {
            const header = target.closest('.accordion-header');
            const content = header.nextElementSibling;
            header.classList.toggle('expanded');
            content.classList.toggle('expanded');
        } else if (optionBtn && optionBtn.dataset.prompt) {
            const group = optionBtn.closest('.accordion-content');
            const isSingleSelect = optionBtn.closest('#img-gen-tab-style, #img-gen-tab-composition, #img-gen-tab-lighting');

            if (isSingleSelect) {
                const wasActive = optionBtn.classList.contains('active');
                group.querySelectorAll('.option-btn').forEach(b => b.classList.remove('active'));
                if (!wasActive) {
                    optionBtn.classList.add('active');
                }
            } else {
                optionBtn.classList.toggle('active');
            }
            if (userApiSettings.visionWeaverSettings.rememberOptions) {
                debouncedSaveRemembered();
            }
        }
    };
    
     const handleGlobalOptionsClick = (e) => {
        const optionBtn = e.target.closest('.option-btn');
        if (!optionBtn || !optionBtn.closest('#img-gen-global-options')) return;

        if (optionBtn.id === 'img-gen-include-all-dom') {
            optionBtn.classList.toggle('active');
            const currentText = textarea.value.trim();
            const separator = '\n\n---\n[현재 장면 전체 내용]:\n';
            const oldContextIndex = currentText.indexOf(separator);
            const baseText = stripImageStudioAppendedContext(currentText);
            
            if (optionBtn.classList.contains('active')) {
                const contextContainerId = targetElement.closest('#recall-content-area') ? 'recall-content-area' : 'learning-content';
                const domContent = extractContextFromDOM(contextContainerId);
                textarea.value = baseText ? `${baseText}${IMAGE_STUDIO_CONTEXT_SEPARATOR}${domContent}` : domContent;
            } else {
                textarea.value = baseText;
            }
        } else if (optionBtn.id === 'img-gen-disable-text-toggle') {
            e.stopPropagation();
            const isActive = optionBtn.classList.toggle('active');
            userApiSettings.visionWeaverSettings.disableTextOutput = isActive;
            saveUserSettingsToFirebase(true);
        } else if (optionBtn.id === 'img-gen-remember-options-toggle') {
            e.stopPropagation();
            const isActive = optionBtn.classList.toggle('active');
            userApiSettings.visionWeaverSettings.rememberOptions = isActive;
            if (!isActive) {
                userApiSettings.visionWeaverSettings.rememberedOptions = {};
            } else {
                _saveRememberedOptions();
            }
            saveUserSettingsToFirebase(true);
        }
    };
    
    const handleUploadClick = () => fileInput.click();
    const handleRemoveClick = () => {
        studioUploadedImage = null;
        previewWrapper.style.display = 'none';
        preview.style.backgroundImage = 'none';
        fileInput.value = '';
    };

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            studioUploadedImage = event.target.result;
            preview.style.backgroundImage = `url('${studioUploadedImage}')`;
            previewWrapper.style.display = 'block';
        };
        reader.readAsDataURL(file);
    };

    const modalContent = modal.querySelector('.image-generation-options-modal');
    modalContent.addEventListener('click', handleModalClick);
    searchInput.addEventListener('input', _filterOptions);
    document.getElementById('img-gen-global-options').addEventListener('click', handleGlobalOptionsClick);
    uploadButton.addEventListener('click', handleUploadClick);
    removeButton.addEventListener('click', handleRemoveClick);
    fileInput.addEventListener('change', handleFileChange);
    
    const close = () => {
        if (userApiSettings.visionWeaverSettings.rememberOptions) {
            _saveRememberedOptions();
            saveUserSettingsToFirebase(true);
        }
        modal.style.display = 'none';
        modalContent.removeEventListener('click', handleModalClick);
        searchInput.removeEventListener('input', _filterOptions);
        document.getElementById('img-gen-global-options').removeEventListener('click', handleGlobalOptionsClick);
        uploadButton.removeEventListener('click', handleUploadClick);
        removeButton.removeEventListener('click', handleRemoveClick);
        fileInput.removeEventListener('change', handleFileChange);
        cancelButton.onclick = null;
        quickButton.onclick = null;
    };

    const generate = (mode) => {
        const activeButtons = modal.querySelectorAll('.option-btn.active[data-prompt]');
        const promptParts = [];
        activeButtons.forEach(btn => {
            const prompt = btn.dataset.prompt;
            if (prompt && btn.id !== 'img-gen-include-all-dom') {
                promptParts.push(prompt);
            }
        });

        const userText = textarea.value.trim();
        const baseUserText = stripImageStudioAppendedContext(userText);
        const finalPrompt = [...promptParts, userText].filter(Boolean).join(', ');

        if (!finalPrompt) {
            showModal("이미지 생성을 위한 프롬프트를 입력하거나 옵션을 선택해주세요.", () => {});
            return;
        }
        
        _generateImageFromParagraph(
            mode,
            finalPrompt,
            targetElement,
            replace,
            studioUploadedImage,
            baseUserText || resolvedPrefillText
        );
        close();
    };

    cancelButton.onclick = close;
    quickButton.onclick = () => generate('quick');
    
    highestZIndex++;
    modal.style.zIndex = highestZIndex;
    modal.style.display = 'flex';
    requestAnimationFrame(() => {
        if (studioLeft) studioLeft.scrollTop = 0;
        if (tabPanels) tabPanels.scrollTop = 0;
        if (textarea) textarea.scrollTop = 0;
    });
}

function _updateAndSaveVisionSettings() {
    if (!userApiSettings.visionWeaverSettings) {
        console.warn("Vision Weaver settings object not initialized. Skipping save.");
        return;
    }
    const settings = userApiSettings.visionWeaverSettings;

    settings.autoGenerateMode = document.getElementById('auto-generate-mode-select').value;
    settings.autoGenerateMode = settings.autoGenerateMode === 'off' ? 'off' : 'quick';
    settings.imageApi = document.getElementById('image-api-select').value;
    delete settings.refineApi;
    
    const activePreset = document.getElementById('active-preset-select').value;
    settings.activePreset = activePreset === 'none' ? null : activePreset;
    
    const disableTextToggle = document.getElementById('img-gen-disable-text-toggle');
    if (disableTextToggle) {
        settings.disableTextOutput = disableTextToggle.classList.contains('active');
    }

    if (activePreset !== 'none') {
        const presetData = settings.presets[activePreset] || {};
        presetData.main = document.getElementById('preset-url-main').value.trim() || null;
        presetData.face = document.getElementById('preset-url-face').value.trim() || null;
        presetData.clothing = document.getElementById('preset-url-clothing').value.trim() || null;
        settings.presets[activePreset] = presetData;
    }

    saveUserSettingsToFirebase(true);
    trace("VisionWeaver", "SettingsAutoSaved", { activePreset: settings.activePreset, disableText: settings.disableTextOutput });
}

async function openVisionWeaverSettingsModal() {
    const modal = document.getElementById('vision-weaver-settings-modal');
    if (!modal) return;
    const settings = userApiSettings.visionWeaverSettings;
    document.getElementById('auto-generate-mode-select').value = settings.autoGenerateMode === 'off' ? 'off' : 'quick';
    document.getElementById('image-api-select').value = settings.imageApi || 'universal';
    
    const activePreset = settings.activePreset || 'none';
    document.getElementById('active-preset-select').value = activePreset;
    await renderPresetEditor(activePreset);
    
    highestZIndex++;
    modal.style.zIndex = highestZIndex;
    modal.style.display = 'flex';
}

function closeVisionWeaverSettingsModal() {
    const modal = document.getElementById('vision-weaver-settings-modal');
    if (modal) modal.style.display = 'none';
}

async function renderPresetEditor(presetNum) {
    const container = document.getElementById('preset-editor-container');
    if (!container) return;

    if (presetNum === 'none') {
        container.style.display = 'none';
        return;
    }
    container.style.display = 'block';

    const presetData = userApiSettings.visionWeaverSettings.presets[presetNum] || { main: null, face: null, clothing: null };
    
    const types = ['main', 'face', 'clothing'];
    for (const type of types) {
        const input = document.getElementById(`preset-url-${type}`);
        const preview = document.querySelector(`.preset-preview[data-type="${type}"]`);
        const url = presetData[type];
        
        input.value = url || '';
        preview.style.backgroundImage = 'none';

        if (url) {
            try {
                const base64 = await fetchImageAsBase64(url);
                preview.style.backgroundImage = `url(${base64})`;
            } catch (e) {
                preview.style.backgroundImage = 'none';
            }
        }
    }
}

function initializeVisionWeaverPanel() {
    if (!visionWeaverPanel) return;

    const settingsBtn = document.getElementById('vision-weaver-settings-btn');
    const closeBtn = visionWeaverPanel.querySelector('.close-btn');
    const minimizeBtn = visionWeaverPanel.querySelector('.panel-minimize-btn');
    const maximizeBtn = visionWeaverPanel.querySelector('.panel-maximize-btn');
    const quickGenerateBtn = document.getElementById('quick-generate-btn');
    
    const settingsModal = document.getElementById('vision-weaver-settings-modal');
    const settingsCloseBtn = document.getElementById('vision-settings-close-btn');
    const activePresetSelect = document.getElementById('active-preset-select');
    const presetEditorContainer = document.getElementById('preset-editor-container');
    const resetAllPresetsBtn = document.getElementById('reset-all-presets-btn');
    document.getElementById('refined-generate-btn')?.remove();
    document.querySelector('#auto-generate-mode-select option[value="refined"]')?.remove();
    document.getElementById('refine-api-select')?.closest('.api-choice')?.remove();

    if (visionWeaverToggleBtn) {
        visionWeaverToggleBtn.addEventListener('click', () => togglePanel(visionWeaverPanel));
    }
    settingsBtn.addEventListener('click', openVisionWeaverSettingsModal);
    closeBtn.addEventListener('click', () => togglePanel(visionWeaverPanel, false));
    minimizeBtn.addEventListener('click', () => handlePanelMinimize(visionWeaverPanel));
    maximizeBtn.addEventListener('click', () => handlePanelMaximize(visionWeaverPanel));
    initializeDraggableAndResizablePanel(visionWeaverPanel);

    settingsCloseBtn.addEventListener('click', closeVisionWeaverSettingsModal);
    settingsModal.addEventListener('click', (e) => {
        if (e.target === settingsModal) closeVisionWeaverSettingsModal();
    });

    const debouncedSave = debounce(_updateAndSaveVisionSettings, 500);
    
    activePresetSelect.addEventListener('change', (e) => {
        renderPresetEditor(e.target.value);
        _updateAndSaveVisionSettings();
    });
    
    const controlsToWatch = ['auto-generate-mode-select', 'image-api-select'];
    controlsToWatch.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', _updateAndSaveVisionSettings);
    });

    if (presetEditorContainer) {
        presetEditorContainer.addEventListener('input', (e) => {
            if (e.target.matches('input[type="text"]')) {
                debouncedSave();
            }
        });
    }
    
    presetEditorContainer.addEventListener('click', async (e) => {
        if (e.target.classList.contains('preset-url-fetch')) {
            const type = e.target.dataset.type;
            const input = document.getElementById(`preset-url-${type}`);
            const preview = document.querySelector(`.preset-preview[data-type="${type}"]`);
            const url = input.value.trim();
            
            preview.style.backgroundImage = 'none';

            if (!url) {
                _updateAndSaveVisionSettings(); 
                return;
            }
            
            try {
                const base64 = await fetchImageAsBase64(url);
                if (base64) {
                    preview.style.backgroundImage = `url(${base64})`;
                    _updateAndSaveVisionSettings(); 
                }
            } catch (error) {
                console.error("Failed to fetch preset image:", error);
                showToastNotification("❌ 이미지 로드 실패", "URL을 확인해주세요.", `preset-img-fail-${Date.now()}`);
            }
        }
    });

    resetAllPresetsBtn.addEventListener('click', () => {
        const settings = userApiSettings.visionWeaverSettings;
        for (const key in settings.presets) {
            settings.presets[key] = { main: null, face: null, clothing: null };
        }
        settings.activePreset = null;
        document.getElementById('active-preset-select').value = 'none';
        
        renderPresetEditor('none');
        _updateAndSaveVisionSettings();
        showToastNotification("✅ 모든 프리셋이 초기화되었습니다.", "", `presets-reset-${Date.now()}`);
    });

    visionWeaverPanel.addEventListener('mousedown', () => focusPanel(visionWeaverPanel));
    quickGenerateBtn.addEventListener('click', () => handleGeneration('quick'));
}
