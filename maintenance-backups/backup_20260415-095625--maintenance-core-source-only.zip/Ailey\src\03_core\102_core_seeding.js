/* --- Ailey & Bailey Canvas --- */
// File: 102_core_seeding.js
// Version: 2.3 (Version-Based Sync)
// Description: Modified `addDefaultPromptTemplatesIfNeeded` to use a `version` field for comparing and updating default templates. This ensures Firebase data is always reliably synchronized with the latest source code, preventing issues with stale prompts.

// [MODIFIED] Uses a 'version' field for robust, reliable synchronization of default prompts on every load.
async function addDefaultPromptTemplatesIfNeeded() {
    if (!promptTemplatesCollectionRef) return;
    try {
        // 1. Get JS default templates and their names
        const jsDefaultTemplates = DEFAULT_PROMPT_TEMPLATES;
        const jsDefaultTemplateNames = new Set(jsDefaultTemplates.map(t => t.name));

        // 2. Get all Firestore templates
        const snapshot = await promptTemplatesCollectionRef.get();
        const firestoreTemplates = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        const firestoreTemplatesMap = new Map(firestoreTemplates.map(t => [t.name, t]));

        const batch = db.batch();
        let operations = 0;

        // 3. Logic to delete orphaned default templates from Firestore
        firestoreTemplates.forEach(fsTemplate => {
            // Check if a template is marked as default in Firestore but doesn't exist in our JS definition
            if (fsTemplate.isDefault && !jsDefaultTemplateNames.has(fsTemplate.name)) {
                trace("Seeding", "OrphanedPrompt.Delete", { name: fsTemplate.name });
                const docRef = promptTemplatesCollectionRef.doc(fsTemplate.id);
                batch.delete(docRef);
                operations++;
            }
        });

        // 4. Logic to add or update templates from JS definitions based on version
        jsDefaultTemplates.forEach(jsTemplate => {
            const existingFsTemplate = firestoreTemplatesMap.get(jsTemplate.name);
            
            if (existingFsTemplate) {
                // A template with the same name exists. Check if it needs updating.
                const needsUpdate = 
                    (jsTemplate.version && existingFsTemplate.version !== jsTemplate.version) || // Version mismatch is the primary trigger
                    (!jsTemplate.version && existingFsTemplate.promptText !== jsTemplate.promptText) || // Fallback to text compare if no version
                    !existingFsTemplate.isDefault; // The isDefault flag is incorrect in DB
                
                if (needsUpdate) {
                    trace("Seeding", "DefaultPrompt.Update", { name: jsTemplate.name, old_v: existingFsTemplate.version || 'N/A', new_v: jsTemplate.version || 'N/A' });
                    const docRef = promptTemplatesCollectionRef.doc(existingFsTemplate.id);
                    const { name, ...updateData } = jsTemplate; // Exclude name from update data
                    batch.update(docRef, { ...updateData, updatedAt: firebase.firestore.FieldValue.serverTimestamp() });
                    operations++;
                }
            } else {
                // Template does not exist, add it
                trace("Seeding", "DefaultPrompt.Add", { name: jsTemplate.name });
                const docRef = promptTemplatesCollectionRef.doc();
                batch.set(docRef, jsTemplate); // jsTemplate already includes createdAt
                operations++;
            }
        });

        // 5. Commit all operations
        if (operations > 0) {
            await batch.commit();
            trace("Seeding", "Commit.Success", { opCount: operations });
        }

    } catch (error) {
        console.error("Error synchronizing default prompt templates:", error);
        trace("Seeding", "Sync.Error", { error: error.message }, {}, "ERROR");
    }
}


async function seedDefaultData() {
    await addDefaultPromptTemplatesIfNeeded();
    // In the future, other seeding functions can be added here.
}