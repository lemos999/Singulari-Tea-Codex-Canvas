Plan Type: work-plan
Workstream: Startup Header Ready Optimization Retry
Version: v01
Status: Completed
Created: 2026-04-15 01:45 KST
Last Updated: 2026-04-15 02:01 KST
Supersedes or Related Plan: Related to the rolled-back startup optimization pass that was removed before publication stability was re-established. This plan intentionally replaces that direction with a narrower and safer retry.
Current Completion State: Planning, implementation, rebuild, validation, and publication completed
Completed So Far: Root-cause analysis from the prior failed attempt has been preserved, the broken optimization has already been rolled back, the bundle has been restored to the last known good state, the risky full-file rewrite approach has been ruled out, the startup source has been updated with a surgical ASCII-only helper that unlocks the header dock immediately after settings load, the bundle has been rebuilt, the retry harness has verified that unlock now occurs after settings but before seeded and listener-delayed completion, Korean text-bearing runtime blocks remain byte-identical to the pre-change backup in the startup source, and the updated bundle has been published to the GitHub Pages repo as commit `83debc4`.
Remaining Work: No further implementation work is required for this pass. The next action is user confirmation in the real runtime.
Current Blockers: None
Next Step: Monitor the real runtime experience and only consider deeper startup optimization if the user confirms this smaller pass is stable.

# Scoreboard

Current Score: 50
Score Source: provisional
Last Updated: 2026-04-15 01:45 KST
Score Rationale: The user explicitly asked for a safer retry after a rollback. Trust is currently tied to proving that the optimization can be applied without another regression. No user-visible improvement has been delivered yet in this retry, so the working score should remain conservative until implementation and validation succeed.
What Improved: The real failure mode of the prior attempt is now understood more precisely. The retry is being scoped to a smaller, rollback-friendly boundary that avoids large text-bearing rewrites.
What Remains Unsatisfactory: Startup still feels slower than necessary because the top-right dock remains blocked until non-critical initialization completes.
What Should Happen Next To Raise Or Maintain The Score: Apply only the minimal timing change, prove that Korean text remains intact, prove that no runtime errors appear, and publish only after those checks pass.

## Score History

- 2026-04-15 01:45 KST | 50 | provisional | New retry plan opened after rollback. Confidence is intentionally capped until the safer implementation path is proven.

# Objective

Reduce the perceived startup delay caused by the persistent `로딩 중...` header dock state, while preserving the current application behavior, avoiding any encoding corruption in Korean UI strings, and keeping rollback risk extremely low.

The immediate user-facing goal is not to redesign initialization, not to change listener architecture, and not to restructure app startup. The goal is to make the startup feel responsive sooner by moving only the header lock boundary. The user already experienced a failed optimization followed by mojibake in Korean UI, so the acceptance bar for this retry is stricter than normal. The solution must be stable first and only then slightly faster. This means correctness and byte safety take priority over maximizing the optimization delta.

# Background and Problem Summary

The current startup path blocks the fixed tool dock in the mounted canvas until initialization reaches a late point inside `initializeFirebase()`. The UI expresses this by showing the `로딩 중...` text and keeping the tool dock in a disabled visual state. The analysis from the previous pass showed that the lock remained active until three things completed:

1. loading user settings
2. seeding default prompt template data
3. waiting for the first snapshot from multiple listeners

That design makes the startup feel slow even when the application is already safe enough to expose the top-right dock. The last attempt to optimize this changed the code too broadly and introduced an encoding-related regression in Korean-visible strings. The user explicitly rolled back the pass and requested that no new optimization be applied until the cause was understood.

The main lesson from that failure is that the file containing startup logic also contains Korean text literals and must not be rewritten wholesale in this environment. The retry therefore has to stay very small, change as few lines as possible, and preferably touch only ASCII-only lines. The design should also avoid changing the data consistency contract of listeners or background seeding unless absolutely required.

# Real Scope

This workstream covers only the startup dock readiness boundary.

Included in scope:

- identifying the narrowest startup point at which the dock can be safely unlocked
- implementing that timing change with surgical edits only
- preserving the existing initialization order for settings, seeding, and listeners unless a change is absolutely necessary
- rebuilding the bundle
- validating that runtime text remains readable and that no new runtime errors appear
- publishing the bundle only if the checks are clean

Explicitly out of scope:

- changing how notes, projects, prompt templates, or sessions are loaded
- redesigning startup architecture
- reworking Firebase listener initialization
- changing connection toast wording
- changing the main shell layout
- introducing lazy-loading for major surfaces
- modifying any localized Korean string text
- any cleanup or unrelated refactor adjacent to startup

# Constraints and Guardrails

This retry is governed by stronger-than-usual safety rules because the user already had to request a rollback.

The implementation must satisfy all of these constraints:

- do not rewrite the entire startup file
- do not edit Korean string literals unless there is no other possible path
- prefer ASCII-only edits to timing and control flow
- do not widen the change into listener refactoring
- do not touch multiple startup modules unless verification proves it is necessary
- keep the rollback surface very small
- avoid speculative “cleanups”
- do not publish if validation is ambiguous

The user also asked for a “stable range” optimization. That phrase is interpreted here to mean the result should improve perceived startup while keeping behavior predictable under local mode and canvas mode, under slow storage, and under delayed snapshots. The right response is therefore a conservative unlock-boundary adjustment rather than an ambitious async redesign.

# Smallest Safe Assumption

The smallest safe assumption is that the top-right header dock can be exposed as soon as user settings are loaded, even if seeding and listeners are still completing, because the dock’s visible readiness is primarily a shell affordance and not the source of truth for notes, prompt templates, or session hydration.

This assumption is safer than assuming the entire application is ready. It does not claim that every panel is fully hydrated at the earlier moment. It claims only that the dock no longer needs to remain visually blocked for those later non-critical steps. If this assumption fails in verification, the pass must be rolled back rather than widened casually.

# Technical Intent

The safest design is to leave the current asynchronous work exactly where it is and to move only the removal of the `controls-disabled` class earlier in the startup flow. That keeps user settings as the required precondition for visual readiness while leaving seeding and listener startup contracts unchanged. Under this design:

- settings still load before the dock is considered ready
- seeding still runs
- listeners still initialize
- the connection toast can remain at the later point if needed
- only the dock’s locked visual state changes earlier

This is intentionally less aggressive than the previous attempt, which also changed whether some initialization work was awaited. The retry favors byte safety and minimal behavioral movement over maximum latency improvement.

# Why This Design Is Better Than the Failed Attempt

The failed attempt mixed two different kinds of changes:

- behavioral optimization
- structural rewriting of a localized file

That created two risks at once: runtime contract drift and text encoding corruption. The retry separates them. It changes only the minimal condition that controls the loading affordance. That makes three things better:

1. the reason for improvement is easy to understand
2. the rollback surface is obvious
3. validation can focus on a small number of outcomes

This narrower design also helps if the user later wants another rollback. A rollback of a two-line timing shift is straightforward. A rollback of a broadened async architecture pass is more error-prone and harder to reason about.

# Phased Work Sequence

## Phase 1: Confirm the exact lock boundary

Re-read the current startup path and verify the exact lines where the dock remains disabled. Confirm that the current late unlock is still happening after settings, seeding, and listeners. Confirm that the class removal is the actual visual gate.

Success for this phase means the implementation target is unambiguous.

## Phase 2: Save the approved plan record

Write this plan file as the living work record and make the rollback boundary explicit. Record that the optimization retry is intentionally narrower than the previous attempt and that byte-safe editing is a core acceptance rule, not an implementation detail.

Success for this phase means the task has a durable artifact that explains the approach, risks, and rollback expectation.

## Phase 3: Implement the minimal timing change

Use a surgical edit in the startup initializer. Avoid changing Korean string text. Avoid moving seeding or listener code if an earlier header unlock can be achieved without that. If duplicate unlock logic remains later in the function, guard it so it does not change behavior or re-run unnecessarily.

Success for this phase means the change exists only where needed and the readable behavior is obvious from the control flow.

## Phase 4: Rebuild and verify locally

Rebuild the bundle from source. Then validate:

- the dock unlocks earlier than before
- `로딩 중...` does not remain visible after the earlier-ready point
- Korean UI strings are still readable
- there are no new page or console errors
- seeding and listener completion still happen

Success for this phase means the optimization produces user-visible improvement without regressions.

## Phase 5: Review and publish

Run a focused review on correctness, simplicity, and rollback safety. Only after that copy the updated bundle into the publish repo, commit, and push.

Success for this phase means the published bundle is both improved and still reversible.

# Hidden Rules and Consistency Details

The user did not merely ask for startup to be faster. The deeper requirement is that optimization must not trade away trust. Several hidden expectations follow from the conversation history:

- if the optimization makes any visible Korean text look broken, the user will reasonably consider the change a failure regardless of latency gains
- if the optimization introduces even a small startup race that causes a setting selector, prompt selector, or top-right control to behave unpredictably, the user will reasonably prefer the slower old behavior
- if the solution becomes hard to rollback, it violates the repeated user expectation that changes remain reversible

This means the acceptance standard is not raw speed. The acceptance standard is “noticeably better startup feel with no new fragility.”

Another hidden rule is that the dock’s message is only a proxy for readiness. The user likely interprets it as “the app is not ready,” so keeping it visible too long harms perceived responsiveness. But removing it too early could be misleading if the app still hard-fails. The right middle ground is to unlock the shell only once the environment and settings are ready, not before.

# Risk Analysis

## Risk: Early unlock exposes controls before data is safe

If the dock is unlocked too early, a user might click a control that expects listeners or seeded data to already exist.

Mitigation:

- unlock only after user settings are loaded
- do not return from initialization earlier
- keep the rest of the initialization flow intact

## Risk: Duplicate unlock logic causes inconsistent toast behavior

If the earlier unlock is added without guarding the later unlock block, the code may still execute redundant visual changes or confuse future maintenance.

Mitigation:

- keep later logic guarded by class state or separate concerns clearly
- avoid mixing the visual unlock with the connection toast behavior if not necessary

## Risk: Encoding corruption reappears

This is the highest-risk item from the prior attempt.

Mitigation:

- patch only ASCII lines
- avoid replacing whole blocks that contain Korean strings
- inspect the resulting file and runtime text after bundling

## Risk: Bundle is correct locally but wrong after publication

Even with local success, the published bundle may differ if the wrong artifact is copied.

Mitigation:

- rebuild first
- validate the rebuilt local bundle
- only then copy exact bundle outputs to the publish repo
- commit only those artifacts

# Validation Plan

Validation must prove observable outcomes rather than vague confidence.

Required checks:

1. startup still completes in both the source runtime path and the rebuilt bundle path
2. the dock unlock happens before the work previously blamed for the long perceived delay
3. the `로딩 중...` indicator is not still visible after the earlier unlock point
4. Korean text visible in startup-adjacent UI remains intact
5. there are no new page errors or console errors
6. no change is required in unrelated files

Preferred validation method:

- use a lightweight local runtime harness or browser validation script that records the earlier-ready condition
- inspect runtime text manually or through selectors where practical
- keep the validation close to this exact behavior change instead of attempting a full end-to-end regression sweep

# Definition of Done

The work is done only when all of the following are true:

- the startup dock visually unlocks sooner than before
- the change was implemented without a broad rewrite of the startup file
- Korean UI strings remain uncorrupted
- no new runtime errors appear
- the bundle rebuild succeeds
- publication to the GitHub Pages bundle repo succeeds
- the plan record is updated with final status and evidence

If any of those fail, the work is not done, even if startup appears faster.

# Rollback Strategy

Rollback must stay simple and immediate.

The rollback boundary for this plan is:

- the edited startup source file
- the rebuilt bundle artifact
- the published bundle artifact

If verification reveals text corruption, startup races, or header controls becoming unreliable, revert only this optimization retry and return to the last known good published state. Do not attempt layered fixes on top of a broken retry unless the issue is obviously within the same two or three lines changed.

# Review Standard

Before publishing, the change should be reviewed against these questions:

- Is the improvement achieved by the fewest possible changed lines?
- Does the code remain easy to read for the next maintainer?
- Did the retry avoid changing localized text?
- Is the later startup behavior still intact?
- Is rollback obvious?

If any answer is “no,” simplify further before shipping.

# Working Notes for This Retry

This plan deliberately chooses not to optimize seeding or listener startup yet. That may still be a worthwhile future improvement, but it is not the right first retry after an encoding regression. The correct engineering discipline here is to restore confidence first with the smallest complete fix, then consider deeper optimization only after the system proves stable again.

The expected user-visible improvement is modest but real: the top-right dock should stop showing `로딩 중...` sooner, which makes the app feel ready sooner. That narrower improvement is preferable to a more ambitious optimization that risks another rollback.
