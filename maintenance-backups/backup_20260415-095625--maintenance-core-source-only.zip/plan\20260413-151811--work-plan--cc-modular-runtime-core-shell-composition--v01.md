# Work Plan: `.cc` Modular Runtime With Always-On Core Shell

## Objective

Refactor the current Ailey canvas runtime so `.cc` can compose content more freely while still guaranteeing the shared top header, chat, and notes surfaces at all times. The goal is to reduce hard coupling to a single `renderAppShell` content path without breaking the existing hosted runtime, export path, or bundle contract.

## User Intent

- Keep `main.js` and `main.css` feature value.
- Preserve a permanent core shell:
  - top header
  - chat
  - notes
- Make the content surface more composable:
  - stronger freedom inside the body/content area
  - less dependence on one rigid shell/content handshake
  - support for future app-shell, standalone-like, and hybrid content strategies
- Avoid dropping current functionality just to gain flexibility.

## Current Findings

- `renderAppShell(...)` is currently the public bootstrap path:
  - `Ailey/index.html`
  - `Ailey/src/00_shell/005_shell_part6_main_assembler.js`
  - `Ailey/bundler.js` reserves the symbol during minification.
- The runtime is already partly modular in source layout:
  - `src/00_shell` owns shell assembly
  - `src/04_features_chat` owns chat
  - `src/05_features_notes` owns notes
  - `src_css` is already split into base, panels, chat, notes, widget CSS
- The hard coupling is mostly in the current bootstrap contract:
  - `renderAppShell()` clears the body
  - injects the whole shell template
  - mounts content into `#ai-content-placeholder`
  - initializes core features globally afterward

## Scope

### In scope

- Backup current runtime entry points before changes.
- Introduce a clearer split between:
  - always-on core shell mounting
  - content mounting / hydration
- Preserve backward compatibility for existing callers that still invoke `renderAppShell(...)`.
- Prepare the runtime so content composition can evolve without requiring shell replacement each time.
- Rebuild `bundle/main.js` and `bundle/main.css`.
- Run focused verification for:
  - header presence
  - chat availability
  - notes availability
  - `.cc` content mounting

### Out of scope for this pass

- Full removal of `renderAppShell` as a public compatibility adapter.
- A complete new standalone renderer contract for every mode.
- Major redesign of visual styling unrelated to modularization.
- Rewriting the prompt module again unless runtime changes require a small alignment tweak.

## Design Intent

Implement the smallest safe architectural shift:

1. Keep `renderAppShell(...)` as a compatibility adapter.
2. Extract shell setup into a reusable core-shell mount path.
3. Extract content mounting into a separate composable function.
4. Ensure header/chat/notes are always mounted by the core-shell path.
5. Keep initialization order explicit so retries and future alternate renderers stay predictable.

## Risks

- Breaking existing hosted bootstrap if `renderAppShell(...)` behavior drifts.
- Rebinding failures after body replacement.
- Feature initialization depending on implicit DOM timing.
- Export/archive flows assuming the old mount structure.
- CSS regressions if shell/content boundaries shift without matching selectors.

## Verification Plan

- Rebuild bundles with `node Ailey/bundler.js`.
- Verify no build errors.
- Verify `Ailey/index.html` still boots through the compatibility path.
- Verify the mounted DOM still contains:
  - `#immersive-header`
  - `#chat-panel`
  - `#notes-app-panel`
  - `#ai-content-placeholder`
- Verify canvas content still renders and hydrates.
- Check for obvious regressions in export/bootstrap error handling.

## Assumptions

- The safest first step is to preserve `renderAppShell(...)` as a public wrapper while refactoring internals underneath it.
- The user’s requirement is “always-on core shell, freer content composition,” not “delete all existing shell behavior immediately.”
