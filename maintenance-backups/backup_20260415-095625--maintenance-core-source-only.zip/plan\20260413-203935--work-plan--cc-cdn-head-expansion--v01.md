Plan Type: Work Plan
Workstream: Expand `.cc` to allow head-level CDN freedom while preserving runtime shell guarantees
Version: v01
Status: Completed
Created: 2026-04-13 20:39:35 +09:00
Last Updated: 2026-04-13 21:03:30 +09:00
Supersedes or Related Plan: Related `plan/20260413-170640--work-plan--cc-ccc-freedom-absorption-loop--v01.md`; Related `plan/20260413-181700--cc-ccc-freedom-absorption-loop-report--v01.md`; Related `plan/20260413-153557--work-plan--publish-bundled-runtime-to-singulari-tea-codex-canvas--v01.md`
Current Completion State: The workstream is complete. A pre-edit backup of `cc_universal_module_mm.md` was created, the prompt contract now authorizes broad head-level CDN use including full Tailwind CDN and other public CDN assets, two real validation fixtures were rendered through the local runtime path, the runtime-owned shell surfaces remained present, and the updated prompt was published to GitHub after passing local validation.
Completed So Far: The current `.cc` contract was re-read, the active shell rules were reviewed, and the approved plan was written to disk. A local backup was then created at `backups/cc-module/cc_universal_module_mm--20260413-203935-pre-cdn-expansion.md`. The prompt was revised so the canonical bootstrap shell remains the required runtime handoff skeleton while the head becomes extensible. The rewrite now explicitly permits additional head-level `<link>`, `<script>`, `<style>`, `<meta>`, and related resources, states that there is no CDN whitelist, and names full Tailwind CDN support plus other external resources as normal `.cc` composition tools. Two validation fixtures were authored under `visual-tests/20260413-203935-cc-cdn-head-expansion/`: one Tailwind-only head expansion page and one multi-CDN page using Tailwind, Font Awesome, Animate.css, and Alpine. Both fixtures were rendered through the local server on `http://127.0.0.1:8002` using headless Chrome. Screenshots were captured, rendered DOM snapshots were saved, and a Playwright-core validation script confirmed that `#immersive-header`, `#chat-panel`, `#notes-app-panel`, `#ai-content-placeholder`, and `#learning-content` all remained present for both cases. The multi-CDN fixture also confirmed extra head assets and Alpine-driven behavior. After validation passed, the prompt file was copied into `Singulari-Tea-Codex-Canvas-pr`, committed as `4ad922a`, and pushed to `origin/main`.
Remaining Work: No required work remains under this plan.
Current Blockers: No active blocker remains.
Next Step: Report the successful local validation and GitHub publish back to the user, including the backup path, validation evidence, and commit id.

# Scoreboard

Current Score: 50 / 100
Score Source: provisional
Last Updated: 2026-04-13 21:03:30 +09:00
Score Rationale: The user has not supplied an explicit numeric satisfaction score, so the score must remain provisional and capped. The evidence state is now strong: the live prompt contract has been updated to permit broad head-level CDN use, a local backup exists, Tailwind-only and multi-CDN fixtures rendered successfully under the runtime shell, shell-surface selectors remained present, and the tested prompt has been published to the canonical GitHub repo.
What Improved:
1. The prompt now explicitly permits broad head-level CDN expansion instead of forbidding it.
2. A dated local backup preserves the pre-change contract.
3. Tailwind-only and multi-CDN fixtures both rendered successfully inside the `.cc` runtime path.
4. Shell-surface selector checks passed for both validation pages.
5. The validated prompt was published to GitHub and the remote branch is current.
What Remains Unsatisfactory:
1. The contract is now intentionally permissive, so future prompt outputs could still misuse that freedom if they ignore the remaining shell-ownership guardrails.
2. Validation covered strong representative cases but not every possible third-party CDN library or aggressive reset stylesheet.
Actions To Raise Or Maintain The Score:
1. Keep using the shell-ownership clauses when broad CDN freedom is exercised in future prompt revisions.
2. If a specific third-party CDN library causes shell reset or takeover pressure, handle that as a targeted prompt refinement rather than retreating from the broad permission model by default.

Score History:
1. 2026-04-13 20:39:35 +09:00 | score 50 | source provisional | New approved workstream opened for `.cc` CDN-expansion with backup-first and test-before-publish requirements.
2. 2026-04-13 21:03:30 +09:00 | score 50 | source provisional | Backup created, prompt revised for broad head-level CDN freedom, Tailwind-only and multi-CDN fixtures passed local runtime validation, and the tested prompt was pushed to GitHub as commit `4ad922a`.

# Objective

Revise `cc_universal_module_mm.md` so that `.cc` can legally and explicitly use head-level CDN resources, including but not limited to Tailwind CDN, other CSS frameworks, icon packs, utility libraries, or subject-specific presentation libraries, while preserving the core behavioral identity of the `.cc` runtime. The user wants the system to favor freedom over restraint and wants that freedom to extend beyond Tailwind alone. The result should make it possible for a `.cc` artifact to use external presentation resources broadly, yet still remain recognizably within the `.cc` execution model: one public trigger, one transport contract, one runtime shell, and one mounted payload surface that hydrates inside the existing application chrome.

The change is not merely a wording cleanup. It is a policy shift. Under the current prompt, the shell is effectively fixed, the head asset list is locked, and external CDN inclusion is disallowed. Under the new approved direction, the shell must remain operational but the head must become resource-extensible. The contract needs to describe what freedom has been granted, what remains protected, and what still counts as a violation.

# Confirmed Facts

The live prompt file currently says `.cc` is the only public trigger and that the canonical bootstrap shell should keep the loader text, loader style, asset set, head order, script placement, bootstrap logic, and `renderAppShell` call shape intact.

The current prompt explicitly forbids shell-replacement runtimes, outer-shell style blocks, standalone Tailwind page shells, and alternate body-level bootstrap systems.

The user now explicitly wants CDN freedom broad enough to support all Tailwind capabilities and, beyond that, other external libraries as well.

The user still wants `.cc` behavior preserved. In conversation, this means the runtime-owned header, chat, notes, and other persistent shell surfaces should remain available and should not be silently replaced by a fully standalone page takeover.

The user asked for a local backup before modification and wants a real test-and-repair loop before any GitHub publish.

# Working Assumptions

The smallest safe assumption is that "all CDN allowed" is a design goal about expressive resources rather than a request to permit arbitrary privileged remote execution against runtime-owned shell surfaces. Therefore the contract should still forbid payload logic from targeting or mutating the runtime-owned header, chat, notes, top bar, or shell-controlled panels even if external resources are now allowed in the document head.

The next safe assumption is that the user values freedom more than canonical exactness, but not more than basic product viability. Therefore the revised wording should allow head-level `<script>` and `<link>` additions while continuing to preserve the loader, the `#ai-content-placeholder`, the runtime bootstrap call, and the concept of a persistent application shell.

Another safe assumption is that broad CDN freedom will create new failure modes: script load-order problems, duplicate CSS resets, external font flashes, icon libraries that assume DOM ownership, and UI kits that try to style `body` or globally reset all elements. The plan must therefore validate both a simple Tailwind case and a more adversarial multi-CDN case to learn whether the revised contract still yields usable `.cc` artifacts.

The final assumption is that GitHub publish should target the canonical repo only after the revised prompt passes local validation. If validation shows contract ambiguity or runtime breakage, the work should recurse locally until stable enough to release.

# Scope

This workstream covers:

1. creating a local backup of the prompt file before modification,
2. revising `cc_universal_module_mm.md`,
3. writing or refreshing local validation fixtures that reflect the new policy,
4. running runtime validation and inspecting the results,
5. applying repair iterations when validation shows contract-level weakness,
6. updating this plan and leaving evidence,
7. publishing the prompt update to GitHub only after the local evidence is acceptable.

This workstream does not automatically include:

1. a production runtime code refactor unrelated to the contract change,
2. a rewrite of the bundle pipeline unless the validation proves the prompt change alone is insufficient,
3. deployment of experimental prompt variants other than the approved live file,
4. publishing partial or unvalidated drafts.

# Why This Needs More Than A Simple One-Line Rule Change

At first glance the request sounds like a single permission flip: remove the no-CDN rule and allow all CDN resources. In practice that would be incomplete and fragile. The live prompt interlocks several ideas:

1. the head asset set is fixed,
2. the bootstrap shell is exact,
3. freedom lives only inside the mounted payload,
4. the runtime shell owns shared chrome,
5. payload-local scripts must stay scoped,
6. placeholder-backed visuals are optional and risk-aware.

If the old fixed-head wording is removed without replacing the surrounding guardrails, the prompt may drift toward a fully standalone document model in which generated pages override or ignore the runtime shell. That would satisfy "freedom" in a narrow sense while quietly violating the user's broader goal of preserving `.cc` behavior. The revised document must therefore carefully separate three layers:

1. transport shell invariants that still matter,
2. head-level resource freedom that is now allowed,
3. runtime-shell ownership boundaries that still remain in force.

This means the wording change must explain that `.cc` may extend the head, but head freedom does not imply body-level shell takeover, runtime control duplication, or permission to destroy the persistent application chrome. It also means the self-check section must be updated to test for the new desired behavior rather than the old prohibition.

# Desired End State

When the revised prompt is active, a `.cc` artifact should be able to:

1. keep the `.cc` public trigger as the only trigger,
2. derive the frozen host answer and preserve host semantics,
3. emit the familiar bootstrap loader and runtime handoff surface,
4. add extra CDN `<link>` and `<script>` tags in the head when useful,
5. use Tailwind CDN without restriction to a narrow safelist,
6. use other presentation or utility CDNs when they help the mounted payload,
7. still mount into the runtime shell instead of replacing it,
8. remain readable even if some optional CDN resource is slow or missing,
9. avoid duplicating runtime-owned shell controls or taking ownership of chat, notes, or top-level app chrome.

# Phased Work Sequence

## Phase 1: Backup Preservation

Create a dated local backup copy of `cc_universal_module_mm.md` before changing the live file. The backup should sit in an already established local preservation area or, if no obvious home exists for this specific artifact class, in a new timestamped backup directory under the workspace. The backup should be named clearly enough that the pre-change state can be recovered without ambiguity.

Success criteria:

1. The backup exists on disk.
2. The backup captures the exact current file contents before any edits.
3. The backup path is recorded in this plan or the final report.

## Phase 2: Contract Rewrite

Revise the prompt so the fixed-head prohibition becomes a controlled permission model for head-level expansion. The revision should do all of the following:

1. preserve `.cc` as the only public trigger,
2. keep the frozen host answer semantics unchanged,
3. preserve the loader and runtime-handoff concepts,
4. replace the "do not add head assets" prohibition with explicit allowance for additional external resources,
5. state that external CDN resources may include CSS, JS, fonts, icons, utility frameworks, and other presentation-adjacent libraries,
6. make clear that head freedom does not authorize runtime-shell replacement or mutation of runtime-owned UI surfaces,
7. keep payload-local script behavior scoped and non-blocking where possible,
8. update the self-check so it validates the new freedoms rather than the old ban.

The wording should intentionally favor freedom. It should not sneak in a tight allowlist or a disguised whitelist unless validation proves that completely unconstrained wording causes immediate unrecoverable problems. The user explicitly wants broad freedom, so the default posture should be permissive.

## Phase 3: Fixture Design

Create at least two real local `.cc` validation artifacts.

Fixture A should prove that Tailwind CDN can be used openly in a `.cc` artifact without violating the runtime shell handoff.

Fixture B should be more aggressive and include multiple external resources, for example Tailwind CDN plus an icon library and possibly a small auxiliary library or stylesheet, as long as the test remains understandable and directly relevant to the contract.

These fixtures should intentionally exercise head-level expansion, visible layout freedom, and at least one small client-side enhancement so that the test is meaningful rather than superficial.

## Phase 4: Runtime Validation

Run the fixtures through a local path that reflects actual runtime behavior. Validation should check more than "page loads." It should confirm:

1. the runtime shell still mounts,
2. the content is visible,
3. the extra CDN resources load without obvious breakage,
4. the mounted payload remains distinct from runtime-owned chrome,
5. major user-facing reading flow is intact,
6. no obvious loading-order regression breaks the page.

Where possible, collect screenshot evidence and DOM-level confirmation of persistent shell surfaces such as `#immersive-header`, `#chat-panel`, `#notes-app-panel`, `#ai-content-placeholder`, and `#learning-content`.

## Phase 5: Repair Loop

If validation reveals issues, fix the weakest contract points first. Likely repair classes include:

1. wording ambiguity that accidentally authorizes full shell takeover,
2. overly restrictive wording that still prevents the desired CDN usage,
3. weak failure-handling guidance for optional external resources,
4. insufficient separation between head freedom and runtime-shell ownership,
5. poor self-check coverage.

Any repair should remain surgical and evidence-led. The goal is not to retreat from freedom unless the failure is severe enough that no other repair is plausible.

## Phase 6: Release

Only after the contract passes the local evidence bar should the updated prompt be published to the GitHub repo. The final release step should include a clean commit, push, and verification that the target branch matches the remote after push.

# Validation Matrix

The validation matrix for this workstream should intentionally cover both friendly and adversarial cases.

Friendly case:

1. Tailwind CDN only
2. strong free-layout composition
3. no special runtime hostility
4. confirm that the output stays mounted inside the shell

Adversarial case:

1. Tailwind CDN plus at least one more CDN resource
2. visible global-styling pressure such as icon fonts or helper utilities
3. one small head-loaded script or library if it remains relevant
4. confirm that runtime shell still survives and that content remains readable

Failure signals to watch:

1. the page styling the whole body in a way that visually erases the runtime shell,
2. the head additions preventing the loader or handoff from finishing,
3. global resets destroying shell chrome,
4. duplicate controls appearing where runtime-owned controls should remain singular,
5. script collisions causing errors before main content renders,
6. a contract so vague that it would obviously encourage a future generator to replace the application shell entirely.

Passing evidence:

1. fixtures render successfully,
2. shell surfaces still exist,
3. content remains expressive and uses the external resources meaningfully,
4. no immediate repair is needed to use the rule safely,
5. the final prompt reads as clearly permissive rather than accidentally half-permissive.

# Risks And Tradeoffs

The user has explicitly chosen freedom over strict shell determinism, but the tradeoffs still need to be surfaced and managed:

1. Broad CDN allowance increases dependency risk. Remote outages, CSP mismatches, or slow networks may degrade appearance.
2. External CSS frameworks can globally reset or override runtime-shell styling.
3. External scripts can load in unsafe order or assume document-wide ownership patterns.
4. The more permissive the rule, the more important it becomes to protect the runtime-owned shell concept explicitly in prose.
5. A future generator might interpret "all CDN allowed" as permission to generate a fully independent microsite that only incidentally contains the mounted payload marker. The revised contract must resist that drift.

None of these risks require rejecting the user's direction. They simply mean the document must become clearer, not tighter by default.

# Definition Of Done

This workstream is done when:

1. a pre-edit backup of `cc_universal_module_mm.md` exists locally,
2. the live file explicitly allows head-level CDN expansion broadly enough to support full Tailwind CDN usage and other CDN resources,
3. the same live file still preserves `.cc` trigger unification, frozen-host semantics, and runtime-shell ownership,
4. validation fixtures prove the new rule-set works in practice,
5. any discovered breakage has been repaired or, if irreducible, clearly documented before release,
6. the final tested version is pushed to GitHub,
7. the final report to the user includes what changed, what was validated, and any remaining real-world caveats.

# Evidence To Leave Behind

Expected evidence artifacts include:

1. the backup path,
2. the updated prompt file,
3. one or more validation fixture files,
4. one or more screenshots or DOM capture files,
5. an updated plan state,
6. the final git commit and push confirmation.

# Rollback Plan

If the revised wording proves too permissive in a way that immediately breaks `.cc` runtime behavior, rollback should use the local backup created in Phase 1, not guesswork or a manual reconstruction. If the change has already been pushed, the rollback should happen through a clean forward commit that restores the previous contract, not by history rewriting. This keeps recovery safe and legible.

# Next Operational Action

The next operational action under this approved plan is to create the local backup of `cc_universal_module_mm.md`, then land the first wording revision and immediately prepare the validation fixtures so the policy shift is tested rather than merely asserted.
