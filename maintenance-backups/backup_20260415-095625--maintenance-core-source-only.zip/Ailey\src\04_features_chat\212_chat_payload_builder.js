/* --- Ailey & Bailey Canvas --- */
// File: 212_chat_payload_builder.js
// Version: 2.0 (Multi Attachment Payload)
// Description: Builds Gemini-style content arrays from chat history, including multiple images, PDFs, and text attachments.

function buildAttachmentPayloadParts(attachments) {
    const parts = [];

    attachments.forEach(attachment => {
        if (!attachment) return;

        if (attachment.type === 'image') {
            parts.push({
                inlineData: {
                    mimeType: getMimeTypeFromDataUrl(attachment.content),
                    data: getBase64FromDataUrl(attachment.content)
                }
            });
            return;
        }

        if (attachment.type === 'pdf') {
            parts.push({
                inlineData: {
                    mimeType: 'application/pdf',
                    data: getBase64FromDataUrl(attachment.content)
                }
            });
            return;
        }

        if (attachment.type === 'text') {
            parts.push({
                text: `[첨부 파일: ${attachment.name}]\n${attachment.content}`
            });
        }
    });

    return parts;
}

function buildChatPayload(systemInstruction, history, hiddenContext, attachmentOrAttachments) {
    const fallbackAttachments = Array.isArray(attachmentOrAttachments)
        ? attachmentOrAttachments
        : (attachmentOrAttachments ? [attachmentOrAttachments] : []);

    const contextForApi = hiddenContext
        ? [
            { role: 'user', parts: [{ text: `Here is the full context for the next request.\n\n${hiddenContext}` }] },
            { role: 'model', parts: [{ text: 'Understood.' }] }
        ]
        : [];

    return [
        { role: 'user', parts: [{ text: systemInstruction }] },
        { role: 'model', parts: [{ text: 'Understood.' }] },
        ...contextForApi,
        ...history.map(message => {
            const attachments = normalizeChatMessageAttachments(message);
            const effectiveAttachments = attachments.length > 0 ? attachments : fallbackAttachments;
            const parts = [];
            const textContent = message.displayName || message.content || '';

            if (textContent) {
                parts.push({ text: textContent });
            }

            if (message.role === 'user' && effectiveAttachments.length > 0) {
                parts.push(...buildAttachmentPayloadParts(effectiveAttachments));
            }

            if (parts.length === 0) {
                parts.push({ text: '' });
            }

            return {
                role: message.role === 'user' ? 'user' : 'model',
                parts
            };
        })
    ];
}
