# Work Plan: /sub CC Module Compact Rewrite Recursive Pass

- Timestamp: 2026-04-15 06:20 KST
- Owner: Codex
- User approval: granted
- Type: work-plan
- Status: completed
- Scope: use `/sub` high-reasoning workers to diagnose why `cc_universal_module_mm_compact_v01.md` is underperforming, iterate on a stronger compact rewrite, and keep improving until the result is materially more usable while preserving the critical `.cc` contract

## Understanding

The current compact module exists and is under the 8000-character limit, but the user reports it is not working well enough in practice. The real objective is not merely to shorten the full module; it is to produce a compact MM-style version that still exerts strong behavioral control over downstream HTML generation. The user explicitly requested `/sub`, maximum reasoning, and recursive improvement, so the safest approach is to split the work into bounded analysis, drafting, and review tracks, then integrate the strongest result in the parent workspace.

## Goals

1. Keep the existing full `cc_universal_module_mm.md` intact as the canonical long-form contract.
2. Diagnose likely reasons the current compact version underperforms.
3. Produce a stronger compact module in Markdown, still under 8000 characters.
4. Preserve the critical `.cc` contract:
   - `.cc` as the only trigger
   - frozen host answer as sole semantic source
   - host-unit preservation
   - truthful metadata
   - host-light fallback with subject-native composition
   - mandatory official runtime bootstrap and `bundle/main.js`
   - shell-safe extensible head
   - free/standard mounted layout logic
   - aesthetic fit and runtime theme fit
   - mandatory `image-placeholder` and `visualization-placeholder`
   - final self-check
5. Leave clear evidence on disk for why the final compact wording was chosen.

## Pre-Launch Report

- Request summary: recursively improve the compact `.cc` module with `/sub` and maximum reasoning until it works better
- User constraints: use `/sub`; improve usability; keep MM style; stay under 8000 characters; preserve the `.cc` runtime/composition contract
- Delegation justification: the task benefits from parallel high-reasoning passes on failure analysis, rewrite drafting, and contract review
- Approval status: approved
- Worker count: 3
- Execution mode: mixed
- Review policy: one late read-only review pass before parent integration
- Acceptance strategy: parent compares worker outputs, lands one integrated rewrite in the primary workspace, and verifies character count plus contract coverage
- Evidence path: `subagent-runs/20260415-062000-cc-module-compact-rewrite/`

## Worker Plan

1. Worker A, role `analysis`, stage `diagnose`
   - Mission: explain why the current compact file likely underperforms compared with the long-form module
   - Writable scope: worker workspace only
   - Model: `gpt-5.4`
   - Reasoning effort: `xhigh`
2. Worker B, role `writer`, stage `draft`
   - Mission: write a stronger compact MM-style replacement under 8000 characters
   - Writable scope: worker workspace only
   - Model: `gpt-5.4`
   - Reasoning effort: `xhigh`
3. Worker C, role `reviewer`, stage `acceptance`
   - Mission: compare the current compact file to the full module and identify critical contract loss or weak language
   - Writable scope: worker workspace only
   - Model: `gpt-5.4`
   - Reasoning effort: `high`

## Planned Changes

1. Launch bounded `/sub` workers for diagnosis, draft creation, and review.
2. Integrate the strongest findings into a new compact Markdown artifact.
3. Validate character count and required contract coverage.
4. Close when one stronger compact draft is produced and recorded.

## Risks And Constraints

- Over-compression can silently weaken behavioral control even when the text still mentions the right concepts.
- A compact rewrite that is too abstract may stop producing the canonical shell reliably.
- A compact rewrite that is too literal may preserve the rules but lose MM force and token efficiency.
- Parent integration must stay narrow and auditable.

## Validation

- Confirm the chosen compact file is under 8000 characters.
- Confirm it still explicitly covers the critical `.cc` trigger, host-freeze, runtime, placeholder, theme, aesthetic, and self-check rules.
- Confirm the integrated rewrite is materially stronger than the current compact file in specificity and binding force.
- Confirm evidence from the `/sub` run exists on disk.

## Definition Of Done

An improved compact `.cc` module exists in Markdown, remains under 8000 characters, preserves the core runtime/composition contract, and is backed by `/sub` analysis and review evidence.

## Progress Update

- 2026-04-15 07:45 KST: launched `/sub` workers for diagnosis, draft creation, and review
- 2026-04-15 07:52 KST: created `cc_universal_module_mm_compact_v02.md`
- 2026-04-15 07:54 KST: validated character count at `7989` and confirmed the draft still explicitly preserves `.cc` trigger, frozen host answer, official runtime/bootstrap with `bundle/main.js`, theme fit, mandatory `image-placeholder` and `visualization-placeholder`, and the final self-check
- 2026-04-15 08:03 KST: accepted `cc_universal_module_mm_compact_v02.md` and saved `/sub` evidence under `subagent-runs/20260415-062000-cc-module-compact-rewrite/`

## Rollback Boundary

- `cc_universal_module_mm_compact_v02.md`
- `plan/20260415-062000--work-plan--sub-cc-module-compact-rewrite-recursive--v01.md`
- `subagent-runs/20260415-062000-cc-module-compact-rewrite/`

## Scoreboard

- Current score: 50
- Score source: provisional
- Last updated: 2026-04-15 08:03 KST
- Score rationale: a materially stronger compact draft now exists, passes the explicit contract and character checks, and is backed by `/sub` evidence, but the user has not yet scored or accepted it
- What improved: the underperforming compact v01 now has a tighter v02 replacement under 8000 characters with stronger invalidation/runtime law and cleaner placeholder obligations
- What remains unsatisfactory: user acceptance is still pending and one review worker returned only a partial signal rather than a full acceptance checklist
- Next score action: get user feedback on v02 and refine further only if it still underperforms

### Score History

- 2026-04-15 06:20 KST | 50 | provisional | approved `/sub` recursive compact-rewrite pass opened
- 2026-04-15 07:54 KST | 50 | provisional | created `cc_universal_module_mm_compact_v02.md` under 8000 chars after `/sub` diagnosis and drafting
- 2026-04-15 08:03 KST | 50 | provisional | accepted `cc_universal_module_mm_compact_v02.md` as the stronger compact rewrite
