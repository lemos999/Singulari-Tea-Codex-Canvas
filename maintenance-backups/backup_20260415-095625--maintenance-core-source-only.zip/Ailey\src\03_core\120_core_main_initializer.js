/* --- Ailey & Bailey Canvas --- */
// File: 120_core_main_initializer.js
// Version: 24.3 (Silent Auto-Generation)
// Description: Keeps the parallel auto-generation flow while converting the header to a scroll-aware upper-right icon dock and removing ambient auto-generation toasts.

function initializeImmersiveHeaderDock() {
    if (!body) return;

    const header = document.getElementById('immersive-header');
    if (!header) return;

    let lastScrollY = Math.max(window.scrollY || 0, 0);
    let ticking = false;

    const syncHeaderVisibility = () => {
        const currentScrollY = Math.max(window.scrollY || 0, 0);
        const isNearTop = currentScrollY <= 24;
        const scrollingUp = currentScrollY < (lastScrollY - 4);
        const scrollingDown = currentScrollY > (lastScrollY + 4);

        if (isNearTop || scrollingUp) {
            body.classList.add('header-visible');
        } else if (scrollingDown) {
            body.classList.remove('header-visible');
        }

        lastScrollY = currentScrollY;
        ticking = false;
    };

    body.classList.add('header-visible');

    window.addEventListener('scroll', () => {
        if (ticking) return;
        ticking = true;
        window.requestAnimationFrame(syncHeaderVisibility);
    }, { passive: true });

    window.addEventListener('resize', syncHeaderVisibility, { passive: true });
    syncHeaderVisibility();
}

function openPromptManager() {
    if (promptManagerModalOverlay) {
        highestZIndex++;
        promptManagerModalOverlay.style.zIndex = highestZIndex;
        promptManagerModalOverlay.style.display = 'flex';
    }
    renderPromptManager();
}

function closePromptManager() {
    if (promptManagerModalOverlay) promptManagerModalOverlay.style.display = 'none';
}

async function handleSequentialGenerationOnLoad() {
    const isLiveExportRuntime = document.body?.dataset?.exportMode === 'live';
    if (isLiveExportRuntime) {
        trace("AutoGenerate", "skip", { reason: "Live export runtime preserves existing media and disables auto-generation." });
        return;
    }

    if (!userApiSettings.visualizationSettings?.autoGenerateOnLoad) {
        trace("AutoGenerate", "skip", { reason: "Feature is disabled in settings." });
        return;
    }

    const imagePlaceholders = Array.from(document.querySelectorAll('.type-generated-image')).filter((element) => {
        return !element.querySelector('.generated-image-wrapper img[src]');
    });
    const vizPlaceholders = Array.from(document.querySelectorAll('.type-visualization-placeholder'));

    if (imagePlaceholders.length === 0 && vizPlaceholders.length === 0) {
        trace("AutoGenerate", "skip", { reason: "No placeholders found on the page." });
        return;
    }

    const totalItems = imagePlaceholders.length + vizPlaceholders.length;
    let itemsProcessed = 0;
    const toastId = null;
    const showProgressToast = () => {};
    const hideProgressToast = () => {};
    trace("AutoGenerate", "start", { images: imagePlaceholders.length, viz: vizPlaceholders.length });

    showProgressToast(`자동 생성 중... (0 / ${totalItems})`, toastId);

    const updateProgress = () => {
        itemsProcessed++;
        showProgressToast(`자동 생성 중... (${itemsProcessed} / ${totalItems})`, toastId);
    };

    // --- Stream 1: Process Images in Batches of 10 ---
    const imagePromise = (async () => {
        if (imagePlaceholders.length === 0) return;

        const IMAGE_BATCH_SIZE = 10;
        trace("AutoGenerate", "process.image.start.batch", { count: imagePlaceholders.length, batchSize: IMAGE_BATCH_SIZE });

        for (let i = 0; i < imagePlaceholders.length; i += IMAGE_BATCH_SIZE) {
            const chunk = imagePlaceholders.slice(i, i + IMAGE_BATCH_SIZE);
            
            const chunkPromises = chunk.map(async (element) => {
                try {
                    // isAuto: true allows parallel execution without global UI locking
                    await handleGeneration('quick', { targetElement: element, isAuto: true });
                } catch (error) {
                    console.error("Auto-generation for an image failed:", error);
                    trace("AutoGenerate", "process.image.error", { error: error.message }, {}, "ERROR");
                    if (element) {
                        element.innerHTML = `<p style="color: #d9534f;">이미지 생성 실패</p>`;
                    }
                } finally {
                    updateProgress();
                }
            });

            // Wait for the current batch of 10 to finish before starting the next batch
            await Promise.all(chunkPromises);
        }
    })();


    // --- Stream 2: Process Visualizations One at a Time ---
    const vizPromise = (async () => {
        if (vizPlaceholders.length === 0) return;

        const batchSize = 1;
        trace("AutoGenerate", "process.viz.start", { total: vizPlaceholders.length, batchSize });

        for (const placeholder of vizPlaceholders) {
            try {
                await handleBatchVisualizationGeneration(
                    { libraries: ['AI 추천'], isSimulation: false, isSimpleMode: true },
                    [placeholder]
                );
            } catch (error) {
                console.error("Auto-generation for a visualization failed:", error);
                trace("AutoGenerate", "process.viz.item.error", { error: error.message }, {}, "ERROR");
            }
            updateProgress();
        }
    })();

    // Wait for both independent streams to complete
    await Promise.all([imagePromise, vizPromise]);

    hideProgressToast(toastId);
    showToastNotification("✅ 자동 생성 완료", `${totalItems}개의 항목이 생성되었습니다.`, `auto-generate-complete-${Date.now()}`);
    trace("AutoGenerate", "complete");
}


async function initializeCoreFeatures() {
    if (!body) { console.error("Core body element not found post-render."); return; }

    if (isCoreShellInitialized) {
        trace("System", "CoreShellReuse", { canvasId, layout: currentCanvasLayoutMode });
        if (typeof applyMobileShellViewportMode === 'function') {
            applyMobileShellViewportMode();
        }
        handleSequentialGenerationOnLoad();
        return;
    }

    temporarySession.messages = [];
    if (typeof katex_css_data !== 'undefined' && !document.getElementById('katex-style-injected')) {
        const style = document.createElement('style');
        style.id = 'katex-style-injected';
        style.textContent = katex_css_data;
        document.head.appendChild(style);
    }
    setInterval(checkStreamCompletions, 500);
    createApiSettingsModal();
    debouncedSaveUserSettings = debounce(() => saveUserSettingsToFirebase(true), 1000);

    if (!areCoreShellBindingsInitialized) {
        setupUnifiedSettingsControl();
        attachEventListeners();
        areCoreShellBindingsInitialized = true;
    }

    initializeDraggableAndResizablePanel(document.getElementById('chat-panel'));
    initializeVisionWeaverPanel();
    if (typeof renderStagedChatAttachments === 'function') {
        renderStagedChatAttachments();
    }

    applyPanelStates();
    if (typeof applyMobileShellViewportMode === 'function') {
        applyMobileShellViewportMode();
        window.addEventListener('resize', applyMobileShellViewportMode);
        if (window.visualViewport) {
            window.visualViewport.addEventListener('resize', applyMobileShellViewportMode);
            window.visualViewport.addEventListener('scroll', applyMobileShellViewportMode);
        }
    }
    initializeImmersiveHeaderDock();
    
    await initializeFirebase();

    renderApiPresetSelector();
    updateChatHeaderModelSelector();
    renderQuickPromptSelect();

    // Expose the generation handler for onclick events in rendered blocks
    window.handleImageGeneration = handleGeneration;
    window.openImageGenerationOptionsModal = openImageGenerationOptionsModal;
    window.openVisionWeaverSettingsModal = openVisionWeaverSettingsModal;

    handleNewChat(false);
    setupDebugger();
    if (typeof initializePortalTooltip === 'function') {
        initializePortalTooltip();
    }
    
    // [REMOVED] The old auto-generation logic is now replaced by the new sequential system.
    // handleAutoImageGeneration();
    
    if (typeof initializeLocalBackupAutomation === 'function') {
        initializeLocalBackupAutomation();
    }

    isCoreShellInitialized = true;

    // [NEW] Trigger for the narrative archiver
    if (typeof handleAutomaticArchiving === 'function') {
        handleAutomaticArchiving();
    }
    
    // [NEW] Trigger for the sequential auto-generation system
    handleSequentialGenerationOnLoad();
}

if (typeof window !== 'undefined') {
    window.initializeCoreFeatures = initializeCoreFeatures;
}

function attachEventListeners() {
    document.addEventListener('click', (e) => {
        const mobileSidebarReturn = e.target.closest('#mobile-sidebar-return-btn');
        if (mobileSidebarReturn && chatPanel && document.body?.classList.contains('mobile-shell-mode')) {
            e.preventDefault();
            e.stopPropagation();
            settingsPopover?.classList.remove('show');
            chatPanel.classList.remove('mobile-sidebar-open');
            return;
        }

        const chatSidebarToggle = e.target.closest('#sidebar-toggle-btn');
        if (chatSidebarToggle && chatPanel) {
            e.preventDefault();
            e.stopPropagation();
            if (document.body?.classList.contains('mobile-shell-mode')) {
                settingsPopover?.classList.remove('show');
                chatPanel.classList.toggle('mobile-sidebar-open');
            } else {
                chatPanel.classList.toggle('sidebar-collapsed');
            }
            return;
        }

        const recallSidebarToggle = e.target.closest('#recall-sidebar-toggle-btn');
        if (recallSidebarToggle && noteRecallView) {
            e.preventDefault();
            e.stopPropagation();
            noteRecallView.classList.toggle('recall-sidebar-collapsed');
            return;
        }

        if (selectionPopover) handleTextSelection(e);
        const notesDropdown = document.getElementById('notes-dropdown-menu');
        if (notesDropdown && !e.target.closest('.more-options-container')) {
            notesDropdown.classList.remove('show');
        }
        if (settingsPopover && !e.target.closest('#settings-control-container')) {
            settingsPopover.classList.remove('show');
        }
        if (
            chatPanel
            && document.body?.classList.contains('mobile-shell-mode')
            && chatPanel.classList.contains('mobile-sidebar-open')
            && !e.target.closest('#chat-session-sidebar, #sidebar-toggle-btn')
        ) {
            chatPanel.classList.remove('mobile-sidebar-open');
        }
        if (
            noteRecallView
            && document.body?.classList.contains('mobile-shell-mode')
            && !noteRecallView.classList.contains('recall-sidebar-collapsed')
            && !e.target.closest('#recall-turn-list-container, #recall-sidebar-toggle-btn')
        ) {
            noteRecallView.classList.add('recall-sidebar-collapsed');
        }
    });

    const aiContentPlaceholder = document.getElementById('ai-content-placeholder');
    if (aiContentPlaceholder) {
        initializeDynamicContentListeners(aiContentPlaceholder);
    }
    
    window.addEventListener('message', (event) => {
        if (event.data && event.data.type === 'viz-resize') {
            const iframes = document.querySelectorAll('iframe');
            for (const iframe of iframes) {
                try {
                    // Check if the message came from this iframe's contentWindow
                    if (iframe.contentWindow === event.source) {
                        // Cap the height to a maximum of 1600px to prevent extremely long visualizations from breaking the layout.
                        const newHeight = Math.min(event.data.height, 1600); 
                        iframe.style.height = `${newHeight}px`;
                        break; 
                    }
                } catch (e) {
                    // This can throw a cross-origin error if the iframe is not from the same origin,
                    // which is expected for some libraries. We can safely ignore it.
                }
            }
        }
    });


    if (popoverAskAi) popoverAskAi.addEventListener('click', () => handlePopoverAskAi(chatInput, chatPanel));
    if (popoverAddNote) popoverAddNote.addEventListener('click', handlePopoverAddNote);
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            body.classList.toggle('dark-mode');
            const newTheme = body.classList.contains('dark-mode') ? 'dark' : 'light';
            trace("UI.Action", "ThemeChanged", { to: newTheme });
            saveUserSettingsToFirebase();
            if (window.toastEditorInstance) {
                try { window.toastEditorInstance.setTheme(newTheme); } catch (error) { trace("UI.Error", "ToastThemeFail", { error: error.message }, {}, "ERROR"); console.error("Failed to set ToastUI editor theme:", error); }
            }
        });
    }
    if (chatToggleBtn) chatToggleBtn.addEventListener('click', () => togglePanel(chatPanel));
    
    if (exportMainContentBtn) {
        exportMainContentBtn.addEventListener('click', () => {
            if (typeof window.exportAsLiveHtml === 'function') {
                const currentTitle = document.title || 'Canvas-Export';
                window.exportAsLiveHtml({ title: currentTitle });
            }
        });
    }

    if (chatPanel) {
        chatPanel.addEventListener('mousedown', () => focusPanel(chatPanel));
        chatPanel.querySelector('.close-btn').addEventListener('click', () => togglePanel(chatPanel, false));
        chatPanel.querySelector('.panel-minimize-btn').addEventListener('click', () => handlePanelMinimize(chatPanel));
        chatPanel.querySelector('.panel-maximize-btn').addEventListener('click', () => handlePanelMaximize(chatPanel));
    }
    if (notesAppPanel) {
        notesAppPanel.addEventListener('mousedown', () => focusPanel(notesAppPanel));
    }
    if (contextToggleBtn) {
        contextToggleBtn.addEventListener('click', () => {
            isContextlessMode = !isContextlessMode;
            contextToggleBtn.classList.toggle('active', isContextlessMode);
            trace("UI.Action", "ContextToggleChanged", { to: isContextlessMode });
        });
    }
    if (groundingQuickToggleBtn) {
        groundingQuickToggleBtn.addEventListener('click', () => {
            const activePreset = userApiSettings.apiPresets.find(p => p.id === userApiSettings.activePresetId);
            if (activePreset && activePreset.provider === 'google_paid') {
                activePreset.useGrounding = !activePreset.useGrounding;
                groundingQuickToggleBtn.classList.toggle('active', !!activePreset.useGrounding);
                trace("UI.Action", "GroundingQuickToggleChanged", { to: activePreset.useGrounding });
                saveUserSettingsToFirebase(true);
            }
        });
    }
    if (notesAppToggleBtn) {
        notesAppToggleBtn.addEventListener('click', () => {
            const isOpening = !notesAppPanel || notesAppPanel.style.display !== 'flex';
            togglePanel(notesAppPanel);
            if (isOpening) {
                ensureNotePanelHeader();
                switchView('list');
                renderNoteList();
            }
        });
    }

    if (fileImporter) fileImporter.addEventListener('change', importAllData);
    if (backToListBtn) backToListBtn.addEventListener('click', () => switchView('list'));
    if (recallBackToListBtn) recallBackToListBtn.addEventListener('click', () => switchView('list'));
    if (noteTitleInput) noteTitleInput.addEventListener('input', debounce(() => saveNote(), 1500));
    if (chatForm) {
        chatForm.addEventListener('submit', e => { e.preventDefault(); handleChatSend({ inputElement: chatInput }); });
        chatForm.addEventListener('dragenter', handleChatComposerDragEnter);
        chatForm.addEventListener('dragover', handleChatComposerDragOver);
        chatForm.addEventListener('dragleave', handleChatComposerDragLeave);
        chatForm.addEventListener('drop', handleChatComposerDrop);
    }
    if (chatInput) {
        chatInput.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleChatSend({ inputElement: chatInput }); } });
        chatInput.addEventListener('input', () => autoResizeTextarea(chatInput));
        chatInput.addEventListener('paste', handleChatComposerPaste);
    }
    if (tempSessionToggle) {
        tempSessionToggle.addEventListener('click', () => { const isActive = tempSessionToggle.classList.contains('active'); setTempChatMode(!isActive); });
    }
    if (newChatBtn) newChatBtn.addEventListener('click', () => { handleNewChat(false); });
    if (newProjectBtn) newProjectBtn.addEventListener('click', createNewProject);
    if (searchSessionsInput) searchSessionsInput.addEventListener('input', debounce(renderSidebarContent, 300));
    if (sessionListContainer) {
         sessionListContainer.addEventListener('click', e => {
             const sessionItem = e.target.closest('.session-item'); if(sessionItem) { selectSession(sessionItem.dataset.sessionId); if (document.body?.classList.contains('mobile-shell-mode') && chatPanel) { chatPanel.classList.remove('mobile-sidebar-open'); } return; }
             const projectHeader = e.target.closest('.project-header');
             if(projectHeader) {
                const actionsBtn = e.target.closest('.project-actions-btn');
                if(actionsBtn) { showProjectContextMenu(projectHeader.closest('.project-container').dataset.projectId, e); }
                else { toggleProjectExpansion(projectHeader.closest('.project-container').dataset.projectId); }
                return;
             }
         });
         sessionListContainer.addEventListener('contextmenu', e => {
            const sessionItem = e.target.closest('.session-item');
            if(sessionItem) { showSessionContextMenu(sessionItem.dataset.sessionId, e); }
         });
        sessionListContainer.addEventListener('dragstart', handleDragStart);
        sessionListContainer.addEventListener('dragover', handleDragOver);
        sessionListContainer.addEventListener('dragleave', handleDragLeave);
        sessionListContainer.addEventListener('drop', handleDrop);
    }

    if (chatMessages) {
        chatMessages.addEventListener('click', async (e) => {
            const actionButton = e.target.closest('.message-inline-action-button');
            if (!actionButton) return;
            e.preventDefault();
            e.stopPropagation();
            if (typeof handleInlineMessageActionTrigger === 'function') {
                await handleInlineMessageActionTrigger(actionButton);
            }
        });
        if (typeof setupChatScrollListener === 'function') {
            setupChatScrollListener();
        } else {
            chatMessages.addEventListener('scroll', handleChatScroll);
        }
    }
    if (chatAttachBtn) chatAttachBtn.addEventListener('click', handleFileAttachClick);
    if (chatFileInput) chatFileInput.addEventListener('change', handleFileSelected);
    if (manageApiSettingsBtn) manageApiSettingsBtn.addEventListener('click', openApiSettingsModal);
    if (promptSaveBtn) promptSaveBtn.addEventListener('click', saveCustomPrompt);
    if (promptCancelBtn) promptCancelBtn.addEventListener('click', closePromptModal);
    if (promptModalOverlay) {
        promptModalOverlay.addEventListener('click', (e) => { if (e.target.id === 'prompt-modal-overlay') { closePromptModal(); } });
    }
    if (managePromptsBtn) managePromptsBtn.addEventListener('click', openPromptManager);
    if (promptManagerCloseBtn) promptManagerCloseBtn.addEventListener('click', closePromptManager);
    if (promptManagerModalOverlay) {
        promptManagerModalOverlay.addEventListener('click', e => { if (e.target.id === 'prompt-manager-modal-overlay') closePromptManager(); });
    }
    if (templateListContainer) {
        templateListContainer.addEventListener('click', e => {
            const item = e.target.closest('.template-list-item');
            if (item) { selectTemplate(item.dataset.id); }
        });
    }
    if (addNewTemplateBtn) addNewTemplateBtn.addEventListener('click', handleAddNewTemplateClick);
    if (saveTemplateBtn) saveTemplateBtn.addEventListener('click', handleSaveTemplate);
    if (deleteTemplateBtn) deleteTemplateBtn.addEventListener('click', handleDeleteTemplate);
    if(apiSettingsSaveBtn) apiSettingsSaveBtn.addEventListener('click', () => saveApiSettings(true));
    if(apiSettingsCancelBtn) apiSettingsCancelBtn.addEventListener('click', closeApiSettingsModal);
    if(apiSettingsResetBtn) apiSettingsResetBtn.addEventListener('click', resetApiKeyInFirebase);
    if(verifyApiKeyBtn) verifyApiKeyBtn.addEventListener('click', handleVerifyApiKey);
    if(resetTokenUsageBtn) resetTokenUsageBtn.addEventListener('click', resetTokenUsage);
    if(apiSettingsModalOverlay) {
        apiSettingsModalOverlay.addEventListener('click', (e) => { if (e.target.id === 'api-settings-modal-overlay') { closeApiSettingsModal(); } });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    console.log("Core script (bundle/main.js) loaded. Waiting for render trigger.");
});
