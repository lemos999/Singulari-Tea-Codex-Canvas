/* --- Ailey & Bailey Canvas --- */
// File: 214_chat_utils.js
// Version: 1.0 (Refactored from 210_chat_engine.js)
// Description: Contains utility functions specific to the chat feature.

function checkStreamCompletions() {
    let changed = false;
    for (const sessionId in activeStreams) {
        const stream = activeStreams[sessionId];
        if (!stream.isComplete) {
            const elapsed = (Date.now() - stream.startTime) / 1000;
            const estimatedDuration = stream.content.length / CHAR_PER_SECOND + 0.5;
            if (elapsed > estimatedDuration) {
                trace("System", "StreamTimeout", { sessionId: sessionId.substring(0,5) }, {}, "WARN");
                stream.isComplete = true;
                delete activeStreams[sessionId];
                changed = true;
            }
        }
    }
    if (changed) {
        renderSidebarContent();
    }
}

function getMimeTypeFromDataUrl(dataUrl) {
    if (!dataUrl) return 'application/octet-stream';
    return dataUrl.substring(dataUrl.indexOf(":") + 1, dataUrl.indexOf(";"));
}

function getBase64FromDataUrl(dataUrl) {
    if (!dataUrl) return '';
    return dataUrl.substring(dataUrl.indexOf(",") + 1);
}

function getLatestSession() {
    if (!localChatSessionsCache || localChatSessionsCache.length === 0) return null;
    return [...localChatSessionsCache].sort((a, b) => (b.updatedAt?.toMillis() || 0) - (a.updatedAt?.toMillis() || 0))[0];
}