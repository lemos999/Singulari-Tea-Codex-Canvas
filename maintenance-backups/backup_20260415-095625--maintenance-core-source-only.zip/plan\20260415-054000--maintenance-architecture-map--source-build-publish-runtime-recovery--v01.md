Plan Type: maintenance-architecture-map
Workstream: source-build-publish-runtime-recovery
Version: v01
Status: Active
Created: 2026-04-15 05:40 KST
Updated: 2026-04-15 05:40 KST
Current Completion: 100%
Completed Work:
- Mapped the maintenance backup set required to rebuild and republish the runtime.
- Documented why the publish repository exists and what the HTML artifacts actually load.
- Documented the major runtime subsystems: shell, state, chat, notes, visualization, and export.
- Added operational guidance for backup, rebuild, publish, rollback, and failure diagnosis.
Remaining Work:
- None for this documentation pass.
Blockers:
- None.
Next Step:
- Use this document as the maintenance reference before changing shell bootstrapping, chat behavior, note storage, visualization rendering, bundling, or GitHub publish flow.

# Objective

Preserve the smallest complete set of project knowledge needed to maintain the runtime without carrying the full workspace. This document explains what to back up, why each path matters, how the project is rebuilt and published, and where to debug specific classes of failures.

# Core Principle

The workspace has three different kinds of assets:

1. editable source
2. generated local bundles
3. published runtime files that exported HTML and `.cc` artifacts actually consume

Maintenance problems usually happen when these layers are confused. Source edits do not change already-generated HTML pages until a new bundle is built and the publish repo is updated.

# The Curated Maintenance Backup Set

## Keep These Paths

- `plan/`
- `Ailey/src/`
- `Ailey/src_css/`
- `Ailey/vendor/`
- `Ailey/dist/katex-styles.js`
- `Ailey/bundler.js`
- `Ailey/package.json`
- `Ailey/package-lock.json`
- `Ailey/index.html`
- `Singulari-Tea-Codex-Canvas-pr/bundle/main.js`
- `Singulari-Tea-Codex-Canvas-pr/bundle/main.css`
- `Singulari-Tea-Codex-Canvas-pr/katex.min.css`
- `Singulari-Tea-Codex-Canvas-pr/.github/workflows/static.yml`

## Why Each Path Exists

### `plan/`

This is the maintenance ledger. It stores the approved work plans, reports, rollback notes, root-cause investigations, and architecture notes that explain why the current code looks the way it does.

Without `plan/`, future maintenance loses:

- repair history
- rollback boundaries
- prior root-cause analysis
- design intent for fragile fixes

### `Ailey/src/`

This is the JavaScript source of truth. It contains the runtime logic for:

- shell mounting
- state and local Firebase shim
- core initialization
- API preset management
- chat orchestration and UI
- visualization generation and rendering
- notes and archive behavior
- HTML export logic

If runtime behavior changes, it is almost always rooted here.

### `Ailey/src_css/`

This is the CSS source of truth. It contains the styling for:

- shell chrome
- chat panels and message actions
- notes panels and list views
- modals, notifications, and settings surfaces
- image and visualization UI
- mobile adaptations

If a visual regression is not caused by generated HTML, it is usually here.

### `Ailey/vendor/`

This is not optional. `Ailey/bundler.js` reads fixed browser-side dependencies directly from this folder and embeds them into the generated runtime bundle.

Important vendor assets currently include:

- Firebase compat scripts
- ToastUI editor bundle
- Prism
- KaTeX runtime
- marked
- Leaflet
- KaTeX font files

If `Ailey/vendor/` is missing, the bundle cannot be reproduced faithfully.

### `Ailey/dist/katex-styles.js`

This is also required. The bundler explicitly expects this file and fails if it is absent. It is used to inject embedded KaTeX style content during bundling.

### `Ailey/bundler.js`

This is the build pipeline. It:

1. ensures build dependencies are available
2. reads vendor assets in a fixed order
3. reads source files from `src/00_shell` and `src/`
4. distinguishes regular source from ESM
5. bundles ESM via `esbuild`
6. minifies JS via `terser`
7. minifies CSS via `postcss` and `cssnano`
8. writes `Ailey/bundle/main.js` and `Ailey/bundle/main.css`

If build output is wrong, missing, out of order, or broken, this file is one of the first places to inspect.

### `Ailey/package.json` and `Ailey/package-lock.json`

These define the local build toolchain. They are needed to restore the exact bundling environment, especially for:

- `esbuild`
- `terser`
- `postcss`
- `cssnano`

These files matter even if `node_modules/` is excluded from the backup.

### `Ailey/index.html`

This is the local-mode bootstrap page. It is the simplest local smoke-test harness for `bundle/main.js` and `bundle/main.css`.

Use it when you want to confirm:

- shell mounting works
- the local runtime still boots
- `renderAppShell(...)` is exposed
- local-mode content and stored state still load

### `Singulari-Tea-Codex-Canvas-pr/bundle/main.js`
### `Singulari-Tea-Codex-Canvas-pr/bundle/main.css`

These are the publish-ready runtime bundles. They are not source files. They are the exact artifacts the GitHub Pages site serves to exported HTML and `.cc` artifacts.

They are worth backing up because they preserve the last known-good deployed runtime even if a future rebuild breaks.

### `Singulari-Tea-Codex-Canvas-pr/katex.min.css`

This publish-side static stylesheet is loaded by live export and `.cc` outputs. The bundle alone is not enough for full math rendering.

### `Singulari-Tea-Codex-Canvas-pr/.github/workflows/static.yml`

This preserves the publish automation contract. It explains how the publish repo becomes GitHub Pages output.

# Maintenance Source Map

This section is the fast navigation index. When maintaining the system, start here before reading code.

## Top-Level Map

- `plan/`
  - investigation history, rollback notes, architecture references, and accepted plan records
- `Ailey/src/`
  - JavaScript source of truth
- `Ailey/src_css/`
  - CSS source of truth
- `Ailey/vendor/`
  - browser-side third-party assets embedded by the bundler
- `Ailey/dist/katex-styles.js`
  - required KaTeX style payload used by the bundler
- `Ailey/bundler.js`
  - build pipeline for runtime bundles
- `Ailey/index.html`
  - local bootstrap page for smoke-testing the runtime
- `Singulari-Tea-Codex-Canvas-pr/`
  - publish-side runtime artifacts served by GitHub Pages

## `Ailey/src/` Source Map

### `Ailey/src/00_shell/`

Purpose: shell layout, shell HTML fragments, and shell mount assembly.

Start here when:

- the app frame is missing
- chat/notes containers are misplaced
- top chrome is wrong
- runtime mount contract seems broken

Important files:

- `000_shell_template.js`
  - base shell template markup and shell-owned controls
- `001_shell_part2_modals_common.js`
  - shared modal markup
- `002_shell_part3_*.js`
  - advanced modal fragments and surface blocks
- `003_shell_part4_panel_notes_chat.js`
  - notes/chat panel shell structure
- `004_shell_part5_panel_vision_debugger.js`
  - vision/debugger shell blocks
- `005_shell_part6_main_assembler.js`
  - final shell assembler and `renderAppShell(...)` mount path

### `Ailey/src/01_state/`

Purpose: runtime-global state and local persistence shim.

Start here when:

- local mode behaves differently from canvas mode
- stored notes or sessions are missing
- Firebase-like persistence breaks locally

Important files:

- `001_state_globalVars.js`
  - shared global variables and runtime registries
- `002_local_firebase_shim.js`
  - IndexedDB-backed Firebase substitute for local mode

### `Ailey/src/02_utils/`

Purpose: reusable utility layer shared across shell, chat, notes, export, and visualization.

Start here when:

- a mechanic is reused in several features
- HTML export is wrong
- panel positioning is wrong
- block rendering fails
- context menus or portal tooltips misbehave

Important files:

- `011_utils_helpers.js`
  - string helpers, KaTeX helpers, common rendering helpers
- `012_utils_ui_components.js`
  - shared UI factories and helpers
- `012_utils_context_menu.js`
  - context menu plumbing
- `013_utils_block_renderer.js`
  - mounted content block renderer, visualization wrappers, placeholder hydration, failure states
- `013_utils_panel_manager.js`
  - panel drag, restore, minimize, viewport logic
- `014_utils_visualization_renderer.js`
  - visualization-specific rendering helpers
- `014_utils_ui_actions.js`
  - shared UI action helpers
- `015_utils_vision.js`
  - vision/image helpers
- `016_utils_map_renderer.js`
  - map rendering helpers
- `017_utils_map_icons.js`
  - map marker/icon helpers
- `018_utils_html_exporter.js`
  - live export and standalone export HTML generation
- `019_utils_portal_tooltip.js`
  - tooltip portal behavior
- `020_utils_intelligent_splitter.js`
  - content splitting helpers

### `Ailey/src/03_core/`

Purpose: feature wiring, runtime initialization, API preset management, visualization and archive coordination.

Start here when:

- startup fails
- API preset behavior is wrong
- visualization generation/regeneration is wrong
- image generation studio is wrong
- archive extraction or note archival breaks

Important files:

- `100_core_firebase.js`
  - local vs canvas bootstrap and Firebase init
- `101_core_listeners.js`
  - runtime listeners and data subscriptions
- `102_core_seeding.js`
  - default seed/template bootstrap
- `102_template_*.js`
  - built-in prompt template definitions
- `103_core_default_templates_assembler.js`
  - template assembly
- `110_core_api_settings.js`
  - settings initialization entry
- `111_core_api_settings_data.js`
  - API settings persistence and defaults
- `112_core_api_settings_ui_structure.js`
  - API settings UI layout
- `113_core_api_settings_ui_logic.js`
  - settings UI behavior
- `114_core_api_settings_api_service.js`
  - provider/model discovery and remote calls for settings
- `114_core_api_settings_ui_refresh.js`
  - settings UI refresh/render helpers
- `115_core_api_settings_utils.js`
  - provider classification and small helpers
- `120_core_main_initializer.js`
  - global runtime initializer and cross-surface wiring
- `121_core_initializer_visualization.js`
  - visualization generate/regenerate/code-fix pipeline
- `122_core_initializer_panel_utils.js`
  - panel-side helper initialization
- `123_core_initializer_vision_logic.js`
  - image/vision logic
- `124_core_initializer_vision_handler.js`
  - vision request handling
- `125_core_initializer_vision_ui.js`
  - vision/image UI surface behavior
- `130_core_archiver.js`
  - archive extraction, note archive content capture, structured archival behavior

### `Ailey/src/04_features_chat/`

Purpose: chat data, payload assembly, provider calls, orchestration, compaction, session UI, and message actions.

Start here when:

- model requests fail
- history is wrong
- auto-compact is wrong
- message actions fail
- sidebar/session switching breaks

Important files by concern:

- data and persistence:
  - `200_chat_data.js`
- realtime hooks:
  - `201_chat_realtime.js`
- request and response pipeline:
  - `212_chat_payload_builder.js`
  - `213_chat_api_service.js`
  - `215_chat_orchestrator.js`
  - `216_chat_context_compaction.js`
- action handlers:
  - `210_chat_ui_actions.js`
  - `211_chat_actions.js`
- message rendering:
  - `222_chat_ui_messages_utils.js`
  - `223_chat_ui_messages_content.js`
  - `224_chat_ui_messages_element_factory.js`
  - `225_chat_ui_messages_toolbar.js`
  - `226_chat_ui_messages_rendering.js`
- shell/sidebar/session control:
  - `221_chat_ui_sidebar.js`
  - `227_chat_ui_modals.js`
  - `228_chat_ui_controller.js`
  - `232_chat_prompt_manager.js`
  - `233_chat_sidebar_actions.js`
  - `234_chat_session_manager.js`
  - `235_chat_drag_drop.js`

### `Ailey/src/05_features_notes/`

Purpose: note storage, note editor, recall/archive viewer, note jobs, note backup, and note UI.

Start here when:

- notes fail to save
- archive sections are wrong
- recall or archive display is wrong
- note jobs or backup/import are wrong

Important files by concern:

- note data and CRUD:
  - `300_notes_data.js`
- editor and viewer:
  - `310_notes_editor.js`
  - `315_notes_recall_viewer.js`
  - `320_notes_ui.js`
- backup and import/export:
  - `331_notes_backup_exporter.js`
  - `332_notes_backup_importer.js`
- app wiring:
  - `340_notes_app.js`
  - `341_notes_job_state.js`
- note job pipelines:
  - `342_notes_job_refinement_logic.js`
  - `343_notes_job_report_logic.js`
  - `344_notes_job_ui.js`
  - `345_notes_utils.js`
  - `346_notes_job_translation_logic.js`
- highlights:
  - `350_notes_highlights.js`
  - `351_notes_highlights.js`

### `Ailey/src/06_features_immersion/`

Purpose: immersion mode behavior and any runtime that changes how the content canvas is staged or emphasized.

Start here when:

- immersion mode behavior regresses
- content presentation mode interacts badly with shell or mounted payload

Important file:

- `250_immersion_controller.js`

## `Ailey/src_css/` Source Map

### Foundation and shell surfaces

- `001_base.css`
- `002_widgets.css`
- `002_widget_modals_base.css`
- `003_header_addons.css`
- `004_panels.css`
- `010_widget_header_addons.css`
- `028_settings_surface_refresh.css`

### Chat surfaces

- `005_chat.css`
- `009_message_toolbar.css`
- `020_chat_panel_base.css`
- `021_chat_sidebar.css`
- `022_chat_messages.css`
- `023_chat_input.css`
- `024_chat_controls_modals.css`

### Notes surfaces

- `006_notes.css`
- `015_notes_panel_base.css`
- `016_notes_list_view.css`
- `017_notes_editor_view.css`
- `018_notes_recall_viewer.css`
- `019_notes_job_ui.css`

### Visualization, image, and support surfaces

- `004_widget_visualization_options.css`
- `011_image_generation.css`
- `012_map_embed.css`
- `025_vision_weaver_panel.css`
- `026_vision_weaver_settings.css`
- `027_image_gen_studio.css`
- `028_image_placeholders.css`
- `029_viz_cinema_host.css`
- `029_gemini_chat_widget.css`
- `leaflet.css`

### Other support surfaces

- `007_markdown.css`
- `007_widget_notifications.css`
- `008_context_menu.css`
- `008_widget_simple_modals.css`
- `009_widget_misc.css`
- `013_immersion_modes.css`
- `013_widget_doc_translator.css`
- `014_widget_status_dashboard.css`

## Publish Source Map

### `Singulari-Tea-Codex-Canvas-pr/bundle/`

Purpose: last known-good publish runtime.

- `main.js`
  - deployed runtime logic bundle
- `main.css`
  - deployed runtime style bundle

### `Singulari-Tea-Codex-Canvas-pr/katex.min.css`

Purpose: deployed math styling for exported and `.cc` pages.

### `Singulari-Tea-Codex-Canvas-pr/.github/workflows/static.yml`

Purpose: publish automation contract for the runtime delivery repo.

# What You Can Safely Exclude

These are not part of the curated maintenance backup:

- `Ailey/node_modules/`
- root `vendor/agent-skills/`
- `visual-tests/`
- root generated `.html` artifacts
- old `.zip` backups
- `handoff/`
- `subagent-runs/`

These can be large, noisy, or reproducible from the kept sources.

# Runtime Layers

## Layer 1: Artifact Bootstrap

Generated HTML and `.cc` outputs typically contain:

- a page shell with linked CSS and JS
- a hidden or staged payload root
- a `renderAppShell(...)` bootstrap call

The canonical export path is assembled in:

- `Ailey/src/02_utils/018_utils_html_exporter.js`

That exporter writes pages which load:

- `https://lemos999.github.io/Singulari-Tea-Codex-Canvas/bundle/main.css`
- `https://lemos999.github.io/Singulari-Tea-Codex-Canvas/katex.min.css`
- `https://uicdn.toast.com/editor/latest/toastui-editor.min.css`
- `https://lemos999.github.io/Singulari-Tea-Codex-Canvas/bundle/main.js`

This is why the GitHub publish repo matters. Exported pages are usually not loading your local source tree. They are loading the published runtime.

## Layer 2: Shell Runtime

The shell assembly lives in:

- `Ailey/src/00_shell/`

Important files:

- `000_shell_template.js`
- `003_shell_part4_panel_notes_chat.js`
- `004_shell_part5_panel_vision_debugger.js`
- `005_shell_part6_main_assembler.js`

This layer is responsible for:

- top chrome
- shell panel structure
- notes/chat panel hosts
- modal mounting points
- shell bootstrapping and payload insertion

If the whole app chrome is missing or malformed, start here.

## Layer 3: State and Persistence

Important files:

- `Ailey/src/01_state/001_state_globalVars.js`
- `Ailey/src/01_state/002_local_firebase_shim.js`
- `Ailey/src/03_core/100_core_firebase.js`
- `Ailey/src/03_core/101_core_listeners.js`
- `Ailey/src/03_core/102_core_seeding.js`

This layer is responsible for:

- global runtime variables
- local-mode IndexedDB persistence through the Firebase shim
- real Firebase path when canvas mode is active
- listener setup
- default template seeding

If settings, notes, sessions, or startup readiness are broken, inspect this layer.

## Layer 4: Core Initialization And Shared Feature Wiring

Important files:

- `Ailey/src/03_core/110_core_api_settings.js`
- `111_core_api_settings_data.js`
- `112_core_api_settings_ui_structure.js`
- `113_core_api_settings_ui_logic.js`
- `114_core_api_settings_api_service.js`
- `114_core_api_settings_ui_refresh.js`
- `115_core_api_settings_utils.js`
- `120_core_main_initializer.js`
- `121_core_initializer_visualization.js`
- `122_core_initializer_panel_utils.js`
- `123_core_initializer_vision_logic.js`
- `124_core_initializer_vision_handler.js`
- `125_core_initializer_vision_ui.js`
- `130_core_archiver.js`

This layer handles:

- API preset storage and provider behavior
- main runtime wiring
- visualization generation and regenerate flows
- image and vision flows
- archive extraction and note archival behavior

If a feature spans multiple surfaces, this layer is often the real center of gravity.

## Layer 5: Shared Utility Layer

Important files:

- `Ailey/src/02_utils/011_utils_helpers.js`
- `012_utils_ui_components.js`
- `012_utils_context_menu.js`
- `013_utils_block_renderer.js`
- `013_utils_panel_manager.js`
- `014_utils_visualization_renderer.js`
- `015_utils_vision.js`
- `016_utils_map_renderer.js`
- `018_utils_html_exporter.js`
- `019_utils_portal_tooltip.js`
- `020_utils_intelligent_splitter.js`

This layer provides reusable mechanics:

- block rendering
- panel positioning and restoration
- context menus
- HTML export
- map rendering
- placeholder hydration helpers
- shared UI plumbing

If one feature works but the same pattern fails in multiple places, inspect utility code.

## Layer 6: Chat Feature

Important files:

- `Ailey/src/04_features_chat/200_chat_data.js`
- `210_chat_engine.js`
- `210_chat_ui_actions.js`
- `211_chat_actions.js`
- `212_chat_payload_builder.js`
- `213_chat_api_service.js`
- `214_chat_utils.js`
- `215_chat_orchestrator.js`
- `216_chat_context_compaction.js`
- `221_chat_ui_sidebar.js`
- `223_chat_ui_messages_content.js`
- `224_chat_ui_messages_element_factory.js`
- `225_chat_ui_messages_toolbar.js`
- `226_chat_ui_messages_rendering.js`
- `227_chat_ui_modals.js`
- `228_chat_ui_controller.js`
- `232_chat_prompt_manager.js`
- `233_chat_sidebar_actions.js`
- `234_chat_session_manager.js`
- `235_chat_drag_drop.js`

Chat is split into:

- storage
- prompt payload assembly
- provider calls
- orchestration
- compaction and history rules
- UI rendering and actions
- session/sidebar control

When debugging chat:

- provider/auth/request issue -> `213_chat_api_service.js`
- wrong history payload -> `212_chat_payload_builder.js` and `215_chat_orchestrator.js`
- auto-compact behavior -> `216_chat_context_compaction.js`
- message UI/actions -> `223` to `226`
- session list or switching -> `221`, `233`, `234`

## Layer 7: Notes And Archive Feature

Important files:

- `Ailey/src/05_features_notes/300_notes_data.js`
- `310_notes_editor.js`
- `315_notes_recall_viewer.js`
- `320_notes_ui.js`
- `331_notes_backup_exporter.js`
- `332_notes_backup_importer.js`
- `340_notes_app.js`
- `341_notes_job_state.js`
- `342_notes_job_refinement_logic.js`
- `343_notes_job_report_logic.js`
- `344_notes_job_ui.js`
- `345_notes_utils.js`
- `346_notes_job_translation_logic.js`
- `350_notes_highlights.js`
- `351_notes_highlights.js`

This layer is responsible for:

- note CRUD
- note editor behavior
- recall/archive display
- note-side jobs like refinement/report/translation
- note backup and import/export

If archive extraction, note editing, or note job flows break, inspect this layer.

## Layer 8: Visualization And Image Support

Visualization work is distributed across:

- `Ailey/src/03_core/121_core_initializer_visualization.js`
- `Ailey/src/02_utils/013_utils_block_renderer.js`
- `Ailey/src/02_utils/014_utils_visualization_renderer.js`
- `Ailey/src/03_core/123_core_initializer_vision_logic.js`
- `Ailey/src/03_core/124_core_initializer_vision_handler.js`
- `Ailey/src/03_core/125_core_initializer_vision_ui.js`

Responsibilities include:

- placeholder and visualization prompt handling
- generate/regenerate/code-fix flows
- runtime execution of generated blocks
- failure cards and recovery affordances
- image generation studio and vision UI

When debugging visualization:

- generation prompt/regenerate behavior -> `121_core_initializer_visualization.js`
- rendering/mount/transaction/failure cards -> `013_utils_block_renderer.js`
- vision/image studio surface -> `123` to `125`

# CSS Responsibility Map

The CSS source tree is divided by feature area. The most important maintenance groups are:

- base and widgets:
  - `001_base.css`
  - `002_widgets.css`
  - `002_widget_modals_base.css`
  - `003_header_addons.css`
  - `004_panels.css`
- chat:
  - `020_chat_panel_base.css`
  - `021_chat_sidebar.css`
  - `022_chat_messages.css`
  - `023_chat_input.css`
  - `024_chat_controls_modals.css`
  - `009_message_toolbar.css`
- notes:
  - `015_notes_panel_base.css`
  - `016_notes_list_view.css`
  - `017_notes_editor_view.css`
  - `018_notes_recall_viewer.css`
  - `019_notes_job_ui.css`
  - `006_notes.css`
- visualization and image:
  - `004_widget_visualization_options.css`
  - `011_image_generation.css`
  - `025_vision_weaver_panel.css`
  - `026_vision_weaver_settings.css`
  - `027_image_gen_studio.css`
  - `028_image_placeholders.css`
  - `029_viz_cinema_host.css`
- settings and surfaces:
  - `003_widget_api_settings.css`
  - `028_settings_surface_refresh.css`

If a UI issue is clearly scoped to one surface, start in the corresponding CSS file before touching runtime JS.

# Why GitHub Publish Exists

GitHub is not just backup. It is part of the runtime delivery path.

Exported HTML and `.cc` pages usually load the published runtime from:

- `https://lemos999.github.io/Singulari-Tea-Codex-Canvas/bundle/main.js`
- `https://lemos999.github.io/Singulari-Tea-Codex-Canvas/bundle/main.css`
- `https://lemos999.github.io/Singulari-Tea-Codex-Canvas/katex.min.css`

That means:

1. editing `Ailey/src/` changes nothing for existing exported pages
2. you must rebuild local bundles
3. you must copy the rebuilt artifacts into `Singulari-Tea-Codex-Canvas-pr/`
4. you must commit and push that publish repo
5. GitHub Pages then serves the new runtime to those pages

If you skip the publish step, existing `.html` and `.cc` outputs keep loading the older runtime.

# How To Build Locally

From the workspace root:

1. go to `Ailey/`
2. run `node bundler.js`
3. verify new output in:
   - `Ailey/bundle/main.js`
   - `Ailey/bundle/main.css`

Important build-time dependencies:

- `Ailey/vendor/`
- `Ailey/dist/katex-styles.js`
- `Ailey/package*.json`

# How To Publish

After a successful local rebuild:

1. copy `Ailey/bundle/main.js` to `Singulari-Tea-Codex-Canvas-pr/bundle/main.js`
2. copy `Ailey/bundle/main.css` to `Singulari-Tea-Codex-Canvas-pr/bundle/main.css`
3. keep `Singulari-Tea-Codex-Canvas-pr/katex.min.css` in place unless intentionally updating it
4. commit inside `Singulari-Tea-Codex-Canvas-pr/`
5. push to the publish repository
6. allow GitHub Pages to refresh

This publish repo is the rollback anchor for last known-good deployed runtime bundles.

# How To Restore From The Curated Backup

## Restore Source For Development

Restore these paths into the workspace:

- `plan/`
- `Ailey/src/`
- `Ailey/src_css/`
- `Ailey/vendor/`
- `Ailey/dist/katex-styles.js`
- `Ailey/bundler.js`
- `Ailey/package*.json`
- `Ailey/index.html`

Then run the local bundler again.

## Restore Publish Runtime Without Rebuilding

Restore these directly:

- `Singulari-Tea-Codex-Canvas-pr/bundle/main.js`
- `Singulari-Tea-Codex-Canvas-pr/bundle/main.css`
- `Singulari-Tea-Codex-Canvas-pr/katex.min.css`
- `Singulari-Tea-Codex-Canvas-pr/.github/workflows/static.yml`

This is the fastest route when source is suspected broken but you need the last deployed runtime back online.

# Failure Triage Guide

## Whole shell does not mount

Start with:

- `Ailey/src/00_shell/005_shell_part6_main_assembler.js`
- `Ailey/src/03_core/120_core_main_initializer.js`
- `Ailey/index.html`
- publish `bundle/main.js`

## Exported page still shows old behavior

Check:

- whether local rebuild actually happened
- whether copied publish bundle was committed
- whether GitHub Pages has the new files
- whether the HTML page is loading remote publish URLs, not local files

## Visualization generation or recovery broken

Check:

- `Ailey/src/03_core/121_core_initializer_visualization.js`
- `Ailey/src/02_utils/013_utils_block_renderer.js`
- `Ailey/src_css/004_widget_visualization_options.css`

## Chat responds incorrectly or loses context

Check:

- `Ailey/src/04_features_chat/212_chat_payload_builder.js`
- `213_chat_api_service.js`
- `215_chat_orchestrator.js`
- `216_chat_context_compaction.js`

## Note archive or recall behavior breaks

Check:

- `Ailey/src/03_core/130_core_archiver.js`
- `Ailey/src/05_features_notes/300_notes_data.js`
- `315_notes_recall_viewer.js`
- `320_notes_ui.js`

## Mobile layout regression

Check:

- relevant panel/chat/notes CSS in `Ailey/src_css/`
- panel and shell JS in `Ailey/src/00_shell/` and `Ailey/src/02_utils/013_utils_panel_manager.js`

## Build succeeds but runtime text or behavior is corrupted

Check:

- source file encoding
- bundled output diff
- whether broken text came from source or from a copied stale bundle
- whether a runtime path still uses duplicated late-bound code

# Operational Rules For Safe Maintenance

1. Separate source fixes from publish fixes.
2. Keep rollback scope narrow.
3. Never assume a local source edit affects already-exported HTML until publish is updated.
4. When a bug is already working in deployed runtime but not in local source, treat publish bundle as evidence.
5. Preserve the last known-good publish bundle even when source refactors are underway.
6. Prefer bounded fixes over mixed passes that alter unrelated subsystems.

# Summary

The maintenance minimum is not just source code. It is:

- source
- source CSS
- embedded vendor/runtime inputs
- the bundler and its dependency manifest
- a local bootstrap page
- the last known-good published runtime
- the plan ledger that explains how the system evolved

That is the smallest clean set that still lets a maintainer:

- understand the system
- rebuild it
- republish it
- restore it
- debug it without full-root workspace baggage
