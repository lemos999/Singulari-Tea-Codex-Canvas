/* --- Ailey & Bailey Canvas --- */
// File: 224_chat_ui_messages_element_factory.js
// Version: 2.0 (Multi Attachment Rendering)
// Description: Creates user and AI message elements with clean metadata and support for multiple attachments.

function escapeChatHtml(text) {
    return String(text || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function renderUserAttachmentsMarkup(message) {
    const attachments = normalizeChatMessageAttachments(message);
    if (!attachments.length) return '';

    const imageAttachments = attachments.filter(item => item.type === 'image');
    const fileAttachments = attachments.filter(item => item.type !== 'image');

    const imageGridHtml = imageAttachments.length > 0
        ? `
            <div class="message-attachment-grid">
                ${imageAttachments.map(attachment => `
                    <div class="message-attachment-card">
                        <img src="${attachment.content}" alt="${escapeChatHtml(attachment.name)}">
                        <div class="message-attachment-card-meta">
                            <span class="message-attachment-card-name">${escapeChatHtml(attachment.name)}</span>
                            <span class="message-attachment-card-size">${formatFileSize(attachment.size || 0)}</span>
                        </div>
                    </div>
                `).join('')}
            </div>
        `
        : '';

    const fileChipHtml = fileAttachments.length > 0
        ? `
            <div class="message-attachment-chip-list">
                ${fileAttachments.map(attachment => `
                    <div class="attachment-chip">
                        <span>${attachment.type === 'pdf' ? 'PDF' : 'TXT'}</span>
                        <span>${escapeChatHtml(attachment.name)}</span>
                    </div>
                `).join('')}
            </div>
        `
        : '';

    return `
        <div class="message-attachment-stack">
            ${imageGridHtml}
            ${fileChipHtml}
        </div>
    `;
}

function buildCompactionMetaMarkup(compactionInfo) {
    if (!compactionInfo) return '';

    const compactedCount = Number(compactionInfo.compactedMessageCount) || 0;
    const compactedChunkCount = Number(compactionInfo.compactedChunkCount) || 0;
    const threshold = Number(compactionInfo.threshold) || 20;
    const label = compactedCount > 0 ? `메모리 압축 ${compactedCount}개` : '메모리 압축';
    const detail = compactedChunkCount > 1 ? `${compactedChunkCount}회분 · 기준 ${threshold}` : `기준 ${threshold}`;

    return `<span class="meta-item compact-meta-item" title="이 답변 전에 이전 대화가 압축 메모리로 정리되었습니다."><svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M4,4H20A2,2 0 0,1 22,6V18A2,2 0 0,1 20,20H4A2,2 0 0,1 2,18V6A2,2 0 0,1 4,4M6,8V10H18V8H6M6,12V14H15V12H6M6,16V18H12V16H6Z" /></svg><span>${escapeChatHtml(label)}</span><span class="compact-meta-divider">•</span><span>${escapeChatHtml(detail)}</span></span>`;
}

function createUserMessageElement(msg, isNewlyArrived = false) {
    const wrapper = document.createElement('div');
    wrapper.className = 'user-message-container';

    const element = document.createElement('div');
    element.className = 'chat-message user content-section';
    element.dataset.messageId = getMessageId(msg);
    element.dataset.blockId = getMessageId(msg);

    const textContent = msg.displayName || msg.content || '';
    const safeText = escapeChatHtml(textContent);
    const textHtml = safeText ? `<p>${safeText.replace(/\n/g, '<br>')}</p>` : '';
    const attachmentsHtml = renderUserAttachmentsMarkup(msg);

    element.innerHTML = `${textHtml}${attachmentsHtml}`;

    wrapper.appendChild(element);
    const userActionMarkup = typeof buildInlineMessageActionsMarkup === 'function'
        ? buildInlineMessageActionsMarkup(getMessageId(msg), { isUser: true })
        : '';
    if (userActionMarkup) {
        const metaRow = document.createElement('div');
        metaRow.className = 'message-meta-row user-message-meta';
        metaRow.innerHTML = userActionMarkup;
        wrapper.appendChild(metaRow);
    }
    _addCollapsibleFeature(element, wrapper, textContent, isNewlyArrived);
    return wrapper;
}

function createAiMessageContainer(msg, index, isNewlyArrived) {
    const aiContainer = document.createElement('div');
    aiContainer.className = 'ai-response-container';

    if (msg.status === 'loading') {
        aiContainer.dataset.messageId = msg.id;
        aiContainer.innerHTML = `
            <div class="chat-message ai loading-animation">
                <div class="dot"></div>
                <div class="dot"></div>
                <div class="dot"></div>
            </div>
        `;
        return aiContainer;
    }

    const messageBubble = document.createElement('div');
    messageBubble.className = 'chat-message ai content-section';
    messageBubble.dataset.messageId = getMessageId(msg);
    messageBubble.dataset.blockId = getMessageId(msg);

    const content = msg.content || '';
    const reasoningRegex = /^\[REASONING_START\]([\s\S]*?)\[REASONING_END\]/;
    const reasoningMatch = content.match(reasoningRegex);
    const finalContent = reasoningMatch ? content.replace(reasoningRegex, '').trim() : content;

    renderStaticMarkdown(messageBubble, finalContent);
    aiContainer.appendChild(messageBubble);
    _addCollapsibleFeature(messageBubble, aiContainer, finalContent, isNewlyArrived);

    if (msg.responseIssue) {
        aiContainer.classList.add('has-response-issue');
        const statusCard = document.createElement('div');
        statusCard.className = 'ai-response-status is-warning';

        const finishReason = String(msg.responseMeta?.finishReason || '').trim();
        statusCard.innerHTML = `
            <div class="ai-response-status-head">
                <span class="ai-response-status-kicker">Response Guard</span>
                ${finishReason ? `<span class="ai-response-status-chip">${escapeChatHtml(finishReason)}</span>` : ''}
            </div>
            <strong class="ai-response-status-title">응답이 완전하게 끝나지 않았을 수 있습니다.</strong>
            <p class="ai-response-status-copy">${escapeChatHtml(msg.responseIssue)}</p>
        `;
        aiContainer.appendChild(statusCard);
    }

    const isRefinementJob = finalContent.includes('데이터 정제가 완료');
    const isReportJob = finalContent.includes('AI 종합 보고서 생성이 완료');
    const isTranslationJob = finalContent.includes('모든 문서 조각의 번역이 완료');
    const isLearningReport = msg.isLearningReport;

    if (isRefinementJob || isReportJob || isTranslationJob || isLearningReport) {
        const downloadBtn = document.createElement('button');
        downloadBtn.className = 'refinement-download-btn';
        downloadBtn.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z" /></svg><span>TXT로 저장</span>';

        downloadBtn.addEventListener('click', () => {
            const sessionForTitle = localChatSessionsCache.find(session => session.id === currentSessionId);
            let themeName = (sessionForTitle?.title || 'Unknown_Job').trim();
            let fileType = 'data';
            let fileContent = finalContent;

            if (isLearningReport) {
                fileType = 'learning_report';
                fileContent = `[Codex-Theme-Archive: ${themeName}]\n\n${msg.reportMarkdown}`;
            } else {
                const separator = '\n\n---\n\n';
                const contentOnly = finalContent.includes(separator)
                    ? finalContent.substring(finalContent.indexOf(separator) + separator.length)
                    : finalContent;

                if (isRefinementJob || isReportJob) {
                    themeName = themeName.replace('학습 ', '').replace(' 데이터 정제', '').trim();
                    fileType = isReportJob ? 'comprehensive_report' : 'refined_data';
                    fileContent = `[Codex-Theme-Archive: ${themeName}]\n\n${contentOnly}`;
                } else if (isTranslationJob) {
                    themeName = themeName.replace('번역: ', '').trim();
                    fileType = 'translated';
                    fileContent = contentOnly;
                }
            }

            const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `${(themeName || 'data').replace(/[/\\?%*:|"<>]/g, '-')}_${fileType}.txt`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
        });

        aiContainer.appendChild(downloadBtn);
    }

    if (msg.groundingMetadata && msg.groundingMetadata.groundingChunks) {
        const sourcesContainer = document.createElement('div');
        sourcesContainer.className = 'grounding-sources-container';

        const uniqueSources = new Map();
        msg.groundingMetadata.groundingChunks.forEach(chunk => {
            if (chunk.web && chunk.web.uri) {
                uniqueSources.set(chunk.web.uri, chunk.web.title || chunk.web.uri);
            }
        });

        if (uniqueSources.size > 0) {
            sourcesContainer.innerHTML = '<span class="sources-label">출처</span>';
            let sourceIndex = 1;
            uniqueSources.forEach((title, uri) => {
                const sourceLink = document.createElement('a');
                sourceLink.href = uri;
                sourceLink.target = '_blank';
                sourceLink.rel = 'noopener noreferrer';
                sourceLink.className = 'source-link';
                sourceLink.innerHTML = `<span class="source-index">${sourceIndex++}</span> ${escapeChatHtml(title)}`;
                sourcesContainer.appendChild(sourceLink);
            });
            aiContainer.appendChild(sourcesContainer);
        }
    }

    const actionMarkup = typeof buildInlineMessageActionsMarkup === 'function'
        ? buildInlineMessageActionsMarkup(getMessageId(msg), { isUser: false })
        : '';

    if (msg.duration || msg.compactionInfo || msg.model || (msg.thinkingBudget !== null && typeof msg.thinkingBudget !== 'undefined') || actionMarkup) {
        const metaDiv = document.createElement('div');
        metaDiv.className = 'ai-response-meta message-meta-row';

        let metaHtml = '';
        if (msg.duration) {
            metaHtml += `<span class="meta-item"><svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M12,20A8,8 0 0,0 20,12A8,8 0 0,0 12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M12.5,7V12.25L17,14.92L16.25,16.15L11,13V7H12.5Z" /></svg><span>응답 생성 ${msg.duration}초</span></span>`;
        }

        metaHtml += buildCompactionMetaMarkup(msg.compactionInfo);

        if (msg.model) {
            metaHtml += `<span class="meta-item"><svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M7,9H17V11H7V9M7,13H14V15H7V13Z" /></svg><span>${escapeChatHtml(msg.model)}</span></span>`;
        }

        if (msg.thinkingBudget !== null && typeof msg.thinkingBudget !== 'undefined') {
            metaHtml += `<span class="meta-item"><svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M12,2A7,7 0 0,1 19,9C19,12.53 16.39,15.44 13,15.92V18H11V15.92C7.61,15.44 5,12.53 5,9A7,7 0 0,1 12,2M12,4A5,5 0 0,0 7,9A5,5 0 0,0 12,14A5,5 0 0,0 17,9A5,5 0 0,0 12,4M9,20H15V22H9V20Z" /></svg><span>추론 ${Number(msg.thinkingBudget).toLocaleString()}</span></span>`;
        }

        metaDiv.innerHTML = `
            ${metaHtml ? `<div class="message-meta-primary">${metaHtml}</div>` : ''}
            ${actionMarkup}
        `;
        aiContainer.appendChild(metaDiv);
    }

    return aiContainer;
}
