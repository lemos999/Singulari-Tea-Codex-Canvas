/* --- Ailey & Bailey Canvas --- */
// File: 114_core_api_settings_ui_refresh.js
// Description: Refines API preset list/editor rendering so the management workspace matches the renewed shell language.

function renderApiPresetsList() {
    const listEl = document.getElementById('api-preset-list');
    if (!listEl) return;

    listEl.innerHTML = '';

    tempPresets.forEach((preset) => {
        const item = document.createElement('div');
        item.className = 'api-preset-item';
        item.dataset.presetId = preset.id;
        if (preset.id === selectedPresetId) {
            item.classList.add('selected');
        }

        const isActive = (preset.isUniversal && userApiSettings.activePresetId === null) || preset.id === userApiSettings.activePresetId;
        item.innerHTML = `
            <div class="api-preset-card-top">
                <span class="preset-name">${preset.name}</span>
                ${isActive ? '<span class="api-preset-chip is-active">활성</span>' : ''}
            </div>
            <div class="api-preset-card-meta">
                <span class="preset-provider">${preset.provider || '미검증'}</span>
                <span class="api-preset-chip">${preset.isUniversal ? '공용' : '사용자'}</span>
            </div>
        `;
        item.addEventListener('click', () => handlePresetSelection(preset.id));
        listEl.appendChild(item);
    });
}

function renderApiPresetEditor(preset) {
    const modal = document.getElementById('api-settings-modal-overlay');
    if (!modal) return;

    initializeModelSearch();
    const modelSearchInput = modal.querySelector('#api-model-search-input');

    const titleEl = modal.querySelector('#api-editor-title');
    const editorStatusText = modal.querySelector('#api-editor-status-text');
    const activeChip = modal.querySelector('#api-editor-active-chip');
    const nameInput = modal.querySelector('#api-preset-name-input');
    const keyInput = modal.querySelector('#api-key-input');
    const statusEl = modal.querySelector('#api-key-status');
    const modelSelect = modal.querySelector('#api-model-select');
    const maxTokensInput = modal.querySelector('#max-output-tokens-input');
    const historyLimitInput = modal.querySelector('#chat-history-limit-input');
    const autoCompactToggle = modal.querySelector('#chat-auto-compact-toggle');
    const deleteBtn = modal.querySelector('#api-settings-delete-btn');
    const verifyBtn = modal.querySelector('#verify-api-key-btn');
    const tempSlider = modal.querySelector('#api-temperature-slider');
    const tempValue = modal.querySelector('#api-temperature-value');
    const topPSlider = modal.querySelector('#api-top-p-slider');
    const topPValue = modal.querySelector('#api-top-p-value');
    const groundingSection = modal.querySelector('.grounding-toggle-section');
    const groundingToggle = modal.querySelector('#google-grounding-toggle');
    const thinkingBudgetSection = modal.querySelector('.thinking-budget-section');
    const thinkingBudgetToggle = modal.querySelector('#thinking-budget-toggle');
    const thinkingBudgetControls = modal.querySelector('#thinking-budget-controls');
    const thinkingBudgetSlider = modal.querySelector('#api-thinking-budget-slider');
    const thinkingBudgetValue = modal.querySelector('#api-thinking-budget-value');
    const advancedTabBtn = modal.querySelector('.api-settings-tab-btn[data-tab="advanced"]');
    const usageTabBtn = modal.querySelector('.api-settings-tab-btn[data-tab="usage"]');

    const setEditorSummary = (title, message, chipText, chipIsActive = false) => {
        if (titleEl) titleEl.textContent = title;
        if (editorStatusText) editorStatusText.textContent = message;
        if (activeChip) {
            activeChip.textContent = chipText;
            activeChip.classList.toggle('is-active', !!chipIsActive);
        }
    };

    const updateGroundingVisibility = () => {
        const selectedModel = modelSelect.value || '';
        const isGroundable = selectedModel.includes('gemini');
        if (groundingSection) groundingSection.style.display = isGroundable ? 'block' : 'none';
    };

    const updateThinkingBudgetVisibility = () => {
        const selectedModel = modelSelect.value || '';
        const currentPreset = tempPresets.find((p) => p.id === selectedPresetId);
        const provider = currentPreset ? currentPreset.provider : null;
        const isGoogleModel = provider === 'google_paid' || provider === 'Google';
        const proModels = ['gemini-2.5-pro', 'gemini-pro-latest'];
        const flashModels = ['gemini-2.5-flash', 'gemini-flash-lite-latest', 'gemini-flash-latest'];
        const isPro = proModels.includes(selectedModel);
        const isFlash = flashModels.includes(selectedModel);
        const isThinkingBudgetSupported = isGoogleModel && (isPro || isFlash);

        if (!thinkingBudgetSection) return;

        if (isThinkingBudgetSupported) {
            thinkingBudgetSection.style.display = 'block';

            let budget = null;
            if (currentPreset && currentPreset.id === 'universal') {
                budget = userApiSettings.universalModelSettings?.thinkingBudget;
            } else if (currentPreset) {
                budget = currentPreset.thinkingBudget;
            }

            const isEnabled = budget !== null && typeof budget !== 'undefined';
            thinkingBudgetToggle.checked = isEnabled;
            thinkingBudgetControls.classList.toggle('disabled', !isEnabled);
            thinkingBudgetSlider.min = '0';
            thinkingBudgetSlider.max = isPro ? '32768' : '24576';
            thinkingBudgetSlider.step = '128';

            const currentValue = isEnabled ? budget : 0;
            thinkingBudgetSlider.value = currentValue;
            thinkingBudgetValue.textContent = currentValue;
        } else {
            thinkingBudgetSection.style.display = 'none';
        }
    };

    modelSelect.removeEventListener('change', updateGroundingVisibility);
    modelSelect.addEventListener('change', updateGroundingVisibility);
    modelSelect.removeEventListener('change', updateThinkingBudgetVisibility);
    modelSelect.addEventListener('change', updateThinkingBudgetVisibility);

    if (preset && preset.isUniversal) {
        const universalSettings = userApiSettings.universalModelSettings || { selectedModel: 'gemini-flash-latest', maxOutputTokens: 65536, temperature: 1, topP: 0.95, useGrounding: false, chatHistoryLimit: 20, autoCompactEnabled: true, thinkingBudget: null };

        setEditorSummary(
            '범용 모델 (기본)',
            '별도 API 키 없이 기본 제공 Gemini 모델을 사용하는 공용 워크스페이스입니다.',
            userApiSettings.activePresetId === null ? '현재 활성' : '공용',
            userApiSettings.activePresetId === null
        );
        nameInput.value = preset.name;
        keyInput.value = '******************';
        statusEl.innerHTML = '기본 제공 Gemini 모델을 사용합니다.<br>별도의 API 키가 필요 없습니다.';
        statusEl.className = 'status-success';

        const universalModels = ['gemini-flash-latest', 'gemini-flash-lite-latest', 'gemini-2.5-pro'];
        modelSelect.innerHTML = '';
        universalModels.forEach((modelId) => {
            const option = document.createElement('option');
            option.value = modelId;
            option.textContent = modelId;
            modelSelect.appendChild(option);
        });
        modelSelect.value = universalSettings.selectedModel || 'gemini-flash-latest';
        modelSelect.removeAttribute('data-full-list');
        if (modelSearchInput) modelSearchInput.style.display = 'none';

        maxTokensInput.value = universalSettings.maxOutputTokens;
        historyLimitInput.value = universalSettings.chatHistoryLimit ?? 20;
        if (autoCompactToggle) autoCompactToggle.checked = universalSettings.autoCompactEnabled !== false;
        const temp = universalSettings.temperature ?? 1;
        const topP = universalSettings.topP ?? 0.95;
        tempSlider.value = temp;
        tempValue.textContent = parseFloat(temp).toFixed(2);
        topPSlider.value = topP;
        topPValue.textContent = parseFloat(topP).toFixed(2);

        [nameInput, keyInput].forEach((el) => { el.disabled = true; });
        [modelSelect, maxTokensInput, historyLimitInput, tempSlider, topPSlider].forEach((el) => { el.disabled = false; });
        if (autoCompactToggle) autoCompactToggle.disabled = false;
        deleteBtn.style.display = 'none';
        verifyBtn.style.display = 'none';

        updateGroundingVisibility();
        if (groundingToggle) groundingToggle.checked = userApiSettings.universalModelSettings?.useGrounding || false;
        updateThinkingBudgetVisibility();

        if (advancedTabBtn) advancedTabBtn.disabled = false;
        if (usageTabBtn) usageTabBtn.disabled = true;
        return;
    }

    [nameInput, keyInput, maxTokensInput, historyLimitInput, tempSlider, topPSlider].forEach((el) => { el.disabled = false; });
    if (autoCompactToggle) autoCompactToggle.disabled = false;
    [deleteBtn, verifyBtn].forEach((el) => { el.style.display = 'inline-flex'; });
    if (advancedTabBtn) advancedTabBtn.disabled = false;
    if (usageTabBtn) usageTabBtn.disabled = false;

    if (isEditingNewPreset) {
        setEditorSummary('새 프리셋 추가', '새 API 키를 검증한 뒤 모델을 불러오고, 저장과 동시에 바로 활성화할 수 있습니다.', '신규');
        nameInput.value = '';
        keyInput.value = '';
        statusEl.textContent = 'API 키를 입력하고 검증해주세요.';
        statusEl.className = '';
        modelSelect.innerHTML = '<option>키 검증 필요</option>';
        modelSelect.disabled = true;
        modelSelect.removeAttribute('data-full-list');
        if (modelSearchInput) modelSearchInput.style.display = 'none';
        maxTokensInput.value = '65536';
        historyLimitInput.value = '20';
        if (autoCompactToggle) autoCompactToggle.checked = true;
        tempSlider.value = 1;
        tempValue.textContent = '1.00';
        topPSlider.value = 0.95;
        topPValue.textContent = '0.95';
        deleteBtn.style.display = 'none';
    } else if (preset) {
        setEditorSummary(
            '프리셋 편집',
            '연결 정보, 모델 선택, 토큰/생성 설정을 한 번에 정리하는 관리 화면입니다.',
            preset.id === userApiSettings.activePresetId ? '현재 활성' : '선택됨',
            preset.id === userApiSettings.activePresetId
        );
        nameInput.value = preset.name || '';
        keyInput.value = preset.key || '';
        statusEl.textContent = preset.provider ? `[${preset.provider}] 키가 검증되어 있습니다.` : '키 검증 필요';
        statusEl.className = preset.provider ? 'status-success' : '';

        const availableModels = preset.availableModels || [];
        modelSelect.dataset.fullList = JSON.stringify(availableModels);
        populateModelSelector(availableModels, preset.provider, preset.selectedModel, 'api-model-select');

        if (modelSearchInput) {
            if (availableModels.length > 10) {
                modelSearchInput.style.display = 'block';
                modelSearchInput.value = '';
            } else {
                modelSearchInput.style.display = 'none';
            }
        }

        maxTokensInput.value = preset.maxOutputTokens || '65536';
        historyLimitInput.value = preset.chatHistoryLimit ?? 20;
        if (autoCompactToggle) autoCompactToggle.checked = preset.autoCompactEnabled !== false;
        const temp = preset.temperature ?? 1;
        const topP = preset.topP ?? 0.95;
        tempSlider.value = temp;
        tempValue.textContent = parseFloat(temp).toFixed(2);
        topPSlider.value = topP;
        topPValue.textContent = parseFloat(topP).toFixed(2);
        deleteBtn.style.display = 'inline-flex';
    }

    updateGroundingVisibility();
    if (groundingToggle) groundingToggle.checked = preset?.useGrounding || false;
    updateThinkingBudgetVisibility();
}
