# Work Plan: Publish Bundled Runtime To `lemos999/Singulari-Tea-Codex-Canvas`

## Objective

Publish the current bundled runtime artifacts to the existing GitHub repository checkout at:

- `Singulari-Tea-Codex-Canvas-pr/`
- remote: `https://github.com/lemos999/Singulari-Tea-Codex-Canvas.git`

The goal is to deliver the current usable bundle so the user can consume it from GitHub-hosted paths.

## User Intent

- The target is not the loose workspace root.
- The intended publish target is the actual repo:
  - `lemos999/Singulari-Tea-Codex-Canvas`
- The user specifically wants the bundled result available there so it can be used in practice.

## Current Findings

- Workspace root is a git worktree with no remote configured and is not safe as a direct publish target.
- There is a separate checked-out repo:
  - `Singulari-Tea-Codex-Canvas-pr/`
- That repo has:
  - a valid git worktree
  - `origin` correctly set to `lemos999/Singulari-Tea-Codex-Canvas`
- The runtime/bundle work was performed under:
  - `Ailey/`
- The likely publish artifacts are the built bundle and static assets required by `.cc` shell consumers.

## Scope

### In scope

- Inspect the target repo checkout and branch state.
- Determine the minimum file set to publish from the current bundle/runtime work.
- Copy or sync only the intended artifacts into the target repo.
- Verify the resulting diff is scoped and sane.
- Commit and push the result to GitHub.

### Out of scope

- Publishing the entire loose workspace root.
- Mixing unrelated backups, plans, or local experiments into the target repo.
- Reworking the prompt contract again unless needed for a missing published asset.

## Design Intent

Use the smallest safe publish surface:

1. Treat `Singulari-Tea-Codex-Canvas-pr/` as the authoritative publish repo.
2. Publish only the artifacts that GitHub-hosted `.cc` consumers actually need.
3. Keep the diff narrow and avoid leaking local-only files.
4. Push through a dedicated branch unless the repo state clearly indicates a direct update flow is already intended.

## Risks

- Copying too much from the workspace and polluting the repo.
- Publishing a bundle that no longer matches required static assets.
- Accidentally pushing from the wrong local repository.
- Overwriting repo-owned files unrelated to the bundle/runtime deliverable.

## Verification Plan

- Check `git status`, `git branch`, and `git remote -v` inside `Singulari-Tea-Codex-Canvas-pr/`.
- Inspect the existing repo file layout.
- Copy candidate artifacts and review the exact changed files.
- If needed, rebuild bundle again before copy to guarantee freshness.
- Commit and push only after the scoped diff looks correct.

## Assumptions

- The repo is meant to host bundled static assets, not the entire Ailey source tree.
- The bundle and supporting static files are the primary deliverable the user wants published first.
