# Ailey UI Surface Rationalization Plan

- Artifact Type: cleanup-plan
- Created: 2026-04-12 16:12:30 +09:00
- Status: awaiting-user-validation
- Scope: remove low-value legacy UI surfaces, eliminate ambiguous navigation behavior, simplify visualization block controls, and preserve only the highest-confidence user flows
- Goal: reduce UI ambiguity and maintenance burden without regressing core chat, notes, export, visualization generation, or instrumentation visibility
- Relationship to Prior Work: this plan follows `20260412-145425--visualization-generation-stability-plan--ailey--v01.md`. That work stabilized generated visualization rendering. This plan now simplifies the surrounding product surface so the stabilized renderer sits behind a clearer and smaller UX.

## Scoreboard

- Current Score: 100
- Score Source: user
- Last Updated: 2026-04-12 17:46:09 +09:00
- Rationale: the user explicitly awarded `100` after retesting the shipped header/menu fixes. A new dark-mode readability follow-up request was opened immediately afterward, but that does not negate acceptance of the completed cleanup slice.
- What Improved: debugger UI is gone, immersion mode is removed from the product path, the old back-scene rollback path is removed, the visualization rail now centers on a smaller primary action set with overflow actions, the header labels are readable in Korean again, the chat toggle icon renders again, and overflow submenus now stay inside the visible viewport.
- What Remains Unsatisfactory: a new follow-up issue is now under analysis for light-surface visualization text becoming too faint when the app shell is in dark mode.
- Next Score Target: preserve `100` while shipping a targeted contrast follow-up without regressing the accepted cleanup work.

### Score History

- 2026-04-12 16:12:30 +09:00 | 40 | provisional | Analysis was completed, the cleanup direction was approved by the user, and a concrete implementation plan was written before code changes.
- 2026-04-12 16:37:00 +09:00 | 50 | provisional | Phase 0 through Phase 2 completed locally: debugger UI was removed while preserving headless trace logging, the immersion subsystem was removed from the visible product path, and the bundle rebuild succeeded.
- 2026-04-12 16:59:05 +09:00 | 50 | provisional | Phase 3 through Phase 6 completed: back-scene state was removed, visualization controls were simplified, the bundle was rebuilt, and the hosted deployment repo was updated on `main`.
- 2026-04-12 17:32:40 +09:00 | 50 | provisional | Manual-validation follow-up fixes were deployed: header mojibake labels were corrected, the broken chat icon markup was repaired, overflow menu labels were localized, and submenu placement was made viewport-aware.
- 2026-04-12 17:46:09 +09:00 | 100 | user | The user explicitly awarded `100` after validating the shipped UI-surface cleanup fixes and requested a separate dark-mode text-contrast follow-up analysis.

### Immediate Progress Note

- Phase 0 completed: created `backup_20260412-162337--ui-surface-rationalization-preflight.zip` at repo root as the pre-cleanup rollback point.
- Phase 1 completed locally: the debugger header button, debugger panel markup, debugger panel CSS, and debugger-specific panel wiring were removed.
- Phase 1 compatibility note: `trace(...)` now writes to an in-memory ring buffer and optional console output, so existing instrumentation calls remain valid without debugger DOM.
- Phase 2 completed locally: immersion modal markup, immersion controller behavior, immersion header entry, and immersion CSS payloads were removed or neutralized.
- Phase 2 migration note: saved settings now delete obsolete `immersionMode` during persistence, and an existing saved field is silently migrated away on load.
- Verification completed locally: touched JavaScript files passed `node --check`, and `node bundler.js` completed successfully.
- Phase 3 completed locally: the old single-slot back-scene header affordance, snapshot state, and restore listeners were removed from shell, render, and recall paths.
- Phase 4 completed locally: the visualization rail now renders as `expand`, `regenerate`, and `more`, with note-save and AI helper actions moved into overflow.
- Phase 5 completed locally: obsolete visualization pin/theme CSS states were removed, and the rail cleanup shipped with no syntax regressions.
- Phase 6 completed: `node --check` passed for touched files, `node bundler.js` succeeded, and the hosted bundle repo `Singulari-Tea-Codex-Canvas` was updated on `main` at commit `1cfbada8fcc167612860b7ee5e6d837c2c6eda9f`.
- Follow-up fix completed: `000_shell_template.js` was rebuilt with valid Korean labels and the chat toggle SVG markup was repaired, fixing the missing icon while preserving the button behavior.
- Follow-up fix completed: `012_utils_context_menu.js` and `008_context_menu.css` now keep nested overflow menus inside the viewport by flipping left and aligning upward when needed.
- Follow-up fix completed: visualization overflow labels and primary rail titles are now Korean, and the hosted bundle repo `Singulari-Tea-Codex-Canvas` was updated again on `main` at commit `0480ad9`.
- Follow-up housekeeping completed: created root backup `backup_20260412-174609.zip` before analyzing the next dark-mode readability issue.
- Remaining from this plan: user manual validation only.

---

## Working Understanding

The current issue is not a single bug. It is a product-surface coherence problem.

Several legacy or experimental controls still exist in the shipped UI even though:

- their meaning is unclear to the user
- their state model is weak or implicit
- their maintenance cost is now higher than their value
- some of them overlap with stronger existing flows

The cleanup should therefore prefer:

- removal over rebranding when a feature no longer serves a clear product purpose
- explicit state over DOM snapshot tricks
- fewer visible controls with stronger semantics
- preservation of internal observability even when developer-facing UI is removed

## Approved Direction

### 1. Remove the debugger UI, but keep instrumentation

Approved product decision:

- remove the debugger header button
- remove the live debugger panel
- remove debugger-specific panel styling
- keep `trace(...)` as an internal instrumentation API

Implementation intent:

- `trace(...)` must stop depending on debugger panel DOM presence as its only sink
- it should degrade to console logging and/or a lightweight in-memory buffer
- code that calls `trace(...)` across the app should not need to change

Reason:

- the user no longer wants a dedicated debugger UI surface
- instrumentation still matters for diagnosis, logs, and future maintenance
- the right simplification is “remove viewer UI, keep logging contract”

Primary files:

- `Ailey/src/00_shell/000_shell_template.js`
- `Ailey/src/00_shell/004_shell_part5_panel_vision_debugger.js`
- `Ailey/src/02_utils/015_utils_debugger.js`
- `Ailey/src/03_core/120_core_main_initializer.js`
- `Ailey/src_css/001_base.css`

### 2. Remove immersion mode as a full subsystem

Approved product decision:

- remove the immersion mode header button
- remove the immersion modal
- remove the immersion controller
- remove immersion-specific CSS effects and mode styles
- migrate stored `immersionMode` settings back to `default`

Reason:

- this is no longer treated as a core product capability
- the feature is not just a small toggle; it is a persistent subsystem with UI, styling, and saved state
- partial hiding would leave dead state and maintenance cost behind

Primary files:

- `Ailey/src/00_shell/000_shell_template.js`
- `Ailey/src/00_shell/002_shell_part3_modals_advanced.js`
- `Ailey/src/06_features_immersion/250_immersion_controller.js`
- `Ailey/src/03_core/120_core_main_initializer.js`
- `Ailey/src/01_state/001_state_globalVars.js`
- `Ailey/src_css/005_widget_immersion_mode.css`
- `Ailey/src_css/013_immersion_modes.css`

### 3. Remove the current “back to previous scene” behavior until a real navigation model exists

Approved product decision:

- remove the current header back button and its behavior
- do not replace it with another implicit rollback trick
- if the feature ever returns, redesign it as explicit navigation state with push/pop semantics

Reason:

- the current implementation is only a single-slot HTML snapshot restore
- it is not a real navigation model
- its validity conditions are unclear and brittle
- removing it is safer than preserving a misleading control

Primary files:

- `Ailey/src/00_shell/000_shell_template.js`
- `Ailey/src/01_state/001_state_globalVars.js`
- `Ailey/src/03_core/120_core_main_initializer.js`
- `Ailey/src/05_features_notes/315_notes_recall_viewer.js`
- `Ailey/src/00_shell/005_shell_part6_main_assembler.js`

### 4. Shrink the visualization action rail into a smaller, clearer model

Approved product decision:

- keep visible primary actions:
  - `expand`
  - `regenerate`
  - `more`
- remove direct always-visible buttons for:
  - `replay`
  - `theme`
  - `fix`
  - `modify`
  - `export`
  - `explain`
  - `pin`

New interaction model:

- `expand` stays as the primary view action
- `regenerate` stays as the primary content action
- a single overflow or context menu becomes the entry for lower-frequency secondary actions

Secondary actions inside `more`:

- `AI edit`
  - `adjust prompt/options` (current `modify`)
  - `repair broken code` (current `fix`)
- `explain`
- `export source`
- `save to note` only when note context exists

Reason:

- the current rail mixes runtime playback, AI editing, export, and note actions at one visual priority level
- users should not need to infer subtle differences from icon-only buttons
- preserving power actions is fine, but they should not all be top-level

Primary files:

- `Ailey/src/02_utils/013_utils_block_renderer.js`
- `Ailey/src/03_core/121_core_initializer_visualization.js`
- `Ailey/src_css/004_widget_visualization_options.css`

### 5. Follow-up cleanup: reduce header crowding and panel inventory

Approved product direction:

- after the removals above, audit remaining top-header controls for redundancy
- keep core, durable actions at header level
- move low-frequency or experimental actions into menus where appropriate

Candidate review targets:

- header export cluster
- global snapshot discoverability and value
- panel inventory after debugger removal

This is a lower-priority cleanup slice unless the implementation reveals obvious dead UI or broken spacing.

## Confirmed Findings

### A. Debugger UI and logging are tightly coupled today

Current behavior:

- `trace(...)` returns early when debugger DOM is absent
- the live debugger viewer is the only meaningful sink for a large amount of internal instrumentation

Implication:

- deleting the panel without redesigning `trace(...)` would silently drop visibility for internal events

### B. Immersion mode is deeper than its header icon suggests

Current behavior:

- it persists `userApiSettings.immersionMode`
- it applies body classes
- it ships a modal, tabs, radio controls, and multiple CSS effect families

Implication:

- this must be removed as a full subsystem, not hidden as a cosmetic icon

### C. The current back button is not real navigation

Current behavior:

- it stores one HTML snapshot in `previousMainContent`
- it restores that snapshot later if present

Implication:

- behavior is stateful but not modeled as navigation
- nested transitions, invalid history, refresh persistence, and eligibility are all underspecified

### D. Visualization controls are overloaded

Current behavior:

- the rail mixes view controls, AI repair controls, note actions, and export actions
- several actions are power-user or recovery flows rather than primary viewing flows

Implication:

- the rail should be reduced to a small primary set with an overflow for secondary actions

## Non-Goals

- redesigning the entire header visual language
- changing core chat, notes, or export product positioning
- rewriting the visualization generation pipeline itself
- adding a new full navigation framework in this cleanup pass

## Risks and Guardrails

### 1. Observability regression

Risk:

- removing debugger UI could accidentally remove useful runtime traces

Guardrail:

- preserve `trace(...)` contract
- route logs to console and/or an in-memory ring buffer before removing panel-specific rendering

### 2. Settings migration residue

Risk:

- stale `immersionMode` values could remain in saved settings and create confusing future behavior

Guardrail:

- explicitly normalize saved `immersionMode` to `default`
- delete or ignore obsolete setting fields safely

### 3. Regression in note rendering flows

Risk:

- removing the back button could leave hidden dependencies in recall or scene rendering code

Guardrail:

- audit all writes to `previousMainContent`
- remove dead state and button toggles in the same pass

### 4. Visualization power-feature discoverability

Risk:

- collapsing the action rail too aggressively could make legitimate expert flows harder to reach

Guardrail:

- preserve secondary actions in an overflow menu instead of deleting all of them
- remove only low-value or duplicate first-level buttons

## Phase Plan

### Phase 0. Baseline and cleanup guardrails

- snapshot the current workspace state
- trace all references to debugger UI, immersion mode state, back-scene state, and visualization actions
- keep this phase read-oriented except for plan updates and backup artifacts

Success criteria:

- all removal targets and dependency paths are enumerated before deletion

### Phase 1. Decouple logging from debugger UI and remove debugger surface

- refactor `trace(...)` into headless-safe logging
- remove debugger header button, panel markup, panel initialization, and panel styles
- keep internal logging stable for existing call sites

Success criteria:

- debugger UI disappears
- app still runs with existing `trace(...)` calls intact
- no runtime code depends on debugger DOM existence

### Phase 2. Remove immersion mode subsystem and migrate settings

- remove header button
- remove modal markup
- remove controller initialization and controller file usage
- remove immersion-specific CSS assets
- normalize stored settings to `default` or ignore obsolete values

Success criteria:

- no user-facing immersion controls remain
- no body classes or persistence paths are still driven by immersion mode

### Phase 3. Remove current back-scene behavior

- delete the header back button
- remove the `previousMainContent` state path
- remove storage and restore logic tied to the old single-slot rollback model

Success criteria:

- no visible back-scene affordance remains
- recall or scene rendering still works without hidden rollback coupling

### Phase 4. Simplify visualization block controls

- reduce the visible rail to `expand`, `regenerate`, and `more`
- move secondary actions into a consolidated overflow model
- remove replay and theme actions from the user-facing rail
- show note-save only where note context exists

Success criteria:

- the rail is visibly smaller and semantically clearer
- secondary actions remain accessible without cluttering the default view

### Phase 5. CSS and dead-code cleanup

- remove obsolete CSS, icon states, selectors, and panel styles left behind by Phases 1 through 4
- tighten any remaining layout assumptions created by the removed controls

Success criteria:

- no dead selectors or action handlers remain for removed UI

### Phase 6. Verification, rebundle, deploy, and report

- run syntax checks on touched files
- run `node bundler.js`
- update the hosted bundle repository after local verification
- write a completion report and update this plan scoreboard

Success criteria:

- local bundle succeeds
- hosted bundle is updated
- report captures what was removed, what was preserved, and what remains intentionally deferred

## Validation Checklist

- the app loads without debugger panel markup
- `trace(...)` still executes safely with no debugger UI present
- no immersion mode button, modal, setting behavior, or body class application remains
- no back-to-previous-scene button or snapshot-restore path remains
- visualization blocks still support expand and regenerate
- secondary visualization actions remain reachable via overflow when intended
- note-context save behavior still works where applicable
- `node --check` passes for touched JavaScript files
- `node bundler.js` succeeds

## Rollback Strategy

- keep the cleanup changes grouped by subsystem so rollback can be selective
- preserve `trace(...)` API shape even if its sink changes
- avoid mixing unrelated feature additions into this cleanup pass
- if visualization toolbar simplification causes confusion, restore only the overflow model first rather than resurrecting the full old rail

## Assumptions

- the user wants removal, not cosmetic hiding, for debugger UI and immersion mode
- the current back-scene button should be removed unless a real navigation model is explicitly requested later
- a smaller visualization rail is preferable even if some expert actions move one click deeper

## Next Implementation Step

Begin with Phase 1 and Phase 2 together:

- decouple `trace(...)` from debugger DOM
- remove debugger UI
- remove immersion mode subsystem

That sequence delivers the largest clarity gain with the lowest interaction-model ambiguity, while leaving the visualization rail and back-scene cleanup for a second pass if integration issues appear.
