# Header Shell Candidate Prototypes Plan

- Created: 2026-04-12 22:42:04 +09:00
- Last Updated: 2026-04-12 22:47:12 +09:00
- Status: in_progress
- Plan Type: prototype
- Scope: immersive header / top shell replacement candidates only

## Objective

Create a new local prototype folder with 10 or more `header/top shell` design candidates that prioritize readability, narrow-canvas resilience, and mobile support.

Also remove the previously created wrong prototype folder that explored `status/dashboard` layouts instead of the actual header shell.

## Approved Direction

- Remove these legacy assumptions from the candidate set:
  - quick chat in the header
  - clock/time display
  - header visibility toggle
- Favor clean reading surfaces over persistent chrome.
- Mobile and narrow-width behavior must be visible in the candidates.
- Produce local HTML files only for user review and selection.

## Deliverables

1. New candidate folder with:
   - index page
   - shared stylesheet
   - shared script
   - 10 or more candidate HTML files
2. Old incorrect candidate folder removed
3. Refined `04 / Single FAB + Sheet` alternatives that reduce content obstruction
4. Short handoff in chat with the folder path and recommended first files to open

## Design Constraints

- The prototypes should focus on top shell/header behavior, not content widgets.
- The content area should remain visually primary.
- Each candidate should feel materially different enough to support comparison.
- Candidates should communicate their mobile/narrow behavior inside the mock layout.

## Execution Steps

1. Capture a fresh timestamp and confirm the old incorrect folder exists.
2. Create a new header-shell candidate folder and populate it with shared assets plus 10+ HTML options.
3. Remove the old incorrect folder.
4. Add low-obstruction refinements for the user-selected `04` direction.
5. Verify the resulting files and provide entry links.

## Scoreboard

- Current Score: 50
- Score Source: provisional
- Last Updated: 2026-04-12 22:47:12 +09:00
- Rationale: the main prototype set exists, and one selected direction is now being refined for lower visual obstruction
- What Improved: the user selected `04` as a promising direction, narrowing the next design pass
- What Remains Unsatisfactory: refined `04` variants have not been added yet
- Next Step: add low-obstruction `04` variants and point the user to those entry files

## Score History

- 2026-04-12 22:42:04 +09:00 | 50 | provisional | approved prototype work started for immersive header candidate exploration
- 2026-04-12 22:43:55 +09:00 | 50 | provisional | prototype set completed and old incorrect candidate folder removed
- 2026-04-12 22:47:12 +09:00 | 50 | provisional | user selected `04` as the strongest direction and requested less obstructive refinements
