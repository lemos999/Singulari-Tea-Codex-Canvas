# CC Direct Visualization Code Contract Work Plan

Plan Type: Work Plan  
Workstream: `.cc` standard-mode visualization contract rewrite  
Version: v01  
Status: Complete  
Created: 2026-04-13 02:28:32 +09:00  
Last Updated: 2026-04-13 02:41:37 +09:00  
Supersedes or Related Plan: `plan/20260413-021900--cc-standard-mode-prompt-hardening-plan--ailey--v01.md`  
Current Completion State: Completed. The `.cc` contract requires direct visualization code rather than prompt-authored visualization placeholders, and follow-up refinements now also push zero-shot best-fit selection, runtime-safe latest CDN usage, Korean user-facing text, stronger first-pass quality expectations, and explicit rejection of decorative-only low-information visuals while staying under the character cap.  
Completed So Far: The runtime surface was re-checked, the old `.cc` prompt-only direction was confirmed to be no longer sufficient, a new backup was created, the `.cc` rules were rewritten to require direct visualization code through the existing visualization-container path, and follow-up refinements added zero-shot best-fit selection, runtime-safe latest CDN guidance, Korean visualization text, stronger quality expectations, and an anti-decorative rule against unlabeled hero art and trivial one-shape SVGs. The prompt file length was re-verified at `51,978` characters.  
Remaining Work: None for this approved scope.  
Current Blockers: None. The user has already approved the new direction.  
Next Step: Use the updated `.cc` contract in the next generation pass and evaluate whether standard-mode canvases now ship with denser, more explanatory first-render visualizations instead of decorative hero graphics.

## Objective

The objective of this plan is to change the meaning of standard canvas generation for `.cc` so that it no longer instructs the model to leave behind visualization placeholders that must later be filled by prompt-driven generation. Instead, the `.cc` contract should direct the model to write the actual visualization code directly into the generated HTML from the start. This change must be isolated to `.cc`, must leave `.ccc` untouched, and must keep the prompt file at or below 52,000 characters after the rewrite.

This is a material change in behavior, not just a wording tweak. The previous approved plan hardened authored prompts. The newly approved direction rejects prompt-only visualization authoring as the main output surface for `.cc`. The user explicitly wants direct visualization code to exist in the initial `.cc` artifact itself. That means the contract must stop treating visualization as a deferred placeholder problem and must instead treat visualization as a first-class generated HTML behavior that ships with the standard canvas output.

## Why The Approved Direction Changed

The earlier `.cc` change improved prompt quality, but it still preserved the same core interaction model: generate textual content, leave a visualization placeholder, and rely on downstream generation to materialize the visualization later. That is not the same as direct authored visualization code. From the user’s perspective, it still feels indirect, fragile, and too dependent on follow-up steps. The new request makes the intended outcome much clearer. A `.cc` artifact should already contain the visualization logic or markup that can render immediately inside the runtime shell.

That distinction matters because the runtime already has a difference between placeholder-driven visualizations and immediately renderable visualizations. If the prompt contract continues to talk about placeholder prompts, the model will keep producing shells that defer real work. If the contract instead tells the model to author concrete visualization markup and block-local execution code, the generated artifact can become substantially more complete on first render. The plan therefore needs to rewrite the instructions at the contract level, not just add stronger prose around existing placeholders.

## Confirmed Scope

The approved scope is intentionally narrow.

Only the `.cc` path may change. The work is limited to `Ailey/Ailey & Bailey X_260304.md`, specifically the standard-mode contract under `[PATH A: STANDARD MODE (.cc)]`. The `.ccc` path must remain unchanged in meaning and wording unless a tiny adjacent adjustment is required purely to preserve formatting integrity, which is not expected here.

The change is contractual rather than runtime-behavioral. The codebase runtime is being consulted only to ensure the new contract points at a surface the current shell can actually accept. No bundler work, renderer rewrite, or broader app refactor is part of this task unless a critical incompatibility is discovered. At the moment, the runtime already supports directly hydrated visualization containers, so the smallest complete design is to align the prompt contract to that existing surface rather than invent a new one.

The file must remain at or below 52,000 characters. That means the rewrite cannot simply add new direct-code rules on top of the old placeholder rules. It must replace and compress enough existing wording to stay within the cap while still being clear enough to steer generation reliably.

## Explicit Non-Goals

This work does not clean up the rest of the prompt file outside the `.cc` section. It does not revise `.ccc`, the search protocol, the learning engines, or the output formats beyond what is strictly required to keep the `.cc` contract coherent. It does not redesign the visualization renderer, remove visualization features from the app, or promise broader runtime guarantees than the current system can already reasonably support.

This work also does not turn `.cc` into a free-form application authoring mode. The generated visualization code should remain scoped to section-level educational or explanatory visualization blocks inside the existing shell. The plan is not to give the model permission to author arbitrary app frameworks or page-wide takeover code. The generated visualization behavior must still live inside the shell, remain export-friendly, and avoid destabilizing the surrounding document.

## Findings From The Current Runtime

The current runtime surface already exposes a path for immediate visualization hydration. In `Ailey/src/02_utils/013_utils_block_renderer.js`, the renderer scans for `[data-component="visualization-container"]` blocks, extracts `script.viz-source`, and converts that source into a stable visualization block using `renderVisualizationBlock`. That means the prompt contract does not need to invent a speculative direct-execution mechanism. A concrete and existing target already exists.

The renderer also already expects block-local execution discipline. It scopes the visualization container, rewrites risky global accesses, sanitizes body-level side effects, normalizes dependencies, and executes inline visualization code inside a controlled wrapper. That matters because it tells us what the `.cc` contract should encourage. The prompt should steer the model toward inline SVG first, small scoped HTML plus minimal JavaScript second, and only limited dependency usage when the concept genuinely needs it. The contract should not encourage global document lookups, page-wide CSS takeover, or brittle library-heavy fragments as the default.

Another important runtime finding is that plain visualization placeholders remain supported and are still used elsewhere. That is useful context because it means the contract must be explicit about not using the placeholder route for `.cc`. If the rewritten instructions are vague, the model may continue emitting `data-component="visualization-placeholder"` because that pattern already exists in the broader system. The new `.cc` rules must therefore clearly prohibit prompt-only visualization placeholders for standard mode.

## Working Assumptions

The safest assumption is that `.cc` should produce visualization code using the renderer’s existing immediate-container surface rather than raw uncontrolled inline scripts placed randomly in the page. That means the contract should likely require one of two acceptable shapes.

The first acceptable shape is direct static markup, usually inline SVG, placed inside a visualization container and accompanied by a `script.viz-source` block when hydration requires the renderer to reinterpret the content as a visualization block. The second acceptable shape is small HTML scaffold plus block-local inline JavaScript scoped to `vizContainer`, again carried through the visualization-container contract that the runtime already knows how to hydrate.

Another safe assumption is that image generation remains placeholder-based for now. The user’s correction targeted visualization code specifically, not the image placeholder path. Keeping image placeholders intact avoids unnecessary scope growth and preserves headroom under the character cap.

## Plan Of Work

### Phase 1: Replace The Contract Surface, Not Just The Vocabulary

The `.cc` section will be rewritten so that visualization generation is defined as direct code authoring rather than prompt authoring. The current bullets that instruct the model to inject `data-component="visualization-placeholder"` with a completed prompt will be removed. In their place, the contract will instruct the model to inject a direct visualization block that already contains real visualization markup and any minimal block-local logic needed to render it.

This rewrite must make the behavioral distinction unmistakable. The language should say that `.cc` must not leave behind prompt-only visualization shells for dense sections. Instead, the model should author the actual visualization code during the initial HTML transformation pass.

### Phase 2: Point The Contract At The Existing Safe Runtime Shape

The revised `.cc` instructions should reference the immediate container pattern that the runtime already supports. The model should be guided to use a direct visualization wrapper such as `[data-component="visualization-container"]` and to keep executable logic inside `script.viz-source` when scripting is needed. The plan does not need to dump a long implementation manual into the prompt, but it should be specific enough that the model understands the expected output shape.

The revised contract should strongly prefer inline SVG for diagrams, process flows, labeled structures, timelines, comparisons, cycles, and other didactic visuals. When static SVG is insufficient, it should allow small scoped JavaScript that targets `vizContainer`, stays inside the block, and avoids document-global access. External libraries should be framed as an exception path rather than the default path.

### Phase 3: Preserve `.ccc` And Keep The Character Budget Under Control

Because the file length budget is tight, the new direct-code wording must compress at least as much as it adds. The prior prompt-authoring bullets are good candidates for replacement with fewer but sharper rules. The base-shell comment should also be updated so that it reflects direct visualization code rather than “fully authored prompts.”

The `.ccc` section must not be touched semantically. If any edit lands near the separator between `.cc` and `.ccc`, it should be carefully reviewed so the freestyle mode remains byte-for-byte unchanged where practical.

### Phase 4: Validate The Contract And Length Constraints

After editing, the prompt file length must be re-measured. The result must remain at or below 52,000 characters. The edited region should be checked to confirm that the old `.cc` placeholder-based visualization language is gone, the new direct-code language is present, and `.ccc` still reads the same.

If the file goes over the cap, the fallback path is not to weaken the new behavior. The fallback is to trim redundant prose in the `.cc` section while preserving the new direct-code requirement. The rewrite should never regress back to placeholder visualization prompts just to save characters.

## Hidden Rules And Failure Cases To Surface

The most important hidden rule is that direct visualization code still has to behave like a good citizen inside the host shell. If the contract simply says “write visualization code directly,” the model may produce fragments that take over the full page, depend on global IDs, or assume isolated control of `document.body`. The runtime has defenses, but the prompt contract should reduce how often those repairs are needed.

Another hidden rule is that the first frame matters. A direct visualization block that only becomes legible after heavy animation, a delayed external dependency, or a resize side effect will feel broken in practice. The prompt should therefore imply that the initial render must already fit the container and communicate something useful. That is especially important for educational `.cc` output where the visualization is part of the explanation, not a bonus afterthought.

There is also a consistency rule around content hierarchy. The standard `.cc` path already bans `h4` and deeper headers. Direct visualization code must fit into that same normalized structure rather than introducing a parallel mini-app hierarchy. The visualization is an embedded explanation component, not a competing document shell.

Finally, there is a rollback rule. If the direct-code wording unexpectedly causes unstable generations later, the safest rollback is not a broad runtime change. The rollback is to revert only the contract wording in this prompt file or refine it toward more restrictive direct-code guidance such as “SVG-first unless a script is essential.” That keeps rollback risk localized.

## Validation Strategy

Validation for this task is mostly static because the change target is a prompt document, not an executable JS module. The first validation layer is structural isolation: only `.cc` language should change. The second validation layer is semantic alignment: the new `.cc` bullets must now describe direct visualization code and must explicitly disallow placeholder-only visualization output in standard mode. The third validation layer is size control: the file must remain within the 52,000-character ceiling.

Because the runtime compatibility question was the only meaningful uncertainty, a short pre-edit scan of the renderer was already performed. That scan confirmed a supported immediate visualization container path. That is sufficient evidence to justify the contract rewrite without adding speculative runtime code changes.

## Completion Notes

Implementation finished by updating only the `.cc` language inside `Ailey/Ailey & Bailey X_260304.md`. The old placeholder-oriented visualization bullets were removed and replaced with a direct-visualization rule, a preferred-shape rule that points at `data-component="visualization-container"` plus `script.viz-source`, and a stricter negative constraint that rejects prompt-only shells and page-global behavior. The adjacent base-shell comment was also updated so it now reflects image prompts plus direct visualization code rather than “fully authored prompts.”

The preflight backup for this direction was written to `backup_20260413-022832--cc-direct-visualization-code-preflight.zip`. The file-length check after editing returned `51,857`, so the user’s 52,000-character ceiling remains satisfied. No `.ccc` wording was intentionally changed as part of this work.

## Definition Of Done

This task is done when all of the following are true.

The active plan file exists, the previous `.cc` plan is marked superseded, and the source file has been backed up again for the new direction.

The `.cc` contract in `Ailey/Ailey & Bailey X_260304.md` no longer tells the model to inject visualization placeholders with completed prompts for standard mode.

The `.cc` contract now clearly tells the model to author direct visualization code into the generated HTML, using the existing runtime-compatible visualization-container pattern and a block-local execution style.

The `.ccc` section remains unchanged in behavior.

The full prompt file remains at or below 52,000 characters.

The active plan file is updated to show completion state, remaining work, next step, and final score state once implementation and validation are done.

## Scoreboard

Current score: 50  
Score source: provisional  
Last updated: 2026-04-13 02:41:37 +09:00  
Score rationale: The `.cc` contract now carries the direct-code rule plus zero-shot fitting, runtime-safe latest CDN preference, Korean visualization text, and a clearer ban on decorative low-information visuals, all while staying under the hard 52,000-character limit.  
What improved: The standard-mode contract now explicitly pushes explanatory density and rejects unlabeled hero art and trivial single-shape SVG output. The size cap remains satisfied after the refinement.  
What remains unsatisfactory: The actual quality of future `.cc` outputs still needs a live generation sample to validate the prompt effect.  
What should happen next to raise or maintain the score: Generate a fresh `.cc` artifact and inspect whether the chosen visualization now teaches structure, comparison, or mechanism instead of acting like ambient decoration.  

## Score History

2026-04-13 02:28:32 +09:00 | score: 45 | source: provisional | rationale: material-direction change approved, new active plan created, implementation pending
2026-04-13 02:33:24 +09:00 | score: 50 | source: provisional | rationale: `.cc`-only direct-visualization-code contract completed, backup created, and final file length verified under 52,000
2026-04-13 02:37:50 +09:00 | score: 50 | source: provisional | rationale: follow-up refinement added zero-shot fit, runtime-safe latest CDN guidance, Korean visualization text, and stronger first-pass quality wording while preserving the size cap
2026-04-13 02:41:37 +09:00 | score: 50 | source: provisional | rationale: follow-up refinement explicitly rejected decorative-only visuals and trivial one-shape SVG output while preserving the size cap
