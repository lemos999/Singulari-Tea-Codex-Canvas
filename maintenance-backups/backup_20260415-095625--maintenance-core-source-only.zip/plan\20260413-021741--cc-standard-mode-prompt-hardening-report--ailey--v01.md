---
title: CC Standard Mode Prompt Hardening Report
slug: cc-standard-mode-prompt-hardening-report
created: 2026-04-13 02:17:41 +09:00
last_updated: 2026-04-13 02:17:41 +09:00
status: complete
owner: Codex
requested_by: User
version: v01
related_plan: 20260413-021900--cc-standard-mode-prompt-hardening-plan--ailey--v01.md
---

# CC Standard Mode Prompt Hardening Report

## Scope

Only `.cc` behavior inside `Ailey/Ailey & Bailey X_260304.md` was changed. `.ccc` behavior was left untouched.

## What Changed

Inside `[PATH A: STANDARD MODE (.cc)]`, the prompt contract was strengthened so the model no longer has permission to leave vague placeholder shells like:

- `data-prompt="..."`
- generic deferred visualization notes
- "refine later" style filler

The `.cc` rules now explicitly require:

- a complete section-specific image prompt for every major section
- a complete visualization prompt for dense/comparative/causal/process-heavy sections
- direct prompt authoring at generation time
- prompt contents that already specify:
  - subject
  - viewpoint
  - structure
  - key labels
  - intended interaction or scene behavior
  - the learner's first takeaway

## Why This Is the Safe Fix

The runtime already understands `data-component="visualization-placeholder"` and `data-prompt="..."`. Changing the markup contract too aggressively without runtime work would increase risk. So this update hardens the prompt-writing behavior while preserving the existing runtime-compatible placeholder format.

## Length Check

- File after edit: `51,787` characters
- User limit: `52,000` characters
- Result: pass

## Notes

- This was intentionally not bundled, because the task only targeted the source prompt document.
- If the next `.cc` generations still feel too abstract, the next safe step would be a second pass that introduces a stricter mini-template for section-level visualization prompt phrasing, still without touching `.ccc`.
