/* --- Ailey & Bailey Canvas --- */
// File: 123_core_initializer_vision_logic.js
// Version: 1.6 (Programmatic Chat Fix)
// Description: Handles image placeholder auto-generation, image overlay controls, and generation failure UI.

function extractContextFromDOM(containerId = 'learning-content') {
    const contentContainer = document.getElementById(containerId);
    if (!contentContainer) return '';

    const contextParts = [];
    // Define block types to exclude from the context extraction
    const excludedTypes = [
        'type-ordered-list',
        'type-list',
        'type-unordered-list',
        'type-generated-image-placeholder',
        'type-visualization-placeholder',
        'type-horizontal-rule'
    ];

    const contentSections = contentContainer.querySelectorAll('.content-section');

    contentSections.forEach(section => {
        const classList = Array.from(section.classList);
        // Check if any of the section's classes are in the exclusion list
        const hasExcludedType = classList.some(cls => excludedTypes.includes(cls));

        if (!hasExcludedType) {
            const text = section.innerText.trim();
            if (text) {
                // Clean up button text that might be included from hover buttons
                const cleanedText = text.replace(/\n🎨$/, '').replace(/\n📊$/, '').trim();
                if (cleanedText) {
                    contextParts.push(cleanedText);
                }
            }
        }
    });

    const fullContext = contextParts.join('\n\n');
    trace("VisionWeaver", "extractContextFromDOM", {
        source: containerId,
        length: fullContext.length,
        method: 'full_dom_scan_exclusive'
    });

    return fullContext;
}

async function refineContextViaChatbot(rawContext) {
    trace("VisionWeaver", "refineContext.start");
    
    const imageGenPrompt = promptTemplatesCache.find(p => p.name === "Image Prompt Generator");
    if (!imageGenPrompt) {
        throw new Error("Could not find 'Image Prompt Generator' prompt template.");
    }
    const systemInstruction = imageGenPrompt.promptText;
    const userContent = `---BEGIN SCENE---\n${rawContext}\n---END SCENE---`;

    const sessionName = "🎨 이미지 생성 컨텍스트";
    let targetSessionId;
    try {
        targetSessionId = await findOrCreateSystemSession(sessionName);
        if (!targetSessionId) {
            throw new Error("Failed to create or find a system session for image generation.");
        }
    } catch (error) {
        console.error("Session creation/finding failed:", error);
        throw error;
    }

    try {
        const refinedPrompt = await programmaticChatSend(targetSessionId, userContent, systemInstruction, true);
        return refinedPrompt;
    } catch (error) {
        console.error("Context refinement failed:", error);
        throw error;
    }
}


async function logImageGenerationHistory(canvasIdToLog) {
    if (!canvasImageHistoryCollectionRef || !canvasIdToLog) return;
    try {
        await canvasImageHistoryCollectionRef.doc(canvasIdToLog).set({
            generatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (error) {
        console.error("Failed to log image generation history:", error);
    }
}

// [DEPRECATED] This function is no longer called from the main initializer.
// It is superseded by the new handleSequentialGenerationOnLoad in 120_core_main_initializer.js
async function handleAutoImageGeneration() {
    const settings = userApiSettings.visionWeaverSettings;
    if (!settings || settings.autoGenerateMode === 'off') {
        return;
    }

    // A short delay ensures the AI-generated content is fully rendered and event listeners are attached before we try to trigger a click.
    setTimeout(() => {
        // Target the placeholder within the main content, not the floating panel's buttons.
        const placeholder = document.querySelector('#learning-content .type-generated-image');
        if (!placeholder) {
            trace("VisionWeaver", "AutoGenerate.skip", { reason: "No image placeholder found in the current scene." });
            return;
        }

        trace("VisionWeaver", "AutoGenerate.triggering", { mode: settings.autoGenerateMode });
        
        placeholder.querySelector('.placeholder-action-btn.quick')?.click();
    }, 100); // 100ms delay for robustness against render race conditions.
}

function legacyInsertImageIntoDOM(imageDataUrl, targetElement, contextForRegen) {
    if (!targetElement) return;

    const wrapper = document.createElement('div');
    wrapper.className = 'generated-image-wrapper';

    const imgElement = document.createElement('img');
    imgElement.src = imageDataUrl;
    imgElement.alt = 'AI가 생성한 장면 이미지';

    const controls = document.createElement('div');
    controls.className = 'image-overlay-controls';
    controls.innerHTML = `
        <button class="overlay-control-btn" data-action="quick" title="빠른 생성">
            <svg viewBox="0 0 24 24"><path d="M7,2V13H10V22L17,10H13L17,2H7Z"></path></svg>
            <span>빠른 생성</span>
        </button>
        <button class="overlay-control-btn" data-action="refined" title="정제 후 생성">
            <svg viewBox="0 0 24 24"><path d="M16.5,2C15.9,2.4 15,3.5 15,3.5L12.5,1L10,3.5C10,3.5 9.1,2.4 8.5,2C7.9,1.6 7.1,1.5 6.5,1.7C5.9,1.9 5.3,2.3 5,2.9C4.4,3.9 4.8,5.1 5.3,5.8C5.6,6.2 6.1,6.8 6.1,6.8L3,9.9L9.1,16L12.2,12.9L15.3,16L21.4,9.9L18.3,6.8C18.3,6.8 18.8,6.2 19.1,5.8C19.6,5.1 20,3.9 19.4,2.9C19.1,2.3 18.5,1.9 17.9,1.7C17.3,1.5 16.5,1.6 15.9,2H16.5M15.3,9.7L11.8,13.2L10.4,11.8L13.9,8.3L15.3,9.7M17,17.2L19.8,20L17,22.8L14.2,20L17,17.2Z"></path></svg>
            <span>정제 후 생성</span>
        </button>
        <button class="overlay-control-btn" data-action="options" title="장면 이미지화 옵션">
            <svg viewBox="0 0 24 24"><path d="M17.5,12A1.5,1.5 0 0,1 16,10.5A1.5,1.5 0 0,1 17.5,9A1.5,1.5 0 0,1 19,10.5A1.5,1.5 0 0,1 17.5,12M14.5,8A1.5,1.5 0 0,1 13,6.5A1.5,1.5 0 0,1 14.5,5A1.5,1.5 0 0,1 16,6.5A1.5,1.5 0 0,1 14.5,8M9.5,8A1.5,1.5 0 0,1 8,6.5A1.5,1.5 0 0,1 9.5,5A1.5,1.5 0 0,1 11,6.5A1.5,1.5 0 0,1 9.5,8M6.5,12A1.5,1.5 0 0,1 5,10.5A1.5,1.5 0 0,1 6.5,9A1.5,1.5 0 0,1 8,10.5A1.5,1.5 0 0,1 6.5,12M12,3A9,9 0 0,0 3,12A9,9 0 0,0 12,21A9,9 0 0,0 21,12A9,9 0 0,0 12,3Z"></path></svg>
            <span>옵션</span>
        </button>
        <button class="overlay-control-btn" data-action="settings" title="설정">
            <svg viewBox="0 0 24 24"><path d="M12,8A4,4 0 0,1 16,12A4,4 0 0,1 12,16A4,4 0 0,1 8,12A4,4 0 0,1 12,8M12,10A2,2 0 0,0 10,12A2,2 0 0,0 12,14A2,2 0 0,0 14,12A2,2 0 0,0 12,10M19.03,7.39L20.45,5.97C20,5.46 19.54,5 19.03,4.55L17.61,5.97C16.07,4.74 14.12,4 12,4C9.88,4 7.93,4.74 6.39,5.97L5,4.55C4.5,5 4,5.46 3.55,5.97L4.97,7.39C3.74,8.93 3,10.88 3,13C3,15.12 3.74,17.07 4.97,18.61L3.55,20.03C4,20.54 4.5,21 5,21.45L6.39,20.03C7.93,21.26 9.88,22 12,22C14.12,22 16.07,21.26 17.61,20.03L19.03,21.45C19.54,21 20,20.54 20.45,20.03L19.03,18.61C20.26,17.07 21,15.12 21,13C21,10.88 20.26,8.93 19.03,7.39Z"></path></svg>
            <span>설정</span>
        </button>
        <button class="overlay-control-btn" data-action="download" title="이미지 다운로드">
            <svg viewBox="0 0 24 24"><path d="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z"></path></svg>
            <span>다운로드</span>
        </button>
    `;

    controls.querySelector('[data-action="refined"]')?.remove();
    controls.addEventListener('click', (e) => {
        const button = e.target.closest('.overlay-control-btn');
        if (!button) return;
        
        switch (button.dataset.action) {
            case 'quick':
            case 'refined':
                handleGeneration('quick', { contextContainerId: contextForRegen, targetElement: targetElement });
                break;
            case 'options':
                const storedPrompt = targetElement?.dataset?.studioPrompt || targetElement?.dataset?.prompt || extractContextFromDOM(contextForRegen);
                openImageGenerationOptionsModal(storedPrompt, targetElement, true);
                break;
            case 'settings':
                openVisionWeaverSettingsModal();
                break;
            case 'download':
                const a = document.createElement('a');
                a.href = imageDataUrl;
                a.download = `codex-generated-${Date.now()}.png`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                break;
        }
    });

    wrapper.appendChild(imgElement);
    wrapper.appendChild(controls);

    targetElement.innerHTML = '';
    targetElement.appendChild(wrapper);

    if (targetElement.classList.contains('type-generated-image')) {
        setTimeout(() => { targetElement.classList.add('loaded'); }, 50);
    }
}

function resolveGeneratedImageDisplayMode(targetElement) {
    const resolvedMode = targetElement?.dataset?.placeholderDisplayResolved;
    const explicitMode = targetElement?.dataset?.placeholderDisplay;
    const rawMode = String(resolvedMode || explicitMode || '').trim().toLowerCase();
    return rawMode === 'slot' ? 'slot' : 'block';
}

function resolveGeneratedImageFit(targetElement, displayMode) {
    const explicitFit = String(
        targetElement?.dataset?.imageFit ||
        targetElement?.dataset?.mediaFit ||
        ''
    ).trim().toLowerCase();

    if (explicitFit === 'cover' || explicitFit === 'contain') {
        return explicitFit;
    }

    return displayMode === 'slot' ? 'cover' : 'contain';
}

function resolveImageRegenContextId(targetElement, fallbackContextId = 'learning-content') {
    if (typeof fallbackContextId === 'string' && fallbackContextId.trim()) {
        return fallbackContextId.trim();
    }

    const recallRoot = targetElement?.closest?.('#recall-content-area');
    if (recallRoot) return 'recall-content-area';

    const learningRoot = targetElement?.closest?.('#learning-content');
    if (learningRoot) return 'learning-content';

    return 'learning-content';
}

function buildGeneratedImageOverlayControls(targetElement, fallbackContextId = 'learning-content', imageDataUrl = '') {
    const displayMode = resolveGeneratedImageDisplayMode(targetElement);
    const controls = document.createElement('div');
    controls.className = displayMode === 'slot'
        ? 'image-overlay-controls image-overlay-controls-slot'
        : 'image-overlay-controls';
    controls.innerHTML = `
        <button class="overlay-control-btn" data-action="expand" title="Open fullscreen">
            <svg viewBox="0 0 24 24"><path d="M7,14H5V19H10V17H7V14M5,10H7V7H10V5H5V10M17,17H14V19H19V14H17V17M14,5V7H17V10H19V5H14Z"></path></svg>
        </button>
        <button class="overlay-control-btn" data-action="quick" title="Regenerate image">
            <svg viewBox="0 0 24 24"><path d="M7,2V13H10V22L17,10H13L17,2H7Z"></path></svg>
        </button>
        <button class="overlay-control-btn" data-action="options" title="Image options">
            <svg viewBox="0 0 24 24"><path d="M17.5,12A1.5,1.5 0 0,1 16,10.5A1.5,1.5 0 0,1 17.5,9A1.5,1.5 0 0,1 19,10.5A1.5,1.5 0 0,1 17.5,12M14.5,8A1.5,1.5 0 0,1 13,6.5A1.5,1.5 0 0,1 14.5,5A1.5,1.5 0 0,1 16,6.5A1.5,1.5 0 0,1 14.5,8M9.5,8A1.5,1.5 0 0,1 8,6.5A1.5,1.5 0 0,1 9.5,5A1.5,1.5 0 0,1 11,6.5A1.5,1.5 0 0,1 9.5,8M6.5,12A1.5,1.5 0 0,1 5,10.5A1.5,1.5 0 0,1 6.5,9A1.5,1.5 0 0,1 8,10.5A1.5,1.5 0 0,1 6.5,12M12,3A9,9 0 0,0 3,12A9,9 0 0,0 12,21A9,9 0 0,0 21,12A9,9 0 0,0 12,3Z"></path></svg>
        </button>
        <button class="overlay-control-btn" data-action="download" title="Download image">
            <svg viewBox="0 0 24 24"><path d="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z"></path></svg>
        </button>
    `;

    controls.querySelector('[data-action="refined"]')?.remove();
    controls.addEventListener('click', (e) => {
        const button = e.target.closest('.overlay-control-btn');
        if (!button) return;

        const contextContainerId = resolveImageRegenContextId(targetElement, fallbackContextId);
        const currentImageUrl = imageDataUrl || targetElement?.querySelector('.generated-image-wrapper img')?.src || '';

        switch (button.dataset.action) {
            case 'expand': {
                const wrapperToExpand = targetElement?.querySelector('.generated-image-wrapper');
                if (wrapperToExpand?.requestFullscreen) {
                    wrapperToExpand.requestFullscreen().catch(() => {
                        if (currentImageUrl) window.open(currentImageUrl, '_blank', 'noopener,noreferrer');
                    });
                } else if (currentImageUrl) {
                    window.open(currentImageUrl, '_blank', 'noopener,noreferrer');
                }
                break;
            }
            case 'quick':
            case 'refined':
                handleGeneration('quick', { contextContainerId, targetElement });
                break;
            case 'options': {
                const storedPrompt = targetElement?.dataset?.studioPrompt || targetElement?.dataset?.prompt || extractContextFromDOM(contextContainerId);
                openImageGenerationOptionsModal(storedPrompt, targetElement, true);
                break;
            }
            case 'download': {
                if (!currentImageUrl) return;
                const a = document.createElement('a');
                a.href = currentImageUrl;
                a.download = `codex-generated-${Date.now()}.png`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                break;
            }
        }
    });

    return controls;
}

function restoreGeneratedImageControls(rootElement = document) {
    if (!rootElement?.querySelectorAll) return;

    const generatedBlocks = rootElement.querySelectorAll('.content-section.type-generated-image');
    generatedBlocks.forEach((targetElement) => {
        const wrapper = targetElement.querySelector('.generated-image-wrapper');
        const imageElement = wrapper?.querySelector('img');
        if (!wrapper || !imageElement || wrapper.querySelector('.image-overlay-controls')) {
            return;
        }

        const displayMode = resolveGeneratedImageDisplayMode(targetElement);
        const fitMode = resolveGeneratedImageFit(targetElement, displayMode);
        imageElement.dataset.fit = fitMode;
        imageElement.style.objectFit = fitMode;
        imageElement.loading = imageElement.loading || 'lazy';
        imageElement.decoding = imageElement.decoding || 'async';

        wrapper.classList.toggle('generated-image-slot-wrapper', displayMode === 'slot');
        wrapper.appendChild(buildGeneratedImageOverlayControls(targetElement));
        targetElement.classList.add('loaded');
        targetElement.classList.toggle('type-generated-image-slot', displayMode === 'slot');
        targetElement.classList.toggle('type-generated-image-block', displayMode !== 'slot');
    });
}

// Override the legacy block-only implementation so generated media can stay inside authored slots.
function insertImageIntoDOM(imageDataUrl, targetElement, contextForRegen) {
    if (!targetElement) return;

    const displayMode = resolveGeneratedImageDisplayMode(targetElement);
    const fitMode = resolveGeneratedImageFit(targetElement, displayMode);

    const wrapper = document.createElement('div');
    wrapper.className = displayMode === 'slot'
        ? 'generated-image-wrapper generated-image-slot-wrapper'
        : 'generated-image-wrapper';

    const imgElement = document.createElement('img');
    imgElement.src = imageDataUrl;
    imgElement.alt = 'AI generated image';
    imgElement.loading = 'lazy';
    imgElement.decoding = 'async';
    imgElement.dataset.fit = fitMode;
    imgElement.style.objectFit = fitMode;

    wrapper.appendChild(imgElement);
    wrapper.appendChild(buildGeneratedImageOverlayControls(targetElement, contextForRegen, imageDataUrl));

    targetElement.dataset.placeholderDisplayResolved = displayMode;
    targetElement.dataset.imageFitResolved = fitMode;
    targetElement.classList.add('type-generated-image');
    targetElement.classList.remove('type-generated-image-loading');
    targetElement.classList.toggle('type-generated-image-slot', displayMode === 'slot');
    targetElement.classList.toggle('type-generated-image-block', displayMode !== 'slot');

    targetElement.innerHTML = '';
    targetElement.appendChild(wrapper);

    if (targetElement.classList.contains('type-generated-image')) {
        setTimeout(() => { targetElement.classList.add('loaded'); }, 50);
    }
}

window.restoreGeneratedImageControls = restoreGeneratedImageControls;

function _renderGenerationFailure(containerElement, showRetryButtons) {
    if (!containerElement) return;
    containerElement.classList.remove('type-generated-image-loading');

    if (showRetryButtons) {
        containerElement.innerHTML = `
            <div class="placeholder-content">
                <p style="color: #d9534f; font-weight: bold; font-size: 1.1em;">생성 실패.</p>
            </div>
            <div class="placeholder-actions">
                <button class="placeholder-action-btn quick" onclick="window.handleImageGeneration('quick')">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M7,2V13H10V22L17,10H13L17,2H7Z"></path></svg>
                    <span>빠른 생성</span>
                </button>
                <button class="placeholder-action-btn refined" onclick="window.handleImageGeneration('refined')">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M16.5,2C15.9,2.4 15,3.5 15,3.5L12.5,1L10,3.5C10,3.5 9.1,2.4 8.5,2C7.9,1.6 7.1,1.5 6.5,1.7C5.9,1.9 5.3,2.3 5,2.9C4.4,3.9 4.8,5.1 5.3,5.8C5.6,6.2 6.1,6.8 6.1,6.8L3,9.9L9.1,16L12.2,12.9L15.3,16L21.4,9.9L18.3,6.8C18.3,6.8 18.8,6.2 19.1,5.8C19.6,5.1 20,3.9 19.4,2.9C19.1,2.3 18.5,1.9 17.9,1.7C17.3,1.5 16.5,1.6 15.9,2H16.5M15.3,9.7L11.8,13.2L10.4,11.8L13.9,8.3L15.3,9.7M17,17.2L19.8,20L17,22.8L14.2,20L17,17.2Z"></path></svg>
                    <span>정제 후 생성</span>
                </button>
                <button class="placeholder-action-btn options" onclick="window.openImageGenerationOptionsModal()">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M17.5,12A1.5,1.5 0 0,1 16,10.5A1.5,1.5 0 0,1 17.5,9A1.5,1.5 0 0,1 19,10.5A1.5,1.5 0 0,1 17.5,12M14.5,8A1.5,1.5 0 0,1 13,6.5A1.5,1.5 0 0,1 14.5,5A1.5,1.5 0 0,1 16,6.5A1.5,1.5 0 0,1 14.5,8M9.5,8A1.5,1.5 0 0,1 8,6.5A1.5,1.5 0 0,1 9.5,5A1.5,1.5 0 0,1 11,6.5A1.5,1.5 0 0,1 9.5,8M6.5,12A1.5,1.5 0 0,1 5,10.5A1.5,1.5 0 0,1 6.5,9A1.5,1.5 0 0,1 8,10.5A1.5,1.5 0 0,1 6.5,12M12,3A9,9 0 0,0 3,12A9,9 0 0,0 12,21A9,9 0 0,0 21,12A9,9 0 0,0 12,3Z"></path></svg>
                    <span>옵션</span>
                </button>
                <button class="placeholder-action-btn settings" onclick="window.openVisionWeaverSettingsModal()">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M12,8A4,4 0 0,1 16,12A4,4 0 0,1 12,16A4,4 0 0,1 8,12A4,4 0 0,1 12,8M12,10A2,2 0 0,0 10,12A2,2 0 0,0 12,14A2,2 0 0,0 14,12A2,2 0 0,0 12,10M19.03,7.39L20.45,5.97C20,5.46 19.54,5 19.03,4.55L17.61,5.97C16.07,4.74 14.12,4 12,4C9.88,4 7.93,4.74 6.39,5.97L5,4.55C4.5,5 4,5.46 3.55,5.97L4.97,7.39C3.74,8.93 3,10.88 3,13C3,15.12 3.74,17.07 4.97,18.61L3.55,20.03C4,20.54 4.5,21 5,21.45L6.39,20.03C7.93,21.26 9.88,22 12,22C14.12,22 16.07,21.26 17.61,20.03L19.03,21.45C19.54,21 20,20.54 20.45,20.03L19.03,18.61C20.26,17.07 21,15.12 21,13C21,10.88 20.26,8.93 19.03,7.39Z"></path></svg>
                    <span>설정</span>
                </button>
            </div>
        `;
        containerElement.querySelector('.placeholder-action-btn.refined')?.remove();
    } else {
        containerElement.innerHTML = `<p style="color: #d9534f;">생성 실패.</p>`;
    }
}

async function fetchImageAsBase64(url) {
    if (!url) return null;
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const blob = await response.blob();
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    } catch (error) {
        console.error('Error fetching image as Base64:', url, error);
        throw error;
    }
}
