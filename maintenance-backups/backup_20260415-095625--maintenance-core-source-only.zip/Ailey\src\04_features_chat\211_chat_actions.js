/* --- Ailey & Bailey Canvas --- */
// File: 211_chat_actions.js
// Version: 5.0 (Clipboard First Message Actions)
// Description: Modernizes message copy/delete/regenerate behavior with direct clipboard support, safer delete sequencing, and bounded regeneration rules.

function getSessionForMessageAction() {
    if (!currentSessionId) return null;
    return (currentSessionId === 'temporary-chat')
        ? temporarySession
        : localChatSessionsCache.find(s => s.id === currentSessionId);
}

function getMessageForAction(session, messageId) {
    return session?.messages?.find(m => getMessageId(m) === messageId) || null;
}

function getCopyableMessageContent(messageToCopy) {
    let content = messageToCopy?.content || '';
    if (messageToCopy?.role === 'ai') {
        const reasoningRegex = /^\[REASONING_START\]([\s\S]*?)\[REASONING_END\]\s*/;
        content = content.replace(reasoningRegex, '');
    }
    return content.trim();
}

async function tryWriteTextToClipboard(text) {
    const normalized = String(text || '').trim();
    if (!normalized) return false;

    try {
        if (navigator.clipboard?.writeText) {
            await navigator.clipboard.writeText(normalized);
            return true;
        }
    } catch (error) {
        trace("UI", "message.copy.clipboardApiFailed", { error: error.message || String(error) }, {}, "WARN");
    }

    try {
        const fallbackTextarea = document.createElement('textarea');
        fallbackTextarea.value = normalized;
        fallbackTextarea.setAttribute('readonly', 'readonly');
        fallbackTextarea.style.position = 'fixed';
        fallbackTextarea.style.top = '12px';
        fallbackTextarea.style.left = '12px';
        fallbackTextarea.style.width = '1px';
        fallbackTextarea.style.height = '1px';
        fallbackTextarea.style.opacity = '0';
        fallbackTextarea.style.pointerEvents = 'none';
        document.body.appendChild(fallbackTextarea);
        fallbackTextarea.focus();
        fallbackTextarea.select();
        fallbackTextarea.setSelectionRange(0, fallbackTextarea.value.length);
        const copied = document.execCommand('copy');
        document.body.removeChild(fallbackTextarea);
        return !!copied;
    } catch (error) {
        trace("UI", "message.copy.execCommandFailed", { error: error.message || String(error) }, {}, "WARN");
        return false;
    }
}

function openCopyFallbackModal(text) {
    if (!copyModalOverlay || !copyModalTextarea) return false;
    copyModalTextarea.value = text;
    copyModalOverlay.style.display = 'flex';
    copyModalTextarea.focus();
    copyModalTextarea.select();
    return true;
}

function removeMessageFromSessionCache(session, messageId) {
    if (!session?.messages) return -1;
    const messageIndex = session.messages.findIndex(m => getMessageId(m) === messageId);
    if (messageIndex > -1) {
        session.messages.splice(messageIndex, 1);
    }
    return messageIndex;
}

function removeMessageElementFromDom(messageElement) {
    messageElement.closest('.ai-response-container, .user-message-container')?.remove();
}

async function handleMessageCopy(messageId) {
    const session = getSessionForMessageAction();
    if (!session?.messages) return;

    const messageToCopy = getMessageForAction(session, messageId);
    if (!messageToCopy) {
        console.error("Message to copy not found:", messageId);
        return;
    }

    const formattedString = getCopyableMessageContent(messageToCopy);
    if (!formattedString) {
        showToastNotification("복사할 내용이 없습니다.", "", `copy-empty-${Date.now()}`);
        return;
    }

    if (await tryWriteTextToClipboard(formattedString)) {
        showToastNotification("✅ 복사되었습니다.", "클립보드", `copy-toast-${Date.now()}`);
        return;
    }

    if (!openCopyFallbackModal(formattedString)) {
        showModal("복사 가능한 텍스트를 준비하지 못했습니다.", () => {});
    }
}

function closeCopyModal() {
    if (copyModalOverlay) {
        copyModalOverlay.style.display = 'none';
    }
}

async function handleMessageDelete(messageId, messageElement) {
    const session = getSessionForMessageAction();
    if (!session?.messages) return;

    if (typeof dismissActiveMessageToolbar === 'function') {
        dismissActiveMessageToolbar();
    }

    if (currentSessionId === 'temporary-chat') {
        removeMessageFromSessionCache(session, messageId);
        removeMessageElementFromDom(messageElement);
        return;
    }

    const messageToDelete = getMessageForAction(session, messageId);
    if (!messageToDelete) return;

    try {
        await chatSessionsCollectionRef.doc(currentSessionId).collection("messages").doc(messageId).delete();
        removeMessageFromSessionCache(session, messageId);
        removeMessageElementFromDom(messageElement);
    } catch (err) {
        console.error("Failed to delete message from Firestore:", err);
        showModal("메시지 삭제에 실패했습니다. 페이지를 새로고침합니다.", () => location.reload());
    }
}

async function handleMessageRegenerate(messageId, messageElement) {
    const session = getSessionForMessageAction();
    if (!session?.messages?.length) return;

    const isTemporary = currentSessionId === 'temporary-chat';
    const aiMessageIndex = session.messages.findIndex(m => getMessageId(m) === messageId);
    if (aiMessageIndex < 1) return;

    const aiMessage = session.messages[aiMessageIndex];
    const userMessage = session.messages[aiMessageIndex - 1];
    const isLatestAssistant = aiMessageIndex === session.messages.length - 1;
    if (aiMessage?.role !== 'ai' || userMessage?.role !== 'user' || !isLatestAssistant) {
        showToastNotification("가장 최근 AI 답변만 다시 생성할 수 있습니다.", "", `regen-skip-${Date.now()}`);
        return;
    }

    const historyForApi = session.messages.slice(0, aiMessageIndex);

    if (typeof dismissActiveMessageToolbar === 'function') {
        dismissActiveMessageToolbar();
    }

    if (isTemporary) {
        session.messages.splice(aiMessageIndex);
        removeMessageElementFromDom(messageElement);
        sendQueryToAI(userMessage, historyForApi, currentSessionId, true);
        return;
    }

    try {
        await chatSessionsCollectionRef.doc(currentSessionId).collection("messages").doc(messageId).delete();
        session.messages.splice(aiMessageIndex);
        removeMessageElementFromDom(messageElement);
        sendQueryToAI(userMessage, historyForApi, currentSessionId, false);
    } catch (err) {
        console.error("Failed to regenerate message:", err);
        showModal("답변 재생성에 실패했습니다.", () => location.reload());
    }
}
