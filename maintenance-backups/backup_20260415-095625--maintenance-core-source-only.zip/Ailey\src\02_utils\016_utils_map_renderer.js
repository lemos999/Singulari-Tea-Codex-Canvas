
/* --- Ailey & Bailey Canvas --- */
// File: 016_utils_map_renderer.js
// Version: 3.1 (LaTeX Support)
// Description: Renders an interactive map and adds a Google Earth link to the marker popup. Now supports LaTeX in location names.

function renderInteractiveMapBlock(blockData, containerElement) {
    if (typeof L === 'undefined') {
        containerElement.innerHTML = '<p style="color:red;">[오류] 지도 라이브러리(Leaflet)가 로드되지 않았습니다.</p>';
        console.error("Leaflet.js (L) is not defined.");
        return;
    }

    try {
        const lat = blockData.latitude;
        const lon = blockData.longitude;
        const locationName = blockData.locationName || '현재 위치';
        const zoom = blockData.zoom || 15;

        // The containerElement is where the map will be rendered.
        containerElement.style.height = '400px'; // Ensure container has a height
        containerElement.style.borderRadius = '8px';
        containerElement.style.overflow = 'hidden';

        const map = L.map(containerElement).setView([lat, lon], zoom);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // [MODIFIED] Process location name with LaTeX renderer if available
        const processedLocationName = typeof renderKatexInString === 'function' 
            ? renderKatexInString(locationName) 
            : locationName;

        // [MODIFIED] Create dynamic popup content with Google Earth link
        const earthLink = `https://earth.google.com/web/search/${lat},${lon}`;
        const popupContent = `
            <div class="map-popup-content">
                <b>${processedLocationName}</b>
                <a href="${earthLink}" target="_blank" rel="noopener noreferrer" class="google-earth-link">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M12,2C6.48,2 2,6.48 2,12C2,17.52 6.48,22 12,22C17.52,22 22,17.52 22,12C22,6.48 17.52,2 12,2M16,18.53C14.73,17.15 13.06,16.2 12,16.2C10.94,16.2 9.27,17.15 8,18.53C5.7,16.86 4,14.59 4,12C4,11.33 4.14,10.68 4.38,10.09L9,11.5L11,8.5L5.5,6.5C6.54,4.82 8.5,3.8 10.64,3.53L12.5,7.5L14.5,4.5L12,2.35C16.31,3.22 19.33,6.78 19.86,11C19.95,11.33 20,11.66 20,12C20,14.59 18.3,16.86 16,18.53Z"/></svg>
                    Google Earth에서 보기
                </a>
            </div>
        `;

        L.marker([lat, lon], { icon: defaultIcon }).addTo(map)
            .bindPopup(popupContent)
            .openPopup();

        // HACK: Leaflet sometimes has trouble with initial tile loading in dynamic containers.
        // This timeout forces a resize check after a short delay.
        setTimeout(() => {
            map.invalidateSize();
        }, 200);

    } catch (e) {
        containerElement.innerHTML = `<p style="color: red; text-align: center;">지도를 초기화하는 중 오류가 발생했습니다: ${e.message}</p>`;
        console.error("Leaflet.js map initialization error:", e);
    }
}
