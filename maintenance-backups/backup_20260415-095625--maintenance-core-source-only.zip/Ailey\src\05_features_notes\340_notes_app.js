/* --- Ailey & Bailey Canvas --- */
// File: 340_notes_app.js
// Version: 12.0 (Learning Note Recall)
// Description: Modified openNoteEditor to route notes whose titles start with '[학습]' to the recall viewer, enabling recall functionality for learning content.

function handleNewTranslationProject() {
    const modal = document.getElementById('doc-translator-modal-overlay');
    if (!modal) return;

    const modalContent = modal.querySelector('.doc-translator-modal');
    const titleInput = document.getElementById('doc-translator-title-input');
    const contentTextarea = document.getElementById('doc-translator-content-textarea');
    const turnCountDisplay = document.getElementById('doc-translator-turn-count');
    const saveBtn = document.getElementById('doc-translator-save-btn');
    const cancelBtn = document.getElementById('doc-translator-cancel-btn');

    const langSelectRadio = document.getElementById('lang-select-radio');
    const langDirectRadio = document.getElementById('lang-direct-radio');
    const langSelect = document.getElementById('doc-translator-lang-select');
    const langDirectInput = document.getElementById('doc-translator-lang-direct-input');
    const promptSelect = document.getElementById('doc-translator-prompt-select');

    // --- Chunk Size Button Logic ---
    const decreaseBtn = document.getElementById('chunk-size-decrease-btn');
    const increaseBtn = document.getElementById('chunk-size-increase-btn');
    const valueDisplay = document.getElementById('chunk-size-value-display');
    const chunkSizeInput = document.getElementById('doc-translator-chunk-size-input');

    const MIN_CHUNK_SIZE = 1000;
    const MAX_CHUNK_SIZE = 120000;
    const CHUNK_STEP = 1000;

    const updateTotalTurns = () => {
        const content = contentTextarea.value;
        const chunkSize = parseInt(chunkSizeInput.value, 10);
        if (content.length > 0 && chunkSize > 0 && typeof hybridHierarchicalSplit === 'function') {
            const chunks = hybridHierarchicalSplit(content, chunkSize);
            turnCountDisplay.textContent = chunks.length.toLocaleString();
        } else if (content.length > 0 && chunkSize > 0) {
            turnCountDisplay.textContent = Math.ceil(content.length / chunkSize).toLocaleString();
        } else {
            turnCountDisplay.textContent = '0';
        }
    };
    
    // [MODIFIED] Update UI based on selected prompt template
    const updateChunkSizeUI = (newValue) => {
        const value = Math.max(MIN_CHUNK_SIZE, Math.min(newValue, MAX_CHUNK_SIZE));
        chunkSizeInput.value = value;
        valueDisplay.textContent = `${value / 1000}K`;

        const selectedOption = promptSelect.options[promptSelect.selectedIndex];
        const isLearningTranslator = selectedOption && selectedOption.text === "Learning Subtitle Translator";

        valueDisplay.classList.remove('safe', 'caution', 'danger');
        
        if (isLearningTranslator) {
            if (value <= 3000) {
                valueDisplay.classList.add('safe');
            } else {
                valueDisplay.classList.add('danger');
            }
        } else {
            if (value <= 3000) {
                valueDisplay.classList.add('safe');
            } else if (value <= 6000) {
                valueDisplay.classList.add('caution');
            } else {
                valueDisplay.classList.add('danger');
            }
        }

        updateTotalTurns();
    };

    const handleDecrease = () => {
        let currentValue = parseInt(chunkSizeInput.value, 10);
        updateChunkSizeUI(currentValue - CHUNK_STEP);
    };

    const handleIncrease = () => {
        let currentValue = parseInt(chunkSizeInput.value, 10);
        updateChunkSizeUI(currentValue + CHUNK_STEP);
    };
    
    const handleLanguageOptionChange = () => {
        if (langSelectRadio.checked) {
            langSelect.disabled = false;
            langDirectInput.disabled = true;
        } else {
            langSelect.disabled = true;
            langDirectInput.disabled = false;
        }
    };
    
    const handleAccordionClick = (e) => {
        const header = e.target.closest('.accordion-header');
        if (header) {
            const content = header.nextElementSibling;
            header.classList.toggle('expanded');
            content.classList.toggle('expanded');
        }
    };

    // Reset fields
    titleInput.value = '';
    contentTextarea.value = '';
    langSelectRadio.checked = true;
    handleLanguageOptionChange();
    updateChunkSizeUI(1000); // Initialize

    if (promptSelect) {
        promptSelect.innerHTML = '';
        // [MODIFIED] Include the new template in the filter
        const translationTemplates = promptTemplatesCache
            .filter(t => ["Document Translator", "Master Translator", "Learning Subtitle Translator"].includes(t.name))
            .sort((a,b) => a.name.localeCompare(b.name));
            
        translationTemplates.forEach(template => {
            const option = document.createElement('option');
            option.value = template.id;
            option.textContent = template.name;
            promptSelect.appendChild(option);
        });
        // Default to Master Translator
        const masterTranslator = translationTemplates.find(t => t.name === "Master Translator");
        if (masterTranslator) {
            promptSelect.value = masterTranslator.id;
        }
    }

    const debouncedUpdate = debounce(() => {
        updateTotalTurns();
        if (promptSelect) {
            const hasSrtVttStructure = /^\d+\s*\n\d{2}:\d{2}:\d{2},\d{3}\s*-->\s*\d{2}:\d{2}:\d{2},\d{3}/m.test(contentTextarea.value);
            const docTranslator = promptTemplatesCache.find(t => t.name === "Document Translator");
            const masterTranslator = promptTemplatesCache.find(t => t.name === "Master Translator");
            if (hasSrtVttStructure && docTranslator) {
                promptSelect.value = docTranslator.id;
            } else if (masterTranslator) {
                promptSelect.value = masterTranslator.id;
            }
        }
    }, 300);

    // [NEW] Event handler for prompt selection change
    const onPromptSelectChange = () => {
        const currentValue = parseInt(chunkSizeInput.value, 10);
        updateChunkSizeUI(currentValue);
    };

    // Attach event listeners
    contentTextarea.addEventListener('input', debouncedUpdate);
    if(decreaseBtn) decreaseBtn.addEventListener('click', handleDecrease);
    if(increaseBtn) increaseBtn.addEventListener('click', handleIncrease);
    langSelectRadio.addEventListener('change', handleLanguageOptionChange);
    langDirectRadio.addEventListener('change', handleLanguageOptionChange);
    if(modalContent) modalContent.addEventListener('click', handleAccordionClick);
    promptSelect.addEventListener('change', onPromptSelectChange); // [NEW]

    const close = () => {
        modal.style.display = 'none';
        contentTextarea.removeEventListener('input', debouncedUpdate);
        if(decreaseBtn) decreaseBtn.removeEventListener('click', handleDecrease);
        if(increaseBtn) increaseBtn.removeEventListener('click', handleIncrease);
        langSelectRadio.removeEventListener('change', handleLanguageOptionChange);
        langDirectRadio.removeEventListener('change', handleLanguageOptionChange);
        if(modalContent) modalContent.removeEventListener('click', handleAccordionClick);
        promptSelect.removeEventListener('change', onPromptSelectChange); // [NEW]
        saveBtn.onclick = null;
        cancelBtn.onclick = null;
        modal.onclick = null;
    };

    saveBtn.onclick = async () => {
        const title = titleInput.value.trim();
        const content = contentTextarea.value;
        const chunkSize = parseInt(chunkSizeInput.value, 10);
        const selectedPromptId = promptSelect.value;
        
        let targetLanguage = 'Korean';
        if (langSelectRadio.checked) {
            targetLanguage = langSelect.value;
        } else {
            targetLanguage = langDirectInput.value.trim();
        }

        if (!title) {
            showModal("문서 제목을 입력해주세요.", () => titleInput.focus());
            return;
        }
        if (!content) {
            showModal("번역할 내용을 입력해주세요.", () => contentTextarea.focus());
            return;
        }
        if (!targetLanguage) {
            showModal("번역할 언어를 선택하거나 입력해주세요.", () => langDirectInput.focus());
            return;
        }

        if (typeof startTranslationProcess === 'function') {
            await startTranslationProcess(title, content, chunkSize, targetLanguage, selectedPromptId);
        }
        close();
    };

    cancelBtn.onclick = close;
    modal.onclick = (e) => { if (e.target === modal) close(); };

    highestZIndex++;
    modal.style.zIndex = highestZIndex;
    modal.style.display = 'flex';
    titleInput.focus();

    if (typeof createCustomSelect === 'function') {
        createCustomSelect(document.getElementById('doc-translator-lang-select'));
        createCustomSelect(promptSelect);
    }
}


function ensureNotePanelHeader() {
    if (!notesAppPanel) return;
    let header = notesAppPanel.querySelector('.panel-header');
    if (!header) {
        header = document.createElement('div');
        header.className = 'panel-header';
        header.innerHTML = `
            <div class="notes-panel-title">
                <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" style="margin-right: 8px; vertical-align: -3px;"><path d="M17,4V10L15,8L13,10V4H6A2,2 0 0,0 4,6V18A2,2 0 0,0 6,20H18A2,2 0 0,0 20,18V6A2,2 0 0,0 18,4H17Z"></path></svg>
                <span class="notes-panel-title-copy">
                    <span class="notes-panel-title-main">Ailey's Note</span>
                    <span class="notes-panel-title-sub">Archive workspace</span>
                </span>
            </div>
            <div class="panel-controls">
                <button class="panel-control-btn panel-minimize-btn" title="최소화"><svg viewBox="0 0 24 24" width="18" height="18"><path d="M20,14H4V10H20" /></svg></button>
                <button class="panel-control-btn panel-maximize-btn" title="최대화">
                    <span class="icon-maximize"><svg viewBox="0 0 24 24" width="16" height="16"><path d="M4,4H20V20H4V4M6,8V18H18V8H6Z"/></svg></span>
                    <span class="icon-restore"><svg viewBox="0 0 24 24" width="16" height="16"><path d="M4,8H8V4H20V16H16V20H4V8M16,8V14H18V6H10V8H16M6,10V18H14V10H6Z"/></svg></span>
                </button>
                <button class="panel-control-btn close-btn" title="닫기"><svg viewBox="0 0 24 24" width="22" height="22"><path d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z" /></svg></button>
            </div>
        `;
        header.querySelector('.close-btn').addEventListener('click', () => togglePanel(notesAppPanel, false));
        header.querySelector('.panel-minimize-btn').addEventListener('click', () => handlePanelMinimize(notesAppPanel));
        header.querySelector('.panel-maximize-btn').addEventListener('click', () => handlePanelMaximize(notesAppPanel));
        notesAppPanel.prepend(header);
        initializeDraggableAndResizablePanel(notesAppPanel);
    }
}

function switchView(view) {
    trace("UI", "note.switchView", { view });
    if (noteListView) noteListView.classList.remove('active');
    if (noteEditorView) noteEditorView.classList.remove('active');
    if (noteRecallView) noteRecallView.classList.remove('active');

    if (view === 'editor') {
        if(noteEditorView) noteEditorView.classList.add('active');
    } else if (view === 'recall') {
        if(noteRecallView) noteRecallView.classList.add('active');
    } else { // Assuming 'list' view
        if (noteTitleInput && noteTitleInput.value.trim() === '' && currentNoteId && toastEditorInstance) {
            const content = toastEditorInstance.getMarkdown();
            const newTitle = generateTitleFromContent(content);
            if (newTitle && newTitle !== '무제 노트') {
                notesCollectionRef.doc(currentNoteId).update({ title: newTitle });
            }
        }
        
        if (toastEditorInstance) {
            toastEditorInstance.destroy();
            toastEditorInstance = null;
        }

        if(noteListView) noteListView.classList.add('active');
        currentNoteId = null;
    }
}

function openNoteEditor(noteId) {
    const note = localNotesCache.find(n => n.id === noteId);
    if (!note) return;

    // Check if the note is a narrative record OR a learning canvas record.
    const isRecallable = (note.content && (note.content.includes('## [턴') || note.content.includes('## [📸 스냅샷:'))) || note.title.startsWith('[학습]');

    if (isRecallable) {
        if (typeof initializeSingleNoteRecallViewer === 'function') {
            initializeSingleNoteRecallViewer(note);
        }
        return;
    }

    switchView('editor');

    const editorEl = document.getElementById('toast-editor');
    if (!editorEl) {
        console.error("Toast editor container element not found!");
        return;
    }

    if (toastEditorInstance) {
        toastEditorInstance.destroy();
        toastEditorInstance = null;
    }
    
    // The drawing button logic will be handled inside the editor initialization
    openNoteEditorWithToastUI(note, editorEl);
}

function getNewNoteProjectDefaultName() {
    const baseName = "새 폴더";
    let i = 1;
    let newName = baseName;
    const existingNames = new Set(localNoteProjectsCache.map(p => p.name));
    while (existingNames.has(newName)) {
        newName = `${baseName} ${++i}`;
    }
    return newName;
}

function toggleNoteProjectExpansion(projectId) {
    const project = localNoteProjectsCache.find(p => p.id === projectId);
    if (project) {
        project.isExpanded = !project.isExpanded;
        renderNoteList();
    }
}

function startNoteProjectRename(projectId) {
    const titleSpan = document.querySelector(`.note-project-container[data-project-id="${projectId}"] .note-project-title`);
    if (!titleSpan) return;
    const originalTitle = titleSpan.textContent;
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'note-project-title-input';
    input.value = originalTitle;
    titleSpan.replaceWith(input);
    input.focus();
    input.select();
    const finish = () => {
        const newName = input.value.trim();
        if (newName && newName !== originalTitle) {
            renameNoteProject(projectId, newName);
        } else {
            renderNoteList();
        }
        input.removeEventListener('blur', finish);
        input.removeEventListener('keydown', onKeydown);
    };
    const onKeydown = (e) => {
        if (e.key === 'Enter') input.blur();
        else if (e.key === 'Escape') { input.value = originalTitle; input.blur(); }
    };
    input.addEventListener('blur', finish);
    input.addEventListener('keydown', onKeydown);
}

function startNoteRename(noteId) {
    const titleSpan = document.querySelector(`.note-item[data-id="${noteId}"] .note-item-title`);
    if (!titleSpan) return;
    const originalTitle = titleSpan.textContent;
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'note-item-title-input';
    input.value = originalTitle;
    titleSpan.replaceWith(input);
    input.focus();
    input.select();
    const finish = () => {
        const newName = input.value.trim();
        if (newName && newName !== originalTitle) {
            renameNote(noteId, newName);
        } else {
            renderNoteList();
        }
        input.removeEventListener('blur', finish);
        input.removeEventListener('keydown', onKeydown);
    };
    const onKeydown = (e) => {
        if (e.key === 'Enter') input.blur();
        else if (e.key === 'Escape') { input.value = originalTitle; input.blur(); }
    };
    input.addEventListener('blur', finish);
    input.addEventListener('keydown', onKeydown);
}

async function handleAddNewNote() {
    const newNoteId = await addNote();
    if (newNoteId) {
        openNoteEditor(newNoteId);
    }
}
