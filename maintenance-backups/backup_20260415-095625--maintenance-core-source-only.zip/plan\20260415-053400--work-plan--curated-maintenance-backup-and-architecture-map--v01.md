# Work Plan: Curated Maintenance Backup And Architecture Map

- Timestamp: 2026-04-15 05:34 KST
- Owner: Codex
- User approval: granted
- Type: documentation + backup
- Status: in_progress
- Scope: create a maintenance-only backup set and write a detailed plan-side architecture reference for source, build, publish, runtime, and recovery

## Understanding

The user does not want another full-root backup. They want a clean maintenance backup that contains only the files needed to understand, rebuild, publish, restore, and maintain the runtime. They also want a detailed architecture reference under `plan/` that explains what each important path is for, why GitHub publish exists, how bundling works, how chat/notes/visualization/export fit together, and how maintainers should diagnose failures.

## Goals

1. Lock the exact curated backup scope so it includes required sources and excludes noisy artifacts.
2. Write a maintenance-grade architecture map under `plan/` with enough detail to support future repair work.
3. Create a root backup zip containing only the approved maintenance set.
4. Verify the backup contents and document the result in the active plan file.

## Approved Backup Scope

Include:

- `plan/`
- `Ailey/src/`
- `Ailey/src_css/`
- `Ailey/vendor/`
- `Ailey/dist/katex-styles.js`
- `Ailey/bundler.js`
- `Ailey/package.json`
- `Ailey/package-lock.json`
- `Ailey/index.html`
- `Singulari-Tea-Codex-Canvas-pr/bundle/main.js`
- `Singulari-Tea-Codex-Canvas-pr/bundle/main.css`
- `Singulari-Tea-Codex-Canvas-pr/katex.min.css`
- `Singulari-Tea-Codex-Canvas-pr/.github/workflows/static.yml`

Exclude:

- `Ailey/node_modules/`
- root `vendor/`
- `visual-tests/`
- root generated `.html`
- existing `.zip` backups
- `subagent-runs/`
- `handoff/`
- unrelated publish repo files not needed for runtime restore

## Steps

1. Create the approved work-plan record. Completed.
2. Write the detailed maintenance architecture reference in `plan/`. In progress.
3. Create the curated maintenance backup zip in the workspace root. Pending.
4. Verify the archive contents and update this plan with the final artifact path. Pending.

## Rollback Boundary

- `plan/20260415-053400--work-plan--curated-maintenance-backup-and-architecture-map--v01.md`
- new maintenance architecture reference under `plan/`
- one new root backup zip

## Scoreboard

- Current score: 50
- Score source: provisional
- Last updated: 2026-04-15 05:34 KST
- Score rationale: scope is approved and bounded, but the requested reference doc and curated backup have not been delivered yet
- What improved: the backup scope is now explicit and tied to actual build/runtime dependencies
- What remains unsatisfactory: the artifact and reference documentation still need to be written and verified
- Next score action: produce the backup and architecture map with an exact manifest and restore path

### Score History

- 2026-04-15 05:34 KST | 50 | provisional | approved documentation + curated maintenance backup pass opened
