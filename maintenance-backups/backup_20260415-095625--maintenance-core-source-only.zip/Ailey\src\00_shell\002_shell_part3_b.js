/* --- Ailey & Bailey Canvas --- */
// File: 002_shell_part3_b.js
// Version: 4.0 (Visualization Option Studio Expansion)
// Description: Rebuilt the visualization options modal with clearer naming, richer library coverage, and a summary-last studio flow.

const SHELL_PART_3_B_A = `
    <div id="visualization-options-modal-overlay" class="custom-modal-overlay">
        <div class="custom-modal visualization-options-modal">
            <div class="viz-modal-header">
                <div class="viz-modal-title-block">
                    <p class="viz-modal-kicker">VISUALIZATION STUDIO</p>
                    <h3>시각화 옵션 스튜디오</h3>
                    <p class="viz-modal-subtitle">무엇을 보여줄지, 어떤 방식으로 읽히게 할지, 어떤 엔진과 안전 장치를 둘지 한 화면에서 정리합니다.</p>
                </div>
                <div class="viz-ai-recommend-strip">
                    <button id="viz-ai-recommend-toggle" class="option-btn viz-ai-recommend-btn" type="button" data-tooltip="현재 플레이스홀더 프롬프트와 세부 요청을 읽고 가장 잘 맞는 목표·구조·엔진·안전 옵션 조합을 고릅니다.">AI 추천으로 전체 구성</button>
                    <p class="viz-ai-recommend-copy">AI 추천은 추가 호출 없이 현재 요청 내용을 기준으로 가장 어울리는 구조, 엔진, 안전 조합을 빠르게 정합니다.</p>
                    <p class="viz-ai-recommend-restore-copy">기본값은 꺼져 있으며, <strong>마지막 설정 기억</strong>이 켜져 있을 때만 이전 상태를 복원합니다.</p>
                    <p id="viz-ai-lock-note" class="viz-ai-lock-note" hidden>AI 추천이 켜져 있어 옵션 버튼이 잠겨 있습니다. 직접 커스텀하려면 AI 추천을 끄세요.</p>
                </div>
            </div>
            <div class="viz-studio-layout">
                <aside class="viz-studio-sidebar">
                    <section class="viz-stage-card viz-stage-card-primary">
                        <div class="viz-stage-heading">
                            <span class="viz-stage-index">1</span>
                            <div>
                                <h4>무엇을 만들까요?</h4>
                                <p>이번 시각화가 맡아야 할 가장 큰 역할을 먼저 고릅니다.</p>
                            </div>
                        </div>
                        <div class="viz-choice-grid viz-choice-grid-goals">
                            <button class="viz-choice-card" data-role="goal" data-goal="explain" data-tooltip="개념, 원리, 비교 포인트를 이해하기 쉽게 풀어주는 결과물에 맞습니다."><strong>개념 설명</strong><span>핵심 개념과 원리를 차분하게 이해시키는 데 맞춥니다.</span></button>
                            <button class="viz-choice-card" data-role="goal" data-goal="explore" data-tooltip="사용자가 직접 값이나 구조를 만져보며 살펴보는 탐색형 결과물에 맞습니다."><strong>직접 탐색</strong><span>사용자가 조작하면서 데이터와 구조를 살펴보게 합니다.</span></button>
                            <button class="viz-choice-card" data-role="goal" data-goal="simulate" data-tooltip="변화, 동역학, 규칙 기반 시스템을 움직임과 함께 보여줄 때 적합합니다."><strong>변화 시뮬레이션</strong><span>시간에 따라 달라지는 규칙과 흐름을 보여줍니다.</span></button>
                            <button class="viz-choice-card" data-role="goal" data-goal="map" data-tooltip="위치, 분포, 경로, 지역 차이를 읽어야 하는 공간형 결과물에 맞습니다."><strong>지도·공간 해석</strong><span>장소, 분포, 공간적 차이를 읽기 쉽게 정리합니다.</span></button>
                            <button class="viz-choice-card" data-role="goal" data-goal="relate" data-tooltip="연결 관계, 의존 구조, 상호작용, 계통을 한눈에 보여줄 때 적합합니다."><strong>관계와 연결</strong><span>네트워크와 연결 구조를 시각적으로 드러냅니다.</span></button>
                            <button class="viz-choice-card" data-role="goal" data-goal="present" data-tooltip="보고서, 발표, 브리핑처럼 빠르게 핵심을 전달해야 하는 결과물에 맞습니다."><strong>보고·발표</strong><span>브리프와 요약 중심의 전달용 결과물에 맞춥니다.</span></button>
                            <button class="viz-choice-card" data-role="goal" data-goal="story" data-tooltip="장면성과 몰입감이 중요한 내러티브형 설명 블록에 적합합니다."><strong>이야기 장면</strong><span>장면처럼 몰입감 있는 설명과 연출을 만듭니다.</span></button>
                        </div>
                    </section>
                    <section class="viz-stage-card">
                        <div class="viz-stage-heading">
                            <span class="viz-stage-index">2</span>
                            <div>
                                <h4>어떻게 보여줄까요?</h4>
                                <p>정보 구조, 표현 방식, 상호작용, 대상 독자를 정해 결과물의 읽는 맛을 맞춥니다.</p>
                            </div>
                        </div>
                        <div class="viz-field-block">
                            <label>정보 구조</label>
                            <div class="option-btn-group viz-option-wrap" id="viz-family-options">
                                <button class="option-btn" data-role="family" data-family="comparison" data-tooltip="두 대상 이상을 나란히 비교하고 차이를 읽게 할 때 좋습니다.">비교와 차이</button>
                                <button class="option-btn" data-role="family" data-family="timeline" data-tooltip="시간 순서, 역사 흐름, 연속 단계처럼 순서를 중심으로 보여줍니다.">순서와 시간</button>
                                <button class="option-btn" data-role="family" data-family="flow" data-tooltip="절차, 파이프라인, 변화 과정을 단계적으로 설명할 때 좋습니다.">과정과 변화</button>
                                <button class="option-btn" data-role="family" data-family="network" data-tooltip="노드와 연결, 상호작용, 의존 관계를 보여주는 데 적합합니다.">관계와 연결</button>
                                <button class="option-btn" data-role="family" data-family="map" data-tooltip="위치, 분포, 경로, 공간 차이를 다룰 때 적합합니다.">지도와 위치</button>
                                <button class="option-btn" data-role="family" data-family="science" data-tooltip="과학 데이터, 정량 분석, 실험 결과를 다룰 때 적합합니다.">과학과 데이터</button>
                                <button class="option-btn" data-role="family" data-family="dashboard" data-tooltip="현황판, 보고서형 정리, KPI 카드처럼 요약 전달에 좋습니다.">대시보드와 현황</button>
                                <button class="option-btn" data-role="family" data-family="diagram" data-tooltip="개념 구조, 시스템 구성, 분류 체계를 설명할 때 좋습니다.">개념과 구조</button>
                                <button class="option-btn" data-role="family" data-family="scene" data-tooltip="장면형 인포그래픽이나 몰입형 시각 설명에 적합합니다.">장면과 세계관</button>
                                <button class="option-btn" data-role="family" data-family="hierarchy" data-tooltip="상하 구조, 카테고리, 포함 관계를 트리형으로 보여줍니다.">계층과 분류</button>
                                <button class="option-btn" data-role="family" data-family="causal" data-tooltip="원인과 결과, 영향 관계, 결정 요인을 설명할 때 좋습니다.">원인과 결과</button>
                                <button class="option-btn" data-role="family" data-family="distribution" data-tooltip="분포, 빈도, 통계 범위를 읽게 할 때 적합합니다.">분포와 통계</button>
                                <button class="option-btn" data-role="family" data-family="forecast" data-tooltip="추세, 전망, 변화 가능성을 보여주는 데 적합합니다.">예측과 전망</button>
                                <button class="option-btn" data-role="family" data-family="accessibility" data-tooltip="쉽게 읽히고 설명이 풍부한 학습 보조형 결과물에 적합합니다.">쉬운 이해와 접근성</button>
                            </div>
                        </div>
                        <div class="viz-field-grid">
                            <div class="viz-field-block">
                                <label>표현 방식</label>
                                <div class="option-btn-group viz-option-wrap" id="viz-renderer-options">
                                    <button class="option-btn" data-role="renderer" data-renderer="ai-recommended" data-tooltip="상황에 따라 가장 무난한 엔진 조합을 자동 추천합니다.">자동 추천</button>
                                    <button class="option-btn" data-role="renderer" data-renderer="stable-2d" data-tooltip="레이아웃 붕괴 위험이 낮고 내보내기에 강한 2D 중심 경로입니다.">안정형 2D</button>
                                    <button class="option-btn" data-role="renderer" data-renderer="interactive-chart" data-tooltip="차트 상호작용과 데이터 툴팁이 중요한 경우에 적합합니다.">인터랙티브 차트</button>
                                    <button class="option-btn" data-role="renderer" data-renderer="svg-first" data-tooltip="벡터 기반이라 선명하고 구조가 명확한 결과를 지향합니다.">SVG·벡터</button>
                                    <button class="option-btn" data-role="renderer" data-renderer="canvas-first" data-tooltip="애니메이션과 자유도는 높지만 구조 안정성은 더 챙겨야 하는 경로입니다.">Canvas·애니메이션</button>
                                    <button class="option-btn" data-role="renderer" data-renderer="scene-3d" data-tooltip="Three.js 등 장면형 엔진을 적극 사용하는 몰입형 결과에 맞습니다.">3D 장면</button>
                                    <button class="option-btn" data-role="renderer" data-renderer="map-engine" data-tooltip="지도 타일, 지형, 공간 계층을 다루는 전용 엔진 경로입니다.">지도 엔진</button>
                                    <button class="option-btn" data-role="renderer" data-renderer="graph-engine" data-tooltip="그래프 레이아웃과 네트워크 배치를 잘 다루는 엔진 경로입니다.">네트워크 엔진</button>
                                    <button class="option-btn" data-role="renderer" data-renderer="dom-infographic" data-tooltip="HTML/CSS 중심이라 내보내기와 텍스트 가독성에 강합니다.">DOM 인포그래픽</button>
                                    <button class="option-btn" data-role="renderer" data-renderer="hybrid-mixed" data-tooltip="둘 이상의 엔진을 섞어 표현력과 안정성을 균형 있게 노립니다.">혼합형 렌더</button>
                                    <button class="option-btn" data-role="renderer" data-renderer="table-matrix" data-tooltip="표, 매트릭스, 카드 정리가 핵심일 때 적합합니다.">표·매트릭스</button>
                                </div>
                            </div>
                            <div class="viz-field-block">
                                <label>움직임과 조작</label>
                                <div class="option-btn-group viz-option-wrap" id="viz-interaction-options">
                                    <button class="option-btn" data-role="interaction" data-interaction="low" data-tooltip="움직임을 줄이고 읽기 쉬운 정적 결과물에 가깝게 갑니다.">정적 중심</button>
                                    <button class="option-btn" data-role="interaction" data-interaction="guided" data-tooltip="움직임은 최소화하되 사용자가 따라가기 쉬운 안내형 상호작용을 둡니다.">가이드형</button>
                                    <button class="option-btn" data-role="interaction" data-interaction="balanced" data-tooltip="읽기 쉬움과 탐색 재미를 적절히 섞습니다.">균형형</button>
                                    <button class="option-btn" data-role="interaction" data-interaction="high" data-tooltip="슬라이더, 토글, 드래그 등 적극적인 상호작용을 우선합니다.">상호작용 강화</button>
                                </div>
                            </div>
                            <div class="viz-field-block">
                                <label>누가 보나요?</label>
                                <div class="option-btn-group viz-option-wrap" id="viz-audience-options">
                                    <button class="option-btn" data-role="audience" data-audience="general" data-tooltip="일반 독자를 위한 기본 설명 밀도입니다.">일반 독자</button>
                                    <button class="option-btn" data-role="audience" data-audience="learner" data-tooltip="학습자에게 설명과 안내를 조금 더 붙이는 쪽입니다.">학습자</button>
                                    <button class="option-btn" data-role="audience" data-audience="analyst" data-tooltip="분석가를 위해 정보 밀도와 세부성을 높이는 쪽입니다.">분석가</button>
                                    <button class="option-btn" data-role="audience" data-audience="presenter" data-tooltip="발표/브리핑용으로 구조를 빠르게 읽히게 만듭니다.">발표용</button>
                                    <button class="option-btn" data-role="audience" data-audience="executive" data-tooltip="의사결정자에게 핵심만 짧게 전달하는 쪽입니다.">의사결정자</button>
                                    <button class="option-btn" data-role="audience" data-audience="young-learner" data-tooltip="어린 학습자나 매우 쉬운 설명이 필요한 경우에 적합합니다.">어린 학습자</button>
                                </div>
                            </div>
                        </div>
                    </section>
                </aside>
                <section class="viz-studio-main">
                    <div class="viz-studio-scroll">
                        <div class="viz-workspace-grid">
                            <section class="viz-stage-card">
                                <div class="viz-stage-heading">
                                    <span class="viz-stage-index">3</span>
                                    <div>
                                        <h4>결과 톤과 안전성</h4>
                                        <p>정보량, 실패 대응, 프리셋, 테마를 묶어 결과물의 성격을 다듬습니다.</p>
                                    </div>
                                </div>
                                <div class="viz-field-grid">
                                    <div class="viz-field-block">
                                        <label>정보량</label>
                                        <div class="option-btn-group viz-option-wrap" id="viz-complexity-options">
                                            <button class="option-btn" data-role="complexity" data-complexity="simple" data-tooltip="핵심만 남기고 빠르게 이해되는 결과를 우선합니다.">핵심만</button>
                                            <button class="option-btn" data-role="complexity" data-complexity="balanced" data-tooltip="핵심과 디테일을 균형 있게 담습니다.">균형형</button>
                                            <button class="option-btn" data-role="complexity" data-complexity="detailed" data-tooltip="정교한 정보량과 부연 설명을 넉넉히 담습니다.">정보 풍부</button>
                                            <button class="option-btn" data-role="complexity" data-complexity="ambitious" data-tooltip="표현력과 실험성을 조금 더 적극적으로 추구합니다.">실험적 확장</button>
                                        </div>
                                    </div>
                                    <div class="viz-field-block">
                                        <label>실패 시 대처</label>
                                        <div class="option-btn-group viz-option-wrap" id="viz-fallback-options">
                                            <button class="option-btn" data-role="fallback" data-fallback="prefer-static-safe" data-tooltip="문제가 생기면 정적인 대체 레이아웃으로 빠르게 돌아섭니다.">정적 대체 우선</button>
                                            <button class="option-btn" data-role="fallback" data-fallback="prefer-stable" data-tooltip="표현력보다 안정적인 엔진과 레이아웃을 우선합니다.">안정성 우선</button>
                                            <button class="option-btn" data-role="fallback" data-fallback="balanced" data-tooltip="안정성과 표현력을 균형 있게 봅니다.">균형형</button>
                                            <button class="option-btn" data-role="fallback" data-fallback="prefer-ambitious" data-tooltip="가능한 한 표현력을 유지하되 실패 시에만 한 단계 내려옵니다.">표현력 우선</button>
                                        </div>
                                    </div>
                                    <div class="viz-field-block">
                                        <label>설명 밀도</label>
                                        <div class="option-btn-group viz-option-wrap" id="viz-density-options">
                                            <button class="option-btn" data-role="density" data-density="core" data-tooltip="핵심 메시지만 남기고 짧게 정리합니다.">핵심만</button>
                                            <button class="option-btn" data-role="density" data-density="balanced" data-tooltip="핵심 설명과 보조 정보를 적당히 섞습니다.">균형형</button>
                                            <button class="option-btn" data-role="density" data-density="detailed" data-tooltip="주석, 범례, 설명 문장을 더 풍부하게 둡니다.">정보 풍부</button>
                                        </div>
                                    </div>
                                    <div class="viz-field-block">
                                        <label>움직임 연출</label>
                                        <div class="option-btn-group viz-option-wrap" id="viz-motion-options">
                                            <button class="option-btn" data-role="motion" data-motion="still" data-tooltip="고정형 결과에 가깝게 갑니다.">정적</button>
                                            <button class="option-btn" data-role="motion" data-motion="guided" data-tooltip="부드러운 유도 애니메이션 정도만 허용합니다.">부드럽게</button>
                                            <button class="option-btn" data-role="motion" data-motion="dynamic" data-tooltip="조작과 반응에 따라 움직이는 요소를 적극적으로 넣습니다.">반응형</button>
                                            <button class="option-btn" data-role="motion" data-motion="cinematic" data-tooltip="장면 연출과 몰입감 있는 움직임을 강화합니다.">시네마틱</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="viz-field-block">
                                    <label>빠른 구성</label>
                                    <div class="option-btn-group viz-option-wrap" id="viz-preset-options">
                                        <button class="option-btn" data-role="preset" data-preset="teach-clearly" data-tooltip="학습자에게 개념을 또렷하게 설명하는 기본형입니다.">학습 설명형</button>
                                        <button class="option-btn" data-role="preset" data-preset="stable-first" data-tooltip="내보내기와 안정성을 우선하는 보수적 구성입니다.">안정성 우선</button>
                                        <button class="option-btn" data-role="preset" data-preset="interactive-lab" data-tooltip="조작 가능한 실험형 결과에 맞는 구성입니다.">인터랙티브 실험</button>
                                        <button class="option-btn" data-role="preset" data-preset="dashboard-brief" data-tooltip="현황 전달과 브리핑에 맞는 대시보드형 구성입니다.">대시보드 브리프</button>
                                        <button class="option-btn" data-role="preset" data-preset="story-scene" data-tooltip="장면형 내러티브 결과에 맞는 구성입니다.">서사 장면형</button>
                                        <button class="option-btn" data-role="preset" data-preset="scientific-rigor" data-tooltip="정교한 분석과 데이터 중심 표현에 맞는 구성입니다.">과학 분석형</button>
                                        <button class="option-btn" data-role="preset" data-preset="executive-brief" data-tooltip="의사결정자에게 핵심만 전달하는 브리프형 구성입니다.">의사결정 브리프</button>
                                        <button class="option-btn" data-role="preset" data-preset="accessibility-first" data-tooltip="고대비와 쉬운 문구를 우선하는 구성입니다.">접근성 우선</button>
                                        <button class="option-btn" data-role="preset" data-preset="map-explainer" data-tooltip="공간·지도 해석에 강한 설명형 구성입니다.">지도 설명형</button>
                                        <button class="option-btn" data-role="preset" data-preset="process-monitor" data-tooltip="과정 흐름과 상태 추적을 함께 다루는 구성입니다.">과정 모니터링</button>
                                        <button class="option-btn" data-role="preset" data-preset="network-analyzer" data-tooltip="관계 분석과 네트워크 구조에 강한 구성입니다.">관계 분석형</button>
                                    </div>
                                </div>
                                <div class="viz-field-block">
                                    <label>스타일 무드</label>
                                    <div class="option-btn-group viz-option-wrap" id="viz-theme-options">
                                        <button class="option-btn" data-role="theme" data-theme="[표준 기본]" data-tooltip="가장 무난한 기본 테마입니다.">표준 기본</button>
                                        <button class="option-btn" data-role="theme" data-theme="[교육 설명형]" data-tooltip="학습용 설명에 맞게 또렷한 라벨과 구조를 강조합니다.">교육 설명형</button>
                                        <button class="option-btn" data-role="theme" data-theme="[보고서형 대시보드]" data-tooltip="보고서와 브리핑에 어울리는 정돈된 대시보드 톤입니다.">보고서형 대시보드</button>
                                        <button class="option-btn" data-role="theme" data-theme="[서사 장면형]" data-tooltip="장면감과 몰입감을 살리는 내러티브형 테마입니다.">서사 장면형</button>
                                        <button class="option-btn" data-role="theme" data-theme="[과학 분석형]" data-tooltip="실험과 분석에 어울리는 정밀한 표현 톤입니다.">과학 분석형</button>
                                        <button class="option-btn" data-role="theme" data-theme="[스튜디오 프로토타입]" data-tooltip="실험적인 시안 느낌을 유지하는 스튜디오형 테마입니다.">스튜디오 프로토타입</button>
                                        <button class="option-btn" data-role="theme" data-theme="[지도 브리프]" data-tooltip="지도와 공간 설명에 맞는 차분한 테마입니다.">지도 브리프</button>
                                        <button class="option-btn" data-role="theme" data-theme="[화이트보드 스케치]" data-tooltip="강의실/보드 설명처럼 가벼운 스케치 감성을 줍니다.">화이트보드 스케치</button>
                                        <button class="option-btn" data-role="theme" data-theme="[경영 브리프]" data-tooltip="의사결정자 브리핑처럼 절제된 톤입니다.">경영 브리프</button>
                                        <button class="option-btn" data-role="theme" data-theme="[네온 다크]" data-tooltip="어두운 배경과 선명한 포인트를 쓰는 강한 대비 테마입니다.">네온 다크</button>
                                        <button class="option-btn" data-role="theme" data-theme="[접근성 우선]" data-tooltip="가독성과 대비를 가장 먼저 보는 테마입니다.">접근성 우선</button>
                                        <button class="option-btn" data-role="theme" data-theme="[운영 모니터]" data-tooltip="현황판과 모니터링 화면에 어울리는 테마입니다.">운영 모니터</button>
                                    </div>
                                </div>
                            </section>
                            <section class="viz-stage-card">
                                <div class="viz-stage-heading">
                                    <span class="viz-stage-index">4</span>
                                    <div>
                                        <h4>엔진 · 라이브러리 · 확장 기능</h4>
                                        <p>세부 엔진, 보조 옵션, 플러그인 활용 강도를 함께 조정하는 워크벤치입니다.</p>
                                    </div>
                                </div>
                                <div class="viz-field-block">
                                    <label>보조 옵션</label>
                                    <div class="option-btn-group viz-option-wrap" id="viz-behavior-options">
                                        <button class="option-btn" id="viz-educational-mode" data-tooltip="라벨, 설명, 학습 보조 구조를 더 적극적으로 붙입니다.">교육형 강조</button>
                                        <button class="option-btn" id="viz-worldsim-mode" data-tooltip="장면형 연출과 세계관 몰입을 더 적극적으로 허용합니다.">몰입형 강화</button>
                                        <button class="option-btn" id="viz-simulation-mode" data-tooltip="움직임과 시간 흐름을 포함한 시뮬레이션형 결과를 더 강하게 유도합니다.">시뮬레이션 모드</button>
                                        <button class="option-btn" id="viz-simple-mode" data-tooltip="구조를 단순화하고 첫 화면에서 핵심이 잘 보이게 만듭니다.">단순 모드</button>
                                        <button class="option-btn" id="viz-high-contrast-mode" data-tooltip="배경과 글자 대비를 높여 가독성을 우선합니다.">고대비 우선</button>
                                        <button class="option-btn" id="viz-export-safe-mode" data-tooltip="라이브 HTML과 내보내기에서 덜 흔들리는 구성을 우선합니다.">내보내기 안전</button>
                                        <button class="option-btn" id="viz-include-all-dom" data-tooltip="현재 문서 맥락을 함께 참고해 결과를 만들도록 합니다.">현재 화면 전체 포함</button>
                                        <button class="option-btn" id="viz-auto-generate-toggle" data-tooltip="선택한 설정을 이후 빠른 생성 기본값으로도 활용합니다.">자동 생성 기본값</button>
                                        <button class="option-btn" id="viz-remember-form-toggle" data-tooltip="이번 선택을 다음 옵션 스튜디오 기본값으로 다시 불러옵니다.">마지막 설정 기억</button>
                                        <button class="option-btn" id="viz-add-preset-prompt" style="display:none;" data-tooltip="현재 플레이스홀더 원본 프롬프트를 세부 요청에 추가합니다.">영역 프롬프트 추가</button>
                                    </div>
                                </div>
                                <div id="viz-batch-options" class="viz-inline-note">
                                    <label for="viz-batch-size-input">생성 단위</label>
                                    <input type="number" id="viz-batch-size-input" min="1" max="1" step="1" value="1" disabled>
                                    <small>시각화는 안정성을 위해 현재 한 번에 1개씩만 생성합니다.</small>
                                </div>
                                <div class="viz-field-block">
                                    <label>확장 기능 활용</label>
                                    <div class="option-btn-group viz-option-wrap" id="viz-addon-options">
                                        <button class="option-btn" data-role="addon" data-addon="off" data-tooltip="플러그인이나 추가 레이아웃 보조 도구를 가급적 쓰지 않습니다.">가급적 안 씀</button>
                                        <button class="option-btn" data-role="addon" data-addon="auto" data-tooltip="기본은 단순하게 가되, 꼭 필요할 때만 에드온 사용을 허용합니다.">필요할 때만</button>
                                        <button class="option-btn" data-role="addon" data-addon="recommended" data-tooltip="해당 라이브러리의 검증된 플러그인과 보조 기능은 적극 반영합니다.">추천 수준 사용</button>
                                        <button class="option-btn" data-role="addon" data-addon="aggressive" data-tooltip="레이아웃 플러그인, 지도 보조 도구, 차트 확장기능 등을 적극 활용합니다.">적극 활용</button>
                                    </div>
                                </div>
                                <div class="viz-field-block">
                                    <label>세부 라이브러리 지정</label>
                                    <small class="viz-field-help">라이브러리 선택은 선호도입니다. 안정성이나 내보내기 조건에 따라 가장 가까운 안전한 엔진으로 자동 대체될 수 있습니다.</small>
                                    <div class="viz-library-groups">
                                        <div class="viz-library-group"><h5>차트 · 통계</h5><div class="option-btn-group viz-option-wrap"><button class="option-btn" data-library="Chart.js" data-tooltip="안정적인 기본 차트 라이브러리입니다.">Chart.js</button><button class="option-btn" data-library="ECharts" data-tooltip="대시보드형 상호작용과 다양한 차트 구성이 강합니다.">ECharts</button><button class="option-btn" data-library="ApexCharts.js" data-tooltip="깔끔한 카드형 대시보드에 잘 맞는 차트 라이브러리입니다.">ApexCharts.js</button><button class="option-btn" data-library="Plotly.js" data-tooltip="과학 데이터와 고급 인터랙션에 강한 차트 라이브러리입니다.">Plotly.js</button><button class="option-btn" data-library="Vega-Lite" data-tooltip="선언형 차트 문법으로 구조를 명확히 잡기 좋습니다.">Vega-Lite</button><button class="option-btn" data-library="Google Charts" data-tooltip="가벼운 비즈니스형 차트에 무난한 선택입니다.">Google Charts</button><button class="option-btn" data-library="Observable Plot" data-tooltip="간결한 통계 시각화와 탐색형 플롯에 잘 맞습니다.">Observable Plot</button><button class="option-btn" data-library="uPlot" data-tooltip="대용량 시계열처럼 가벼운 렌더링이 필요할 때 유리합니다.">uPlot</button><button class="option-btn" data-library="AntV G2" data-tooltip="정교한 통계 차트와 데이터 스토리텔링에 강합니다.">AntV G2</button></div></div>
                                        <div class="viz-library-group"><h5>관계 · 다이어그램</h5><div class="option-btn-group viz-option-wrap"><button class="option-btn" data-library="Pure SVG" data-tooltip="엔진 의존성을 줄이고 직접 구조를 통제하기 좋습니다.">Pure SVG</button><button class="option-btn" data-library="D3.js" data-tooltip="커스텀 구조와 데이터 바인딩이 강력한 범용 라이브러리입니다.">D3.js</button><button class="option-btn" data-library="Cytoscape.js" data-tooltip="네트워크와 그래프 레이아웃 표현에 강합니다.">Cytoscape.js</button><button class="option-btn" data-library="vis-network" data-tooltip="노드 기반 관계도를 빠르게 구성하기 좋습니다.">vis-network</button><button class="option-btn" data-library="Mermaid" data-tooltip="플로우차트와 개념도처럼 텍스트 기반 다이어그램에 적합합니다.">Mermaid</button><button class="option-btn" data-library="Sigma.js" data-tooltip="대규모 네트워크 시각화에 강한 그래프 엔진입니다.">Sigma.js</button><button class="option-btn" data-library="dagre-d3" data-tooltip="계층형 플로우와 노드 배치에 유리합니다.">dagre-d3</button><button class="option-btn" data-library="AntV G6" data-tooltip="고급 그래프 레이아웃과 관계 편집 경험에 강합니다.">AntV G6</button><button class="option-btn" data-library="roughViz" data-tooltip="화이트보드/손그림 느낌의 다이어그램 표현에 적합합니다.">roughViz</button></div></div>
                                        <div class="viz-library-group"><h5>지도 · 공간</h5><div class="option-btn-group viz-option-wrap"><button class="option-btn" data-library="Leaflet.js" data-tooltip="가볍고 안정적인 지도 기본 엔진입니다.">Leaflet.js</button><button class="option-btn" data-library="MapLibre GL JS" data-tooltip="벡터 타일과 스타일 커스텀에 강한 지도 엔진입니다.">MapLibre GL JS</button><button class="option-btn" data-library="OpenLayers" data-tooltip="전문적인 GIS형 제어가 필요할 때 유리합니다.">OpenLayers</button><button class="option-btn" data-library="deck.gl" data-tooltip="레이어가 많은 공간 데이터와 3D 표현에 강합니다.">deck.gl</button><button class="option-btn" data-library="CesiumJS" data-tooltip="지구본·지형·3D 공간 표현에 적합합니다.">CesiumJS</button></div></div>
                                        <div class="viz-library-group"><h5>캔버스 · 장면</h5><div class="option-btn-group viz-option-wrap"><button class="option-btn" data-library="p5.js" data-tooltip="교육형 인터랙션과 생성형 스케치에 강합니다.">p5.js</button><button class="option-btn" data-library="Fabric.js" data-tooltip="캔버스 객체 조작과 레이어 편집에 적합합니다.">Fabric.js</button><button class="option-btn" data-library="Three.js" data-tooltip="3D 장면, 입자, 공간 표현의 대표 엔진입니다.">Three.js</button><button class="option-btn" data-library="PixiJS" data-tooltip="2D GPU 렌더링과 많은 스프라이트 처리에 강합니다.">PixiJS</button><button class="option-btn" data-library="Konva.js" data-tooltip="캔버스 UI와 도형 조작을 다루기 좋습니다.">Konva.js</button><button class="option-btn" data-library="Paper.js" data-tooltip="벡터 드로잉과 그래픽 조합에 적합합니다.">Paper.js</button><button class="option-btn" data-library="regl" data-tooltip="저수준 WebGL 제어가 필요할 때 적합합니다.">regl</button></div></div>
                                        <div class="viz-library-group"><h5>표 · 카드 · 문서형</h5><div class="option-btn-group viz-option-wrap"><button class="option-btn" data-library="Grid.js" data-tooltip="가벼운 표와 매트릭스 정리에 적합합니다.">Grid.js</button><button class="option-btn" data-library="Tabulator" data-tooltip="기능이 풍부한 데이터 테이블 구성에 적합합니다.">Tabulator</button><button class="option-btn" data-library="DataTables" data-tooltip="정렬·검색 중심의 표 레이아웃에 적합합니다.">DataTables</button><button class="option-btn" data-library="DOM Cards" data-tooltip="HTML/CSS 카드와 인포그래픽 블록 중심 구성을 뜻합니다.">DOM Cards</button><button class="option-btn" data-library="HTML/CSS Tables" data-tooltip="표준 DOM 기반 표와 레이아웃으로 최대한 안전하게 갑니다.">HTML/CSS Tables</button></div></div>
                                    </div>
                                </div>
                            </section>
                        </div>
                        <section class="viz-stage-card viz-stage-card-request">
                            <div class="viz-stage-heading">
                                <span class="viz-stage-index">5</span>
                                <div>
                                    <h4>세부 요청</h4>
                                    <p>강조할 요소, 피하고 싶은 요소, 설명 문구를 자유롭게 적습니다.</p>
                                </div>
                            </div>
                            <div class="viz-options-section">
                                <label for="viz-options-textarea">자유 지시 요청</label>
                                <textarea id="viz-options-textarea" placeholder="예: 첫 화면에서 핵심 구조가 잘 보이게 하고, 색 대비를 높이며, 설명 레이블은 학습자 기준으로 짧고 또렷하게 정리."></textarea>
                            </div>
                        </section>
                        <section class="viz-stage-card viz-stage-card-review viz-stage-card-highlight">
                            <div class="viz-stage-heading">
                                <span class="viz-stage-index">6</span>
                                <div>
                                    <h4>마지막 확인</h4>
                                    <p>지금 선택이 어떤 결과물로 해석되는지, 생성 직전에 한 번 더 확인합니다.</p>
                                </div>
                            </div>
                            <div id="viz-selection-summary" class="viz-selection-summary"></div>
                        </section>
                    </div>
                </section>
            </div>
            <div class="custom-modal-actions">
                <button id="viz-options-cancel-btn" class="modal-btn">취소</button>
                <button id="viz-options-generate-btn" class="modal-btn">생성하기</button>
            </div>
        </div>
    </div>
`;

const SHELL_PART_3_B = SHELL_PART_3_B_A;
