## Task

초기 로드 시 채팅/노트 패널이 캔버스 밖으로 일부 벗어나는 문제를 고치고, 상단 export를 `라이브 HTML로 내보내기` 단일 동작으로 단순화한다.

## User score

- Latest score for the current product state: `100 / 100`

## Goals

- 저장된 패널 상태를 현재 viewport 기준으로 안전하게 clamp한다.
- 첫 마운트 직후에도 한 번 더 위치를 보정해 오프캔버스 초기 상태를 방지한다.
- `정적 HTML로 내보내기` UI와 관련 분기를 제거한다.
- 상단 export 버튼은 클릭 즉시 `라이브 HTML 내보내기`를 실행한다.

## Scope

- `Ailey/src/02_utils/013_utils_panel_manager.js`
- `Ailey/src/03_core/120_core_main_initializer.js`
- `Ailey/src/00_shell/000_shell_template.js`
- `Ailey/src_css/010_widget_header_addons.css`
- 번들 재생성 및 publish bundle 동기화

## Risks

- 모바일 셸 모드에서 panel visibility/focus 동작이 깨지지 않아야 한다.
- maximize/minimize 상태와 저장 상태 복원이 충돌하지 않아야 한다.
- export 버튼 변경으로 기존 dropdown close 로직이 고아 코드로 남지 않아야 한다.

## Validation

- 데스크톱 첫 로드 시 chat/notes 패널 bounding rect가 viewport 내부에 있다.
- export dropdown/static 항목이 더 이상 존재하지 않는다.
- export 버튼 클릭이 곧바로 `window.exportAsLiveHtml(...)` 호출로 연결된다.
- page error / console error가 없다.

## Steps

1. panel restore 경로에 clamp helper와 post-mount safety pass 추가
2. export UI를 single-action live export로 단순화
3. bundle rebuild
4. focused browser validation
5. publish repo 반영 및 보고서 작성
