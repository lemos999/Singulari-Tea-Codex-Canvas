Plan Type: Work Plan
Workstream: Panorama Fullscreen And Gemini Local Chat Fix
Version: v01
Status: Completed / Published
Created: 2026-04-14 04:55:00 +09:00
Last Updated: 2026-04-14 05:12:00 +09:00
Supersedes or Related Plan: Related to `plan/20260414-032252--work-plan--api-ui-redesign-and-fullscreen-unification--v01.md` and `plan/20260414-045500--panorama-fullscreen-and-gemini-local-chat-fix-report--v01.md`
Current Completion State: Fix implemented, bundle rebuilt, direct browser validation passed, and publish completed
Completed So Far: The cinema-host fullscreen control regression was repaired, the `google_paid` Gemini text path was rerouted from a hanging browser SDK import to direct REST calls with timeout and retry handling, the bundle was rebuilt, the reported panorama artifact plus local chat flows passed targeted validation, and the verified bundle was published to GitHub as commit `193c1e2`.
Remaining Work: None for the approved scope.
Current Blockers: None
Next Step: Hand off the validation evidence and commit hash to the user, and treat any new chat or visualization regressions as separate follow-up work.

# User Understanding

The user reported two concrete regressions and wants both fixed in the live runtime rather than explained away.

First, in `[태양계의 파노라마.html]`, entering fullscreen on a visualization causes the return hover control to disappear. The user expects the quick-action overlay, especially the control that lets them get back out, to remain visible and usable in fullscreen or cinema mode.

Second, the user registered a local Gemini API preset with a Google key, selected `gemini-2.5-flash`, and sent a chat message, but the runtime produced no visible response. The user wants the local paid-Google chat path to work reliably.

The user also wants the fix verified on the reported artifact and then published to GitHub.

# Scope

In scope:

- reproduce the fullscreen-control disappearance on the reported panorama artifact
- trace the fullscreen or cinema host DOM and CSS path that owns the visualization controls
- fix the hover/return control so it remains visible and usable after fullscreen entry
- reproduce the no-response `google_paid` local chat path
- trace the Gemini request transport for both direct calls and UI chat flow
- repair the smallest reliable Google transport path for the browser runtime
- rebuild the bundle, validate the reported behaviors, and publish only the bundle artifacts

Out of scope unless required by the above:

- redesigning unrelated chat surfaces
- changing preset data schema or storage semantics
- broad visualization-generator content rewrites
- changing page payload HTML contracts unless the runtime fix strictly requires it

# Smallest Safe Assumptions

- The fullscreen-control issue is a runtime host or CSS scoping bug rather than a page-authoring bug in the panorama document.
- The local Gemini no-response issue is most likely transport-related and not caused by the user's chosen model string itself.
- The user wants the existing local preset flow preserved, not replaced by a different settings workflow.
- The safest publish unit remains the rebuilt runtime bundle files only.

# Objective

Deliver one narrow runtime bundle update that keeps fullscreen visualization controls visible in panorama-style cinema mode and makes the local `google_paid` Gemini chat path respond reliably for the configured preset and model, with direct validation on the reported artifact and the chat UI before publishing.

# Design Intent

Fix the real runtime invariants rather than layering on page-specific exceptions.

For fullscreen controls, the controls should remain correctly sized, positioned, and visible even after the visualization wrapper is reparented into the body-level cinema host. The fix should follow that relocation path rather than assuming the controls always live under the original article subtree.

For Gemini local chat, the browser runtime should use a predictable, dependency-light transport that works in exported and embedded environments. A direct REST call with explicit timeout and bounded retry is safer here than relying on a dynamic ESM SDK import that can stall or fail under those runtime conditions.

# Hidden Rules And Consistency Requirements

Several constraints matter even if the user did not spell them out line by line.

First, the fullscreen overlay cannot merely exist in the DOM. It must stay visually present with real geometry and usable pointer targets after fullscreen entry.

Second, the Google chat fix cannot depend on a local development-only import path. The same runtime bundle should keep working in the exported or embedded browser environment where the bug was observed.

Third, the fix should preserve existing higher-level chat orchestration contracts. If the runtime expects an async stream-like interface, the repaired transport should still satisfy that interface even if the backing Google call is non-streaming.

Fourth, the change should stay rollback-safe. Reverting the bundle and the corresponding source files should restore the prior state without data migration.

# Work Sequence

## Phase 1: Reproduce And Trace

Reproduce both reported failures with a targeted browser validation harness. Inspect the DOM and computed styles for fullscreen controls before and after cinema-host entry. Inspect the Google chat transport path used by the `google_paid` preset in the runtime.

## Phase 2: Implement The Smallest Complete Runtime Fix

Add cinema-host-native control styling so the visualization overlay stays visible after reparenting. Replace the hanging Google browser SDK path with a direct REST `generateContent` request flow that preserves the existing runtime contract and adds timeout or retry safety.

## Phase 3: Rebuild And Verify

Rebuild the runtime bundle and verify:

- fullscreen controls have non-zero geometry and visible icons after entry
- exiting fullscreen remains possible
- direct Google text generation returns content
- local temporary send and UI send both render an AI response
- no page errors or request failures appear in the acceptance run

## Phase 4: Publish

Copy the rebuilt bundle into the publish repository, verify the diff is limited to the intended bundle files, commit with a scoped message, push, and record the final commit hash.

# Technical Approach

The fullscreen repair is host-scoped CSS hardening. The controls move into `.viz-cinema-host` during fullscreen, so they need explicit sizing, positioning, and icon rendering rules in that host context instead of inheriting only from `.type-visualization`.

The Gemini repair is transport hardening. Use the Google REST `generateContent` endpoint directly, keep request assembly explicit, place `thinkingConfig` under `generationConfig`, and normalize the response into the runtime's existing `{ content, usage, raw }` shape. For the stream-oriented path, return a single-chunk async generator so the rest of the runtime remains unchanged.

# Risks

- A CSS-only fullscreen fix could still fail if cinema-host layering or pointer handling is wrong.
- Replacing the Google SDK path could regress usage accounting or stream assumptions if the normalization layer is incomplete.
- Browser validation must avoid relying only on local direct calls; it should prove the real UI path responds too.

# Failure Cases To Actively Check

- fullscreen controls exist but still render at `0x0`
- fullscreen controls render but the icon itself is invisible
- fullscreen entry works but exit control is not clickable
- direct Google generation succeeds while UI chat still hangs
- Google response text returns but is not rendered into the chat surface
- the runtime introduces new page errors or request failures while fixing the transport path

# Validation Strategy

Use the targeted validation harness at `visual-tests/panorama-fullscreen-google-paid-repro/validate_panorama_fullscreen_google_paid.mjs` and capture:

1. fullscreen overlay geometry and visibility before and after entry
2. direct Google stream-style path success
3. direct Google non-stream path success
4. temporary send success
5. UI send success
6. page error count, console issue count, and request failure count

Record the results in `visual-tests/panorama-fullscreen-google-paid-repro/validation.json`.

# Definition Of Done

This task is done when all of the following are true:

- panorama fullscreen keeps visible quick-action controls with a usable return path
- the local `google_paid` Gemini preset responds in runtime chat
- the validation artifact records successful fullscreen and chat outcomes
- the bundle rebuild succeeds
- only the intended bundle files are published to GitHub
- the final handoff includes the validation evidence and commit hash

# Rollback

Rollback remains straightforward. Revert the source edits in the fullscreen cinema-host CSS and Google chat API service, rebuild the bundle, and restore the previous published bundle files. No persisted data or schema migration is involved.

# Scoreboard

Current Score: 95
Score Source: verified
Last Updated: 2026-04-14 05:12:00 +09:00
Score Rationale: The requested panorama fullscreen and local Gemini chat regressions were repaired, directly validated in the reported runtime path, and published to the canonical GitHub bundle with a narrow two-file diff.
What Improved: The fullscreen overlay survives cinema-host reparenting with visible controls, and the Google local chat path now returns content through direct REST transport with timeout and retry handling.
What Remains Unsatisfactory: The validation run still records a small amount of non-blocking console noise from surrounding runtime or page surfaces, but no page errors or request failures remained in the acceptance path.
What Should Happen Next To Raise Or Maintain The Score: Preserve the cinema-host control contract and the direct Google REST transport path in future runtime changes, and reuse the validation harness when adjacent chat or visualization logic is touched.

## Score History

- 2026-04-14 05:05:00 +09:00 | Score: 50 | Source: provisional | Reason: Fix implemented and validated locally; GitHub publish still pending.
- 2026-04-14 05:12:00 +09:00 | Score: 95 | Source: verified | Reason: Panorama fullscreen control repair and local Gemini chat transport fix passed targeted validation and were published as commit `193c1e2`.
