# Corner Dock Header Follow-up Report

- Created: 2026-04-12 23:35:55 +09:00
- Status: completed_pending_user_validation
- Scope: immersive header follow-up
- Related Plan: `plan/20260412-232926--corner-dock-header-followup-plan--ailey--v01.md`

## Summary

Replaced the recently introduced thin action bar with a smaller upper-right corner dock.

The new header now:

- uses only the icon action cluster
- removes visible branding and helper copy
- avoids spanning the reading width
- hides when scrolling down
- reappears when scrolling up or near the top

## Code Changes

### Header Markup

- Rebuilt `Ailey/src/00_shell/000_shell_template.js`
- Removed:
  - `Codex Canvas` brand text
  - `슬림 액션 바` helper text
- Kept:
  - snapshot
  - export
  - notes
  - chat
  - theme

### Header Layout

- Updated `Ailey/src_css/001_base.css`
- Moved the header shell to the upper-right corner
- Reduced it to a compact floating dock
- Added `body.header-visible` driven opacity/translate behavior
- Reduced top body padding so the dock stops reserving a full-width header lane
- Tightened mobile spacing further

- Rebuilt `Ailey/src_css/010_widget_header_addons.css`
- Removed brand-specific styling
- Kept only compact icon-dock button styling

### Runtime Behavior

- Updated `Ailey/src/03_core/120_core_main_initializer.js`
- Removed unused brand font loading and reveal logic
- Added `initializeImmersiveHeaderDock()`
- Restored scroll-direction visibility behavior without reviving the old header toggle UI

## Verification

- `node --check Ailey/src/00_shell/000_shell_template.js`
- `node --check Ailey/src/03_core/120_core_main_initializer.js`
- `node Ailey/bundler.js`

All checks passed.

## Hosted Bundle Deployment

- Target repo: `Singulari-Tea-Codex-Canvas`
- Delivery path: `bundle/main.js`, `bundle/main.css`
- Commit: `c2dd929`
- Commit message: `Switch header to corner dock`

## Remaining Validation

Still pending user-side manual validation for:

- exported HTML pages that consume the hosted bundle
- narrow desktop widths
- mobile widths
