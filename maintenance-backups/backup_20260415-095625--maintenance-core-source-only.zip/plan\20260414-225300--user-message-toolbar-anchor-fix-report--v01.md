# Report: User Message Toolbar Anchor Fix

- Timestamp: 2026-04-14 22:53 KST
- Status: completed

## What Changed

- Removed the desktop-only left-side override for `.message-toolbar.user-toolbar`.
- User-message actions now reuse the same right-side overlay anchor as the accepted AI-message toolbar pattern.
- Preserved the existing no-layout-shift behavior and mobile tap flow.

## Why The Bug Happened

- The toolbar overlay was correctly moved out of normal flow in the earlier pass.
- A legacy desktop-only exception still forced `.message-toolbar.user-toolbar` to `left: -54px`.
- User messages live inside a full-width row container, so that left anchor pushed the toolbar to the far left edge of the chat area instead of next to the user bubble.

## Verification

- Validation harness: `visual-tests/validate_user_message_toolbar_anchor.mjs`
- Result folder: `visual-tests/user-message-toolbar-anchor-2026-04-14T13-50-32-856Z`
- Desktop:
  - `desktopToolbarVisible=true`
  - `desktopToolbarPosition=absolute`
  - `desktopHeightStableOnHover=true`
  - `desktopToolbarNearRightSide=true`
  - `desktopToolbarNotFarLeft=true`
- Mobile:
  - `mobileToolbarVisible=true`
  - `mobileToolbarPosition=absolute`
  - `mobileHeightStable=true`
  - `mobileToolbarNearMessage=true`
- Errors:
  - `pageErrorCount=0`
  - `consoleErrorCount=0`

## Publish Surface

- `bundle/main.css`
