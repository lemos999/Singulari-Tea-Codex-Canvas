# Report: Isolated Panel Clamp Retry

## Outcome

The isolated desktop panel clamp retry passed validation and was safe to publish.

## What Changed

`Ailey/src/02_utils/013_utils_panel_manager.js`

- added desktop-only parsing and measurement helpers for saved panel coordinates
- added `clampPanelToViewport(...)` to constrain restored panel width, height, left, and top against the current viewport
- preserved the existing draggable header peek behavior with a controlled negative top floor
- applied the clamp:
  - during `applyPanelStates()`
  - during `togglePanel(..., true)` on desktop
- added a delayed `schedulePanelClampPass()` after restore to catch late layout measurement changes

`visual-tests/validate_isolated_panel_clamp_retry.mjs`

- added a synthetic panel harness that injects bad saved coordinates and verifies corrected bounds
- added a real bundle bootstrap harness that confirms shell startup still works with the rebuilt bundle

## Why This Retry Was Safer

- only one production source file changed
- export behavior was not touched
- bundler behavior was not touched
- validation separated logic proof from shell bootstrap proof

## Validation Evidence

Validation directory:

- `visual-tests/isolated-panel-clamp-retry-2026-04-14T10-48-09-087Z/`

Key results:

- `chatInsideViewport=true`
- `notesInsideViewport=true`
- `chatTopKeepsHeaderPeek=true`
- `notesTopRemainsReachable=true`
- `widthsClamped=true`
- `heightsClamped=true`
- `hasChatPanel=true`
- `hasNotesPanel=true`
- `hasChatToggle=true`
- `chatVisible=true`
- `syntheticPageErrorCount=0`
- `syntheticConsoleErrorCount=0`
- `harnessPageErrorCount=0`
- `harnessConsoleErrorCount=0`

Artifacts:

- synthetic screenshot: `01-synthetic-clamp.png`
- shell screenshot: `02-shell-bootstrap.png`
- machine-readable results: `validation.json`
- summary: `validation-summary.txt`

## Rollback Safety

This pass is easy to rollback because it only changes panel placement logic in `013_utils_panel_manager.js` and does not alter export wiring, bundler classification, or mobile sheet behavior.
