# Ailey Visualization Rendering Fix Plan

- Artifact Type: feature-plan
- Created: 2026-04-12 09:51:00 +09:00
- Status: in_progress
- Scope: stabilize direct-DOM visualization rendering inside `renderVisualizationBlock()`
- Goal: render visualizations inside a predictable container without blank first paint, full-page overflow, or self-inflicted script breakage
- Execution Update: Phase 0 backup, the original Phase 1 renderer/CSS fix, the Phase 2 deploy, two follow-up hotfix deployments, and a targeted selector-collision fix deployment all completed on 2026-04-12. Broader follow-up testing then exposed a new issue: scene-like visualizations now render safely inside their host box, but some exported Three.js and p5 scenes feel overly cropped because the normal-mode host size is still too rigid. A fifth follow-up fix is now in progress.

## Scoreboard

- Current Score: 45
- Score Source: provisional
- Last Updated: 2026-04-12 14:12:00 +09:00
- Rationale: The earlier `100` applied to the resolved selector-collision case, but new user feedback during broader testing showed that scene-like exported visualizations are now too tightly boxed, so the current overall satisfaction state must be treated as reduced until the new clipping issue is re-tested.
- What Improved: The prior full-screen takeover bug remains fixed, and the new failure mode is narrower: scene-like visualizations need more adaptive host sizing rather than a rollback to unbounded rendering.
- What Remains Unsatisfactory: Some exported Three.js and p5 scenes still show only part of the intended content because the normal-mode host is not dynamically sized for large scene compositions.
- Next Score Target: Re-test the new scene-profile sizing fix against the exported file `태양의 성계- 중력과 빛의 대서사시.html` and confirm that the clipped visualizations are now readable by default.

### Score History

- 2026-04-12 09:58:30 +09:00 | 45 | provisional | User approved execution, backup was created, and implementation started.
- 2026-04-12 10:06:36 +09:00 | 50 | provisional | Original fix completed with rebundle and GitHub PR #6 merge.
- 2026-04-12 13:16:27 +09:00 | 50 | provisional | Layout-settling follow-up deployed through GitHub PR #7.
- 2026-04-12 13:30:58 +09:00 | 50 | provisional | Constrained render-box follow-up deployed through GitHub PR #8.
- 2026-04-12 13:30:58 +09:00 | 40 | user | User reported that rendering improved but the graph still felt full-screen, so the result remained only partially acceptable.
- 2026-04-12 13:44:00 +09:00 | 0 | user | User reported that the issue still remained and identified the problematic chart under `천체 역학의 황금률과 궤도 특성`, so the current result was considered unacceptable.
- 2026-04-12 13:57:00 +09:00 | 0 | user | A targeted selector-collision fix was implemented and deployed to the hosted bundle, but the current score remained the user's last explicit `0` until the same exported HTML was re-tested.
- 2026-04-12 14:02:00 +09:00 | 100 | user | User re-tested the previously broken exported HTML case after the selector-collision fix, confirmed that it now behaved correctly, and assigned a score of `100`.
- 2026-04-12 14:12:00 +09:00 | 45 | provisional | Broader exported-HTML testing revealed that scene-like visualizations were now too tightly boxed to be comfortably readable, so a follow-up sizing fix was opened.

---

## Problem History

### Iteration 1

The first renderer fix addressed these issues:

- visualization clipping caused by forced height plus hidden overflow
- unsafe `window.onload` brace stripping
- over-broad `document.body` rewriting
- destructive `</script>` cleanup
- partial external-library failure UI

That work shipped in GitHub PR `#6`.

### Iteration 2

A follow-up issue remained: some visualizations still executed before layout settled, so `vizContainer.clientHeight` could be `0` during the first run.

That was addressed by:

- double `requestAnimationFrame(...)` around the initial execution
- a post-execution `resize` dispatch

That work shipped in GitHub PR `#7`.

### Iteration 3

Another regression then appeared: in normal mode, some AI-generated charts used absolute positioning and visually overtook the page when overflow was visible.

The normal-mode render box was changed to:

- `height: 500px`
- `overflow: hidden`

That work shipped in GitHub PR `#8`.

### Iteration 4

The remaining exported-HTML failure was traced to a selector collision:

- the Chart.js block used a generic local `.canvas-container`
- the app-wide drawing overlay stylesheet also styled `.canvas-container` globally with `position: fixed !important`
- live exported HTML loaded the hosted bundle CSS, so the chart wrapper inherited drawing-overlay behavior and visually escaped its section

The fix changed the drawing overlay integration to:

- assign Fabric's wrapper a dedicated ID and class
- target only `#drawing-canvas-wrapper` and `.ailey-drawing-canvas-container` in drawing-overlay CSS
- stop styling the generic `.canvas-container` selector globally

That work shipped as hosted bundle commit `46f2cd2`.

### Iteration 5

Broader testing then revealed a different issue: the hard normal-mode render box that prevented full-page takeover also made large Three.js and p5 scenes feel cropped or unreadable in exported HTML.

The current follow-up changes the sizing policy to:

- classify scene-like visualizations separately from standard chart-like blocks
- keep standard visualizations in a moderate bounded box
- give scene-like visualizations a taller adaptive height
- let scene-like visualizations use a wider exported layout on larger screens without reopening the original full-page takeover path

## Current Implementation State

### `src/02_utils/013_utils_block_renderer.js`

The renderer currently does all of the following:

- creates a visualization container with `position: relative`, `width: 100%`, `height: 500px`, and `overflow: hidden`
- defers the initial `executeDirectVisualization(...)` call through a double `requestAnimationFrame(...)`
- loads external scripts before inline execution
- rewrites only direct `document.body` insertion and query calls needed for container scoping
- preserves normal `document.body` reads
- escapes `</script>` instead of deleting it
- executes newly assigned `window.onload` handlers after script evaluation
- dispatches `window.resize` after script injection so chart libraries can reflow

### `src_css/004_widget_visualization_options.css`

The base `.visualization-content-container` rule currently uses:

- `position: relative`
- `width: 100%`
- `height: 500px`
- `overflow: hidden`
- `box-sizing: border-box`

Cinema mode still overrides the normal render box through its explicit full-screen CSS.

### `src/05_features_notes/311_notes_drawing_canvas.js`

The drawing canvas setup now stamps the Fabric.js wrapper with:

- `id="drawing-canvas-wrapper"`
- `.ailey-drawing-canvas-container`

That gives the drawing overlay a private styling target instead of relying on Fabric's generic `.canvas-container` class.

### `src_css/010_drawing_canvas.css`

The drawing overlay stylesheet now:

- targets only `#drawing-canvas-wrapper` and `.ailey-drawing-canvas-container`
- preserves the fixed full-screen Fabric overlay behavior for drawing mode
- no longer applies any global `.canvas-container` rules that can leak into generated visualization markup

### Iteration 5 Runtime Adjustments

The renderer now distinguishes between:

- `standard` visualizations such as bounded charts
- `scene` visualizations such as Three.js, p5, and similar immersive canvases

Scene-like blocks receive a larger adaptive normal-mode host box, and exported live HTML gives them a wider layout on sufficiently large screens.

### Iteration 5 Files

- `src/02_utils/013_utils_block_renderer.js` now classifies visualization blocks into `standard` and `scene` profiles using lightweight content heuristics.
- `src_css/004_widget_visualization_options.css` now applies taller adaptive heights for scene-like blocks and gives exported live HTML a wider desktop layout for those blocks.

## Root Cause Update

The latest exported HTML investigation narrowed the remaining failure to a specific class-name collision, not to the general render-box sizing logic.

- The problematic block was the Chart.js visualization under `천체 역학의 황금률과 궤도 특성`.
- Its embedded visualization markup defined a generic local wrapper named `.canvas-container`.
- The app also shipped a drawing-overlay stylesheet that styled `.canvas-container` globally.
- Because live exported HTML loads the hosted app bundle CSS, that global drawing rule leaked into the visualization's local Chart.js wrapper and forced the chart container to behave like a fixed full-screen overlay.
- The dedicated drawing-wrapper selector fix removed that shared namespace collision.

## Files In Scope

| File | Responsibility |
|---|---|
| `src/02_utils/013_utils_block_renderer.js` | runtime visualization container behavior and direct execution safeguards |
| `src_css/004_widget_visualization_options.css` | base visualization container sizing and overflow behavior |
| `src/05_features_notes/311_notes_drawing_canvas.js` | assigns a dedicated wrapper identity to the Fabric drawing overlay |
| `src_css/010_drawing_canvas.css` | constrains drawing-overlay styling to the dedicated Fabric wrapper instead of the generic `.canvas-container` selector |

## Deployment History

- PR `#6`: original visualization rendering fix
- PR `#7`: layout-settling follow-up for initial zero-height execution
- PR `#8`: constrained 500px render-box hotfix
- Hosted bundle commit `46f2cd2`: targeted selector-collision fix for drawing-overlay CSS
- Hosted bundle commit `7dadd92`: adaptive scene-profile sizing follow-up

## Remaining Verification

- Re-test `태양의 성계- 중력과 빛의 대서사시.html` with the new scene-profile sizing rules.
- Run broader exploratory checks across additional generated visualization blocks.
- Reconfirm cinema-mode enter and exit behavior under repeated use.
- Reconfirm replay, regenerate, and theme-toggle reruns after repeated executions.
- Reconfirm that drawing mode still behaves correctly after the dedicated wrapper targeting change.
