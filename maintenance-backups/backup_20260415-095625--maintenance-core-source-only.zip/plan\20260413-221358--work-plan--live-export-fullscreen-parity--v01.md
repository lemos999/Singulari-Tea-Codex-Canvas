Plan Type: work-plan
Workstream: Live export parity and fullscreen stabilization for canvas-rendered interactive exports
Version: v01
Status: Completed / Published
Created: 2026-04-13 22:13:58 +09:00
Last Updated: 2026-04-13 23:08:03 +09:00
Supersedes or Related Plan: Related to 20260413-205909--work-plan--cc-cdn-blind-sub-test--v01.md and 20260413-205909--cc-cdn-blind-sub-test-report--v01.md
Current Completion State: Implementation landed, recursive validation passed, late /sub review completed, and publish completed to the canonical GitHub repository
Completed So Far: Live export now preserves the mounted `<main id=\"ai-content-placeholder\">` root and artifact-authored head resources; fullscreen/cinema lifecycle was hardened; concurrent visualization CDN loads now wait for true load completion; common generated D3 easing alias typos are repaired during preflight; the live-export/fullscreen validation matrix passed in both `file://` and served `http://` modes for generated export, stellar essay, and legacy solar artifacts; the repaired bundle was published to `origin/main` as commit `8189e36`
Remaining Work: Optional future hardening only, mainly around shell visibility confidence and reducing non-fatal console warning noise
Current Blockers: None
Next Step: Hand off the published runtime and validation evidence to the user, with the remaining low-risk watch items documented

# Scoreboard

- Current Score: 95
- Score Source: final acceptance
- Last Updated: 2026-04-13 23:08:03 +09:00
- Score Rationale: The user-facing target was met with bounded repairs, hard browser validation, and publish completion. Generated live export, legacy export parity, and fullscreen stability now pass across the validation matrix. Only low-risk confidence/watch items remain.
- What Improved: The export path preserves required resources and mounted layout metadata, the runtime no longer races shared visualization library loads, fullscreen cycles re-enter and exit cleanly, and the legacy solar page no longer throws the earlier D3 runtime error.
- What Remains Unsatisfactory: The validation suite still records shell panels as mounted-but-hidden rather than visibly open, and there is minor non-fatal console warning noise from third-party libraries or CDN usage.
- What Should Raise Or Maintain The Score: Keep future changes narrow around export/runtime parity, preserve the validation matrix, and only broaden heuristics when there is clear new evidence.

## Score History

- 2026-04-13 22:13:58 +09:00 | Score 50 | Source: provisional | Initial approved-run working score recorded at the start of implementation planning. Scope is clear, but there is no shipped fix yet.
- 2026-04-13 23:08:03 +09:00 | Score 95 | Source: final acceptance | Bounded runtime/export/fullscreen repairs passed the harsh validation matrix and were published to GitHub.

# Objective

Repair the live export pipeline so that a locally opened live-export HTML file behaves as close as reasonably possible to the in-canvas rendered experience, with special emphasis on fullscreen stability for visualization-heavy pages. The immediate priority is not to redesign or improve the generated visualization content itself. The priority is to make the export/runtime/frame/fullscreen path robust enough that the same artifact does not materially diverge between the canvas experience and the local live-export experience, and does not break or degrade when the user enters fullscreen or cinema-like expansion flows.

The concrete user-facing target is this:

1. A live-exported HTML file opened locally should preserve the same major layout, styling expectations, runtime handoff behavior, and visualization mounting assumptions as the canvas-backed rendering path.
2. Fullscreen or cinema expansion for visualization surfaces should remain readable, dimensionally sane, and resistant to resize/remount issues.
3. Known fragile visualization content may still be imperfect, but the export/runtime shell must not make that fragility worse or introduce avoidable breakage.
4. The work should be validated aggressively with `/sub` workers, browser-based checks, and repeated regression passes before anything is considered publishable.

# Confirmed Facts

- The user explicitly approved implementation and explicitly requested `/sub` with maximum reasoning and heavy testing.
- The user wants the local live export to work “as-is,” meaning parity between local live export and the canvas/runtime path matters.
- The user wants fullscreen behavior repaired.
- The user explicitly deprioritized fixing the intrinsic quality of AI-authored visualization logic for now.
- The failing example is the solar-system themed live export HTML artifact already present in the workspace.
- Prior evidence already showed that the export file uses a live-export wrapper pattern with `data-export-mode="live"` and a template-driven `renderAppShell(...)` bootstrap instead of a plain static article.
- Prior evidence already showed that the extracted export file uses Tailwind-style utility classes in the payload while the exported head does not include Tailwind, which is a strong parity-divergence candidate.
- Prior evidence already showed at least one visualization runtime error in the solar-system artifact, especially around the “inner structure of the sun” scene.

# Safe Assumptions

- The primary implementation surface is inside `Ailey/src/`, with the main likely files being the HTML exporter, visualization block renderer, and any shell/fullscreen-related code paths.
- The current publish target, if code changes are accepted, will likely involve rebuilding or syncing the runtime bundle and then pushing to the already-used GitHub repository path that hosts the live bundle.
- The export should remain a live export rather than being downgraded into a simpler, less faithful static export. A simpler fallback may be useful as a safety valve, but it should not replace the default live-export behavior unless the default path cannot be stabilized.
- The safest fix is likely architectural and bounded: preserve the same runtime preconditions between local export and canvas where possible, fix obvious missing dependency propagation, and harden fullscreen/remount handling for visualization containers rather than rewriting the entire export model.

# Out Of Scope

- Redesigning the visual identity of the solar-system page.
- Reauthoring all broken visualizations by hand.
- Solving every possible fragile third-party visualization generated by AI across the whole product.
- Broad cleanup unrelated to export parity, fullscreen stability, or the minimum necessary supporting runtime behavior.
- Replacing the runtime shell contract with a completely new shell system.

# Problem Framing

This issue should be treated as a multi-surface runtime consistency problem, not a single CSS bug.

The divergence appears to involve at least four interacting layers:

1. Export artifact construction: what is copied into the live export file, what is stripped, what head resources are preserved, and what bootstrap path the exported file follows.
2. Runtime shell handoff: how the exported content is mounted into the live shell and whether that differs from the in-app canvas path in ways that affect sizing, panel behavior, or hydration timing.
3. Visualization renderer behavior: how visualization blocks load dependencies, hydrate into containers, recover from resize, and behave when containers are reparented, resized, or expanded.
4. Fullscreen or cinema expansion flow: how expanded containers compute size, how resize events are propagated, whether cleanup/reinit is required, and whether the runtime changes body overflow or container geometry in ways that expose renderer bugs.

The goal is not to make every visualization perfect in isolation. The goal is to ensure that:

- export does not silently remove required runtime/style conditions,
- runtime mounting does not cause avoidable divergence,
- fullscreen expansion does not create obviously broken geometry,
- container resizing and remounts do not amplify known renderer fragility.

# Hidden Rules And Consistency Constraints

Several hidden rules matter here even though the visible user request sounds simpler:

- A local live export must remain meaningfully “live.” If we strip too much runtime behavior to make the file more stable, the user will still perceive it as broken parity.
- The export should not rely on ambient in-app state that the local file does not have. If the canvas path only works because the app has already loaded certain resources globally, the exporter must either carry those resources forward or produce a deliberately consistent fallback.
- Fullscreen stability must be judged on actual interactive behavior, not just on a static screenshot after first paint.
- Resize-sensitive visualizations need either resilient sizing logic or a container strategy that guarantees sane dimensions during expand/collapse transitions.
- Cleanup matters. A visualization that works on first mount but leaks transitions, observers, or requestAnimationFrame loops can fail only when expanded, remounted, or revisited, which matches the reported symptom.
- Export parity should not come at the cost of hijacking runtime-owned shell surfaces or breaking chat/notes/header chrome.
- Publish should not happen on a “probably fixed” basis. The acceptance bar must include repeated proof on the affected example and at least a small regression set from similar exported artifacts.

# Recommended Technical Approach

Use a narrow, layered repair strategy:

## Layer 1: Export parity repair

Inspect the live-export generation path and determine which dependencies or state assumptions are missing from the generated document. The most likely first-class example is the missing Tailwind dependency when the exported payload still carries Tailwind utility classes. If the exporter emits payloads that require head-level resources, the exporter must either include those resources truthfully in the export or normalize the payload so it no longer depends on absent resources.

This layer should aim to reduce the gap between:

- canvas runtime rendering in-app
- served live export
- local-file live export

without introducing uncontrolled head bloat or new shell takeover behavior.

## Layer 2: Fullscreen container hardening

Inspect the visualization expansion or cinema-mode path and ensure the expanded visualization container receives a stable geometry contract. The fix may require:

- explicit container sizing guarantees,
- stable min-height or viewport-based sizing in expanded mode,
- resize event sequencing after class toggles,
- better restoration of body overflow and layout state,
- avoiding transient zero-size containers during expansion.

The expanded path should be stable even when the user repeatedly enters and exits fullscreen or cinema mode.

## Layer 3: Visualization lifecycle hardening

Inspect the visualization renderer path for resize/remount sensitivity. A bounded fix may include:

- consistent cleanup hooks,
- safer observer lifecycle management,
- avoiding duplicate initialization on re-entry,
- guarding against zero-width/zero-height initial states,
- preventing repeated transition chains or requestAnimationFrame loops from compounding.

This is not a rewrite of all visualization generators. It is a hardening pass on the mounting and expansion environment so that fragile scenes do not fail more often than necessary.

## Layer 4: Export and fullscreen regression guardrails

Once the main issue is addressed, add or strengthen regression checks and repeatable validation artifacts so that future export changes do not silently regress parity or fullscreen behavior.

# Execution Plan

## Phase 1: Detailed scan and evidence refresh

Inspect the exporter, visualization renderer, and fullscreen controls in source. Build an explicit map of:

- where live-export head assets are chosen,
- how export wrappers are assembled,
- how visualization blocks are serialized and rehydrated,
- how expand/fullscreen mode is activated,
- where resize and cleanup are handled.

Refresh local proof on the known failing solar-system export and at least one sibling exported artifact to separate artifact-specific failure from system-level failure.

Deliverable:

- updated local evidence set,
- concrete candidate fault list,
- narrowed writable scope.

## Phase 2: `/sub` orchestration

Launch a small, mixed worker team with maximum useful reasoning:

- one analysis/validator worker to examine runtime divergence and propose acceptance checks,
- one explorer or reviewer-style worker to focus on fullscreen and lifecycle risks,
- optionally one bounded implementation-support worker if there is a cleanly separable read-only diagnostic task that can accelerate parent work.

The parent remains responsible for landing code in the main workspace and for final acceptance. Workers should not create uncontrolled scope expansion. Their mission is to sharpen diagnosis, stress the acceptance bar, and reduce blind spots while the parent keeps the main implementation coherent.

Deliverable:

- orchestration plan under `subagent-runs/`,
- worker briefs,
- parallel findings that inform bounded implementation.

## Phase 3: Bounded implementation

Land the smallest complete repair set in the main workspace. The likely touched areas are:

- live-export HTML generation,
- visualization dependency propagation or normalization,
- fullscreen or cinema-mode container logic,
- visualization lifecycle hardening where needed.

Prefer systemic fixes over one-off artifact hacks. If an artifact-specific special case becomes necessary, document why and keep it narrow.

Deliverable:

- source changes in the primary workspace,
- updated plan status,
- explicit note of any remaining known limitations.

## Phase 4: Recursive verification

Run repeated browser tests across these conditions:

- local file open,
- served local HTTP open,
- canvas-like runtime handoff path if reproducible locally,
- normal view,
- expanded/fullscreen view,
- repeated enter/exit cycles,
- at least one sibling export artifact as regression coverage.

Verification must distinguish:

- layout parity,
- missing resource parity,
- console/runtime errors,
- shell survival,
- fullscreen geometry stability.

If issues remain within the approved scope, run a bounded fix loop and re-verify. Do not stop at the first “looks better” result.

Deliverable:

- screenshots,
- validation JSON or equivalent evidence,
- final pass/fail decision with residual risks if any.

## Phase 5: Read-only review and publication

Run one final read-only review focused on regressions, brittleness, and rollback risk. If the result is acceptance-grade, rebuild any required bundle or publish artifacts and push to the appropriate GitHub target. If acceptance is not met, stop and report the remaining failure honestly instead of publishing.

Deliverable:

- review verdict,
- acceptance note,
- GitHub commit and push details if published.

# Validation Strategy

Success must be demonstrated, not inferred. Validation should include:

- console error capture,
- shell selector presence checks,
- visible layout checks before and after fullscreen,
- repeated expand/collapse cycles,
- local file and local HTTP comparisons,
- one or more screenshots of the known failing solar-system export before and after repair,
- at least one regression artifact to ensure the fix does not overfit only one page.

Important validation questions:

- Does the export still depend on resources that are absent in the exported head?
- Does the local live export visually approximate the canvas layout after repair?
- Does the first problematic visualization still throw its runtime error?
- Does fullscreen keep sane dimensions and a readable layout?
- Does expansion create hidden-state or resize-state corruption after returning to normal mode?
- Do chat/header/notes shell surfaces remain intact when relevant?

# Definition Of Done

The work is done only when all of the following are true:

- The local live export no longer materially diverges from the canvas rendering because of avoidable export/runtime setup differences.
- The known solar-system example remains stable and readable in fullscreen or cinema expansion.
- No newly introduced console/runtime error appears in the repaired path.
- The fix survives repeat enter/exit fullscreen cycles.
- A small regression set also passes.
- The final result has a clean review verdict and acceptable rollback surface.
- If published, the GitHub state matches the accepted local result and the report names the exact commit.

# Risks

- Fixing export parity may expose more missing-resource assumptions than expected.
- Hardening fullscreen may reveal generator-specific bugs that cannot be fully solved at the runtime layer alone.
- A too-aggressive export parity fix could accidentally widen the exported head or cause shell-style collisions.
- Resize/cleanup fixes can regress existing visualizations if the renderer contracts are inconsistent.
- The workspace contains multiple loosely versioned runtime sources and export artifacts; care is required to edit the canonical source rather than a stale copy.

# Rollback Strategy

Keep the repair bounded and traceable. If a change causes wider regressions:

- revert the specific exporter or fullscreen hardening change,
- keep evidence of the failure,
- fall back to the last known stable baseline,
- report exactly which acceptance criterion failed.

Do not combine speculative cleanup with the behavior change. Keep rollback granular.

# Immediate Working Notes

- Start by locating the canonical implementation in `Ailey/src/`.
- Treat `018_utils_html_exporter.js` and `013_utils_block_renderer.js` as initial primary suspects, not final confirmed fault owners.
- Keep the solar-system artifact as the anchor case.
- Use `/sub` workers to parallelize diagnosis and acceptance pressure, not to spray overlapping code edits into the main workspace.
- Update this file after each major state change: scan complete, worker launch, implementation landed, verification result, review result, and publication result.
