# Scene Image Studio Label Overlap Fix Report

- Artifact Type: implementation-report
- Created: 2026-04-12 22:03:28 +09:00
- Scope: fix the left-column overlap between the helper note and the `장면 설명 메모` label in the remodeled scene image studio
- Status: implemented-and-deployed-awaiting-manual-validation
- Related Plan: `20260412-181504--visualization-options-upgrade-plan--ailey--v01.md`

## What Happened

- after the scene image studio remodel, the left-side helper note under the reference-image card could visually collide with the next card's `장면 설명 메모` label
- this presented as text overlap rather than a functional failure

## Root Cause

- the remodeled left column relied too much on generic flex/card spacing
- the helper note and the memo card header did not have their own explicit separation rules
- depending on viewport, font rendering, and wrapped note length, the two sections could appear to run together

## What Changed

- `Ailey/src_css/027_image_gen_studio.css`
  - added explicit internal gap rules for the global-options card and prompt card
  - normalized the direct label spacing for those cards
  - converted the helper note into a clearly separated block with top padding and a subtle divider
  - gave the prompt card a little more top padding so its header reads as a new section even in tighter layouts

## Verification

- `node Ailey/bundler.js`

## Deployment

- hosted repo: `Singulari-Tea-Codex-Canvas`
- branch: `main`
- commit: `1f68279`
- commit message: `Separate scene image studio side card spacing`

## Remaining Risk

- browser rendering at unusual zoom levels still needs manual confirmation
