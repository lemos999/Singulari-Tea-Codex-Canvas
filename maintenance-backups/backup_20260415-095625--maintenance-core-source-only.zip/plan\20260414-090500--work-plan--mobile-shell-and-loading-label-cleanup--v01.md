Plan Type: Work Plan
Workstream: Mobile Shell and Loading Label Cleanup
Version: v01
Status: Completed
Created: 2026-04-14 09:05:00 +09:00
Last Updated: 2026-04-14 09:41:00 +09:00
Supersedes or Related Plan: Related to `plan/20260414-083555--visualization-transaction-and-loader-center-report--v01.md`
Current Completion State: Root backup completed; mobile shell behavior repaired; loading labels removed from active runtime surfaces; bundle rebuilt, validated on mobile and desktop, synced to the publish repo, and pushed to GitHub
Completed So Far: User-approved mobile shell work was finished; the current workspace backup was created at repo root; mobile viewport mode now enters a single-panel full-viewport shell, desktop drag and resize semantics are suppressed on mobile, early shell bindings now attach before slow Firebase initialization can stall controls, and visible image or batch-generation loading copy was removed or neutralized while preserving explicit error states. Browser validation passed with saved screenshots and zero page or trace errors. The publish repo was updated with the rebuilt bundle and pushed as commit `5eca8e0`.
Remaining Work: Record the final release report
Current Blockers: None
Next Step: Copy the rebuilt bundle into the publish repo, push, and finalize the short maintenance report

# Scoreboard

Current Score: 50
Score Source: provisional
Last Updated: 2026-04-14 09:41:00 +09:00
Score Rationale: The requested backup exists, the mobile shell pass now validates successfully on a phone-sized viewport, desktop behavior still holds, and visible loading labels are gone from the active runtime paths that were in scope. The score remains capped at 50 because it is still provisional until the user reacts to the shipped result.
What Improved: Mobile panels now follow a one-surface-at-a-time model, the chat sidebar and recall drawer behave like mobile drawers, settings popovers fit inside the viewport, early shell bindings no longer wait on Firebase, and the active generation UI now relies on silent visual activity instead of legacy progress copy.
What Remains Unsatisfactory: User confirmation remains outstanding; a later dedicated mobile redesign could still improve navigation beyond this bounded shell pass.
What Should Happen Next To Raise Or Maintain The Score: Keep the saved validation evidence linked from the report, publish the maintenance summary clearly, and collect the user's next round of mobile feedback for any follow-up redesign work.

## Score History

- 2026-04-14 09:05:00 +09:00 | score=50 | source=provisional | New approved workstream opened for root backup, mobile shell improvement, and loading-label cleanup after the user confirmed the prior visualization fixes were stable and asked to proceed.

# Objective

Make the desktop-origin shell usable on mobile without relying on desktop drag or multi-panel assumptions, and remove the remaining visible "image generating" and "batch generating" style loading text so active media work reads as calm, silent progress instead of noisy legacy status copy. The result should preserve existing desktop behavior, keep the shell safe under viewport and keyboard changes, and remain maintainable for later mobile follow-up work.

# Why This Work Exists

The current runtime is still fundamentally desktop-shaped: draggable panels, simultaneously visible workspace surfaces, and compact control layouts. On a phone viewport that produces cramped, overlapping, difficult-to-control UI. At the same time, the runtime still surfaces old loading copy such as image-generation or batch-generation text, even after the visual loading indicators were modernized. This work exists to convert the most important shell behaviors to a mobile-safe mode and to finish the loading-state cleanup so the product feels coherent across the newer UI refreshes.

# Scope

In scope:

- Root-level backup of the current workspace state before new edits
- Mobile viewport detection and viewport-metric syncing for shell panels
- Mobile-specific behavior for chat and note panels so one panel can own the viewport cleanly
- Mobile drawer behavior for chat sessions and note recall turn lists
- Safe handling of minimize/maximize/drag interactions on mobile
- Mobile-safe settings popover and composer spacing
- Removal of remaining visible image-generation and batch-generation loading labels from active runtime surfaces
- Browser validation on at least one mobile-sized viewport and one desktop-sized viewport
- Bundle rebuild, publish-repo sync, and release report

Out of scope unless verification shows a hard dependency:

- A full mobile-native redesign with bottom tabs or a new shell navigation architecture
- Deep content-layout changes inside every payload page
- Rewriting note/chat data models or session architecture

# Confirmed Facts

- The user asked for a root backup first, then approved mobile-shell work and the loading-label cleanup.
- A new root backup already exists: `backup_20260414-084039--pre-mobile-shell-pass.zip`.
- The shell already has initial mobile CSS and panel-manager changes in the working tree.
- Visible loading copy still remains in parts of the image-generation and batch-visualization runtime.
- Desktop behavior must continue working after the mobile pass.

# Safe Assumptions

- The smallest safe mobile pass is a single-panel, full-viewport shell mode rather than a full navigation redesign.
- It is acceptable to keep non-visual progress state internally while hiding cosmetic loading copy from the user-facing surfaces.
- The top priority is touch usability and predictable panel visibility, not pixel-perfect parity with the desktop shell.

# Technical Approach

Use a bounded, behavior-first mobile mode:

1. treat small viewports as a distinct shell mode
2. make the active panel occupy the safe viewport while disabling desktop-only interaction affordances
3. convert sidebars into overlay drawers instead of permanently visible columns
4. ensure only one main panel is visible at a time on mobile
5. remove user-facing loading labels while keeping dot-based progress indicators and explicit failure states

The implementation should stay local to shell/panel CSS, panel state management, and the image/visualization loading helpers.

# Phased Work Sequence

## Phase 1: Record and Align

Open a new plan artifact, record the backup reference, and confirm which mobile and loading-label changes are already staged in source so the next edits stay surgical.

## Phase 2: Repair Mobile Shell Behavior

Finish the runtime behavior so mobile mode consistently applies full-viewport panel geometry, hides competing panels, disables desktop drag semantics, and lets chat and notes side drawers open and close predictably.

## Phase 3: Remove Residual Loading Labels

Strip remaining visible text such as image-generation and batch-generation progress labels from runtime-facing surfaces while preserving error messages and non-blocking progress semantics.

## Phase 4: Verify and Publish

Rebuild the bundle, validate mobile and desktop behavior in browser automation, then sync the publish repo, push GitHub changes, and record the final behavior in a short report.

# Hidden Rules And Consistency Requirements

- Mobile mode must not silently break desktop panel positioning when the viewport grows back to desktop size.
- A loading indicator may stay visible, but it should not show legacy "image generating" or "batch generating" copy unless the text is genuinely part of an error or explicit confirmation.
- Failures must still be explained clearly; only cosmetic progress labels are being removed.
- The new mobile behavior should prefer one obvious active workspace surface over overlapping panels.
- Changes should remain rollback-safe by staying within shell logic, generation helpers, and CSS.

# Risks

## Risk: Mobile fixes accidentally regress desktop drawer behavior

Mitigation: Validate both mobile and desktop after the rebuild, not just the phone viewport.

## Risk: Hiding status text also hides useful failure feedback

Mitigation: Remove only progress wording and keep error/failure states explicit.

## Risk: Viewport and keyboard changes still produce clipped composer or popover surfaces

Mitigation: Validate with `visualViewport`-aware sizing and inspect composer/settings placement on a phone-sized viewport.

# Validation Strategy

Validation should cover:

- mobile viewport entry with the shell in `mobile-shell-mode`
- only one main panel visible at a time on mobile
- chat sidebar drawer opens and closes on mobile
- note recall drawer opens and closes on mobile
- settings popover remains usable on mobile
- image/visualization loaders show dots without visible "image generating" or "batch generating" text
- desktop viewport keeps normal drawer behavior and does not inherit mobile-only geometry

# Definition Of Done

The work is done when:

- the current workspace is backed up at repo root
- mobile mode gives chat and notes a usable touch-first layout
- sidebar drawers behave predictably on mobile
- visible image/batch generation loading text is gone from active runtime surfaces
- desktop behavior still works
- bundle rebuild succeeds
- validations pass with saved evidence
- the publish repo is updated and pushed
- the plan and final report reflect the finished behavior

# Progress Log

- 2026-04-14 09:05:00 +09:00 | Plan created and activated after user approval. Root backup already completed and referenced here. Scan continues on mobile drawer behavior and remaining loading-label surfaces.
- 2026-04-14 09:27:00 +09:00 | Core shell initialization was reordered so event listeners, panel wiring, and mobile viewport mode apply before Firebase initialization completes. This removed the "controls appear but do nothing" failure mode seen in local and mobile validation.
- 2026-04-14 09:37:00 +09:00 | Residual visualization and image-generation progress copy was removed or neutralized in the runtime helpers. Dot-based loaders remain, while failure and recovery text stays explicit.
- 2026-04-14 09:40:00 +09:00 | Rebuilt `Ailey/bundle/main.js` and `Ailey/bundle/main.css`, then passed browser validation at `visual-tests/mobile-shell-validation-2026-04-14T00-39-52-832Z/` with mobile and desktop checks both green and zero page or trace errors.
- 2026-04-14 09:44:00 +09:00 | Synced `bundle/main.js` and `bundle/main.css` into `Singulari-Tea-Codex-Canvas-pr/`, then pushed GitHub Pages repo `lemos999/Singulari-Tea-Codex-Canvas` on `main` as commit `5eca8e0`.
