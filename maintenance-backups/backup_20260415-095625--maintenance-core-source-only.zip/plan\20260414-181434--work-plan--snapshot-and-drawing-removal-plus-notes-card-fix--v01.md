Plan Type: Work Plan
Workstream: Snapshot And Drawing Removal Plus Notes Card Fix
Version: v01
Status: Completed
Created: 2026-04-14 18:14:34 +09:00
Last Updated: 2026-04-14 18:29:33 +09:00
Supersedes or Related Plan: Related to `plan/20260414-170935--work-plan--mobile-chat-session-return-affordance--v01.md` and continues the same shell-cleanup stream after the user approved feature removal
Current Completion State: Implemented, validated, documented, and published
Completed So Far: Confirmed the user wants to keep light/dark mode, fully removed the current-screen snapshot recording flow, fully removed the backtick drawing mode and its runtime hooks, fixed the notes archive card height leak where the next stored card peeked through beneath a collapsed project, rebuilt the bundle, validated the removal and layout fix, synced the publish repo, and pushed GitHub commit `76be8e1`.
Remaining Work: None inside the approved scope.
Current Blockers: None
Next Step: Hold for new user feedback or a future follow-up cleanup pass.

# Scoreboard

Current Score: 90
Score Source: user
Last Updated: 2026-04-14 18:14:34 +09:00
Score Rationale: The user explicitly rated the recent mobile foundation at 90 and then approved this cleanup pass as a follow-up improvement while keeping that score authoritative.
What Improved: The project already has a solid mobile foundation and recent shell stabilization. This pass now narrows the surface area by removing unused snapshot and drawing features while fixing a concrete notes archive layout defect.
What Remains Unsatisfactory: Legacy cleanup is still in progress. Until this pass lands, the shell still contains unused snapshot and drawing pathways, and the notes archive list still leaks spacing under collapsed folders.
What Should Happen Next To Raise Or Maintain The Score: Complete the approved removals cleanly, validate that the shell lost no required behavior, verify the notes archive list no longer peeks through, and keep publish artifacts synchronized.

## Score History

- 2026-04-14 10:05:00 +09:00 | score=90 | source=user | User explicitly rated the earlier mobile foundation pass at 90 and approved follow-up mobile refinement work.
- 2026-04-14 10:48:00 +09:00 | score=90 | source=user | The previous mobile refinement pass completed successfully and retained the user score of 90.
- 2026-04-14 17:09:35 +09:00 | score=90 | source=user | The user approved a mobile discoverability follow-up while preserving the authoritative user score of 90.
- 2026-04-14 17:19:10 +09:00 | score=90 | source=user | The explicit mobile return affordance pass completed successfully without changing the user score.
- 2026-04-14 18:14:34 +09:00 | score=90 | source=user | The user approved a cleanup pass to remove snapshot recording, remove the drawing mode, and fix the notes archive card clipping while keeping the authoritative score at 90.
- 2026-04-14 18:29:33 +09:00 | score=90 | source=user | The cleanup pass completed successfully, validation stayed clean, and the published bundle was updated without changing the user's authoritative score.

# Objective

Reduce shell complexity by removing two no-longer-needed interaction features and fix a notes archive presentation defect. Specifically:

- fully remove the current-screen snapshot recording workflow
- fully remove the backtick-triggered drawing / whiteboard overlay workflow
- fix the collapsed notes archive project container so the next stored item does not peek through underneath

# Why This Work Exists

The user no longer wants the snapshot recording workflow or the floating drawing mode. Keeping those features in place increases maintenance cost, adds UI density, leaves dead affordances in the header and shell, and keeps vendor/runtime code alive that no longer contributes product value. In parallel, the notes archive list currently leaks the next stored project beneath a collapsed header because the collapsed content container still retains bottom padding. This pass exists to simplify the shell, reduce hidden runtime surface, and remove a visible notes layout defect.

# In Scope

- `#global-snapshot-btn` and the current-screen snapshot modal/workflow
- Snapshot event handlers, state bindings, and related modal styling
- Backtick drawing mode entry points, drawing overlay shell markup, drawing runtime code, hotkeys, related state, and unused vendor/style hooks
- Notes archive folder collapse styling so closed groups do not reveal the next saved card underneath
- Bundle rebuild, local verification evidence, publish sync, and maintenance notes

# Out Of Scope

- Removing or altering light/dark mode
- Reworking the notes archive information architecture
- Redesigning the header dock beyond removing snapshot affordances
- Any change to required note archiving, backup, restore, or chat workflows that are still in use

# Confirmed Facts

- The user explicitly wants to keep light/dark mode.
- The user explicitly wants the snapshot recording feature removed, referring to the “현재 화면 스냅샷 기록” flow and its modal.
- The user explicitly wants the drawing / whiteboard feature triggered by the backtick key removed.
- The shell currently includes a snapshot button in the upper-right dock.
- The shell currently mounts drawing overlay elements and initializes drawing runtime plus hotkeys.
- The notes archive list currently leaves residual collapsed height because `.notes-in-project` keeps bottom padding even when `max-height` is zero.

# Safe Assumptions

- The safest cleanup is to remove snapshot and drawing features end-to-end from the active runtime surface rather than merely hiding their buttons.
- If no remaining runtime path uses Fabric, the safest simplification is to drop the Fabric vendor load from the bundler as part of the same cleanup.
- The notes archive clipping bug can be fixed without changing note/project data behavior by moving collapsed padding out of the base state and into the expanded state.

# User Experience Intent

The shell should feel simpler and less cluttered. Users should no longer see or accidentally trigger a snapshot-recording workflow they do not want, and pressing the backtick key should no longer open an in-page drawing system. The notes archive list should look visually clean: collapsed project cards should occupy only the header block, with no residual gap that exposes the next stored card underneath.

# Technical Approach

Use a small complete removal pass:

1. Remove snapshot dock markup, modal markup, state bindings, event listeners, handler logic, and dedicated snapshot modal CSS.
2. Remove drawing overlay shell markup, drawing runtime initialization, drawing-mode keyboard logic, drawing-specific state variables, drawing source files, drawing CSS, and the unused Fabric vendor dependency from bundling.
3. Fix `.notes-in-project` so collapsed containers have no retained bottom padding, while expanded containers receive the full intended interior spacing.
4. Rebuild JS/CSS bundles, validate the removed UI surfaces are gone, confirm no backtick drawing activation remains, and confirm the notes archive no longer peeks through.

# Phased Work Sequence

## Phase 1: Approved Plan Capture

Record this cleanup plan and freeze the scope so removal work stays separate from unrelated redesign changes.

## Phase 2: Snapshot Flow Removal

Remove the snapshot button, modal, state references, event wiring, handler function, and snapshot-specific modal styles.

## Phase 3: Drawing Flow Removal

Remove drawing shell nodes, runtime initialization, keyboard shortcuts, state references, source files, drawing CSS, and the Fabric vendor load if no remaining code depends on it.

## Phase 4: Notes Archive Layout Fix

Correct the collapsed `.notes-in-project` spacing so closed project groups do not retain visual height from bottom padding.

## Phase 5: Rebuild And Validate

Run the bundler, verify the shell still loads, confirm snapshot and drawing surfaces are absent, confirm notes archive cards render cleanly, and collect lightweight evidence.

## Phase 6: Publish And Document

Sync the publish repo bundle, push the GitHub Pages bundle update, and record the outcome in a completion report.

# Hidden Rules And Consistency Requirements

- Light/dark mode must remain intact.
- Snapshot removal must target the actual current-screen snapshot recording flow, not other archive or backup features.
- Drawing removal must include keyboard entry points; simply hiding the toolbar is insufficient.
- Notes archive styling must still allow expanded groups to breathe visually; the fix must only remove residual collapsed spacing.
- Cleanup should not silently break other shell header controls or note archive operations.
- Publish artifacts must match the rebuilt local bundle.

# Risks

## Risk: Partial removal leaves dead references behind

Mitigation: Remove snapshot and drawing paths across shell markup, state, event wiring, runtime code, style hooks, and bundler inputs instead of hiding UI alone.

## Risk: Fabric removal breaks another feature

Mitigation: Confirm remaining source references to `fabric` are limited to the drawing subsystem before removing vendor loading.

## Risk: Notes archive padding fix harms expanded card spacing

Mitigation: Move spacing from the collapsed base state into the `.expanded` state rather than reducing spacing globally.

## Risk: Bundle rebuild succeeds while publish repo remains stale

Mitigation: Explicitly sync `Ailey/bundle/main.js` and `Ailey/bundle/main.css` into the publish repo and record the pushed commit.

# Validation Strategy

Validation should prove the following observable behaviors:

- the snapshot button is gone from the shell
- the snapshot modal cannot be opened because the flow no longer exists
- pressing backtick does not activate any drawing overlay or toolbar
- no drawing overlay DOM is mounted in the shell
- the shell still loads and existing chat/notes controls remain usable
- the collapsed notes archive project no longer leaves a visible gap or reveals the next stored item beneath it
- bundle rebuild succeeds and publish artifacts are updated

# Definition Of Done

This pass is done when:

- snapshot recording UI and runtime flow are removed
- the drawing / whiteboard feature is removed, including key bindings and runtime hooks
- the notes archive list no longer shows the next stored card beneath collapsed projects
- light/dark mode still works
- bundle rebuild succeeds
- validation evidence is saved
- publish repo bundle files are updated and pushed
- this plan and the completion report document the change

# Rollback And Safety Notes

Rollback is straightforward because the pass is scoped to shell affordances, related runtime helpers, drawing-only assets, and one notes CSS correction. If removal causes an unexpected regression, the safest rollback is to restore the removed source files and revert the published bundle commit. No persistent user data migration is involved.

# Maintenance Notes

Future maintainers should treat snapshot recording and drawing mode as deliberately retired surfaces, not hidden features. If either capability is ever reintroduced, it should return as a fresh design with explicit product intent rather than by reviving these legacy paths. The notes archive spacing correction should remain small and structural: collapsed containers should stay padding-free, expanded containers should own their inner spacing explicitly.

# Progress Log

- 2026-04-14 18:14:34 +09:00 | Created the approved cleanup plan after tracing the snapshot workflow, drawing workflow, bundler/vendor hooks, and the notes archive spacing defect.
- 2026-04-14 18:22:00 +09:00 | Removed the snapshot button, snapshot modal markup, snapshot state bindings, snapshot event wiring, drawing shell nodes, drawing key bindings, drawing source files, Fabric vendor loading, and the notes archive collapsed padding leak.
- 2026-04-14 18:28:20 +09:00 | Validation passed using `visual-tests/snapshot-drawing-cleanup-2026-04-14T09-28-20-922Z/` with `snapshotButtonPresent=false`, `snapshotModalPresent=false`, `drawingCanvasPresent=false`, `drawingToolbarPresent=false`, `bodyHasDrawingClassAfterKey=false`, `collapsedProjectHeight=0`, `collapsedProjectPaddingBottom=0px`, `pageErrorCount=0`, and `traceErrorCount=0`.
- 2026-04-14 18:29:33 +09:00 | Synced `Ailey/bundle/main.js` and `Ailey/bundle/main.css` to the publish repo and pushed GitHub commit `76be8e1` on `lemos999/Singulari-Tea-Codex-Canvas`.
