# Vision Settings And Chat Control Surface Fix Plan

- Created: 2026-04-13 01:08:39 +09:00
- Last Updated: 2026-04-13 01:20:28 +09:00
- Plan Type: implementation
- Status: awaiting_user_validation
- Version: v01

## Objective

Fix two active UI regressions in the hosted/live Ailey surface:

1. The Vision Weaver settings modal opened from the image overlay `설정` button shows broken mojibake instead of readable Korean.
2. The chat header control deck allows the model selection surface and previous-context control to overflow panel bounds, reducing visual quality and readability.

## Understanding Report

The Vision Weaver settings modal is not a runtime theme issue. The shell markup source itself is corrupted and still contains obsolete refined-generation controls. The safest repair is to rewrite the modal markup into clean Korean and align it with the current quick-only image generation behavior already enforced elsewhere.

The chat header issue is a layout contract problem. The current deck assumes a wide panel, keeps items on one line, and lets a long settings label compete with the context toggle and popover anchor. The fix should preserve behavior while tightening the visual surface and making the deck responsive inside narrow panels.

## Approved Scope

- Rewrite the Vision Weaver settings modal markup in the shell source.
- Remove obsolete refined-generation strings and controls from the modal markup itself.
- Fix visible Korean labels in the touched Vision Weaver panel surface.
- Refactor the chat control deck and settings button surface to fit narrow widths cleanly.
- Prevent the previous-context toggle and model/prompt label from crossing panel bounds.
- Adjust chat popover sizing if needed to match the new deck behavior.
- Rebundle and update the hosted bundle repo.
- Record the fix in a report.

## Out Of Scope

- Full repo-wide mojibake cleanup outside the touched surfaces.
- New chat functionality or prompt-management feature changes.
- Reworking the entire notes/chat shell structure beyond the affected control deck.

## Constraints And Risks

- The workspace already routes image generation through quick mode. The modal markup must not reintroduce refined-mode as a user-visible option.
- The settings modal uses existing DOM ids consumed by runtime JS. Markup changes must preserve those ids unless code is updated in lockstep.
- The chat settings button is referenced by runtime globals and event wiring. Layout changes should avoid renaming ids.
- The fix must stay safe for dark/light modes and narrow panel widths.

## Implementation Plan

### Phase 0. Source Audit

- Confirm the corrupted shell file and exact ids used by Vision Weaver settings logic.
- Confirm the chat control deck markup and the CSS sources that currently force overflow.

### Phase 1. Vision Weaver Settings Modal Rewrite

- Rebuild the `vision-weaver-settings-modal` markup in clean Korean.
- Keep only currently supported controls:
  - active preset selector
  - preset URL groups
  - auto-generate mode with `off` and `quick`
  - image API selector
- Remove refined-only explanatory text and refine API selector from the shell markup.
- Clean up visible button labels and placeholder copy in the touched panel area.

### Phase 2. Chat Control Deck Responsive Repair

- Rework the control deck layout so it can wrap or compress gracefully in narrow widths.
- Prevent the settings button text from pushing the deck beyond bounds.
- Ensure the context toggle stays inside the control deck and does not visually spill out.
- Adjust the settings popover width and anchor behavior for narrow panels if necessary.

### Phase 3. Verification And Release

- Run `node --check` on touched JS files.
- Run `node Ailey/bundler.js`.
- Copy updated `bundle/main.js` and `bundle/main.css` into the hosted bundle repo.
- Commit and push `main`.
- Write a report file and update this plan with results.

## Success Criteria

- Clicking image overlay `설정` opens a readable Korean Vision Weaver settings modal.
- The modal no longer shows obsolete refined-generation controls or broken labels.
- In the chat panel, the settings/model surface stays within the panel bounds at narrow widths.
- The previous-context toggle also remains visually contained.
- Bundling succeeds and the hosted bundle is updated.

## Scoreboard

- Current Score: 50
- Score Source: provisional
- Last Updated: 2026-04-13 01:20:28 +09:00
- Rationale: The settings modal shell was rewritten in clean Korean, the chat control deck was made responsive, and the hosted bundle was updated. Browser runtime validation is still pending user confirmation.
- What Improved: The Vision Weaver settings surface now matches the current quick-only behavior and the chat header settings surface is constrained to panel width.
- What Remains Unsatisfactory: Final visual confirmation in the user's exported/live HTML is still pending.
- Next Score Target: User validates that the modal copy is readable and the chat control deck no longer spills outside panel bounds.

### Score History

- 2026-04-13 01:08:39 +09:00 | 35 | provisional | New fix request opened for Vision Weaver settings mojibake and chat control overflow.
- 2026-04-13 01:20:28 +09:00 | 50 | provisional | Source rewrite, responsive control-deck fix, rebundle, and hosted bundle deployment completed; awaiting user validation.

## Progress Log

- 2026-04-13 01:08:39 +09:00 | Plan created after source audit and user approval.
- 2026-04-13 01:14:00 +09:00 | Rewrote `004_shell_part5_panel_vision_debugger.js` in clean Korean and removed refined-only modal controls from markup.
- 2026-04-13 01:16:00 +09:00 | Rebuilt `003_shell_part4_panel_notes_chat.js` with clean visible Korean labels and updated chat header settings shell.
- 2026-04-13 01:17:30 +09:00 | Updated `024_chat_controls_modals.css` and `026_vision_weaver_settings.css` for responsive width handling.
- 2026-04-13 01:18:40 +09:00 | Passed `node --check` on touched JS files and `node Ailey/bundler.js`.
- 2026-04-13 01:20:28 +09:00 | Hosted bundle updated in `Singulari-Tea-Codex-Canvas` main at commit `ac52f64`.
