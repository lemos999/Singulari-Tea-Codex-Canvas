/* --- Ailey & Bailey Canvas --- */
// File: 114_core_api_settings_api_service.js
// Version: 1.0 (New Module)
// Description: Handles external API communications for verifying API keys and fetching available models.

async function handleVerifyApiKey() {
    const keyInput = document.getElementById('api-key-input');
    const statusEl = document.getElementById('api-key-status');
    const verifyBtn = document.getElementById('verify-api-key-btn');
    const modelSelect = document.getElementById('api-model-select');

    const key = keyInput.value.trim();
    if (!key) { statusEl.textContent = 'API 키를 입력해주세요.'; statusEl.className = 'status-error'; return; }

    const provider = detectProvider(key);
    if (!provider) { statusEl.textContent = '알 수 없는 형식의 API 키입니다.'; statusEl.className = 'status-error'; return; }
    
    statusEl.textContent = `[${provider}] 키 검증 및 모델 목록 로딩 중...`;
    statusEl.className = 'status-loading';
    statusEl.dataset.provider = '';
    verifyBtn.disabled = true;

    try {
        const models = await fetchAvailableModels(provider, key);
        populateModelSelector(models, provider, null, 'api-model-select');
        statusEl.textContent = `✅ [${provider}] 키 검증 완료! 모델을 선택하고 저장하세요.`;
        statusEl.className = 'status-success';
        statusEl.dataset.provider = provider;
        modelSelect.disabled = false;
        
        const groundingSection = document.querySelector('.grounding-toggle-section');
        if (groundingSection) {
            if (provider === 'google_paid') {
                groundingSection.style.display = 'block';
            } else {
                groundingSection.style.display = 'none';
            }
        }
    } catch (error) {
        console.error("API Key Verification Error:", error);
        statusEl.textContent = `❌ [${provider}] 키 검증 실패: ${error.message}`;
        statusEl.className = 'status-error';
        modelSelect.innerHTML = '<option>키 검증에 실패했습니다</option>';
        modelSelect.disabled = true;
        
        const groundingSection = document.querySelector('.grounding-toggle-section');
        if (groundingSection) {
            groundingSection.style.display = 'none';
        }
    } finally {
        verifyBtn.disabled = false;
    }
}

async function fetchAvailableModels(provider, key) {
    if (provider === 'openai') {
        const response = await fetch('https://api.openai.com/v1/models', { headers: { 'Authorization': `Bearer ${key}` } });
        if (!response.ok) throw new Error('OpenAI 서버에서 모델 목록을 가져올 수 없습니다.');
        const data = await response.json();
        return data.data.filter(m => m.id.includes('gpt')).map(m => m.id).sort().reverse();
    } else if (provider === 'openrouter') {
        const response = await fetch('https://openrouter.ai/api/v1/models', { headers: { 'Authorization': `Bearer ${key}` } });
        if (!response.ok) throw new Error('OpenRouter 서버에서 모델 목록을 가져올 수 없습니다.');
        const data = await response.json();
        return data.data.map(m => m.id).sort();
    } else if (provider === 'anthropic') {
        return ['claude-3-opus-20240229', 'claude-3-sonnet-20240229', 'claude-3-haiku-20240307', 'claude-2.1'];
    } else if (provider === 'google_paid') {
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${key}`);
        if (!response.ok) throw new Error('Google 서버에서 모델 목록을 가져올 수 없습니다.');
        const data = await response.json();
        return data.models.map(m => m.name.replace('models/', '')).filter(m => m.includes('gemini'));
    } else if (provider === 'cerebras') {
        const response = await fetch('https://api.cerebras.ai/v1/models', { headers: { 'Authorization': `Bearer ${key}` } });
        if (!response.ok) throw new Error('Cerebras 서버에서 모델 목록을 가져올 수 없습니다.');
        const data = await response.json();
        return data.data.map(m => m.id).sort();
    } else if (provider === 'groq') {
        const response = await fetch('https://api.groq.com/openai/v1/models', {
            headers: { 'Authorization': `Bearer ${key}` }
        });
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            const errorMessage = errorData?.error?.message || 'Groq 서버에서 모델 목록을 가져올 수 없습니다.';
            throw new Error(errorMessage);
        }
        const data = await response.json();
        return data.data.map(m => m.id).sort();
    }
    return [];
}