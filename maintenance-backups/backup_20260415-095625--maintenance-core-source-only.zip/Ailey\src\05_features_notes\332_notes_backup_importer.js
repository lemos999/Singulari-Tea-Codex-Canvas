/*
--- Ailey & Bailey Canvas ---
File: 332_notes_backup_importer.js
Version: 1.1 (Local Mirror Restore)
Description: Handles JSON import and restore flows, including restores from the local automatic backup mirror.
*/

function isLocalRestoreRuntime() {
    return (window.__AILEY_RUNTIME_MODE__ === 'local') || (typeof __firebase_config === 'undefined');
}

function getLocalMirrorBackupPayload() {
    const rawBackup = localStorage.getItem('ailey_local_auto_backup_v1');
    if (!rawBackup) return null;

    try {
        return JSON.parse(rawBackup);
    } catch (error) {
        console.error("Failed to parse local mirror backup payload:", error);
        return null;
    }
}

function unsubscribeAllDataListeners() {
    if (unsubscribeFromNotes) unsubscribeFromNotes();
    if (unsubscribeFromNoteProjects) unsubscribeFromNoteProjects();
    if (unsubscribeFromTags) unsubscribeFromTags();
    if (unsubscribeFromNoteTemplates) unsubscribeFromNoteTemplates();
    if (unsubscribeFromChatSessions) unsubscribeFromChatSessions();
    if (unsubscribeFromProjects) unsubscribeFromProjects();
    if (unsubscribeFromPromptTemplates) unsubscribeFromPromptTemplates();
}

function clearAllLocalCaches() {
    localNotesCache = [];
    localNoteProjectsCache = [];
    localTagsCache = [];
    noteTemplatesCache = [];
    localChatSessionsCache = [];
    localProjectsCache = [];
    promptTemplatesCache = [];
}

function toFirestoreTimestamp(timestampValue) {
    return timestampValue
        ? firebase.firestore.Timestamp.fromDate(new Date(timestampValue))
        : firebase.firestore.FieldValue.serverTimestamp();
}

window.handleRestoreClick = function() {
    const localMirrorBackup = isLocalRestoreRuntime() ? getLocalMirrorBackupPayload() : null;
    if (!localMirrorBackup) {
        if (fileImporter) fileImporter.click();
        return;
    }

    showChoiceModal("Choose restore source", "A local automatic backup snapshot is available. You can restore from that snapshot or choose a JSON backup file.", [
        {
            id: 'choice-restore-local-mirror',
            text: '<span>Restore local snapshot</span>',
            description: 'Uses the latest automatic backup mirror stored in this browser.',
            class: 'confirm',
            action: () => _presentRestoreModeChoice(localMirrorBackup, 'local-mirror')
        },
        {
            id: 'choice-restore-file',
            text: '<span>Choose backup file</span>',
            description: 'Select a JSON backup file exported from Canvas or Local mode.',
            class: 'secondary',
            action: () => {
                if (fileImporter) fileImporter.click();
            }
        },
        {
            id: 'choice-restore-cancel',
            text: 'Cancel',
            class: 'cancel',
            action: () => {}
        }
    ]);
};

async function _executeOverwriteRestore(data, toastId) {
    unsubscribeAllDataListeners();
    clearAllLocalCaches();
    trace("Backup", "import.overwrite.listenersUnsubscribed");
    trace("Backup", "import.overwrite.cachesCleared");

    showProgressToast('Clearing current data...', toastId);
    trace("Backup", "import.overwrite.start");

    try {
        if (chatSessionsCollectionRef) {
            const sessionsSnap = await chatSessionsCollectionRef.get();
            if (!sessionsSnap.empty) {
                const deleteMessagesBatch = db.batch();
                const readPromises = sessionsSnap.docs.map(sessionDoc =>
                    sessionDoc.ref.collection('messages').get().then(messagesSnap => {
                        messagesSnap.docs.forEach(messageDoc => deleteMessagesBatch.delete(messageDoc.ref));
                    })
                );
                await Promise.all(readPromises);
                await deleteMessagesBatch.commit();
            }
        }

        const collectionsToClear = [notesCollectionRef, noteProjectsCollectionRef, chatSessionsCollectionRef, projectsCollectionRef];
        const deleteDocsBatch = db.batch();
        const snapshots = await Promise.all(collectionsToClear.map(ref => ref ? ref.get() : Promise.resolve({ docs: [] })));
        snapshots.forEach(snapshot => {
            snapshot.docs.forEach(doc => deleteDocsBatch.delete(doc.ref));
        });
        await deleteDocsBatch.commit();
        trace("Backup", "import.overwrite.clearedOldData");

        if (data.userApiSettings) {
            updateProgressToast('Restoring settings...', toastId);
            userApiSettings = data.userApiSettings;
            await saveUserSettingsToFirebase(true);
            trace("Backup", "import.overwrite.settingsRestored");
        }

        updateProgressToast('Writing backup payload...', toastId);
        const importBatch = db.batch();

        (data.notes || []).forEach(note => {
            const { id, ...dataToWrite } = note;
            dataToWrite.createdAt = toFirestoreTimestamp(note.createdAt);
            dataToWrite.updatedAt = toFirestoreTimestamp(note.updatedAt);
            importBatch.set(notesCollectionRef.doc(id), dataToWrite);
        });
        (data.noteProjects || []).forEach(project => {
            const { id, ...dataToWrite } = project;
            dataToWrite.createdAt = toFirestoreTimestamp(project.createdAt);
            dataToWrite.updatedAt = toFirestoreTimestamp(project.updatedAt);
            importBatch.set(noteProjectsCollectionRef.doc(id), dataToWrite);
        });
        (data.projects || []).forEach(project => {
            const { id, ...dataToWrite } = project;
            dataToWrite.createdAt = toFirestoreTimestamp(project.createdAt);
            dataToWrite.updatedAt = toFirestoreTimestamp(project.updatedAt);
            importBatch.set(projectsCollectionRef.doc(id), dataToWrite);
        });
        await importBatch.commit();

        for (const session of (data.chatSessions || [])) {
            const { id, messages, ...sessionData } = session;
            sessionData.createdAt = toFirestoreTimestamp(session.createdAt);
            sessionData.updatedAt = toFirestoreTimestamp(session.updatedAt);
            await chatSessionsCollectionRef.doc(id).set(sessionData);

            if (messages && messages.length > 0) {
                const messagesBatch = db.batch();
                messages.forEach(message => {
                    const messageRef = chatSessionsCollectionRef.doc(id).collection('messages').doc();
                    const { id: _messageId, ...messageData } = message;
                    messageData.timestamp = toFirestoreTimestamp(message.timestamp);
                    messagesBatch.set(messageRef, messageData);
                });
                await messagesBatch.commit();
            }
        }

        trace("Backup", "import.overwrite.success");
        hideProgressToast(toastId);
        showModal("Overwrite restore completed. The page will reload to re-attach listeners cleanly.", () => location.reload());
    } catch (error) {
        console.error("Overwrite restore failed:", error);
        trace("Backup", "import.overwrite.error", { error: error.message }, {}, "ERROR");
        hideProgressToast(toastId);
        showModal(`Restore failed: ${error.message}`, () => {});
    }
}

async function _executeMergeRestore(data, toastId) {
    showProgressToast('Preparing merge restore...', toastId);
    trace("Backup", "import.merge.start");

    try {
        if (data.userApiSettings) {
            updateProgressToast('Merging settings...', toastId);
            userApiSettings = data.userApiSettings;
            await saveUserSettingsToFirebase(true);
            trace("Backup", "import.merge.settingsRestored");
        }

        const [notesSnap, noteProjectsSnap, projectsSnap, sessionsSnap] = await Promise.all([
            notesCollectionRef.get(),
            noteProjectsCollectionRef.get(),
            projectsCollectionRef.get(),
            chatSessionsCollectionRef.get()
        ]);

        const existingNoteIds = new Set(notesSnap.docs.map(doc => doc.id));
        const existingNoteProjectIds = new Set(noteProjectsSnap.docs.map(doc => doc.id));
        const existingProjectIds = new Set(projectsSnap.docs.map(doc => doc.id));
        const existingSessionIds = new Set(sessionsSnap.docs.map(doc => doc.id));

        const newNotes = (data.notes || []).filter(note => !existingNoteIds.has(note.id));
        const newNoteProjects = (data.noteProjects || []).filter(project => !existingNoteProjectIds.has(project.id));
        const newProjects = (data.projects || []).filter(project => !existingProjectIds.has(project.id));
        const newSessions = (data.chatSessions || []).filter(session => !existingSessionIds.has(session.id));

        const totalNewItems = newNotes.length + newNoteProjects.length + newProjects.length + newSessions.length;
        if (totalNewItems === 0 && !data.userApiSettings) {
            hideProgressToast(toastId);
            showModal("No new items were found to merge from this backup.", () => {});
            return;
        }

        updateProgressToast(`Merging ${totalNewItems} new items...`, toastId);

        const importBatch = db.batch();
        newNotes.forEach(note => {
            const { id, ...dataToWrite } = note;
            dataToWrite.createdAt = toFirestoreTimestamp(note.createdAt);
            dataToWrite.updatedAt = toFirestoreTimestamp(note.updatedAt);
            importBatch.set(notesCollectionRef.doc(id), dataToWrite);
        });
        newNoteProjects.forEach(project => {
            const { id, ...dataToWrite } = project;
            dataToWrite.createdAt = toFirestoreTimestamp(project.createdAt);
            dataToWrite.updatedAt = toFirestoreTimestamp(project.updatedAt);
            importBatch.set(noteProjectsCollectionRef.doc(id), dataToWrite);
        });
        newProjects.forEach(project => {
            const { id, ...dataToWrite } = project;
            dataToWrite.createdAt = toFirestoreTimestamp(project.createdAt);
            dataToWrite.updatedAt = toFirestoreTimestamp(project.updatedAt);
            importBatch.set(projectsCollectionRef.doc(id), dataToWrite);
        });
        await importBatch.commit();

        for (const session of newSessions) {
            const { id, messages, ...sessionData } = session;
            sessionData.createdAt = toFirestoreTimestamp(session.createdAt);
            sessionData.updatedAt = toFirestoreTimestamp(session.updatedAt);
            await chatSessionsCollectionRef.doc(id).set(sessionData);

            if (messages && messages.length > 0) {
                const messagesBatch = db.batch();
                messages.forEach(message => {
                    const messageRef = chatSessionsCollectionRef.doc(id).collection('messages').doc();
                    const { id: _messageId, ...messageData } = message;
                    messageData.timestamp = toFirestoreTimestamp(message.timestamp);
                    messagesBatch.set(messageRef, messageData);
                });
                await messagesBatch.commit();
            }
        }

        trace("Backup", "import.merge.success", {
            newNotes: newNotes.length,
            newProjects: newProjects.length,
            newSessions: newSessions.length
        });
        hideProgressToast(toastId);
        showModal(`Merge restore completed. Added ${totalNewItems} new items and reloading now.`, () => location.reload());
    } catch (error) {
        console.error("Merge restore failed:", error);
        trace("Backup", "import.merge.error", { error: error.message }, {}, "ERROR");
        hideProgressToast(toastId);
        showModal(`Merge restore failed: ${error.message}`, () => {});
    }
}

function _presentRestoreModeChoice(data, sourceLabel) {
    const noteCount = data.notes?.length || 0;
    const chatCount = data.chatSessions?.length || 0;
    const apiPresetCount = data.userApiSettings?.apiPresets?.length || 0;
    let message = `Backup source: ${sourceLabel}. Found ${noteCount} notes and ${chatCount} chat sessions.`;
    if (apiPresetCount > 0) {
        message += ` Includes ${apiPresetCount} API presets in the exported settings payload.`;
    }
    message += " Choose how to restore it.";

    showChoiceModal("Choose restore mode", message, [
        {
            id: 'choice-overwrite-restore',
            text: '<span>Overwrite restore</span>',
            description: 'Delete current data first, then restore the backup payload.',
            class: 'confirm',
            action: () => _executeOverwriteRestore(data, `import-progress-${Date.now()}`)
        },
        {
            id: 'choice-merge-restore',
            text: '<span>Merge restore</span>',
            description: 'Keep current data and only add items that do not already exist.',
            class: 'secondary',
            action: () => _executeMergeRestore(data, `import-progress-${Date.now()}`)
        },
        {
            id: 'choice-restore-cancel',
            text: 'Cancel',
            class: 'cancel',
            action: () => {}
        }
    ]);
}

window.importAllData = async function(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(loadEvent) {
        try {
            const data = JSON.parse(loadEvent.target.result);
            const supportedVersions = ['2.0', '3.0', '4.0', '5.0', '5.1'];
            if (!data.backupVersion || !supportedVersions.includes(data.backupVersion)) {
                throw new Error(`Unsupported backup version. Expected one of: ${supportedVersions.join(', ')}`);
            }

            _presentRestoreModeChoice(data, `file:${file.name}`);
        } catch (error) {
            console.error("File parsing error:", error);
            showModal(`File parsing failed: ${error.message}`, () => {});
        } finally {
            event.target.value = null;
        }
    };
    reader.readAsText(file);
};
