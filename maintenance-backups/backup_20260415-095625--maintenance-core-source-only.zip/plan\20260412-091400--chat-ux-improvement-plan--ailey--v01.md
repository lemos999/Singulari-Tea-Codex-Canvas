# Ailey Chat UX Improvement Execution Plan

- Artifact Type: feature-plan
- Created: 2026-04-12 09:14:00 +09:00
- Status: ✅ completed
- Scope: prompt template persistence fix plus chat infinite scroll wiring
- Execution Update: User approved Phase 0-2 execution on 2026-04-12. Phase 0 and Phase 1 code changes were implemented, rebundled, and deployed through GitHub PR #4, followed by a narrow PR #5 follow-up fix for a chat pagination session-switch race on 2026-04-12.

## Scoreboard

- Current Score: 50
- Score Source: provisional
- Last Updated: 2026-04-12 09:33:39 +09:00
- Rationale: Phase 0-2 execution completed successfully, including a bounded follow-up fix found during final review. Prompt fallback behavior was narrowed, chat history pagination was wired, session-switch races were guarded, the bundle was rebuilt, and the hosted deploy repo was updated.
- What Improved: The saved quick prompt is no longer silently overwritten during transient template-listener states, older chat messages now paginate from the top of the chat panel, session switches no longer risk prepending old history into the wrong chat, and the hosted runtime bundle includes the corrected implementation.
- What Remains Unsatisfactory: Browser-level manual validation in Canvas/local runtime and downstream review phases are still pending.
- Next Score Target: Complete Phase 3 manual runtime verification and Phase 4 final review.

### Score History

- 2026-04-12 09:22:00 +09:00 | 45 | provisional | User approved Phase 0-2 execution and implementation started.
- 2026-04-12 09:31:30 +09:00 | 50 | provisional | Phase 0-2 completed with rebundle and GitHub PR #4 merge.
- 2026-04-12 09:33:39 +09:00 | 50 | provisional | Final Phase 2 deploy updated through GitHub PR #5 after fixing a session-switch race in chat pagination.

---

## Goal

Improve two chat UX regressions without widening scope:

1. Keep the user-selected quick prompt template from being silently reset back to a default template such as `Narrative Data Refiner`.
2. Make older chat messages load incrementally when the user scrolls to the top of the chat history.

Phase 2 also includes rebuilding the bundle and shipping the runtime change to the GitHub-hosted deploy repository.

## Problem A: quick prompt selection falls back unexpectedly

### Root cause

`renderQuickPromptSelect()` in `src/04_features_chat/227_chat_ui_modals.js` currently treats any non-matching `activePromptId` as invalid and immediately rewrites it to the default template.

That is too aggressive because the prompt-template listener can render during intermediate states:

1. user settings load `activePromptId`
2. seeding and listeners update template data
3. `renderQuickPromptSelect()` runs while the desired template is not yet present in the current cache snapshot
4. the saved selection is silently replaced with the default template and persisted

### Design decision

- Keep the current selection if `activePromptId` already exists, even when the current cache snapshot does not yet contain that ID.
- Only fall back to a default template when `activePromptId` is truly empty.
- Verify that `src/03_core/102_core_seeding.js` updates default templates in place and does not recreate IDs during the normal sync path.

### Expected result

- Existing selected prompt template remains stable across reloads and listener refreshes.
- First-time users with no selection still get a default template automatically.

## Problem B: infinite scroll support exists but is not wired end to end

### Current state

The codebase already has most of the pagination pieces:

- `MESSAGES_PER_PAGE` in `src/04_features_chat/200_chat_data.js`
- `fetchPastMessages(sessionId, beforeTimestamp, limit)`
- `currentSessionState` pagination flags
- `prependMessages(...)`
- a debounced `handleChatScroll(...)` in `src/04_features_chat/222_chat_ui_messages_utils.js`

What is missing is reliable listener lifecycle management and session wiring.

### Design decision

- Reuse the existing `handleChatScroll(...)` instead of creating a parallel implementation.
- Add explicit `setupChatScrollListener()` and `teardownChatScrollListener()` helpers.
- Bind the scroll listener when a real session is selected.
- Remove the listener whenever session state resets.
- Guard the handler against temporary sessions and stop pagination when fewer than one page of older messages is returned.

### Expected result

- Initial session open still renders only the most recent page.
- Scrolling to the top loads older messages and preserves the user’s scroll position.
- Pagination stops cleanly when there are no more older messages.

## Phases

| Phase | Owner | Deliverable |
|---|---|---|
| 0 | Codex | Fix prompt template fallback in `227_chat_ui_modals.js` and verify seeding assumptions in `102_core_seeding.js` |
| 1 | Codex | Wire chat infinite scroll using `222_chat_ui_messages_utils.js` and `234_chat_session_manager.js` |
| 2 | Codex | Rebundle, sync deploy repo, create PR, merge, and clean up the temporary branch |
| 3 | Gemini | Manual Canvas and local runtime testing |
| 4 | Claude | Final review |

## Files In Scope

| File | Change |
|---|---|
| `src/04_features_chat/227_chat_ui_modals.js` | Restrict fallback so existing prompt selection is not overwritten during transient listener states |
| `src/03_core/102_core_seeding.js` | Read-only verification that default-template sync preserves IDs through `batch.update(...)` |
| `src/04_features_chat/222_chat_ui_messages_utils.js` | Add listener lifecycle helpers and tighten infinite-scroll guards |
| `src/04_features_chat/234_chat_session_manager.js` | Attach and detach chat scroll listener with session lifecycle |

## Verification

- Confirm that a saved prompt selection remains unchanged after reload and listener refresh.
- Confirm that `activePromptId === null` still falls back to a default prompt for first-time use.
- Open a chat session with enough history and verify that only the latest page renders initially.
- Scroll to the top and verify that older messages prepend without scroll jump.
- Verify that loading stops after the oldest page is reached.
- Run rebundle after code changes.
- Deploy the changed bundle to the GitHub-hosted runtime in Phase 2.

## Open Questions

> [!IMPORTANT]
> 1. `createMessageElement` is not a shared factory today, so pagination should continue using the existing user/AI element builders rather than inventing a new renderer.
> 2. `MESSAGES_PER_PAGE` is already `25` in the current codebase, so the implementation should respect that existing limit instead of the earlier draft number.
