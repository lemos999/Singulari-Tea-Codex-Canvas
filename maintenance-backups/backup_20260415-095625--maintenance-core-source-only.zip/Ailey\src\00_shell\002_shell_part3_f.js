/* --- Ailey & Bailey Canvas --- */
// File: 002_shell_part3_f.js
// Version: 1.0 (Modularization)
// Description: Contains the HTML for the Image Generation Studio modal (Part 3: Medium, Palette Tabs, and closing tags).

const SHELL_PART_3_F = `
                        <!-- Art Medium Tab -->
                        <div id="img-gen-tab-medium" class="img-gen-tab-panel">
                            <div class="accordion-container">
                                <div class="accordion-header">기본 재료</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="on canvas" data-tooltip="캔버스 위에 그려진 느낌">캔버스</button>
                                    <button class="option-btn" data-prompt="on paper" data-tooltip="종이 위에 그려진 느낌">종이</button>
                                    <button class="option-btn" data-prompt="on wood panel" data-tooltip="나무판 위에 그려진 느낌">나무판</button>
                                    <button class="option-btn" data-prompt="on parchment" data-tooltip="양피지 위에 그려진 느낌">양피지</button>
                                </div>
                            </div>
                            <div class="accordion-container">
                                <div class="accordion-header">입체와 공예 느낌</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="marble sculpture" data-tooltip="대리석으로 조각한 스타일">대리석 조각</button>
                                    <button class="option-btn" data-prompt="bronze sculpture" data-tooltip="청동으로 주조한 스타일">청동 조각</button>
                                    <button class="option-btn" data-prompt="wood carving" data-tooltip="나무를 깎아 만든 스타일">목조각</button>
                                    <button class="option-btn" data-prompt="clay sculpture" data-tooltip="점토로 빚은 스타일">점토</button>
                                    <button class="option-btn" data-prompt="stained glass" data-tooltip="색유리로 만든 스테인드글라스">스테인드글라스</button>
                                    <button class="option-btn" data-prompt="mosaic" data-tooltip="작은 조각들을 붙여 만든 모자이크">모자이크</button>
                                </div>
                            </div>
                            <div class="accordion-container">
                                <div class="accordion-header">추천 표현 방식</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="comic book panel, webtoon style, with panel borders, speech bubbles, sound effects" data-tooltip="생성된 장면에 만화적인 연출(말풍선, 효과음, 패널 테두리 등)을 추가하는 옵션입니다.">만화/웹툰 패널</button>
                                </div>
                            </div>
                        </div>
                        <!-- Color Palette Tab -->
                        <div id="img-gen-tab-palette" class="img-gen-tab-panel">
                            <div class="accordion-container">
                                <div class="accordion-header">톤과 채도</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="monochromatic" data-tooltip="단일 색상의 톤 변화로만 표현">모노크롬</button>
                                    <button class="option-btn" data-prompt="sepia" data-tooltip="세피아 톤의 고전적인 느낌">세피아</button>
                                    <button class="option-btn" data-prompt="vibrant colors" data-tooltip="생생하고 채도 높은 색상">선명한 색상</button>
                                    <button class="option-btn" data-prompt="pastel colors" data-tooltip="부드럽고 연한 파스텔 톤 색상">파스텔</button>
                                    <button class="option-btn" data-prompt="neon colors" data-tooltip="쨍하고 화려한 네온 색상">네온</button>
                                    <button class="option-btn" data-prompt="earth tones" data-tooltip="차분한 흙빛 계열 색상">흙빛 톤</button>
                                </div>
                            </div>
                            <div class="accordion-container">
                                <div class="accordion-header">색 조합</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="complementary colors" data-tooltip="보색 대비를 활용한 강렬한 느낌">보색 대비</button>
                                    <button class="option-btn" data-prompt="analogous colors" data-tooltip="유사색을 활용한 조화로운 느낌">유사색 조화</button>
                                    <button class="option-btn" data-prompt="triadic colors" data-tooltip="세 가지 색상을 균형있게 사용">3색 조화</button>
                                    <button class="option-btn" data-prompt="rainbow palette" data-tooltip="다채로운 무지개 색상 팔레트">무지개</button>
                                </div>
                            </div>
                            <div class="accordion-container">
                                <div class="accordion-header">추천 팔레트</div>
                                <div class="accordion-content option-btn-grid-5-col">
                                    <button class="option-btn" data-prompt="luminous gold and deep indigo color palette" data-tooltip="에픽 픽셀 아트의 시그니처 색상 조합입니다.">발광 골드 & 딥 인디고</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-modal-actions">
                <button id="img-gen-options-cancel-btn" class="modal-btn cancel">취소</button>
                <button id="img-gen-options-quick-btn" class="modal-btn secondary with-icon">
                    <svg viewBox="0 0 24 24" width="16" height="16"><path d="M7,2V13H10V22L17,10H13L17,2H7Z"></path></svg>
                    <span>빠르게 생성</span>
                </button>
                <button id="img-gen-options-refined-btn" class="modal-btn confirm with-icon">
                    <svg viewBox="0 0 24 24" width="16" height="16"><path d="M16.5,2C15.9,2.4 15,3.5 15,3.5L12.5,1L10,3.5C10,3.5 9.1,2.4 8.5,2C7.9,1.6 7.1,1.5 6.5,1.7C5.9,1.9 5.3,2.3 5,2.9C4.4,3.9 4.8,5.1 5.3,5.8C5.6,6.2 6.1,6.8 6.1,6.8L3,9.9L9.1,16L12.2,12.9L15.3,16L21.4,9.9L18.3,6.8C18.3,6.8 18.8,6.2 19.1,5.8C19.6,5.1 20,3.9 19.4,2.9C19.1,2.3 18.5,1.9 17.9,1.7C17.3,1.5 16.5,1.6 15.9,2H16.5M15.3,9.7L11.8,13.2L10.4,11.8L13.9,8.3L15.3,9.7M17,17.2L19.8,20L17,22.8L14.2,20L17,17.2Z"></path></svg>
                    <span>정교하게 생성</span>
                </button>
            </div>
        </div>
    </div>
`;
