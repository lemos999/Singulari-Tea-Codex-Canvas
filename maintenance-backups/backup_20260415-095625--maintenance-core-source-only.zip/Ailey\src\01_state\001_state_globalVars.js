// --- Ailey & Bailey Canvas ---
// File: 001_state_globalVars.js
// Version: 9.1 (Translation Job)
// Description: Added a state variable for managing document translation jobs.

let learningContent, wrapper, body, systemInfoWidget, selectionPopover, popoverAskAi, popoverAddNote, tocToggleBtn;
let quizModalOverlay, quizContainer, quizSubmitBtn, quizResults, startQuizBtn;
let chatPanel, chatControlDeck, chatForm, chatInput, chatMessages, chatSendBtn, sidebarToggleBtn;
let notesAppPanel, noteListView, noteEditorView, notesList, searchInput, addNewNoteBtn, backToListBtn;
let noteTitleInput, noteContentTextarea, autoSaveStatus, formatToolbar, linkTopicBtn;
let customModal, modalTitle, modalBadge, modalMessage, modalConfirmBtn, modalCancelBtn;
let copyModalOverlay, copyModalTextarea;
let promptModalOverlay, customPromptInput, promptSaveBtn, promptCancelBtn;
let themeToggle, chatToggleBtn, notesAppToggleBtn;
let visionWeaverToggleBtn, visionWeaverPanel, generateInPanelBtn, imagePanelStatus, imageDisplayArea, exportMainContentBtn;
// [MODIFIED] Added variables for the new tabbed UI in the vision settings modal
let referenceImagePreview, uploadReferenceImageBtn, removeReferenceImageBtn, referenceImageInput;
let visionTabFileBtn, visionTabUrlBtn, visionTabFileContent, visionTabUrlContent, referenceUrlInput, fetchUrlImageBtn;
let newChatBtn, newProjectBtn, sessionListContainer, chatSessionTitle, deleteSessionBtn, chatWelcomeMessage, searchSessionsInput, tempSessionToggle;
let fileImporter, chatFileInput, chatAttachBtn, attachedFileDisplay, chatComposerShell, chatAttachmentHint;
// [MODIFIED] Deprecated single API settings variables, will be handled by preset modal logic
let apiSettingsModalOverlay, apiKeyInput, verifyApiKeyBtn, apiKeyStatus, apiModelSelect, maxOutputTokensInput, tokenUsageDisplay, resetTokenUsageBtn, apiSettingsSaveBtn, apiSettingsCancelBtn, apiSettingsResetBtn;

let settingsControlContainer, settingsButton, settingsDisplayText, settingsPopover, apiPresetSelector, aiModelSelector, quickPromptSelect, managePromptsBtn, manageApiSettingsBtn;
let quickQueryInput, quickQuerySendBtn, quickQueryTempToggle;
let isImageGenerating = false; // [RESTORED] Lock to prevent parallel image generation.
let noteRecallView, recallBackToListBtn, recallNoteTitle, recallTurnListContainer, recallContentContainer, recallSearchInput, recallSidebarToggleBtn;
let visualizationOptionsModalOverlay, vizLibraryOptions, vizOptionsTextarea, vizOptionsCancelBtn, vizOptionsGenerateBtn;
let imageGenerationOptionsModalOverlay, imgGenOptionsTextarea, imgGenOptionsCancelBtn, imgGenOptionsQuickBtn, imgGenPresetSettingsBtn;
// [NEW] Variables for image upload in studio
let studioUploadedImage = null;
let imgGenStudioUploadBtn, imgGenStudioRemoveBtn, imgGenStudioFileInput, imgGenStudioPreviewWrapper, imgGenStudioPreview;
// [NEW] Context toggle button and state
let contextToggleBtn, groundingQuickToggleBtn;
let isContextlessMode = false;
// [NEW] Interactive Recall Mode variables
let isInteractiveRecallMode = false;
let interactiveModeTurnCounter = 0;
let lastInteractiveMarkdown = '';
// [NEW] State for translation jobs
let activeTranslationJob = null;
// [NEW] State for AI code fixing jobs
let activeCodeFixJob = null;


let canvasId = 'global_fallback_id';
let db;
let currentUser = null;
const appId = 'AileyBailey_Global_Space';
let debounceTimer = null;
let lastSelectedText = '';
let notesCollectionRef, noteProjectsCollectionRef, tagsCollectionRef, noteTemplatesCollectionRef, userSettingsRef;
let localNotesCache = [], localNoteProjectsCache = [], localTagsCache = [], noteTemplatesCache = [];
let unsubscribeFromNotes = null, unsubscribeFromNoteProjects = null, unsubscribeFromTags = null, unsubscribeFromNoteTemplates = null;
let currentNoteId = null;
let newlyCreatedNoteProjectId = null;
let currentNoteSort = 'updatedAt_desc';
let draggedNoteId = null;
let chatSessionsCollectionRef, projectsCollectionRef, canvasImageHistoryCollectionRef;
let localChatSessionsCache = [], localProjectsCache = [];
let currentSessionId = null;
function createEmptyTemporarySession() {
    return {
        messages: [],
        contextSent: false,
        compactionState: null
    };
}

let temporarySession = createEmptyTemporarySession();
let attachedFile = null;
let stagedChatAttachments = [];
let stagedHiddenContext = null;
let unsubscribeFromChatSessions = null, unsubscribeFromProjects = null, unsubscribeFromMessages = null;
let newlyCreatedProjectId = null;
const activeTimers = {};
let pendingResponses = new Set();
let activeStreams = {};
let completedButUnseenResponses = new Set();
let promptTemplatesCollectionRef;
let promptTemplatesCache = [];
let unsubscribeFromPromptTemplates = null;
let selectedTemplateId = null;
let activePromptId = null;
let defaultModel = 'gemini-2.5-flash-preview-09-2025';
let customPrompt = localStorage.getItem('customTutorPrompt') || '너는 나의 AI 러닝메이트야. 사용자의 모든 질문에 친구처럼 답변해줘.';
let currentQuizData = null;
let noteGraphData = { nodes: [], edges: [] };
// [MODIFIED] userApiSettings now holds the preset structure.
let userApiSettings = {
    apiPresets: [],
    activePresetId: null,
    panelStates: {}
};
let isQuickQueryTempMode = false;
let currentDataPayload = null; 
let debouncedSaveUserSettings;
let isCoreShellInitialized = false;
let areCoreShellBindingsInitialized = false;
let currentCanvasLayoutMode = 'standard';
// Staging variables for reference image
let stagedReferenceImage = null; // For temporary file upload (Base64)
let stagedReferenceImageUrl = null; // For permanent URL reference
// --- Panel Focus State ---
let highestZIndex = 2000;
// --- Session-specific State ---
let currentSessionState = {
    isLoadingMore: false,
    hasMoreMessages: true,
    oldestMessageTimestamp: null,
    lastMessageTimestamp: null,
    autoFollow: true,
    isUserNearBottom: true
};
let activeRecallTurns = []; // For recall viewer search functionality

// --- Note Infinite Scroll State ---
let isNoteLoadingMore = false;
let lastVisibleNoteTimestamp = null;
let hasMoreNotes = true;

function rebindDOMElements() {
    learningContent = document.getElementById('learning-content')
        || document.querySelector('.canvas-content-host')
        || document.getElementById('ai-content-placeholder');
    wrapper = document.querySelector('.wrapper');
    body = document.body;
    systemInfoWidget = document.getElementById('system-info-widget');
    selectionPopover = document.getElementById('selection-popover');
    popoverAskAi = document.getElementById('popover-ask-ai');
    popoverAddNote = document.getElementById('popover-add-note');
    quizModalOverlay = document.getElementById('quiz-modal-overlay');
    quizContainer = document.getElementById('quiz-container');
    quizSubmitBtn = document.getElementById('quiz-submit-btn');
    quizResults = document.getElementById('quiz-results');
    chatPanel = document.getElementById('chat-panel');
    chatControlDeck = document.getElementById('chat-control-deck');
    chatForm = document.getElementById('chat-form');
    chatInput = document.getElementById('chat-input');
    chatMessages = document.getElementById('chat-messages');
    chatSendBtn = document.getElementById('chat-send-btn');
    sidebarToggleBtn = document.getElementById('sidebar-toggle-btn');
    notesAppPanel = document.getElementById('notes-app-panel');
    noteListView = document.getElementById('note-list-view');
    noteEditorView = document.getElementById('note-editor-view');
    backToListBtn = document.getElementById('back-to-list-btn');
    noteTitleInput = document.getElementById('note-title-input');
    autoSaveStatus = document.getElementById('auto-save-status');
customModal = document.getElementById('custom-modal');
modalTitle = customModal ? customModal.querySelector('#modal-title') : null;
modalBadge = customModal ? customModal.querySelector('#modal-badge') : null;
    modalMessage = document.getElementById('modal-message');
    modalConfirmBtn = document.getElementById('modal-confirm-btn');
    modalCancelBtn = document.getElementById('modal-cancel-btn');
    copyModalOverlay = document.getElementById('copy-modal-overlay');
    copyModalTextarea = document.getElementById('copy-modal-textarea');
    promptModalOverlay = document.getElementById('prompt-modal-overlay');
    customPromptInput = document.getElementById('custom-prompt-input');
    promptSaveBtn = document.getElementById('prompt-save-btn');
    promptCancelBtn = document.getElementById('prompt-cancel-btn');
    themeToggle = document.getElementById('theme-toggle');
    chatToggleBtn = document.getElementById('chat-toggle-btn');
    notesAppToggleBtn = document.getElementById('notes-app-toggle-btn');

    visionWeaverToggleBtn = document.getElementById('vision-weaver-toggle-btn');
    visionWeaverPanel = document.getElementById('vision-weaver-panel');
    generateInPanelBtn = document.getElementById('generate-in-panel-btn');
    imagePanelStatus = document.getElementById('image-panel-status');
    imageDisplayArea = document.getElementById('image-display-area');
    exportMainContentBtn = document.getElementById('export-main-content-btn');

    // [MODIFIED] Added variables for the new tabbed UI in the vision settings modal
    referenceImagePreview = document.getElementById('reference-image-preview');
    uploadReferenceImageBtn = document.getElementById('upload-reference-image-btn');
    removeReferenceImageBtn = document.getElementById('remove-reference-image-btn');
    referenceImageInput = document.getElementById('reference-image-input');
    visionTabFileBtn = document.getElementById('vision-tab-btn-file');
    visionTabUrlBtn = document.getElementById('vision-tab-btn-url');
    visionTabFileContent = document.getElementById('vision-tab-file');
    visionTabUrlContent = document.getElementById('vision-tab-url');
    referenceUrlInput = document.getElementById('reference-url-input');
    fetchUrlImageBtn = document.getElementById('fetch-url-image-btn');


    newChatBtn = document.getElementById('new-chat-btn');
    newProjectBtn = document.getElementById('new-project-btn');
    sessionListContainer = document.getElementById('session-list-container');
    chatSessionTitle = document.getElementById('chat-session-title');
    deleteSessionBtn = document.getElementById('delete-session-btn');
    chatWelcomeMessage = document.getElementById('chat-welcome-message');
    searchSessionsInput = document.getElementById('search-sessions-input');
    tempSessionToggle = document.getElementById('temp-session-toggle');
    fileImporter = document.getElementById('file-importer');
    chatFileInput = document.getElementById('chat-file-input');
    chatAttachBtn = document.getElementById('chat-attach-btn');
    attachedFileDisplay = document.getElementById('attached-file-display');
    chatComposerShell = document.getElementById('chat-composer-shell');
    chatAttachmentHint = document.getElementById('chat-attachment-hint');
    settingsControlContainer = document.getElementById('settings-control-container');
    settingsButton = document.getElementById('settings-button');
    settingsDisplayText = document.getElementById('settings-display-text');
    settingsPopover = document.getElementById('settings-popover');
    apiPresetSelector = document.getElementById('api-preset-selector');
    aiModelSelector = document.getElementById('ai-model-selector');
    quickPromptSelect = document.getElementById('quick-prompt-select');
    managePromptsBtn = document.getElementById('manage-prompts-btn');
    manageApiSettingsBtn = document.getElementById('manage-api-settings-btn');
    promptManagerModalOverlay = document.getElementById('prompt-manager-modal-overlay');
    promptManagerCloseBtn = document.getElementById('prompt-manager-close-btn');
    templateListContainer = document.getElementById('template-list-container');
    addNewTemplateBtn = document.getElementById('add-new-template-btn');
    templateEditorPanel = document.querySelector('.template-editor-panel');
    templateNameInput = document.getElementById('template-name-input');
    templatePromptTextarea = document.getElementById('template-prompt-textarea');
    saveTemplateBtn = document.getElementById('save-template-btn');
    deleteTemplateBtn = document.getElementById('delete-template-btn');
    quickQueryInput = document.getElementById('quick-query-input');
    quickQuerySendBtn = document.getElementById('quick-query-send-btn');
    quickQueryTempToggle = document.getElementById('quick-query-temp-toggle');
    // New recall view elements
    noteRecallView = document.getElementById('note-recall-view');
    recallBackToListBtn = document.getElementById('recall-back-to-list-btn');
    recallNoteTitle = document.getElementById('recall-note-title');
    recallTurnListContainer = document.getElementById('recall-turn-list-container');
    recallContentContainer = document.getElementById('recall-content-container');
    recallSearchInput = document.getElementById('recall-search-input');
    document.getElementById('recall-compatibility-toggle')?.remove();
    document.getElementById('recall-editor-toggle')?.remove();
    recallSidebarToggleBtn = document.getElementById('recall-sidebar-toggle-btn');

    // [NEW] Visualization options modal elements
    visualizationOptionsModalOverlay = document.getElementById('visualization-options-modal-overlay');
    vizLibraryOptions = document.getElementById('viz-library-options');
    vizOptionsTextarea = document.getElementById('viz-options-textarea');
    vizOptionsCancelBtn = document.getElementById('viz-options-cancel-btn');
    vizOptionsGenerateBtn = document.getElementById('viz-options-generate-btn');

    // [NEW] Image Generation options modal elements
    imageGenerationOptionsModalOverlay = document.getElementById('image-generation-options-modal-overlay');
    imgGenOptionsTextarea = document.getElementById('img-gen-options-textarea');
    imgGenOptionsCancelBtn = document.getElementById('img-gen-options-cancel-btn');
    imgGenOptionsQuickBtn = document.getElementById('img-gen-options-quick-btn');
    imgGenPresetSettingsBtn = document.getElementById('img-gen-preset-settings-btn');
    
    // [NEW] Bind studio image upload elements
    imgGenStudioUploadBtn = document.getElementById('img-gen-studio-upload-btn');
    imgGenStudioRemoveBtn = document.getElementById('img-gen-studio-remove-btn');
    imgGenStudioFileInput = document.getElementById('img-gen-studio-file-input');
    imgGenStudioPreviewWrapper = document.getElementById('img-gen-studio-preview-wrapper');
    imgGenStudioPreview = document.getElementById('img-gen-studio-preview');

    // [NEW] Bind context toggle button
    contextToggleBtn = document.getElementById('context-toggle-btn');
    groundingQuickToggleBtn = document.getElementById('grounding-quick-toggle-btn');
    
}
