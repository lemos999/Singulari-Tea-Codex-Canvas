/* --- Ailey & Bailey Canvas --- */
// File: 320_notes_ui.js
// Version: 4.0 (Archive Workspace Renewal)
// Description: Renews the Ailey's Note list workspace, removes note-side extraction surfaces, and promotes backup/restore actions as the primary archive maintenance path.

let noteSelection = {
    projectId: null,
    selectedIds: new Set(),
};

function formatArchiveStatusTime(isoString) {
    if (!isoString) return '아직 없음';
    try {
        return new Date(isoString).toLocaleString('ko-KR', {
            dateStyle: 'short',
            timeStyle: 'short'
        });
    } catch (error) {
        return '시간 확인 불가';
    }
}

function getArchiveSummaryText() {
    const noteCount = Array.isArray(localNotesCache) ? localNotesCache.length : 0;
    const projectCount = Array.isArray(localNoteProjectsCache) ? localNoteProjectsCache.length : 0;
    const localBackupStatus = typeof getLocalBackupStatus === 'function'
        ? getLocalBackupStatus()
        : null;

    const summaryParts = [`메모 ${noteCount}개`, `폴더 ${projectCount}개`];

    if (localBackupStatus?.isLocalRuntime) {
        if (localBackupStatus.hasMirror) {
            summaryParts.push(`로컬 백업 ${formatArchiveStatusTime(localBackupStatus.backupDate)}`);
        } else {
            summaryParts.push('로컬 백업 없음');
        }
    } else {
        summaryParts.push('JSON 백업 사용');
    }

    return summaryParts.join(' · ');
}

function renderArchiveHealthSummary() {
    const summaryEl = document.getElementById('notes-archive-summary');
    if (!summaryEl) return;
    summaryEl.textContent = getArchiveSummaryText();
}

function getNoteKindLabel(noteData) {
    if (!noteData) return 'NOTE';
    if (noteData.title?.startsWith('[학습]')) return 'LEARNING';
    if (noteData.content && (noteData.content.includes('## [턴') || noteData.content.includes('## [회상'))) return 'RECALL';
    if (noteData.content && noteData.content.includes('<!-- VIZ_DATA:')) return 'VISUAL';
    return 'NOTE';
}

function isArchiveLikeNote(noteData) {
    const kind = getNoteKindLabel(noteData);
    return kind === 'LEARNING' || kind === 'RECALL' || kind === 'VISUAL';
}

function isMemoLikeNote(noteData) {
    return !isArchiveLikeNote(noteData);
}

function getNotePreviewText(noteData) {
    if (!noteData?.content) {
        return '아직 내용이 없는 메모입니다.';
    }

    const cleaned = noteData.content
        .replace(/<!--[\s\S]*?-->/g, ' ')
        .replace(/^#{1,6}\s+/gm, '')
        .replace(/^\*\*(.*?)\*\*$/gm, '$1')
        .replace(/^>\s+/gm, '')
        .replace(/\n+/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();

    return cleaned ? cleaned.slice(0, 110) : '아직 내용이 없는 메모입니다.';
}

function getProjectDescriptor(project, notesInProject, hasNarrativeNotes, hasLearningNotes) {
    if (hasNarrativeNotes && hasLearningNotes) {
        return `아카이브 ${notesInProject.length}개 · 회상/학습 혼합`;
    }
    if (hasNarrativeNotes) {
        return `아카이브 ${notesInProject.length}개 · 회상 가능`;
    }
    if (hasLearningNotes) {
        return `아카이브 ${notesInProject.length}개 · 학습 노트`;
    }
    return `메모 ${notesInProject.length}개`;
}

function closeNotesDropdownMenu() {
    document.getElementById('notes-dropdown-menu')?.classList.remove('show');
}

function getProjectArchiveMemoDescriptor(notesInProject, hasNarrativeNotes, hasLearningNotes) {
    const archiveCount = notesInProject.filter(isArchiveLikeNote).length;
    const memoCount = notesInProject.length - archiveCount;
    const summaryParts = [];

    if (archiveCount > 0) {
        if (hasNarrativeNotes && hasLearningNotes) {
            summaryParts.push(`아카이브 ${archiveCount}개 · 회상/학습`);
        } else if (hasNarrativeNotes) {
            summaryParts.push(`아카이브 ${archiveCount}개 · 회상`);
        } else if (hasLearningNotes) {
            summaryParts.push(`아카이브 ${archiveCount}개 · 학습`);
        } else {
            summaryParts.push(`아카이브 ${archiveCount}개`);
        }
    }

    if (memoCount > 0) {
        summaryParts.push(`메모 ${memoCount}개`);
    }

    return summaryParts.length > 0 ? summaryParts.join(' · ') : '기록 없음';
}

function appendStandaloneNoteGroup(fragment, title, notes) {
    if (!Array.isArray(notes) || notes.length === 0) return;

    const header = document.createElement('div');
    header.className = 'note-group-header';
    header.textContent = title;
    fragment.appendChild(header);

    notes.forEach(note => fragment.appendChild(createNoteItem(note)));
}

function toggleSelectionMode(projectId) {
    if (noteSelection.projectId === projectId) {
        noteSelection.projectId = null;
        noteSelection.selectedIds.clear();
    } else {
        noteSelection.projectId = projectId;
        noteSelection.selectedIds.clear();
    }
    renderNoteList();
    renderSelectionActionBar();
}

function renderSelectionActionBar() {
    let bar = document.getElementById('note-selection-bar');
    if (!noteListView) return;

    if (noteSelection.projectId && noteSelection.selectedIds.size > 0) {
        if (!bar) {
            bar = document.createElement('div');
            bar.id = 'note-selection-bar';
            noteListView.appendChild(bar);
        }

        const backupSvg = `<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z"></path></svg>`;
        bar.innerHTML = `
            <div id="selection-bar-info">${noteSelection.selectedIds.size}개 메모 선택됨</div>
            <div id="selection-bar-actions">
                <button id="selection-cancel-btn" class="modal-btn cancel">취소</button>
                <button id="selection-backup-btn" class="modal-btn secondary with-icon">${backupSvg}<span>선택 메모 백업</span></button>
            </div>
        `;

        bar.querySelector('#selection-backup-btn')?.addEventListener('click', () => {
            if (typeof exportSelectedNotes === 'function') {
                exportSelectedNotes(Array.from(noteSelection.selectedIds));
            }
        });
        bar.querySelector('#selection-cancel-btn')?.addEventListener('click', () => {
            toggleSelectionMode(noteSelection.projectId);
        });
        bar.classList.add('visible');
        return;
    }

    if (bar) {
        bar.classList.remove('visible');
    }
}

function buildArchiveMenuHtml(localBackupStatus) {
    const localMirrorAction = localBackupStatus?.isLocalRuntime
        ? `
            <button class="dropdown-item" data-action="export-local-mirror">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M5,3H19A2,2 0 0,1 21,5V19A2,2 0 0,1 19,21H5A2,2 0 0,1 3,19V5A2,2 0 0,1 5,3M12,6L7,11H10V16H14V11H17L12,6Z"></path></svg>
                <span>로컬 백업 저장</span>
            </button>
        `
        : '';

    return `
        <div id="notes-dropdown-menu" class="dropdown-menu notes-archive-menu">
            <button class="dropdown-item" data-action="backup-all">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z"></path></svg>
                <span>전체 백업 JSON</span>
            </button>
            <button class="dropdown-item" data-action="restore-all">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M19.35,10.04C18.67,6.59 15.64,4 12,4C9.11,4 6.6,5.64 5.35,8.04C2.34,8.36 0,10.91 0,14A6,6 0 0,0 6,20H19A5,5 0 0,0 19.35,10.04Z"></path></svg>
                <span>백업 복원</span>
            </button>
            ${localMirrorAction}
            <div class="dropdown-separator"></div>
            <button class="dropdown-item" data-action="system-reset" style="color: #d9534f;">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12,4C14.12,4 16.16,4.73 17.89,6.03L16.83,7.09C15.5,6.07 13.83,5.5 12,5.5C8.96,5.5 6.5,7.96 6.5,11H8.5C8.5,9.07 10.07,7.5 12,7.5C12.86,7.5 13.65,7.81 14.29,8.34L13.23,9.4L17.5,10.5L16.4,6.23L15.34,7.29C14.37,6.46 13.23,6 12,6C9.24,6 7,8.24 7,11V11.5H5V11C5,7.13 8.13,4 12,4M12,18C9.88,18 7.84,17.27 6.11,15.97L7.17,14.91C8.5,15.93 10.17,16.5 12,16.5C15.04,16.5 17.5,14.04 17.5,11H15.5C15.5,12.93 13.93,14.5 12,14.5C11.14,14.5 10.35,14.19 9.71,13.66L10.77,12.6L6.5,11.5L7.6,15.77L8.66,14.71C9.63,15.54 10.77,16 12,16C14.76,16 17,13.76 17,11V10.5H19V11C19,14.87 15.87,18 12,18Z"></path></svg>
                <span>시스템 초기화</span>
            </button>
        </div>
    `;
}

function buildNoteActionBarHtml() {
    const localBackupStatus = typeof getLocalBackupStatus === 'function'
        ? getLocalBackupStatus()
        : null;

    const localMirrorBadge = localBackupStatus?.isLocalRuntime
        ? `<button id="notes-local-snapshot-pill" class="notes-chip-btn" title="최근 로컬 자동 백업">${localBackupStatus.hasMirror ? '로컬 백업 있음' : '로컬 백업 없음'}</button>`
        : `<button id="notes-json-backup-pill" class="notes-chip-btn" title="JSON 백업은 언제든 가능합니다">JSON 백업</button>`;

    return `
        <div class="action-bar notes-action-bar">
            <div class="notes-hero-row">
                <div class="notes-hero-copy">
                    <div class="notes-hero-kicker">ARCHIVE WORKSPACE</div>
                    <div class="notes-hero-title-row">
                        <div class="notes-hero-title">Ailey's Note</div>
                        <div id="notes-archive-summary" class="notes-archive-summary"></div>
                    </div>
                </div>
                <div class="notes-toolbar-primary">
                    <button id="add-new-note-btn-dynamic" class="notes-btn notes-btn-primary" title="새 메모">
                        <svg viewBox="0 0 24 24" width="16" height="16"><path d="M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z"/></svg>
                        <span>새 메모</span>
                    </button>
                    <button id="add-new-note-project-btn-dynamic" class="notes-btn notes-btn-secondary" title="새 폴더">
                        <svg viewBox="0 0 24 24" width="16" height="16"><path d="M4,6H2V20A2,2 0 0,0 4,22H18V20H4V6M20,2H8A2,2 0 0,0 6,4V16A2,2 0 0,0 8,18H20A2,2 0 0,0 22,16V4A2,2 0 0,0 20,2M13,13H11V10H8V8H11V5H13V8H16V10H13V13Z"/></svg>
                        <span>새 폴더</span>
                    </button>
                </div>
            </div>
            <div class="notes-toolbar-row">
                <div class="notes-toolbar-search">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L20.71,20L19.29,21.41L13,15.12C11.86,16.09 10.39,16.68 8.77,16.68A6.5,6.5 0 0,1 2.27,10.18A6.5,6.5 0 0,1 8.77,3.68C9.01,3.68 9.26,3.69 9.5,3.73V3M8.77,5.18A5,5 0 0,0 3.77,10.18A5,5 0 0,0 8.77,15.18A5,5 0 0,0 13.77,10.18A5,5 0 0,0 8.77,5.18Z"></path></svg>
                    <input type="text" id="search-input-dynamic" class="search-input-notes" placeholder="메모와 기록 검색...">
                </div>
                <div class="notes-toolbar-secondary">
                    ${localMirrorBadge}
                    <div class="more-options-container">
                        <button id="notes-archive-menu-btn" class="notes-btn notes-btn-ghost" title="아카이브 메뉴">
                            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M13,3.5L18.5,9H13V3.5Z"></path></svg>
                            <span>아카이브</span>
                        </button>
                        ${buildArchiveMenuHtml(localBackupStatus)}
                    </div>
                </div>
            </div>
        </div>
    `;
}

function renderProjectGroup(fragment, title, entries) {
    if (!Array.isArray(entries) || entries.length === 0) return;

    const header = document.createElement('div');
    header.className = 'note-group-header';
    header.textContent = title;
    fragment.appendChild(header);

    entries.forEach(entry => {
        fragment.appendChild(createNoteProjectContainer(entry.project, entry.visibleNotes, entry.allUnpinnedNotes));
    });
}

function renderSeparatedNotesList(notesListContainer, filteredNotes, term) {
    if (!notesListContainer) return;

    const fragment = document.createDocumentFragment();
    const pinnedNotes = filteredNotes.filter(n => n.isPinned);
    const unpinnedNotes = filteredNotes.filter(n => !n.isPinned);
    const pinnedArchiveNotes = pinnedNotes
        .filter(isArchiveLikeNote)
        .sort((a, b) => (b.updatedAt?.toMillis() || 0) - (a.updatedAt?.toMillis() || 0));
    const pinnedMemoNotes = pinnedNotes
        .filter(isMemoLikeNote)
        .sort((a, b) => (b.updatedAt?.toMillis() || 0) - (a.updatedAt?.toMillis() || 0));

    appendStandaloneNoteGroup(fragment, '고정 아카이브', pinnedArchiveNotes);
    appendStandaloneNoteGroup(fragment, '고정 메모', pinnedMemoNotes);

    const projectEntries = localNoteProjectsCache.map(project => {
        const visibleNotes = unpinnedNotes.filter(n => n.projectId === project.id);
        const allUnpinnedNotes = localNotesCache.filter(n => n.projectId === project.id && !n.isPinned);
        const mostRecentNoteUpdate = visibleNotes.reduce((latest, note) => {
            const noteTimestamp = note.updatedAt?.toMillis() || 0;
            return noteTimestamp > latest ? noteTimestamp : latest;
        }, 0);
        const projectTimestamp = project.updatedAt?.toMillis() || 0;

        return {
            project: {
                ...project,
                effectiveTimestamp: Math.max(projectTimestamp, mostRecentNoteUpdate)
            },
            visibleNotes,
            allUnpinnedNotes,
            hasArchiveNotes: allUnpinnedNotes.some(isArchiveLikeNote)
        };
    });

    const visibleArchiveProjects = [];
    const visibleMemoProjects = [];

    projectEntries
        .sort((a, b) => b.project.effectiveTimestamp - a.project.effectiveTimestamp)
        .forEach(entry => {
            const projectNameMatches = term && entry.project.name.toLowerCase().includes(term);
            if (term && !projectNameMatches && entry.visibleNotes.length === 0) return;

            if (entry.hasArchiveNotes) {
                visibleArchiveProjects.push(entry);
            } else {
                visibleMemoProjects.push(entry);
            }
        });

    renderProjectGroup(fragment, '아카이브 폴더', visibleArchiveProjects);
    appendStandaloneNoteGroup(fragment, '일반 아카이브', unpinnedNotes.filter(n => !n.projectId && isArchiveLikeNote(n)));
    renderProjectGroup(fragment, '메모 폴더', visibleMemoProjects);
    appendStandaloneNoteGroup(fragment, '일반 메모', unpinnedNotes.filter(n => !n.projectId && isMemoLikeNote(n)));

    notesListContainer.innerHTML = '';

    if (fragment.childNodes.length === 0) {
        const emptyState = document.createElement('div');
        emptyState.className = 'notes-empty-state';
        emptyState.innerHTML = `
            <div class="notes-empty-kicker">EMPTY ARCHIVE</div>
            <h3>아직 정리된 메모가 없습니다.</h3>
            <p>새 메모를 만들거나, 백업을 복원하거나, 학습 기록을 아카이브로 보존해 보세요.</p>
        `;
        notesListContainer.appendChild(emptyState);
        return;
    }

    notesListContainer.appendChild(fragment);
}

function renderNoteList() {
    if (!noteListView) return;
    trace("UI", "note.renderList.start");

    const isFirstRender = !noteListView.querySelector('.action-bar');

    if (isFirstRender) {
        noteListView.innerHTML = `${buildNoteActionBarHtml()}<div id="notes-list"></div>`;

        document.getElementById('notes-list')?.addEventListener('scroll', handleNoteListScroll);
        document.getElementById('search-input-dynamic')?.addEventListener('input', () => renderNoteList());

        noteListView.addEventListener('change', e => {
            const checkbox = e.target.closest('.note-select-checkbox');
            if (!checkbox) return;

            const noteId = checkbox.dataset.noteId;
            if (checkbox.checked) {
                noteSelection.selectedIds.add(noteId);
            } else {
                noteSelection.selectedIds.delete(noteId);
            }
            renderSelectionActionBar();
        });

        noteListView.addEventListener('click', e => {
            const target = e.target;
            const archiveMenu = document.getElementById('notes-dropdown-menu');
            const archiveMenuBtn = target.closest('#notes-archive-menu-btn');

            if (!archiveMenuBtn && !target.closest('#notes-dropdown-menu')) {
                archiveMenu?.classList.remove('show');
            }

            if (target.closest('#add-new-note-btn-dynamic')) {
                handleAddNewNote();
                return;
            }
            if (target.closest('#add-new-note-project-btn-dynamic')) {
                createNewNoteProject();
                return;
            }
            if (target.closest('#notes-archive-menu-btn')) {
                archiveMenu?.classList.toggle('show');
                return;
            }
            if (target.closest('#notes-local-snapshot-pill')) {
                if (typeof exportLatestLocalAutoBackup === 'function' && typeof getLocalBackupStatus === 'function' && getLocalBackupStatus().hasMirror) {
                    exportLatestLocalAutoBackup();
                }
                return;
            }
            if (target.closest('#notes-json-backup-pill')) {
                if (typeof exportAllData === 'function') {
                    exportAllData();
                }
                return;
            }

            const dropdownAction = target.closest('.dropdown-item')?.dataset.action;
            if (dropdownAction) {
                if (dropdownAction === 'backup-all' && typeof exportAllData === 'function') {
                    exportAllData();
                } else if (dropdownAction === 'restore-all' && typeof handleRestoreClick === 'function') {
                    handleRestoreClick();
                } else if (dropdownAction === 'export-local-mirror' && typeof exportLatestLocalAutoBackup === 'function') {
                    exportLatestLocalAutoBackup();
                } else if (dropdownAction === 'system-reset') {
                    handleSystemReset();
                }
                closeNotesDropdownMenu();
                return;
            }

            const recallBtn = target.closest('.note-project-recall-btn');
            if (recallBtn) {
                e.stopPropagation();
                const projectId = recallBtn.dataset.projectId;
                const recallType = recallBtn.dataset.recallType;
                if (recallType === 'narrative' && typeof initializeProjectRecallViewer === 'function') {
                    initializeProjectRecallViewer(projectId);
                } else if (recallType === 'learning' && typeof initializeLearningProjectRecallViewer === 'function') {
                    initializeLearningProjectRecallViewer(projectId);
                }
                return;
            }

            const selectBtn = target.closest('.select-mode-btn');
            if (selectBtn) {
                e.stopPropagation();
                toggleSelectionMode(selectBtn.dataset.projectId);
                return;
            }

            const noteItem = target.closest('.note-item');
            if (noteItem) {
                const noteId = noteItem.dataset.id;
                const note = localNotesCache.find(n => n.id === noteId);
                if (note && note.projectId != null && note.projectId === noteSelection.projectId) {
                    const checkbox = noteItem.querySelector('.note-select-checkbox');
                    if (checkbox && target !== checkbox) {
                        checkbox.checked = !checkbox.checked;
                        checkbox.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                } else {
                    openNoteEditor(noteId);
                }
                return;
            }

            const projectHeader = target.closest('.note-project-header');
            if (projectHeader) {
                const projectId = projectHeader.closest('.note-project-container')?.dataset.projectId;
                if (projectId) {
                    toggleNoteProjectExpansion(projectId);
                }
            }
        });

        noteListView.addEventListener('contextmenu', e => {
            e.preventDefault();
            handleNoteContextMenu(e);
        });
    }

    renderArchiveHealthSummary();

    const searchInput = document.getElementById('search-input-dynamic');
    const term = (searchInput?.value || '').toLowerCase();
    const filteredNotes = localNotesCache.filter(note => {
        if (!term) return true;
        const haystack = `${note.title || ''}\n${note.content || ''}`.toLowerCase();
        return haystack.includes(term);
    });

    const notesListHost = document.getElementById('notes-list');
    renderSeparatedNotesList(notesListHost, filteredNotes, term);
    renderSelectionActionBar();
    return;

    const notesListContainer = document.getElementById('notes-list');
    const fragment = document.createDocumentFragment();

    const pinnedNotes = filteredNotes.filter(n => n.isPinned);
    const unpinnedNotes = filteredNotes.filter(n => !n.isPinned);

    if (pinnedNotes.length > 0) {
        const pinnedHeader = document.createElement('div');
        pinnedHeader.className = 'note-group-header';
        pinnedHeader.textContent = '고정 메모';
        fragment.appendChild(pinnedHeader);

        pinnedNotes
            .sort((a, b) => (b.updatedAt?.toMillis() || 0) - (a.updatedAt?.toMillis() || 0))
            .forEach(note => fragment.appendChild(createNoteItem(note)));
    }

    const projectsWithEffectiveDate = localNoteProjectsCache.map(project => {
        const notesInProject = unpinnedNotes.filter(n => n.projectId === project.id);
        const mostRecentNoteUpdate = notesInProject.reduce((latest, note) => {
            const noteTimestamp = note.updatedAt?.toMillis() || 0;
            return noteTimestamp > latest ? noteTimestamp : latest;
        }, 0);
        const projectTimestamp = project.updatedAt?.toMillis() || 0;
        return {
            ...project,
            effectiveTimestamp: Math.max(projectTimestamp, mostRecentNoteUpdate)
        };
    });

    projectsWithEffectiveDate
        .sort((a, b) => b.effectiveTimestamp - a.effectiveTimestamp)
        .forEach(project => {
            const notesInProject = unpinnedNotes.filter(n => n.projectId === project.id);
            if (term && !project.name.toLowerCase().includes(term) && notesInProject.length === 0) return;
            fragment.appendChild(createNoteProjectContainer(project, notesInProject));
        });

    const unassignedNotes = unpinnedNotes.filter(n => !n.projectId);
    if (unassignedNotes.length > 0) {
        const generalHeader = document.createElement('div');
        generalHeader.className = 'note-group-header';
        generalHeader.textContent = '일반 메모';
        fragment.appendChild(generalHeader);
        unassignedNotes.forEach(note => fragment.appendChild(createNoteItem(note)));
    }

    if (fragment.childNodes.length === 0) {
        const emptyState = document.createElement('div');
        emptyState.className = 'notes-empty-state';
        emptyState.innerHTML = `
            <div class="notes-empty-kicker">EMPTY ARCHIVE</div>
            <h3>아직 저장된 메모가 없습니다.</h3>
            <p>새 메모를 만들거나, 백업을 복원하거나, 대화와 학습 기록을 아카이브해보세요.</p>
        `;
        notesListContainer.innerHTML = '';
        notesListContainer.appendChild(emptyState);
    } else {
        notesListContainer.innerHTML = '';
        notesListContainer.appendChild(fragment);
    }

    renderSelectionActionBar();
}

const handleNoteListScroll = debounce(async (e) => {
    const { scrollTop, scrollHeight, clientHeight } = e.target;
    if (scrollHeight - scrollTop - clientHeight < 200 && !isNoteLoadingMore && hasMoreNotes) {
        isNoteLoadingMore = true;
        trace("UI", "note.scroll.loadMore", {}, { hasMoreNotes });
        const newNotes = await fetchMoreNotes();
        if (newNotes.length > 0) {
            renderNoteList();
        }
        isNoteLoadingMore = false;
    }
}, 200);

function createNoteProjectContainer(project, notesInProject, sourceNotes = null) {
    const projectContainer = document.createElement('div');
    projectContainer.className = 'note-project-container';
    projectContainer.dataset.projectId = project.id;
    if (noteSelection.projectId === project.id) {
        projectContainer.classList.add('selection-mode');
    }

    const isSelectionActiveForThisProject = noteSelection.projectId === project.id;
    const allNotesInProject = Array.isArray(sourceNotes) ? sourceNotes : localNotesCache.filter(n => n.projectId === project.id);
    const archiveNotesInProject = notesInProject.filter(isArchiveLikeNote);
    const memoNotesInProject = notesInProject.filter(isMemoLikeNote);
    const hasNarrativeNotes = allNotesInProject.some(note =>
        note.content && (note.content.includes('## [턴') || note.content.includes('## [회상'))
    );
    const hasLearningNotes = allNotesInProject.some(note => note.title?.startsWith('[학습]'));

    const recallIcon = `<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M13,3A9,9 0 0,0 4,12H1L4.89,15.89L8.78,12H6A7,7 0 0,1 13,5A7,7 0 0,1 20,12A7,7 0 0,1 13,19C11.07,19 9.32,18.21 8.06,16.94L6.64,18.36C8.27,20 10.5,21 13,21A9,9 0 0,0 22,12A9,9 0 0,0 13,3Z"/></svg>`;

    let recallButtonHTML = '';
    if (hasNarrativeNotes) {
        recallButtonHTML = `<button class="note-project-action-btn note-project-recall-btn" data-project-id="${project.id}" data-recall-type="narrative" title="프로젝트 전체 회상">${recallIcon}<span>회상</span></button>`;
    } else if (hasLearningNotes) {
        recallButtonHTML = `<button class="note-project-action-btn note-project-recall-btn" data-project-id="${project.id}" data-recall-type="learning" title="학습 노트 회상">${recallIcon}<span>학습</span></button>`;
    }

    const selectButtonHTML = notesInProject.length > 0
        ? `<button class="note-project-action-btn select-mode-btn" data-project-id="${project.id}" title="프로젝트 선택">${isSelectionActiveForThisProject ? '<span>완료</span>' : '<span>선택</span>'}</button>`
        : '';

    projectContainer.innerHTML = `
        <div class="note-project-header ${isSelectionActiveForThisProject ? 'selection-active' : ''}">
            <div class="note-project-main">
                <span class="note-project-toggle-icon ${project.isExpanded !== false ? 'expanded' : ''}">
                    <svg viewBox="0 0 24 24" width="16" height="16"><path d="M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z" /></svg>
                </span>
                <span class="note-project-icon">
                    <svg viewBox="0 0 24 24" width="18" height="18"><path d="M4,6H2V20A2,2 0 0,0 4,22H18V20H4V6M20,2H8A2,2 0 0,0 6,4V16A2,2 0 0,0 8,18H20A2,2 0 0,0 22,16V4A2,2 0 0,0 20,2Z" /></svg>
                </span>
                <div class="note-project-copy">
                    <span class="note-project-title">${project.name}</span>
                    <span class="note-project-meta">${getProjectArchiveMemoDescriptor(allNotesInProject, hasNarrativeNotes, hasLearningNotes)}</span>
                </div>
            </div>
            <div class="note-project-controls">
                ${recallButtonHTML}
                ${selectButtonHTML}
            </div>
        </div>
        <div class="notes-in-project ${project.isExpanded !== false ? 'expanded' : ''}"></div>
    `;

    const notesContainer = projectContainer.querySelector('.notes-in-project');
    if (archiveNotesInProject.length > 0) {
        const archiveSection = document.createElement('div');
        archiveSection.className = 'note-project-section note-project-section-archive';
        archiveSection.innerHTML = `<div class="note-project-section-title">아카이브</div>`;
        const archiveItems = document.createElement('div');
        archiveItems.className = 'note-project-section-items';
        archiveNotesInProject.forEach(note => archiveItems.appendChild(createNoteItem(note)));
        archiveSection.appendChild(archiveItems);
        notesContainer.appendChild(archiveSection);
    }

    if (memoNotesInProject.length > 0) {
        const memoSection = document.createElement('div');
        memoSection.className = 'note-project-section note-project-section-memo';
        memoSection.innerHTML = `<div class="note-project-section-title">메모</div>`;
        const memoItems = document.createElement('div');
        memoItems.className = 'note-project-section-items';
        memoNotesInProject.forEach(note => memoItems.appendChild(createNoteItem(note)));
        memoSection.appendChild(memoItems);
        notesContainer.appendChild(memoSection);
    }

    if (notesContainer.childElementCount === 0) {
        const emptySection = document.createElement('div');
        emptySection.className = 'note-project-section note-project-section-empty';
        emptySection.innerHTML = `<div class="note-project-section-title">표시할 메모가 없습니다.</div>`;
        notesContainer.appendChild(emptySection);
    }
    return projectContainer;
}

function createNoteItem(noteData) {
    const item = document.createElement('div');
    item.className = 'note-item';
    item.dataset.id = noteData.id;
    if (noteData.isPinned) item.classList.add('pinned');

    const isSelected = noteSelection.selectedIds.has(noteData.id);
    const kindLabel = getNoteKindLabel(noteData);
    const previewText = getNotePreviewText(noteData);
    const updatedLabel = noteData.updatedAt?.toDate
        ? noteData.updatedAt.toDate().toLocaleString('ko-KR', { dateStyle: 'short', timeStyle: 'short' })
        : '날짜 없음';

    item.innerHTML = `
        <input type="checkbox" class="note-select-checkbox" data-note-id="${noteData.id}" ${isSelected ? 'checked' : ''}>
        <div class="note-item-content">
            <div class="note-item-meta-row">
                <span class="note-item-kind">${kindLabel}</span>
                <span class="note-item-date">${updatedLabel}</span>
            </div>
            <div class="note-item-title">${noteData.title || '무제 노트'}</div>
            <div class="note-item-preview">${previewText}</div>
        </div>
    `;
    return item;
}

function handleNoteContextMenu(event) {
    const target = event.target;
    const noteItem = target.closest('.note-item');
    const projectHeader = target.closest('.note-project-header');

    if (noteItem) {
        const noteId = noteItem.dataset.id;
        const note = localNotesCache.find(n => n.id === noteId);
        if (!note) return;

        if (noteSelection.projectId && noteSelection.projectId === note.projectId) {
            event.preventDefault();
            return;
        }

        const items = [
            { label: '이름 변경', action: () => startNoteRename(noteId) },
            { label: note.isPinned ? '고정 해제' : '고정하기', action: () => togglePin(noteId) },
            { label: '폴더로 이동', action: () => openMoveToFolderModal(noteId) },
            { separator: true },
            { label: '삭제', action: () => deleteNote(noteId) }
        ];

        createContextMenu(items, event);
        return;
    }

    if (projectHeader) {
        const projectId = projectHeader.closest('.note-project-container')?.dataset.projectId;
        if (!projectId) return;

        const items = [
            { label: '이름 변경', action: () => startNoteProjectRename(projectId) },
            { label: '기록 묶음 크기 설정', action: () => openChunkSizeModal(projectId) },
            { label: '이 폴더 백업 (JSON)', action: () => exportNoteProject(projectId) },
            { separator: true },
            { label: '삭제', action: () => deleteNoteProject(projectId) }
        ];

        createContextMenu(items, event);
    }
}

function openChunkSizeModal(projectId) {
    const project = localNoteProjectsCache.find(p => p.id === projectId);
    if (!project) return;

    const modal = document.getElementById('chunk-size-modal-overlay');
    const titleEl = document.getElementById('chunk-size-modal-title');
    const inputEl = document.getElementById('chunk-size-input');
    const saveBtn = document.getElementById('chunk-size-save-btn');
    const cancelBtn = document.getElementById('chunk-size-cancel-btn');

    if (!modal || !titleEl || !inputEl || !saveBtn || !cancelBtn) {
        console.error("Chunk size modal elements not found!");
        return;
    }

    titleEl.textContent = `'${project.name}' 기록 묶음 크기 설정`;
    inputEl.value = project.chunkSize || '';
    inputEl.placeholder = '10';

    const close = () => {
        modal.style.display = 'none';
        saveBtn.onclick = null;
        cancelBtn.onclick = null;
        modal.onclick = null;
    };

    saveBtn.onclick = () => {
        const newSize = inputEl.value;
        if (typeof updateNoteProjectChunkSize === 'function') {
            updateNoteProjectChunkSize(projectId, newSize);
        }
        close();
    };

    cancelBtn.onclick = close;
    modal.onclick = e => {
        if (e.target === modal) close();
    };

    highestZIndex++;
    modal.style.zIndex = highestZIndex;
    modal.style.display = 'flex';
}

function openMoveToFolderModal(noteId) {
    const note = localNotesCache.find(n => n.id === noteId);
    if (!note) return;

    const modal = document.getElementById('move-to-folder-modal-overlay');
    const titleEl = document.getElementById('move-to-folder-modal-title');
    const searchInput = document.getElementById('move-to-folder-search-input');
    const listContainer = document.getElementById('move-to-folder-list-container');
    const cancelBtn = document.getElementById('move-to-folder-cancel-btn');

    if (!modal || !titleEl || !searchInput || !listContainer || !cancelBtn) {
        console.error("Move to folder modal elements not found!");
        return;
    }

    titleEl.textContent = `"${note.title}" 이동`;
    searchInput.value = '';

    const renderList = (filter = '') => {
        listContainer.innerHTML = '';
        const fragment = document.createDocumentFragment();

        const generalItem = document.createElement('div');
        generalItem.className = 'move-folder-item';
        generalItem.dataset.projectId = 'null';
        generalItem.innerHTML = `<svg viewBox="0 0 24 24" width="18" height="18"><path d="M17,4V10L15,8L13,10V4H6A2,2 0 0,0 4,6V18A2,2 0 0,0 6,20H18A2,2 0 0,0 20,18V6A2,2 0 0,0 18,4H17Z" /></svg><span>[일반 메모]</span>`;
        if (!note.projectId) {
            generalItem.setAttribute('disabled', true);
        }
        fragment.appendChild(generalItem);

        const filteredProjects = localNoteProjectsCache
            .filter(p => p.name.toLowerCase().includes(filter.toLowerCase()))
            .sort((a, b) => a.name.localeCompare(b.name, 'ko'));

        filteredProjects.forEach(project => {
            const projectItem = document.createElement('div');
            projectItem.className = 'move-folder-item';
            projectItem.dataset.projectId = project.id;
            projectItem.innerHTML = `<svg viewBox="0 0 24 24" width="18" height="18"><path d="M4,6H2V20A2,2 0 0,0 4,22H18V20H4V6M20,2H8A2,2 0 0,0 6,4V16A2,2 0 0,0 8,18H20A2,2 0 0,0 22,16V4A2,2 0 0,0 20,2Z" /></svg><span>${project.name}</span>`;
            if (note.projectId === project.id) {
                projectItem.setAttribute('disabled', true);
            }
            fragment.appendChild(projectItem);
        });

        listContainer.appendChild(fragment);
    };

    const close = () => {
        modal.style.display = 'none';
        searchInput.oninput = null;
        listContainer.onclick = null;
        cancelBtn.onclick = null;
        modal.onclick = null;
    };

    listContainer.onclick = e => {
        const item = e.target.closest('.move-folder-item');
        if (item && !item.hasAttribute('disabled')) {
            moveNoteToProject(noteId, item.dataset.projectId);
            close();
        }
    };
    searchInput.oninput = () => renderList(searchInput.value);
    cancelBtn.onclick = close;
    modal.onclick = e => {
        if (e.target === modal) close();
    };

    renderList();
    highestZIndex++;
    modal.style.zIndex = highestZIndex;
    modal.style.display = 'flex';
}
