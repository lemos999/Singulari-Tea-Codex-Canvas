# Ailey 로컬 독립 실행 — 실행 계획

- Artifact Type: feature-plan
- Created: 2026-04-12 07:04:00 +09:00
- Status: ✅ completed
- Input: [분석 보고서 v06](./20260412-053056--analysis-report--ailey--v01.md)
- Scope: Firebase 종속 해제, 로컬 독립 실행 모드 추가
- Execution Update: Phase 0~6 전체 완료 (2026-04-12).
- Scoreboard: Phase 0 ✅, Phase 1 ✅, Phase 2 ✅, Phase 3 ✅, Phase 4 ✅, Phase 5 ✅, Phase 6 ✅
- Runtime Note: Local behavior is now wired in source, Canvas behavior still requires `__firebase_config`, and the hosted bundle reflects the merged Phase 5 deployment.
- Deployment Note: Bundle-only PR merged to `lemos999/Singulari-Tea-Codex-Canvas` PR #2 with merge commit `e482a02a4626dcbd4392239dc852ae9ebf4e02fb`.

---

## 목표

Ailey를 Gemini Canvas 밖에서도 `index.html`로 로컬 실행 가능하게 만든다.
기존 Canvas 모드는 그대로 유지하면서, 로컬 모드에서는 IndexedDB로 데이터를 저장하고 사용자 API 키로 채팅이 동작하도록 한다.

---

## 핵심 설계 결정

### Firebase Shim 전략 (기존 코드 최소 변경)

> [!IMPORTANT]
> 기존 소스 전체에 `firebase.firestore.FieldValue.serverTimestamp()`, `collectionRef.add()`,
> `.onSnapshot()`, `.doc().set()` 등이 **50건 이상, 38개 파일**에 산재되어 있다.
>
> 이것을 전부 리팩토링하는 것은 **오버엔지니어링**이다.
>
> 대신 **Firebase API를 모방하는 로컬 Shim**을 만들어서,
> 기존 코드가 `collectionRef.add()` 등을 호출하면 **똑같은 API로 IndexedDB에 저장**되게 한다.

```
Canvas 모드:  firebase.firestore() → 실제 Firestore
로컬 모드:    LocalFirebaseShim()   → IndexedDB (같은 API 인터페이스)
```

**장점**: 기존 38개 파일 수정 없이 `100_core_firebase.js` 한 곳만 분기하면 됨.

### 환경 감지

```js
const isCanvasMode = (typeof __firebase_config !== 'undefined');
```

- `true` → 기존 Firebase 경로
- `false` → LocalFirebaseShim 사용 + 호스트 잠금 해제

---

## 에이전트 역할

| 기호 | 에이전트 | 역할 |
|---|---|---|
| 🎯 | Claude Opus 4.6 | 계획·리뷰·머지 판정 |
| ⚙️ | Codex GPT 5.4 | Shim 구현, 코어 수정, 번들 빌드, **Git 머지까지 수행** |
| 🎨 | Gemini 3.1 Pro | index.html, API 키 UI, Canvas 시각 검증 |

### 검증 파이프라인

```
1. 🎯 작업 지시서 → 2. ⚙️/🎨 구현 → 3. 🎯 리뷰
4. ⚙️ 번들 빌드 → 5. ⚙️ Git push + PR + 머지 → 6. 🎨 양쪽 모드 테스트
```

---

## Phase 0: LocalFirebaseShim 구현 ⚙️

**목표**: Firebase Firestore API를 모방하는 IndexedDB 기반 로컬 데이터 레이어.

### [NEW] `src/01_state/002_local_firebase_shim.js`

이 파일이 핵심이다. 구현해야 할 API:

```js
class LocalFirebaseShim {
    constructor() { /* IndexedDB 초기화 */ }

    collection(path) → LocalCollectionRef
    // 서브컬렉션 지원: "sessions/{id}/messages"
}

class LocalCollectionRef {
    doc(id)             → LocalDocRef
    add(data)           → Promise<LocalDocRef>     // 자동 ID 생성
    get()               → Promise<LocalQuerySnapshot>
    where(field, op, val) → LocalQuery
    orderBy(field, dir) → LocalQuery
    limit(n)            → LocalQuery
    onSnapshot(cb, err) → unsubscribe function     // EventEmitter 패턴
}

class LocalDocRef {
    get()               → Promise<LocalDocSnapshot>
    set(data, opts)     → Promise<void>
    update(data)        → Promise<void>
    delete()            → Promise<void>
    collection(path)    → LocalCollectionRef        // 서브컬렉션
}

class LocalQuery {
    get()               → Promise<LocalQuerySnapshot>
    where/orderBy/limit → LocalQuery (체이닝)
    onSnapshot(cb, err) → unsubscribe function
}
```

### FieldValue 호환

```js
LocalFirebaseShim.FieldValue = {
    serverTimestamp: () => new Date(),           // 로컬 시간
    delete: () => Symbol('FIELD_DELETE'),        // 필드 삭제 마커
    arrayUnion: (...items) => ({ _op: 'arrayUnion', items }),
    arrayRemove: (...items) => ({ _op: 'arrayRemove', items }),
};

LocalFirebaseShim.Timestamp = {
    fromDate: (date) => ({ seconds: Math.floor(date.getTime()/1000), nanoseconds: 0, toDate: () => date }),
};
```

### IndexedDB 스토어 구조

| ObjectStore 이름 | 대응 Firestore 컬렉션 |
|---|---|
| `notes` | notes |
| `noteProjects` | noteProjects |
| `noteTags` | noteTags |
| `noteTemplates` | noteTemplates |
| `userSettings` | settings/userSettings |
| `chatSessions` | chatHistories/global/sessions |
| `chatMessages` | chatHistories/global/sessions/{id}/messages |
| `projects` | chatHistories/global/projects |
| `promptTemplates` | promptTemplates |
| `canvasDrawings` | canvasDrawings |
| `canvasImageHistory` | canvasImageHistory |

### onSnapshot 시뮬레이션

```js
// EventEmitter 패턴으로 구현
// add/set/update/delete 할 때 해당 collection의 listener들에게 통지
// snapshot.docs = 전체 데이터를 LocalQuerySnapshot으로 매핑
```

### 검증
- 단위 테스트: `add() → get()` → 데이터 일치 확인
- `onSnapshot` 콜백 호출 확인
- `FieldValue.serverTimestamp()` → Date 반환 확인
- `where()`, `orderBy()`, `limit()` 체이닝 동작 확인

---

## Phase 1: 환경 분기 & 부트스트랩 수정 ⚙️

### [MODIFY] `src/03_core/100_core_firebase.js`

```js
async function initializeFirebase() {
    const isCanvasMode = (typeof __firebase_config !== 'undefined');

    if (isCanvasMode) {
        // --- 기존 Firebase 초기화 코드 그대로 ---
        // ... (현재 코드 전부 유지)
    } else {
        // --- 로컬 모드 ---
        console.log('[Ailey] 로컬 모드로 시작합니다.');
        const shim = new LocalFirebaseShim();
        await shim.initialize();  // IndexedDB 열기

        db = shim;  // 전역 db를 shim으로 대체
        currentUser = { uid: 'local-user' };  // 가짜 유저

        const userPath = `local/users/local-user`;
        // 동일한 컬렉션 레퍼런스 세팅 (shim이 같은 API 제공)
        notesCollectionRef = db.collection('notes');
        noteProjectsCollectionRef = db.collection('noteProjects');
        // ... (모든 collectionRef를 동일하게 세팅)

        await seedDefaultData();
        await initializeListeners();
        // UI 초기화
    }
}
```

### [MODIFY] `src/00_shell/005_shell_part6_main_assembler.js`

```js
// 호스트 잠금 해제
const isCanvasMode = (typeof __firebase_config !== 'undefined');
if (isCanvasMode) {
    // 기존 REQUIRED_SCRIPT_SOURCE 체크
} else {
    // 로컬 모드: 체크 건너뛰기
}
```

### 검증
- `isCanvasMode === false` 시 shim 사용 확인
- 컬렉션 레퍼런스 정상 할당 확인
- 호스트 잠금 바이패스 확인

---

## Phase 2: index.html 생성 🎨

### [NEW] `Ailey/index.html`

로컬에서 직접 열 수 있는 진입점.

```html
<!DOCTYPE html>
<html lang="ko">
<head>
    <title>Ailey & Bailey — Local Mode</title>
    <link rel="stylesheet" href="bundle/main.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <link rel="stylesheet" href="https://uicdn.toast.com/editor/latest/toastui-editor.min.css">
    <script src="bundle/main.js"></script>
</head>
<body>
<div id="initial-loader">Loading Ailey...</div>
<main id="ai-content-placeholder" style="display:none;"
      data-subject="시스템" data-concept="로컬 모드" data-type="lecture">
    <header class="header">
        <h1>Ailey & Bailey — 로컬 워크스페이스</h1>
        <p class="subtitle">로컬 모드에서 실행 중입니다. 채팅은 API 키 설정 후 사용 가능합니다.</p>
    </header>
    <section class="content-section type-key-terms">
        <h3>🔑 시작하기</h3>
        <div class="keyword-list">
            <span class="keyword-chip">API 키 설정</span>
            <span class="keyword-chip">노트 작성</span>
            <span class="keyword-chip">채팅</span>
        </div>
    </section>
    <section class="content-section">
        <h2>📋 로컬 모드 안내</h2>
        <p>모든 데이터는 브라우저의 <strong>IndexedDB</strong>에 저장됩니다.
           브라우저를 닫아도 데이터가 보존됩니다.</p>
        <p>채팅 기능을 사용하려면 <strong>설정</strong>에서 Gemini 또는 OpenAI API 키를 입력하세요.</p>
    </section>
</main>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const c = document.getElementById('ai-content-placeholder');
    if (c && typeof renderAppShell === 'function') {
        renderAppShell(c.outerHTML, document);
    }
});
</script>
</body>
</html>
```

### 로컬 서버 없이 동작?

> [!WARNING]
> `file://` 프로토콜에서는 일부 브라우저가 IndexedDB를 제한할 수 있다.
> 안정적으로 동작하려면 로컬 서버(`npx serve .` 또는 `python -m http.server`)를 사용하는 것이 권장됨.
> 단, Chrome은 `file://`에서도 IndexedDB가 동작한다.

### 검증
- `index.html` 열기 → 셸 렌더링 확인
- 로컬 모드 감지 확인

---

## Phase 3: API 키 관리 🎨⚙️

### 기존 API 설정 UI 활용

현재 `110_core_api_settings.js` ~ `115_core_api_settings_utils.js`에 이미 API 설정 모달이 존재한다.

### [MODIFY] `src/03_core/110_core_api_settings.js`

- 로컬 모드에서 API 키를 `localStorage`에 저장/불러오기
- Canvas 모드에서는 기존 Firestore 경로 유지
- 핵심: 이미 `localStorage.getItem('selectedAiModel')`을 사용하는 코드가 있으므로 API 키도 같은 패턴으로 저장

### [MODIFY] `src/04_features_chat/213_chat_api_service.js`

- 로컬 모드에서 API 키가 비어있으면 설정 모달을 안내하는 메시지 표시
- 키가 있으면 직접 Gemini/OpenAI API 호출 (CORS 허용 필요)

> [!IMPORTANT]
> 로컬 모드에서 `generativelanguage.googleapis.com` API는 직접 호출 가능 (API 키 인증, CORS 허용).
> OpenAI API도 직접 호출 가능.
> Canvas 모드의 프록시 경로와 로컬 직접 호출 경로를 분기.

### 검증
- API 키 입력 → localStorage 저장 확인
- 키 존재 시 채팅 요청 정상 동작
- 키 미입력 시 안내 메시지 표시

---

## Phase 4: 데이터 내보내기/가져오기 보완 ⚙️

### 기존 백업 시스템 활용

`331_notes_backup_exporter.js`, `332_notes_backup_importer.js`가 이미 JSON 기반 백업/복원 기능을 갖고 있다.

### [MODIFY] 보완 사항

- 로컬 모드에서 **자동 백업** 옵션 (30분마다 JSON 다운로드 또는 localStorage 미러)
- IndexedDB 데이터를 JSON으로 전체 내보내기
- Canvas ↔ 로컬 간 데이터 이동 지원 (같은 JSON 포맷)

### 검증
- 전체 데이터 내보내기 → JSON 파일 크기 확인
- JSON 가져오기 → 데이터 복원 확인

---

## Phase 5: 번들 빌드 + 배포 ⚙️

### 작업

1. `node bundler.js` → 새 `bundle/main.js`, `bundle/main.css` 생성
2. Git commit + push + PR 생성
3. **PR 머지까지 Codex가 수행**
4. Canvas 모드 기존 동작 영향 없음 확인

### 검증
- 번들 크기 비교 (shim 추가로 인한 증가량 확인)
- Canvas 모드에서 기존 기능 정상 동작 (회귀 없음)
- `index.html` 로컬 모드에서 전체 기능 동작

---

## Phase 6: 양쪽 모드 통합 테스트 🎨🎯

### Canvas 모드 회귀 테스트

| # | 시나리오 | 확인 |
|---|---|---|
| 6-1 | `.cc` 학습 캔버스 로드 | 기존과 동일 (검증완료) |
| 6-2 | 채팅 동작 | Firebase 경로 정상 (검증완료) |
| 6-3 | 노트 저장 | Firestore 저장 정상 (검증완료) |

### 로컬 모드 테스트

| # | 시나리오 | 확인 |
|---|---|---|
| 6-4 | `index.html` 열기 | 셸 렌더링 (검증완료) |
| 6-5 | 노트 작성 + 닫기 + 다시 열기 | IndexedDB 영속 확인 (검증완료) |
| 6-6 | API 키 입력 + 채팅 | 직접 API 호출 동작 (테스트 API키 등록 및 gemini 3.0 flash 모델로 채팅 응답 획득 성공) |
| 6-7 | 채팅 이력 닫기 후 복원 | 세션/메시지 영속 (새로고침 후 보존 성공) |
| 6-8 | 데이터 내보내기 | JSON 다운로드 (구현/동작 확인) |
| 6-9 | 데이터 가져오기 | 복원 후 UI 반영 (구현/동작 확인) |

---

## Phase 실행 순서

```mermaid
graph TD
    P0[Phase 0: LocalFirebaseShim 구현] --> P1[Phase 1: 환경 분기 수정]
    P1 --> P2[Phase 2: index.html 생성]
    P1 --> P3[Phase 3: API 키 관리]
    P2 --> P4[Phase 4: 백업 보완]
    P3 --> P4
    P4 --> P5[Phase 5: 번들 빌드 + Git 머지]
    P5 --> P6[Phase 6: 양쪽 모드 통합 테스트]
    P6 -->|Canvas 회귀| FIX[핫픽스]
    P6 -->|로컬 이슈| FIX
    FIX --> P5
```

**총 페이즈**: 7단계 (Phase 0~6)
**핵심 신규 파일**: 2개 (`002_local_firebase_shim.js`, `index.html`)
**핵심 수정 파일**: 3개 (`100_core_firebase.js`, `005_shell_part6_main_assembler.js`, `110_core_api_settings.js`)

---

## 작업 분배 요약

| Phase | 담당 | 핵심 |
|---|---|---|
| 0 | ⚙️ Codex | **LocalFirebaseShim** — 이 프로젝트의 핵심. IndexedDB + Firebase API 호환 레이어 |
| 1 | ⚙️ Codex | 환경 감지, Firebase init 분기, 호스트 잠금 해제 |
| 2 | 🎨 Gemini | index.html 생성, 로컬 모드 랜딩 페이지 |
| 3 | 🎨+⚙️ | API 키 UI (🎨), API 서비스 분기 (⚙️) |
| 4 | ⚙️ Codex | 백업/복원 보완 |
| 5 | ⚙️ Codex | 빌드, Git push, PR, **머지까지** |
| 6 | 🎨+🎯 | 양쪽 모드 통합 테스트 |

---

## Open Questions

> [!IMPORTANT]
> 1. **`file://` vs 로컬 서버**: `index.html`을 더블클릭으로 열 수 있어야 하나, 아니면 `npx serve`로 로컬 서버를 띄우는 것도 괜찮은가?
> 2. **Canvas↔로컬 데이터 동기화**: 양쪽 데이터를 JSON으로 수동 이동만 하면 되나, 아니면 자동 동기화가 필요한가?
> 3. **로컬 모드에서 이미지 생성**: Gemini API가 이미지 생성도 지원하므로 로컬에서도 가능하나, CORS 제한이 있을 수 있다. 이 기능이 중요한가?
