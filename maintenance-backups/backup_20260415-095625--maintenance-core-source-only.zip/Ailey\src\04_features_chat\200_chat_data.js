/* --- Ailey & Bailey Canvas --- */
// File: 200_chat_data.js
// Version: 4.0 (Clean Data Surface)
// Description: Handles prompt template and chat project/session data operations with clean Korean messages.

const MESSAGES_PER_PAGE = 25;

async function addPromptTemplate(templateData) {
    if (!promptTemplatesCollectionRef) return null;
    try {
        const docRef = await promptTemplatesCollectionRef.add({
            ...templateData,
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        return docRef.id;
    } catch (error) {
        console.error('Error adding prompt template:', error);
        showModal('프롬프트 템플릿을 추가하지 못했습니다.', () => {});
        return null;
    }
}

async function updatePromptTemplate(templateId, templateData) {
    if (!promptTemplatesCollectionRef || !templateId) return;
    try {
        await promptTemplatesCollectionRef.doc(templateId).update({
            ...templateData,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (error) {
        console.error('Error updating prompt template:', error);
        showModal('프롬프트 템플릿을 저장하지 못했습니다.', () => {});
    }
}

async function deletePromptTemplate(templateId) {
    if (!promptTemplatesCollectionRef || !templateId) return;
    try {
        await promptTemplatesCollectionRef.doc(templateId).delete();
    } catch (error) {
        console.error('Error deleting prompt template:', error);
        showModal('프롬프트 템플릿을 삭제하지 못했습니다.', () => {});
    }
}

async function fetchPastMessages(sessionId, beforeTimestamp, limit = MESSAGES_PER_PAGE) {
    if (!chatSessionsCollectionRef) return [];
    try {
        let query = chatSessionsCollectionRef.doc(sessionId).collection('messages')
            .orderBy('timestamp', 'desc')
            .limit(limit);

        if (beforeTimestamp) {
            query = query.startAfter(beforeTimestamp);
        }

        const snapshot = await query.get();
        return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
        console.error('Error fetching past messages:', error);
        return [];
    }
}

async function createNewProject() {
    const newName = getNewProjectDefaultName();
    try {
        const newProjectRef = await projectsCollectionRef.add({
            name: newName,
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        newlyCreatedProjectId = newProjectRef.id;
    } catch (error) {
        console.error('Error creating new project:', error);
        showModal('새 프로젝트를 만들지 못했습니다.', () => {});
    }
}

async function createProjectFromSessions(sessionIds) {
    if (!sessionIds || sessionIds.length < 2) return;
    const newName = getNewProjectDefaultName();
    try {
        const batch = db.batch();
        const newProjectRef = projectsCollectionRef.doc();
        batch.set(newProjectRef, {
            name: newName,
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        sessionIds.forEach(sessionId => {
            batch.update(chatSessionsCollectionRef.doc(sessionId), { projectId: newProjectRef.id });
        });
        await batch.commit();
        newlyCreatedProjectId = newProjectRef.id;
    } catch (error) {
        console.error('Error creating project from sessions:', error);
        showModal('선택한 대화들로 프로젝트를 만들지 못했습니다.', () => {});
    }
}

async function renameProject(projectId, newName) {
    if (!projectId || !newName || !newName.trim()) return;
    try {
        await projectsCollectionRef.doc(projectId).update({
            name: newName.trim(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (error) {
        console.error('Error renaming project:', error);
        showModal('프로젝트 이름을 바꾸지 못했습니다.', () => {});
    }
}

async function deleteProject(projectId) {
    const project = localProjectsCache.find(item => item.id === projectId);
    if (!project) return;

    showModal(`프로젝트 '${project.name}'를 삭제하시겠습니까?\n프로젝트 안의 대화는 일반 대화로 이동합니다.`, async () => {
        try {
            const batch = db.batch();
            localChatSessionsCache
                .filter(session => session.projectId === projectId)
                .forEach(session => batch.update(chatSessionsCollectionRef.doc(session.id), { projectId: null }));
            batch.delete(projectsCollectionRef.doc(projectId));
            await batch.commit();
        } catch (error) {
            console.error('Error deleting project:', error);
            showModal('프로젝트를 삭제하지 못했습니다.', () => {});
        }
    });
}

async function moveSessionToProject(sessionId, newProjectId) {
    const session = localChatSessionsCache.find(item => item.id === sessionId);
    if (!session || session.projectId === newProjectId) return;

    try {
        const batch = db.batch();
        batch.update(chatSessionsCollectionRef.doc(sessionId), {
            projectId: newProjectId,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });

        if (newProjectId) {
            batch.update(projectsCollectionRef.doc(newProjectId), {
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            });
        }

        await batch.commit();
    } catch (error) {
        console.error('Error moving session:', error);
        showModal('대화를 프로젝트로 옮기지 못했습니다.', () => {});
    }
}

async function toggleChatPin(sessionId) {
    if (!chatSessionsCollectionRef || !sessionId) return;
    const currentSession = localChatSessionsCache.find(session => session.id === sessionId);
    if (!currentSession) return;
    try {
        await chatSessionsCollectionRef.doc(sessionId).update({
            isPinned: !(currentSession.isPinned || false),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (error) {
        console.error('Error toggling pin status:', error);
    }
}

async function renameSession(sessionId, newTitle) {
    if (!sessionId || !newTitle) return;
    try {
        await chatSessionsCollectionRef.doc(sessionId).update({
            title: newTitle,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (error) {
        console.error('Error renaming session:', error);
        showModal('대화 이름을 바꾸지 못했습니다.', () => {});
    }
}

function handleDeleteSession(sessionId) {
    if (!sessionId) return;
    const sessionToDelete = localChatSessionsCache.find(session => session.id === sessionId);
    if (!sessionToDelete) return;

    showModal(`'${sessionToDelete.title || '새 대화'}'를 삭제하시겠습니까?`, () => {
        const messagesCollection = chatSessionsCollectionRef.doc(sessionId).collection('messages');
        messagesCollection.get()
            .then(snapshot => {
                const batch = db.batch();
                snapshot.docs.forEach(doc => batch.delete(doc.ref));
                return batch.commit().then(() => {
                    chatSessionsCollectionRef.doc(sessionId).delete();
                    if (currentSessionId === sessionId) {
                        handleNewChat();
                    }
                });
            })
            .catch(error => {
                console.error('Error deleting session:', error);
                showModal('대화를 삭제하지 못했습니다.', () => {});
            });
    });
}

async function findOrCreateSystemSession(sessionName) {
    if (!chatSessionsCollectionRef) return null;

    const cached = localChatSessionsCache.find(session => session.title === sessionName);
    if (cached) {
        trace('System', 'findOrCreateSystemSession.found', { sessionId: cached.id });
        return cached.id;
    }

    try {
        const querySnapshot = await chatSessionsCollectionRef.where('title', '==', sessionName).limit(1).get();
        if (!querySnapshot.empty) {
            const doc = querySnapshot.docs[0];
            trace('System', 'findOrCreateSystemSession.foundInDB', { sessionId: doc.id });
            return doc.id;
        }

        const newSessionRef = await chatSessionsCollectionRef.add({
            title: sessionName,
            isSystemSession: true,
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        return newSessionRef.id;
    } catch (error) {
        console.error('Error finding or creating system session:', error);
        trace('System', 'findOrCreateSystemSession.error', { error: error.message }, {}, 'ERROR');
        return null;
    }
}

async function clearSessionMessages(sessionId) {
    if (!chatSessionsCollectionRef || !sessionId) {
        trace('Chat.Data', 'clearSession.skip', { reason: 'No session collection or ID' });
        return;
    }

    try {
        const messagesCollection = chatSessionsCollectionRef.doc(sessionId).collection('messages');
        const snapshot = await messagesCollection.get();
        if (snapshot.empty) {
            trace('Chat.Data', 'clearSession.noop', { reason: 'No messages to delete' });
            return;
        }

        const batch = db.batch();
        snapshot.docs.forEach(doc => batch.delete(doc.ref));
        await batch.commit();

        await chatSessionsCollectionRef.doc(sessionId).update({
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });

        const sessionInCache = localChatSessionsCache.find(session => session.id === sessionId);
        if (sessionInCache) {
            sessionInCache.messages = [];
        }

        if (currentSessionId === sessionId) {
            if (chatMessages) chatMessages.innerHTML = '';
            const activeSession = localChatSessionsCache.find(session => session.id === sessionId);
            if (chatWelcomeMessage && !activeSession?.isSystemSession) {
                chatWelcomeMessage.style.display = 'flex';
            }
        }
    } catch (error) {
        console.error(`Failed to clear messages for session ${sessionId}:`, error);
        trace('Chat.Data', 'clearSession.error', { error: error.message }, {}, 'ERROR');
    }
}
