## Summary

초기 로드 시 저장된 패널 좌표를 현재 viewport 기준으로 다시 clamp하도록 고쳤고, 상단 export는 드롭다운 없이 즉시 `라이브 HTML 내보내기`를 실행하도록 단순화했다.

## What changed

- `Ailey/src/02_utils/013_utils_panel_manager.js`
  - viewport-safe clamp helper 추가
  - `applyPanelStates()`에서 width/height/position 복원 후 즉시 clamp
  - 첫 mount 직후 이중 `requestAnimationFrame` safety pass 추가
  - desktop resize / visualViewport resize 시 visible panel 재-clamp
  - panel reopen 시 desktop 환경에서 즉시 clamp

- `Ailey/src/00_shell/000_shell_template.js`
  - export dropdown 제거
  - `#export-main-content-btn`를 단일 live export button으로 단순화

- `Ailey/src/03_core/120_core_main_initializer.js`
  - export dropdown close logic 제거
  - `정적 HTML` / `라이브 HTML` 개별 버튼 핸들러 제거
  - export main button 클릭 시 즉시 `window.exportAsLiveHtml({ title })` 호출

- `Ailey/src_css/010_widget_header_addons.css`
  - export wrapper 스타일 제거
  - `button.tool-button` 기본 버튼 appearance reset 추가

## Validation

- validation script:
  - `visual-tests/validate_panel_clamp_and_live_export.mjs`
- output:
  - `visual-tests/panel-clamp-live-export-2026-04-14T10-14-27-400Z/validation.json`
  - `visual-tests/panel-clamp-live-export-2026-04-14T10-14-27-400Z/validation-summary.txt`
  - `visual-tests/panel-clamp-live-export-2026-04-14T10-14-27-400Z/01-panel-clamp.png`

## Validation highlights

- `exportDropdownPresentInTemplate=false`
- `exportStaticPresentInTemplate=false`
- `exportLivePresentInTemplate=false`
- `initializerUsesLiveExport=true`
- `initializerMentionsStaticExport=false`
- `initializerMentionsExportDropdown=false`
- `chatInsideViewport=true`
- `notesInsideViewport=true`
- `chatTopKeepsHeaderPeek=true`
- `pageErrorCount=0`
- `consoleErrorCount=0`

## Publish

- bundle synced to `Singulari-Tea-Codex-Canvas-pr/bundle`
- ready for Git commit / push
