Plan Type: Work Plan
Workstream: Mobile UI Refinement and Scroll Reliability
Version: v01
Status: Superseded
Created: 2026-04-14 10:05:00 +09:00
Last Updated: 2026-04-14 17:09:35 +09:00
Supersedes or Related Plan: Follow-up to `plan/20260414-090500--work-plan--mobile-shell-and-loading-label-cleanup--v01.md`
Current Completion State: Implemented, validated, documented, and published; superseded as the active mobile plan by a narrower follow-up
Completed So Far: Reproduced the mobile drawer overlap and scroll-lock conditions, split immediate auto-follow state from debounced history loading, restored a true scroll owner inside the mobile chat panel, widened the mobile session drawer so it behaves like a real sheet, slimmed chat and notes headers plus the notes archive action bar, compressed visualization/image/API/prompt mobile headers and helper copy, rebuilt the bundle, validated on mobile and desktop, synced the publish repo, and pushed GitHub commit `21591fc`.
Remaining Work: None inside the original approved scope; subsequent mobile discoverability follow-up now tracked in `plan/20260414-170935--work-plan--mobile-chat-session-return-affordance--v01.md`
Current Blockers: None
Next Step: Refer to `plan/20260414-170935--work-plan--mobile-chat-session-return-affordance--v01.md` for the active follow-up that adds an explicit return affordance inside the mobile chat session list

# Scoreboard

Current Score: 90
Score Source: user
Last Updated: 2026-04-14 10:48:00 +09:00
Score Rationale: The authoritative user score of 90 still stands and the follow-up pass delivered the specific mobile fixes the user asked for without reopening architecture or harming desktop behavior.
What Improved: Mobile chat drawer layering is now clean, mobile upward reading survives incoming AI output, notes and studio headers are materially thinner, and adjacent internal modals were compressed for phone-sized use.
What Remains Unsatisfactory: The shell is now reliable on mobile, but it is still a compressed desktop shell rather than a fully separate mobile navigation system.
What Should Happen Next To Raise Or Maintain The Score: Gather the user’s reaction to this second pass. If the user wants a higher-end mobile experience, the next step should be a dedicated mobile navigation model instead of more density tweaks.

## Score History

- 2026-04-14 10:05:00 +09:00 | score=90 | source=user | User explicitly rated the previous mobile foundation pass at 90 and approved the deeper mobile refinement follow-up.
- 2026-04-14 10:48:00 +09:00 | score=90 | source=user | No new explicit score was given after the refinement pass. The authoritative user score remains 90 while the approved mobile follow-up was completed and published.

# Objective

Turn the current mobile shell foundation into a dependable everyday mobile UI by fixing interactive flaws that still block comfortable use: overlapping chat list behavior, broken upward scrolling after auto-following AI responses, oversized top headers in notes, chat, and visualization studio, and any nearby mobile regressions uncovered during the audit.

# Why This Work Exists

The previous mobile pass established the basic shell mode, but the user is still feeling friction inside real use flows. A mobile UI can be technically responsive and still feel unusable if list drawers overlap content, auto-scroll traps the reading position, headers consume too much vertical space, or helper text crowds the viewport. This work exists to remove those remaining high-friction mobile behaviors so the shell feels intentional instead of merely compressed from desktop.

# Scope

In scope:

- Mobile chat session-list open and close behavior, including overlap and z-layer issues
- Mobile chat scroll behavior after new AI responses, including restoring normal upward scrolling
- Mobile header-height reduction for chat and Ailey Note surfaces
- Mobile header-height reduction and helper-copy compression for visualization options studio
- Compression or removal of verbose helper text that consumes too much above-the-fold space on mobile
- A focused audit of adjacent mobile regressions discovered while reproducing the reported issues
- Browser validation on mobile and desktop
- Bundle rebuild, publish sync, and release report

Out of scope unless verification shows a hard dependency:

- A full bottom-tab mobile app redesign
- Replacing the chat or notes data model
- Large desktop UI redesigns that are not necessary for safe mobile behavior

# Confirmed Facts

- The user approved this follow-up pass.
- The user explicitly gave the prior mobile foundation pass a score of 90.
- The user reports that opening or closing the chat session list can create overlapping UI on mobile.
- The user reports that once new chat content auto-scrolls to the bottom, the view can become stuck and cannot scroll back upward.
- The user reports that mobile headers in chat, Ailey Note, and visualization option surfaces are too thick and consume too much of the screen.
- The user wants additional unmentioned mobile issues to be improved during the same pass when they are obvious and nearby.

# Safe Assumptions

- The smallest safe fix for the scroll issue is to adjust the scroll container ownership and auto-follow logic instead of removing auto-scroll entirely.
- The smallest safe fix for bulky headers is to compress spacing, typography, and helper copy only on mobile breakpoints while leaving desktop layout intact.
- Nearby mobile issues should be fixed only when they are clearly part of the same interaction surface and do not require reopening the product architecture.

# Technical Approach

Use a reproduce-first refinement pass:

1. reproduce the reported mobile interaction bugs on the current local bundle
2. identify the true scroll owner for chat content and remove any CSS or JS conditions that trap upward scroll
3. make session-list expansion a clean overlay or drawer transition that does not visually collide with the active content surface
4. introduce thinner mobile header variants for chat, notes, and visualization studio
5. compress or hide verbose helper copy on mobile while preserving important guidance
6. sweep nearby high-signal mobile issues in the same components before validating

# Phased Work Sequence

## Phase 1: Reproduce

Open a phone-sized viewport and deliberately trigger the reported chat list, scroll, and header-height issues. Record which DOM elements own the visible scroll and which layers overlap.

## Phase 2: Repair Chat Interaction Surfaces

Fix the chat list toggle overlap and restore reliable upward scrolling after response auto-follow. Keep desktop behavior intact.

## Phase 3: Slim Mobile Headers and Helper Copy

Reduce vertical cost in chat, notes, and visualization options studio by compressing header rows, control spacing, and helper descriptions. Remove or shorten obviously excessive explanatory copy on mobile.

## Phase 4: Sweep Adjacent Mobile Issues

Address nearby mobile regressions uncovered during the audit when they share the same UI surface and can be fixed safely in the same bounded pass.

## Phase 5: Verify and Publish

Rebuild the bundle, validate on mobile and desktop, sync the publish repo, push GitHub changes, and record a short maintenance report with the observed behavior.

# Hidden Rules And Consistency Requirements

- Upward scroll must remain possible after auto-following new chat output; the fix must not simply disable all auto-follow behavior.
- Mobile list or drawer transitions must not leave invisible overlays intercepting taps or scroll.
- Mobile header slimming must preserve recognizability and access to core controls.
- Explanatory copy may be compressed, collapsed, or removed on mobile, but actionable controls and explicit error messages must remain clear.
- Desktop layouts must continue to behave normally after mobile-specific adjustments.

# Risks

## Risk: Fixing chat scroll on mobile regresses desktop message autoscroll

Mitigation: Validate both desktop and mobile reading flows after the change, especially long responses and repeated replies.

## Risk: Reducing header density hides important controls

Mitigation: Slim spacing and copy first, and only collapse secondary text that does not affect task completion.

## Risk: Overlay fixes leave hidden backdrops or pointer interception bugs

Mitigation: Explicitly test open-close-open cycles on the chat session list and other drawers while capturing screenshots.

# Validation Strategy

Validation should cover:

- mobile chat session-list toggle without overlap or stale overlay interception
- mobile chat can scroll upward after one or more AI responses auto-follow to the bottom
- chat, notes, and visualization studio headers consume meaningfully less vertical space on mobile
- helper copy in visualization options studio is compressed or removed on mobile where appropriate
- desktop chat list and message scrolling remain intact
- zero page errors on the validation flow

# Definition Of Done

The work is done when:

- mobile chat list toggling no longer produces overlapping or stuck UI
- mobile chat scrolling can move upward after responses arrive
- mobile headers in chat, notes, and visualization options studio are visibly slimmer
- overly verbose helper copy is compressed for mobile
- adjacent obvious mobile regressions in the touched surfaces are cleaned up
- desktop behavior still works
- bundle rebuild succeeds
- validations pass with saved evidence
- the publish repo is updated and pushed
- the plan and final report reflect the finished behavior

# Progress Log

- 2026-04-14 10:05:00 +09:00 | Follow-up mobile refinement plan created after user approval. Prior pass user score of 90 recorded as authoritative. Reproduction of overlap, scroll, and oversized-header issues is next.
- 2026-04-14 10:18:00 +09:00 | Reproduced the remaining mobile issues and identified two core causes: the chat drawer still behaved like a translucent desktop overlay, and mobile chat scroll ownership was broken by delayed auto-follow state updates plus an unconstrained `#chat-main-view`.
- 2026-04-14 10:31:00 +09:00 | Implemented the second-pass fixes across chat, notes, visualization studio, image studio, API preset UI, and prompt manager mobile surfaces. The drawer now covers the panel cleanly, chat auto-follow yields immediately to manual upward reading, and heavy header/helper copy was compressed for mobile.
- 2026-04-14 10:42:57 +09:00 | Validation passed using `visual-tests/mobile-ui-refinement-2026-04-14T07-42-57-486Z/`. Mobile sidebar coverage, upward-scroll preservation, thin notes/studio headers, and desktop non-regression all passed with `pageErrorCount=0` and `traceErrorCount=0`.
- 2026-04-14 10:48:00 +09:00 | Synced `Ailey/bundle/main.js` and `Ailey/bundle/main.css` to the publish repo, pushed GitHub commit `21591fc` on `lemos999/Singulari-Tea-Codex-Canvas`, and wrote `plan/20260414-104500--mobile-ui-refinement-and-scroll-reliability-report--v01.md`.
